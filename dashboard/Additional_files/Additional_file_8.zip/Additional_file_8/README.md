# Additional file 8. Analysis code, reproduction and verification

Supplement to: Perioperative transcutaneous electrical acupoint stimulation and electroacupuncture for postoperative opioid consumption: a systematic review and meta-analysis of randomised trials. PROSPERO CRD420261452908.

Scripts that produced the analyses, figures, tables and additional files, with the model inputs and outputs and the record of independent numerical verification.

## Software

- Python 3.12 (standard library, numpy, scipy and pandas for analysis; reportlab, matplotlib and pypdf for figures; python-docx and openpyxl for the additional files)
- Stata 19.5 (StataNow/SE; `meta` suite: REML with truncated Hartung–Knapp standard errors)
- R 4.5.2 (base R only)
- Node.js with docx 9.x (manuscript file)

## Verification

- `verification/numerical_verification.csv`: every estimate and empty analysis of the registered-outcome completion compared between Python, Stata and R, field by field (1446 of 1446 comparisons within tolerance; maximum difference in effects or confidence limits 1.4 × 10⁻⁶).
- `verification/*_R_verification.csv`, `independent_R_results.csv`: independent base-R recomputation from arm-level data.
- Later refits (the risk-of-bias restriction update and the Lee 2011 hold, 23 October 2026) were run in base R after first reproducing the existing estimates (maximum differences 6.8 × 10⁻⁸ and 9.5 × 10⁻⁸): `forty_report_analysis/reviewer_rerun/dose_restriction_rerun_2026_10_23.R` and `lee_hold_rerun_2026_10_23.R`.
- `reaudit_d3/astra_recompute_2026-11-03.csv`: an independent AI re-check (3 Nov 2026) recomputed every refit affected by decision D3 (35 rows) with its own code: effects and confidence limits within 4.8 × 10⁻⁷, τ² and I² within 1.5 × 10⁻⁶ (the largest, τ² for QoR15_SHAM_24H_LOO_Zhou_2025, reflects optimiser precision).
- `skp_d3_review/`: records the second review by SKP (reported 3 Nov 2026) of the decision-D3 extraction and assessments, of Wang 1997's 48-hour pain assessments and of the 2 November corrections, triage and English-abstract check. All were confirmed as made or drafted, so no judgement, value or estimate changed.
- `d4/`: decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected reason (`d4_decisions.csv`), with the Fig. 1 counts, text and builder edits that follow; no estimate changed.
- `d5/`: decision D5 (JRNM and SKP, 3 Nov 2026): the 53 outcome exclusions the triage could not assess, sought and read with AI assistance (`d5_retrieval_log.csv`); nine counted under a corrected reason (`d5_decisions.csv`), six not retrieved; no estimate changed.
- `d9/`: Additional file 5, sheet "Analysis inputs", now lists all seven rescue trials (3 Nov 2026); no value changed.
- `d6/`: decision D6 (JRNM and SKP, all authors agreeing, 3 Nov 2026): rest-pain certainty lowered to low; `d6_scenarios.R` refits rest pain and PONV with the trials the opioid-result requirement removed (post-hoc what-ifs, not results; reads the review's inputs and the 70-report extraction).
- `d7/`: decision D7 (JRNM, 3 Nov 2026; checked by SKP): when the routine non-opioid was given in the 14 multimodal reports (`d7_mma_timing.csv`); the definition and counts are unchanged.
- `d10/`: decision D10 (JRNM, 3 Nov 2026): registration history stated in the Methods.
- `confirm/`: the author confirmations of 3 Nov 2026 (title page, Declarations, the 508 automated exclusions, AI tools, the search questions); no estimate changed.
- `astra_2026-11-04/`: repairs after an independent AI check (4 Nov 2026). `reproduce_final.R` also reruns the four D6 what-ifs from `d6/d6_inputs.csv` and compares them with `d6/d6_scenarios.csv`.

## Reproducing the final estimates

From this folder, with R installed: `Rscript reproduce_final.R`. Base R only; it reads `data/inputs` and `data/results`, refits every final model (239: registered outcome, rescue receipt and other opioid models; the broader first-day models without Lee 2011; all other outcomes), writes `reproduced_final_estimates.csv`, and stops with an error if any effect or confidence limit differs from the archived result by more than 2 × 10⁻⁶. It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026), and Colak 2010 and Fu 2024 (decision D3, same date), to every analysis they enter (including the legacy expanded-dose sensitivity models, the nausea and vomiting diagnostics and Wang's single-trial results), and compares the result with `data/results/models_with_wang.csv`. A passing run shows that the distributed models reproduce; it does not show that every eligible analysis or result is included. Expected output ends: "Reproduction passed." A passing run shows that the estimates follow from these inputs; it does not show that the inputs were extracted correctly or that the set of included trials is complete.

Units: in `data/inputs/reviewer_rerun_model_inputs.csv` and `e2_model_inputs.csv` the arm means and SDs are already converted to mg IV morphine (`factor` gives the factor applied); the `unit` column gives the source unit. For example, Chen 1998 is stored as 32.5 and 53.5 (hydromorphone 6.5 and 10.7 mg × 5). Do not convert these values again. Values as reported are in Additional file 5, sheet Analysis inputs.

## Running the build scripts

The scripts expect the project folder layout and the source PDFs, which are pinned by SHA-256 hash but are not distributed here because they are copyrighted. The model inputs in `data/inputs` carry every arm-level value with its source location and quotation, so each estimate can be recomputed from them without the PDFs.

A passing reproduction shows that the estimates follow from the extracted data by the stated methods. It does not show that the extraction is free of error or that the evidence base is complete.

## Contents

- `prisma/build_prisma.py`
- `prisma/build_prisma_manuscript.py`
- `prisma/prisma_counts.json`
- `forty_report_analysis/build_analysis.py`
- `forty_report_analysis/build_contribution_map_2026_10_23.py`
- `forty_report_analysis/build_rob_figure_2026_10_23.py`
- `forty_report_analysis/build_table1_2026_10_23.py`
- `forty_report_analysis/extract_setting_mma_2026_10_24.py`
- `forty_report_analysis/render_contribution_map_2026_10_23.py`
- `forty_report_analysis/verify_models.R`
- `forty_report_analysis/registered_completion/build_completion.py`
- `forty_report_analysis/registered_completion/complete_certainty.py`
- `forty_report_analysis/registered_completion/finalize_completion.py`
- `forty_report_analysis/registered_completion/new_source_data.py`
- `forty_report_analysis/registered_completion/package_figures.py`
- `forty_report_analysis/registered_completion/prepare_figures.py`
- `forty_report_analysis/registered_completion/supplement_rob2_2026_10_23.py`
- `forty_report_analysis/registered_completion/verify_completion.R`
- `forty_report_analysis/registered_completion/forest_calls.do`
- `forty_report_analysis/registered_completion/forest_program.do`
- `forty_report_analysis/registered_completion/refresh_figures.do`
- `forty_report_analysis/registered_completion/refresh_labels.do`
- `forty_report_analysis/registered_completion/run_stata.do`
- `forty_report_analysis/reviewer_rerun/dose_rob2_supplement_2026_10_23.py`
- `forty_report_analysis/reviewer_rerun/package_stata.py`
- `forty_report_analysis/reviewer_rerun/prepare_stata.py`
- `forty_report_analysis/reviewer_rerun/rerun.py`
- `forty_report_analysis/reviewer_rerun/write_report.py`
- `forty_report_analysis/reviewer_rerun/dose_restriction_rerun_2026_10_23.R`
- `forty_report_analysis/reviewer_rerun/lee_hold_rerun_2026_10_23.R`
- `forty_report_analysis/reviewer_rerun/verify_rerun.R`
- `forty_report_analysis/reviewer_rerun/manuscript_figures_2026_10_24.do`
- `forty_report_analysis/reviewer_rerun/stata_additional_forests.do`
- `forty_report_analysis/reviewer_rerun/stata_figures.do`
- `forty_report_analysis/reviewer_rerun/stata_plot_only.do`
- `forty_report_analysis/certainty_and_manuscript/assess_certainty.py`
- `forty_report_analysis/reviewer_sheet_check/chen2020_d3_scenario.R`
- `manuscript/make_sources.py`
- `manuscript/assemble_revision.py`
- `manuscript/build_docx.js`
- `manuscript/build_additional_files.py`
- `manuscript/patch_additional_files.py`
- `manuscript/build_references.py`
- `manuscript/references_revision.csv`
- `manuscript/sources/abstract_REVISED.md`
- `manuscript/sources/additional_files_REVISED.csv`
- `manuscript/sources/background_REVISED.md`
- `manuscript/sources/conclusions_REVISED.md`
- `manuscript/sources/discussion_REVISED.md`
- `manuscript/sources/figures_REVISED.md`
- `manuscript/sources/methods_REVISED.md`
- `manuscript/sources/results_REVISED.md`
- `manuscript/sources/table1_REVISED.csv`
- `manuscript/sources/table1_legend_REVISED.md`
- `manuscript/sources/table2_REVISED.md`
- `manuscript/sources/make_table1_revised.py`
- `manuscript/sources/table1_REVISED_edits.csv`
- `selection_check/build_c01_triage.py`
- `selection_check/C01_historical_outcome_exclusions_triage.csv`
- `selection_check/c01_scenarios.R`
- `selection_check/C01_scenarios.csv`
- `selection_check/C01_FOUR_REPORTS.md`
- `figures/manuscript_figures_REVISED_2026-11-02.do`
- `figures/Fig2_source_contribution_map.csv`
- `wang1997/wang1997_results.csv`
- `wang1997/wang1997_characteristics.csv`
- `wang1997/wang1997_analysis_inputs.csv`
- `wang1997/wang1997_rob2_DRAFT.csv`
- `wang1997/wang1997_grade_DRAFT.csv`
- `wang1997/rob_domain_summary_2026-10-23.csv`
- `wang1997/rob_key_analyses_2026-10-23.csv`
- `wang1997/prisma_counts_with_wang1997.json`
- `wang1997/stata_figures_with_wang1997.log`
- `wang1997/apply_wang_text.py`
- `wang1997/patch_af_wang.py`
- `wang1997/wang1997_outcome_inventory.csv`
- `recheck/update_wang_records.py`
- `recheck/apply_recheck_text.py`
- `recheck/patch_af_recheck.py`
- `d3/build_d3_records.py`
- `d3/apply_d3_text.py`
- `d3/patch_af_d3.py`
- `d3/d3_decisions.csv`
- `d3/d3_results.csv`
- `d3/d3_characteristics.csv`
- `d3/d3_rob2_DRAFT.csv`
- `d3/d3_grade_DRAFT.csv`
- `d3/prisma_counts_current.json`
- `d3/rob_domain_summary_d3.csv`
- `d3/rob_key_analyses_d3.csv`
- `d3/stata_figures_d3.log`
- `d3/d3_outcome_inventory.csv`
- `d3/D3_membership_dossier.md`
- `audit_d3/apply_audit_text.py`
- `audit_d3/patch_af_audit.py`
- `audit_d3/update_verify_audit.py`
- `reaudit_d3/build_wang48_rob2.py`
- `reaudit_d3/wang48_rob2_DRAFT.csv`
- `reaudit_d3/apply_reaudit_text.py`
- `reaudit_d3/patch_af_reaudit.py`
- `reaudit_d3/update_verify_reaudit.py`
- `reaudit_d3/astra_recompute_2026-11-03.csv`
- `reaudit_d3/build_rob_figure_reaudit.py`
- `skp_d3_review/record_skp_review.py`
- `skp_d3_review/apply_skp_text.py`
- `skp_d3_review/patch_af_skp.py`
- `skp_d3_review/update_verify_skp.py`
- `skp_d3_review/build_rob_figure_skp.py`
- `d4/record_d4.py`
- `d4/d4_decisions.csv`
- `d4/apply_d4_text.py`
- `d4/patch_af_d4.py`
- `d4/update_verify_d4.py`
- `d4/build_prisma_manuscript_d4.py`
- `d5/build_d5_log.py`
- `d5/d5_retrieval_log.csv`
- `d5/record_d5.py`
- `d5/d5_decisions.csv`
- `d5/apply_d5_text.py`
- `d5/patch_af_d5.py`
- `d5/update_verify_d5.py`
- `d5/build_prisma_manuscript_d5.py`
- `d9/patch_af_d9.py`
- `d9/update_verify_d9.py`
- `d7/d7_mma_timing.csv`
- `d7/apply_d7_text.py`
- `d7/patch_af_d7.py`
- `d7/update_verify_d7.py`
- `d10/apply_d10_text.py`
- `d10/patch_af_d10.py`
- `d10/update_verify_d10.py`
- `confirm/apply_confirm_static.py`
- `confirm/apply_confirm_text.py`
- `confirm/patch_af_confirm.py`
- `confirm/update_verify_confirm.py`
- `astra_2026-11-04/ASTRA_FINDINGS_2026-11-04.md`
- `astra_2026-11-04/apply_astra_text.py`
- `astra_2026-11-04/patch_af_astra.py`
- `astra_2026-11-04/update_verify_astra.py`
- `d6/d6_decision.csv`
- `d6/build_d6_inputs.py`
- `d6/d6_inputs.csv`
- `d6/d6_scenarios.R`
- `d6/d6_scenarios.csv`
- `d6/apply_d6_text.py`
- `d6/patch_af_d6.py`
- `d6/update_verify_d6.py`
- `data/inputs/reviewer_rerun_model_inputs.csv`
- `data/inputs/e2_model_inputs.csv`
- `data/inputs/registered_completion_model_inputs.csv`
- `data/inputs/model_specs.csv`
- `data/inputs/rescue_model_inputs.csv`
- `data/inputs/missing_outcome_assumptions.csv`
- `data/inputs/dose_bias_linkage.csv`
- `data/results/model_results.csv`
- `data/results/lee_hold_rerun_2026-10-23.csv`
- `data/results/dose_restriction_rerun_2026-10-23.csv`
- `data/results/reproduced_final_estimates.csv`
- `data/results/models_with_wang.csv`
- `data/results/model_results_python.csv`
- `data/results/rescue_model_results.csv`
- `data/results/individual_estimates.csv`
- `verification/numerical_verification.csv`
- `verification/independent_R_results.csv`
- `verification/forty_report_independent_R_verification.csv`
- `verification/reviewer_rerun_independent_R_verification.csv`
- `verification/individual_R_verification.csv`
- `verification/stata_verification.csv`
- `verification/baseline_reproduction.csv`
- `verification/run_manifest.json`
- `verification/manifest.json`
