# Astra's check of the D4–D10 and author-confirmation build (4 Nov 2026)

Pasted by the review owner on 4 Nov 2026 (Astra created or changed no project files). Summary of the six findings and
their disposition; Astra's text is abridged.

| # | Finding (Astra) | Checked | Repair |
|---|---|---|---|
| 1 | D6 is not reproducible from AF9: `d6/d6_scenarios.R` reads files outside the archive, and `reproduce_final.R` never runs it | Confirmed (line 22 reads `opioid_only_review/...` and `10_FINAL_ADJUDICATION/...`) | `d6/build_d6_inputs.py` writes `d6/d6_inputs.csv` (14 rows); the script reads only that file; AF9 ships it and `reproduce_final.R` reruns the four what-ifs and compares them with `d6/d6_scenarios.csv` |
| 2 | The four trials added by D6 (Liu 2021, Xing 2022, Zheng 2025, Lu 2021) are missing from the D9 checklist and AF10 | Confirmed; each D6 input has a v38 RoB 2 assessment (second review SP, 2026-09-28, confirmed) | D9 checklist gains the five D6 inputs; AF10 gains a sheet linking the five earlier assessments; Methods and the AF10 README state that they were not re-assessed |
| 3 | AF2 deviations row still claims an external check of three trials | Confirmed (builder line 645) | Claim removed |
| 4 | Discussion still says 12 language exclusions (ledger 19); its 8/2/2 breakdown covers only the original 12 | Confirmed | Discussion gives 19 and qualifies the breakdown |
| 5 | Methods say all three D8 leads were screened at full text; Li 2026 was excluded from its retraction notice | Confirmed | Methods, AF2 §13, the decision log and the Fig. 1 legend say so |
| 6 | AF4 "Total excluded" (173) omits the three discovery-audit exclusions (176 in Reports) | Confirmed | Labelled as the database-route total; the all-routes total (176) added |

Astra's technical checks (reported, not re-run here): verifier 145/145; 83 refits unchanged; AF9 clean run passes; the four
D6 scenarios reproduce from arm-level inputs; abstract 345 words; RoB 180 results (2/126/52); 304 AF12 Method labels correct.
