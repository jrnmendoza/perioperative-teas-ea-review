"""Manuscript text after Astra's check of 4 Nov 2026 (findings 2, 4 and 5; ASTRA_FINDINGS_2026-11-04.md).

2. The four trials added only in the D6 post-hoc refits were not re-assessed; their earlier assessments are in AF10 (Methods).
4. Language exclusions: 19, not 12; the 8/2/2 breakdown describes the original 12 (Discussion).
5. D8: Li 2026 was excluded from its retraction notice, not screened at full text (Methods; Fig. 1 legend).
Runs after confirm/apply_confirm_text.py; edits sources/*_REVISED.md in place, each passage asserted once."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'methods': [
  ('Results held from synthesis or reported only descriptively were not assessed (Additional files 10 and 11).',
   'Results held from synthesis or reported only descriptively were not assessed (Additional files 10 and 11). The four trials '
   'added only in the post-hoc refits of rest pain and nausea and vomiting were not re-assessed; their assessments from before '
   'the opioid-result requirement (second review on 28 September 2026) are listed in Additional file 10.'),
  ('were screened at full text on 3 November 2026 by JRNM and SKP, with trial results known, and all were excluded (Fig. 1); its '
   'two registry entries had no results (Additional file 2).',
   'were screened on 3 November 2026 by JRNM and SKP, with trial results known: two at full text and one (Li 2026) from its '
   'retraction notice. All were excluded (Fig. 1); its two registry entries had no results (Additional file 2).'),
 ],
 'discussion': [
  ('Twelve reports published in Chinese were excluded for language. Their English abstracts showed no postoperative opioid '
   'outcome in eight, rescue analgesia or pump presses without a named opioid in two, and a postoperative opioid quantity in two; '
   'we could not determine the effect of these exclusions.',
   'Nineteen reports published in Chinese were excluded for language: 12 at screening, whose English abstracts showed no '
   'postoperative opioid outcome in eight, rescue analgesia or pump presses without a named opioid in two and a postoperative '
   'opioid quantity in two, and seven reclassified on re-checking, whose abstracts reported pain at about 24 hours or an opioid '
   'result. We could not determine the effect of these exclusions.'),
 ],
 'figures': [
  ('its three reports, published after the search, were screened on 3 November 2026 (Additional file 2).',
   'its three reports, published after the search, were screened on 3 November 2026, Li 2026 from its retraction notice '
   'without reading the full text (Additional file 2).'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after Astra\'s check of 4 Nov 2026')
