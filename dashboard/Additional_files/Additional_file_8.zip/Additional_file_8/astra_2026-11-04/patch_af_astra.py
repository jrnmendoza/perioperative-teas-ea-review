"""Additional-files and reproduction edits after Astra's check of 4 Nov 2026 (ASTRA_FINDINGS_2026-11-04.md).

1. AF9 ships d6/d6_inputs.csv and d6/build_d6_inputs.py, and reproduce_final.R reruns the four D6 what-ifs from them and
   compares them with the archived d6/d6_scenarios.csv.
2. AF10: a "D6 what-if trials" sheet links the earlier assessments (v38, second review SP, 2026-09-28) of the five results
   that the D6 refits added; the README says they were not re-assessed.
3. AF2 deviations: the external-check claim is removed.
5. AF2 section 13 and decision log: Li 2026 was excluded from its retraction notice, not screened at full text.
6. AF4 "Fig. 1 counts": 173 is labelled the database-route total and the all-routes total (176) is added.
Run after confirm/patch_af_confirm.py; edits build_additional_files.py and reproduce/reproduce_final.R in place, each
replacement asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# 3. AF2 deviations: external-check claim
rep("'Errors in arm-level outcome data would not be caught by a second extractor. An external check of all outcome values for three trials on 24 October 2026 found none.'",
    "'Errors in arm-level outcome data would not be caught by a second extractor.'")
# 5. AF2 section 13 and decision log: Li 2026
rep("The three reports were screened at full '\n            'text and are counted in Fig. 1 under other methods; all were excluded (Additional file 4).",
    "Shi 2026 and Xu 2026 were screened at full '\n            'text and Li 2026 from its retraction notice, without reading its full text; all three are counted in Fig. 1 under '\n            'other methods and were excluded (Additional file 4).")
rep("'screened at full text (section 13). Shi 2026 and Xu 2026 excluded",
    "'screened (section 13): Shi 2026 and Xu 2026 at full text, Li 2026 from its retraction notice. Shi 2026 and Xu 2026 excluded")
# 6. AF4 totals
rep("dict(reason='Total excluded', n=sum(cnt.values()))", "dict(reason='Total excluded, database route', n=sum(cnt.values()))")
rep("    summ += [dict(reason='Other methods: reports assessed', n=pc['citation_assessed'] + pc['audit_assessed'])]\n",
    "    summ += [dict(reason='Other methods: reports assessed', n=pc['citation_assessed'] + pc['audit_assessed'])]\n"
    "    summ += [dict(reason='Total excluded, all routes', n=sum(cnt.values()) + sum(acnt.values()))]   # Astra, 4 Nov 2026\n")
# 2. AF10: earlier assessments of the D6 what-if trials
rep("'3 Nov 2026).'],\n                 [('Judgements'",
    "'3 Nov 2026). The four trials added only in the post-hoc D6 refits (Liu 2021, Xing 2022, Zheng 2025, Lu 2021) were not '\n"
    "                     're-assessed: their assessments from the 70-report review (second review SP, 28 Sep 2026) are in sheet '\n"
    "                     '\"D6 what-if trials\" and are not among the 180.'],\n                 [('Judgements'")
rep("                  ('Not assessed', 'Results held from synthesis or reported only descriptively, which were not assessed')],",
    "                  ('Not assessed', 'Results held from synthesis or reported only descriptively, which were not assessed'),\n"
    "                  ('D6 what-if trials', 'Earlier assessments (70-report review, second review SP 28 Sep 2026) of the five results that the post-hoc D6 refits added')],")
rep("    sheet(wb, 'Not assessed', held, [('model', 'Analysis', 30), ('result', 'Result ID', 24), ('study', 'Report', 18), ('reason', 'Reason', 80)])\n",
    "    sheet(wb, 'Not assessed', held, [('model', 'Analysis', 30), ('result', 'Result ID', 24), ('study', 'Report', 18), ('reason', 'Reason', 80)])\n"
    "    v38 = {r['result_id']: r for r in recs(ROOT / '10_FINAL_ADJUDICATION/02_DECISIONS/v38/rob2_assessments.csv')}   # Astra, 4 Nov 2026\n"
    "    d6l = [dict(v38[rid], used='D6 what-if: ' + x['model_id']) for x in recs(REV / 'd6/d6_inputs.csv')\n"
    "           if x['origin'] != 'review model inputs' for rid in x['result_id'].split('+')]\n"
    "    assert len(d6l) == 5 and all(r['reviewer'].endswith('second review SP, 2026-09-28 (confirmed)') for r in d6l), [r['result_id'] for r in d6l]\n"
    "    sheet(wb, 'D6 what-if trials', d6l, [('result_id', 'Result ID', 16), ('study', 'Report', 14), ('outcome', 'Outcome', 24),\n"
    "          ('used', 'Used in', 30), ('assessment_id', 'Assessment ID', 20), ('d1', 'D1', 13), ('d2', 'D2', 13), ('d3', 'D3', 13),\n"
    "          ('d4', 'D4', 13), ('d5', 'D5', 13), ('overall', 'Overall', 13), ('overall_rationale', 'Overall rationale', 60),\n"
    "          ('reviewer', 'Assessor and second review', 40)])\n")
# 1. AF9: D6 inputs and the astra folder
rep("    'd6': [REV / 'd6' / f for f in ('d6_decision.csv', 'd6_scenarios.R', 'd6_scenarios.csv', 'apply_d6_text.py', 'patch_af_d6.py',\n",
    "    'd6': [REV / 'd6' / f for f in ('d6_decision.csv', 'build_d6_inputs.py', 'd6_inputs.csv', 'd6_scenarios.R', 'd6_scenarios.csv',\n"
    "                                    'apply_d6_text.py', 'patch_af_d6.py',\n")
rep("    'confirm': [REV / 'confirm' / f for f in ('apply_confirm_static.py', 'apply_confirm_text.py', 'patch_af_confirm.py', 'update_verify_confirm.py')],\n",
    "    'confirm': [REV / 'confirm' / f for f in ('apply_confirm_static.py', 'apply_confirm_text.py', 'patch_af_confirm.py', 'update_verify_confirm.py')],\n"
    "    'astra_2026-11-04': [REV / 'astra_2026-11-04' / f for f in ('ASTRA_FINDINGS_2026-11-04.md', 'apply_astra_text.py', 'patch_af_astra.py',\n"
    "                                                                'update_verify_astra.py')],\n")
rep("              'tools, the search questions in Additional file 2); no estimate changed.', '',\n",
    "              'tools, the search questions in Additional file 2); no estimate changed.',\n"
    "              '- `astra_2026-11-04/`: repairs after an independent AI check (4 Nov 2026). `reproduce_final.R` also reruns the four '\n"
    "              'D6 what-ifs from `d6/d6_inputs.csv` and compares them with `d6/d6_scenarios.csv`.', '',\n")
B.write_text(s, encoding='utf-8')

R = HERE.parent / 'reproduce/reproduce_final.R'   # rewritten from its snapshot by recheck/patch_af_recheck.py each run
r = R.read_text(encoding='utf-8')
old = "worst <- max(res$max_abs_difference)\n"
assert r.count(old) == 1
r = r.replace(old,
    "# 5. D6 post-hoc what-ifs (3 Nov 2026; Astra, 4 Nov 2026): rerun d6/d6_scenarios.R from d6/d6_inputs.csv and compare\n"
    "if (file.exists(file.path(here, \"d6\", \"d6_scenarios.R\")) && file.exists(file.path(here, \"d6\", \"d6_inputs.csv\"))) {\n"
    "  out6 <- file.path(tempdir(), \"d6_scenarios_rerun.csv\")\n"
    "  st6 <- system2(file.path(R.home(\"bin\"), \"Rscript\"), c(shQuote(file.path(here, \"d6\", \"d6_scenarios.R\")), shQuote(out6)), stdout = FALSE)\n"
    "  if (st6 != 0) stop(\"D6 what-ifs failed to run\")\n"
    "  a6 <- rd(\"d6/d6_scenarios.csv\"); n6 <- read.csv(out6, stringsAsFactors = FALSE)\n"
    "  stopifnot(identical(a6$scenario, n6$scenario))\n"
    "  d6d <- max(abs(c(num(a6$effect) - n6$effect, num(a6$ci_low) - n6$ci_low, num(a6$ci_high) - n6$ci_high)))\n"
    "  cat(sprintf(\"Refitted %d D6 what-ifs (rest pain and PONV with the trials removed by the opioid-result requirement); maximum absolute difference %.2e\\n\", nrow(n6), d6d))\n"
    "  if (d6d > 1e-9) stop(\"D6 what-ifs differ from the archived values\")\n"
    "}\n" + old, 1)
R.write_text(r, encoding='utf-8')
print(n, 'builder edits and 1 reproduction-script edit after Astra\'s check of 4 Nov 2026')
