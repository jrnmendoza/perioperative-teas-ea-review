"""After Astra's check of 4 Nov 2026 (ASTRA_FINDINGS_2026-11-04.md): adapt verification/verify_revision.py, as written by
confirm/update_verify_confirm.py.

The AF4 and D8 checks now read the database-route total and the corrected D8 wording. Added checks, one per finding: the D6
what-ifs run from d6/d6_inputs.csv alone and AF9 reruns them; the D9 checklist and AF10 cover the four D6 trials (earlier
assessments linked, not re-assessed) and the Methods say so; no external-check claim remains; the Discussion gives 19
language exclusions; Li 2026 is described as excluded from its retraction notice; AF4 gives both totals.
Re-run the earlier update scripts first."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:90], s.count(old))
    s = s.replace(old, new)


rep("f1['Total excluded'] == 173", "f1['Total excluded, database route'] == 173", count=2)
rep("'Its three report leads, all published after the July search, were screened at full text on 3 November 2026 by JRNM and SKP' in methods",
    "'Its three report leads, all published after the July search, were screened on 3 November 2026 by JRNM and SKP' in methods")
A = '''
# Astra's check of 4 Nov 2026 (astra_2026-11-04/): one check per finding
import zipfile as _zf
_d6r = (REV / 'd6/d6_scenarios.R').read_text(encoding='utf-8')
_z9 = _zf.ZipFile(REV / 'additional_files/Additional_file_9.zip').namelist()
_t9 = (HERE / 'af9_unzip_test_skp_2026-11-03.txt').read_text()
check('Astra 1: the D6 what-ifs run from d6/d6_inputs.csv alone; AF9 ships the inputs and its clean run reruns the four what-ifs',
      'opioid_only_review' not in _d6r and '10_FINAL_ADJUDICATION' not in _d6r and 'd6_inputs.csv' in _d6r
      and all(f'Additional_file_9/d6/{f}' in _z9 for f in ('d6_inputs.csv', 'd6_scenarios.R', 'd6_scenarios.csv', 'build_d6_inputs.py'))
      and 'Refitted 4 D6 what-ifs' in _t9 and 'exit 0' in _t9)
_d6c = [r for r in recs(REV / 'd9/d9_checklist.csv') if r['origin'] == 'd6/d6_inputs.csv']
_d6a = xl(10, 'D6 what-if trials', 'Result ID')
check('Astra 2: the four D6 trials are in the D9 checklist; AF10 links their five earlier assessments (second review SP, 28 Sep 2026); Methods and AF10 say they were not re-assessed',
      sorted(r['report'] for r in _d6c) == ['Liu 2021', 'Lu 2021', 'Xing 2022', 'Zheng 2025']
      and not any(r['checked_by'] or r['matches'] for r in _d6c)
      and sorted(x[0] for x in _d6a) == ['V33-OD-0033', 'V33-OD-0064', 'V33-OD-0130', 'V33-OD-0131', 'V33-OD-0163']
      and all(str(x[-1]).endswith('second review SP, 2026-09-28 (confirmed)') for x in _d6a)
      and 'The four trials added only in the post-hoc refits of rest pain and nausea and vomiting were not re-assessed' in methods
      and 'are in sheet "D6 what-if trials" and are not among the 180' in ' '.join(_cells + [str(c) for r in openpyxl.load_workbook(REV / 'additional_files/Additional_file_10.xlsx', read_only=True)['README'].iter_rows(values_only=True) for c in r if c]))
check('Astra 3: no external check of outcome values is claimed anywhere', 'external check of all outcome values' not in _t.lower() and 'colleague' not in methods)
check('Astra 4: the Discussion gives 19 language exclusions and ties the 8/2/2 breakdown to the original 12',
      'Nineteen reports published in Chinese were excluded for language: 12 at screening' in discussion and 'Twelve reports published in Chinese' not in discussion)
check('Astra 5: Li 2026 is described as excluded from its retraction notice (Methods, AF2 section 13 and decision log, Fig. 1 legend)',
      'two at full text and one (Li 2026) from its retraction notice' in methods and 'screened at full text on 3 November' not in methods
      and 'Li 2026 from its retraction notice, without reading its full text' in _t and 'Li 2026 from its retraction notice without reading the full text' in _t
      and 'The three reports were screened at full text' not in _t)
_rp = [x for x in xl(4, 'Reports', 'Covidence ID') if x[8] == 'Excluded']
check('Astra 6: AF4 gives the database-route total (173) and the all-routes total (176), matching the Reports sheet',
      f1['Total excluded, database route'] == 173 and f1['Total excluded, all routes'] == 176 == len(_rp) and 'Total excluded' not in f1)
'''
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, A + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after Astra\'s check of 4 Nov 2026')
