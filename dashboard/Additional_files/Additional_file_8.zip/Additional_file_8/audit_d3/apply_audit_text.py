"""Text repairs after Astra's audit of the D3 build (ASTRA_recheck_2026-11-02/AUDIT_OF_CLAUDE_REVISION_2026-11-02.md, 3 Nov 2026).

Runs after d3/apply_d3_text.py and edits sources/*_REVISED.md in place; every passage is asserted once, and a passage already
repaired is skipped, so the script is re-runnable. Findings addressed here: 4 (the other registered windows: 178 assessed
results, Colak days 2-7), 6 (Fu 2024 stimulation paused during microelectrode recording; Chen 2016's 16-80 years is its
eligible range), 7 (the primary trial reported no 24-hour pain result, not "no pain") and 8 (state directly which
assessments and extraction SKP has checked rather than qualifying a blanket confirmation)."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'results': [
  ('Chen 2016 enrolled participants aged 16–80 years, general anaesthesia',
   "Chen 2016's eligibility criteria admitted patients aged 16–80 years, general anaesthesia"),
  ('Twenty-one reports used a single session: nine of 30 minutes, ten continuous through surgery and two of 20 or 45 minutes.',
   'Twenty-one reports used a single session: nine of 30 minutes, nine continuous through surgery, one through surgery with a pause '
   'during microelectrode recording (Fu 2024) and two of 20 or 45 minutes.'),
  ('Of 169 assessed results, two (1%) were at low risk of bias, 122 (72%) had some concerns and 45 (27%) were at high risk',
   'Of 178 assessed results, two (1%) were at low risk of bias, 125 (70%) had some concerns and 51 (29%) were at high risk'),
  ('[PROVISIONAL: the five judgements for Colak 2010 and Fu 2024 are drafts awaiting second review.]',
   '[PROVISIONAL: the 14 judgements for Colak 2010 and Fu 2024 are drafts awaiting second review.]'),
  ('Fourteen were rated high for outcome measurement', 'Twenty were rated high for outcome measurement'),
  ('Almost every result (166 of 169)', 'Almost every result (175 of 178)'),
  ('Just over half (88) had some concerns about randomisation', 'Just over half (96) had some concerns about randomisation'),
  ('Its opioid result, a 7-day pethidine total, could not enter any 0–24-hour analysis.',
   'Its resting pain on days 2 to 7 and its 7-day pethidine and metamizole totals are reported as single-trial estimates; the '
   'pethidine total could not enter any 0–24-hour analysis.'),
 ],
 'abstract': [
  ('Of 169 assessed results, 27% were at high risk of bias.', 'Of 178 assessed results, 29% were at high risk of bias.'),
  ('could not be evaluated because the primary-outcome trial reported no pain.',
   'could not be evaluated: the primary-outcome trial reported no 24-hour pain result.'),
  ('had nausea and vomiting, with low certainty.', 'had nausea and vomiting (low certainty).'),   # keeps the abstract at 345 words
 ],
 'discussion': [
  ('Of 169 assessed results, 27% were at high risk of bias', 'Of 178 assessed results, 29% were at high risk of bias'),
  ('That trial reported no pain at 24 hours', 'That trial reported no pain result at 24 hours'),
 ],
 'figures': [
  ('across all 169 assessed results', 'across all 178 assessed results'),
 ],
 'methods': [
  ('Chen 2016 enrolled participants aged 16–80 years and was held in the same way',
   'Chen 2016, whose eligibility criteria admitted patients aged 16–80 years, was held in the same way'),
  ('Study characteristics, stimulation protocols, hospital setting, analgesic regimens and the narrative outcome tables were checked by '
   'a second reviewer (SKP). [PROVISIONAL: SKP has not yet checked the extraction for Colak 2010, Fu 2024 and Chen 2016, added on 2 '
   'November 2026.]',
   'A second reviewer (SKP) checked the study characteristics, stimulation protocols, hospital setting, analgesic regimens and narrative '
   'outcome tables of every report except Colak 2010, Fu 2024 and Chen 2016 [PROVISIONAL: their extraction, added on 2 and 3 November '
   '2026, awaits this check].'),
  ('Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation and checked and confirmed by a '
   'second reviewer (SKP). [PROVISIONAL: the assessments for Colak 2010 and Fu 2024, drafted on 2 November 2026, await this check.]',
   'Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation. A second reviewer (SKP) '
   'checked and confirmed all of them except those for Colak 2010 and Fu 2024 [PROVISIONAL: drafted on 2 and 3 November 2026, they '
   'await this check].'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if s.count(new) == 1 and old not in s:
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages repaired after the D3 audit')
