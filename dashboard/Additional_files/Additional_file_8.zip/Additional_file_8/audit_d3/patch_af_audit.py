"""Additional-files repairs after Astra's audit of the D3 build (ASTRA_recheck_2026-11-02/AUDIT_OF_CLAUDE_REVISION_2026-11-02.md,
3 Nov 2026).

Run after d3/patch_af_d3.py (which runs after recheck/patch_af_recheck.py, which rewrites build_additional_files.py from its
snapshot); this script edits build_additional_files.py in place, each replacement asserted once, so run the three together.
Findings addressed: 3 (AF12 method labels follow the final fit; checked by assertion), 4 (the further D3 results, their RoB 2
and GRADE drafts and the D3 outcome inventory), 5 (Fu 2024's printed P values in AF5), 6 (Fu stimulation paused during
microelectrode recording; Chen 2016's 16-80 years is its eligible range) and 8 (state which assessments SKP has checked).
Sources: d3/ (records rebuilt 3 Nov 2026) and wang1997/models_with_wang.csv. Nothing is re-estimated here."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# ---- shared facts --------------------------------------------------------------------------------------------------
rep("D3_RES = {r['result_id']: r for r in recs(D3 / 'd3_results.csv')}\n",
    "D3_RES = {r['result_id']: r for r in recs(D3 / 'd3_results.csv')}\n"
    "D3_INV = recs(D3 / 'd3_outcome_inventory.csv')   # every result the D3 reports give, with its disposition (Astra's D3 audit, 3 Nov 2026)\n")

# ---- AF2: D3 paragraph, decision log -------------------------------------------------------------------------------
rep("'stimulation was done under general anaesthesia, with stimulation through both stages); Chen 2016 included and '",
    "'stimulation was done under general anaesthesia, with stimulation through both stages except during microelectrode '\n"
    "            'recording); Chen 2016 included and '")
rep("'held from pooled analyses, as Lee 2011 is, because it enrolled participants aged 16–80 years; Tu 2018 excluded as '",
    "'held from pooled analyses, as Lee 2011 is, because its eligibility criteria admitted patients aged 16–80 years; Tu 2018 excluded as '")
rep("'result and a 7-day pethidine total (a single-trial estimate in native units); Fu 2024 enters rescue receipt '\n"
    "            '(follow-up not stated, as in Yu 2020), QoR-15 and intraoperative remifentanil. [PROVISIONAL: SKP has not yet '",
    "'result (day 1, with single-trial estimates for days 2 to 7) and 7-day pethidine and metamizole totals (single-trial '\n"
    "            'estimates in native units); Fu 2024 enters rescue receipt (follow-up not stated, as in Yu 2020), QoR-15 (days 1, '\n"
    "            '3 and 7) and intraoperative remifentanil. Every result the three reports give is listed with its disposition in '\n"
    "            'Additional file 4 (sheet \"D3 outcomes\"), added on 3 November 2026 after an independent AI audit of the D3 work. '\n"
    "            '[PROVISIONAL: SKP has not yet '")
rep("'checked the extraction for the three reports or the five RoB 2 and five GRADE drafts for Colak 2010 and Fu 2024; '",
    "'checked the extraction for the three reports or the 14 RoB 2 and seven GRADE drafts for Colak 2010 and Fu 2024; '")
rep("'held from pooled analyses (ages 16–80 years); Tu 2018 relabelled wrong comparator; Zhou 2025 (1879896127) and '",
    "'held from pooled analyses (eligible ages 16–80 years); Tu 2018 relabelled wrong comparator; Zhou 2025 (1879896127) and '")
rep("5 RoB 2 assessments and 5 GRADE profiles for Colak 2010 and Fu 2024', '[CONFIRM: second review pending]'],",
    "14 RoB 2 assessments and 7 GRADE profiles for Colak 2010 and Fu 2024 (9 and 2 of them added on 3 Nov after an independent AI audit)', "
    "'[CONFIRM: second review pending]'],")

# ---- AF4: D3 outcome inventory -------------------------------------------------------------------------------------
rep("                 ('D3 extracted results', 'Results extracted from the three reports included by decision D3, with source location, quotation and use')],",
    "                 ('D3 extracted results', 'Results extracted from the three reports included by decision D3, with source location, quotation and use'),\n"
    "                 ('D3 outcomes', 'Every result reported by Colak 2010, Fu 2024 and Chen 2016 (decision D3), with its disposition: existing analysis, '\n"
    "                                 'single-trial estimate, descriptive, narrative, not a registered outcome or held (added 3 Nov 2026)')],")
rep("""    sheet(wb, 'Wang 1997 outcomes', W97_INV, [('source', 'Source (printed page)', 18), ('result', 'Result', 50),
                                              ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
""",
    """    sheet(wb, 'Wang 1997 outcomes', W97_INV, [('source', 'Source (printed page)', 18), ('result', 'Result', 50),
                                              ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
    sheet(wb, 'D3 outcomes', D3_INV, [('report', 'Report', 12), ('source', 'Source (printed page)', 22), ('result', 'Result', 44),
                                      ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
""")

# ---- AF5: Fu 2024 printed P values ---------------------------------------------------------------------------------
rep("""    ('Fu 2024', 'Rescue analgesic incidence of 2/30 versus 6/29 is printed with P < 0.001, which these counts cannot give.', 'Counts used; the printed P value is not used.'),
""",
    """    ('Fu 2024', 'Printed P values do not match the printed summaries. Rescue analgesic 2/30 versus 6/29 is printed with P < 0.001 '
                '(two-sided Fisher P ≈ 0.15). With the printed means, SDs and arm sizes, QoR-15 gives Welch P ≈ 4 × 10⁻⁷, 3 × 10⁻⁶ and '
                '3 × 10⁻⁸ on days 1, 3 and 7 against printed 0.004, 0.008 and 0.020; remifentanil ≈ 0.006 and propofol ≈ 0.016 against '
                'printed < 0.001; baseline QoR-15 ≈ 0.88 and age ≈ 0.69 against printed 0.761 and 0.606; agitation 3/30 versus 11/29 '
                'gives Fisher P ≈ 0.015 against printed < 0.001. A pooled-variance t test does not explain the differences, and the '
                'report does not show which values, labels or analyses are wrong.',
     'Arm summaries used as printed; printed P values not used. Flagged for the human source check (D9) and for the second '
     'review of the Fu 2024 RoB 2 and GRADE drafts; analyses omitting Fu 2024 are reported (Additional file 12).'),
    ('Fu 2024', 'The dexmedetomidine row of Table 4 (2 [6.7%] versus 6 [20.7%], P < 0.001) repeats the rescue-analgesic row exactly.',
     'Neither row corrected; dexmedetomidine is not an outcome of this review. Flagged for the human source check.'),
""")

# ---- AF8 -----------------------------------------------------------------------------------------------------------
rep("'Lee 2011 (age 14–59 years), Chen 2016 (age 16–80 years), Jin 2023",
    "'Lee 2011 (age 14–59 years), Chen 2016 (eligible ages 16–80 years), Jin 2023")

# ---- AF10 ----------------------------------------------------------------------------------------------------------
rep("    assert len(units) == 169, len(units)\n", "    assert len(units) == 178, len(units)   # 169 + 9 D3 drafts added 3 Nov 2026\n")
rep("not counted among the 169.'))", "not counted among the 178.'))")
rep("held from all pooled analyses (participants aged 16–80 years, as Lee 2011); its results were not assessed.'))",
    "held from all pooled analyses (eligible ages 16–80 years, as Lee 2011); its results were not assessed.'))")
rep("""    held.append(dict(model='opioid7d_pethidine_EA_usual_COLAK', result='COLAK10-PETH-7D', study='Colak 2010',
                     reason='Single-trial estimate in native units over postoperative days 0–7, outside every 0–24-h analysis; not assessed.'))
    held.append(dict(model='Descriptive only', result='FU24-VAS-T1', study='Fu 2024',
                     reason='Pain on postoperative day 1 reported as medians (rest or movement not stated); not converted or pooled, so not assessed.'))""",
    """    held.append(dict(model='Descriptive only', result='FU24-VAS-T1, FU24-VAS-T2, FU24-VAS-T3', study='Fu 2024',
                     reason='Pain on postoperative days 1, 3 and 7 reported as medians (rest or movement not stated); not converted or pooled, so not assessed.'))""")
rep("'Result-specific RoB 2 judgements for all 169 results used in the analyses, with the rationale for each '",
    "'Result-specific RoB 2 judgements for all 178 results used in the analyses, with the rationale for each '")
rep("""                     'Assessments were made by an AI assistant under the review team\\'s delegation, and each was checked and '
                     'confirmed by a second reviewer (SKP); a check is not an independent duplicate assessment. The 12 '""",
    """                     'Assessments were made by an AI assistant under the review team\\'s delegation. A second reviewer (SKP) '
                     'checked and confirmed every assessment except the 14 for Colak 2010 and Fu 2024 (below); a check is not '
                     'an independent duplicate assessment. The 12 '""")
rep("""'confirmed by SKP on 2 Nov 2026. The exception: the five assessments for Colak 2010 and Fu 2024 (included 2 Nov '
                     '2026, decision D3) are AI drafts awaiting second review by SKP [PROVISIONAL].'],""",
    """'confirmed by SKP on 2 Nov 2026. The 14 assessments for Colak 2010 and Fu 2024 (included 2 Nov 2026, decision D3; '
                     'nine added on 3 Nov 2026 after an independent AI audit, for their results at later time points and Colak\\'s '
                     '7-day analgesic totals) are AI drafts awaiting second review by SKP [PROVISIONAL].'],""")
rep("[('Judgements', 'One row per assessed result (169), with domain judgements and rationales'),",
    "[('Judgements', 'One row per assessed result (178), with domain judgements and rationales'),")
rep("f'Signalling responses recorded for {n_with} of the 169 results'", "f'Signalling responses recorded for {n_with} of the 178 results'")

# ---- AF12: further D3 single-trial estimates; method labels follow the final fit ------------------------------------
rep("    left = D3_MOD - {r['model'] for r in oth} - {r['model'] for r in op} - {'opioid7d_pethidine_EA_usual_COLAK'}\n",
    """    D3_AUD = {'COLAK_PAIN_DAY2_EA_USUAL': ('Colak 2010: pain at rest on day 2 (about 48 h), EA vs usual care', 'pain_rest_day2', '0–10 points'),
              'COLAK_PAIN_DAY3_EA_USUAL': ('Colak 2010: pain at rest on day 3 (about 72 h), EA vs usual care', 'pain_rest_day3', '0–10 points'),
              'COLAK_PAIN_DAY4_EA_USUAL': ('Colak 2010: pain at rest on day 4, EA vs usual care', 'pain_rest_day4', '0–10 points'),
              'COLAK_PAIN_DAY5_EA_USUAL': ('Colak 2010: pain at rest on day 5, EA vs usual care', 'pain_rest_day5', '0–10 points'),
              'COLAK_PAIN_DAY6_EA_USUAL': ('Colak 2010: pain at rest on day 6, EA vs usual care', 'pain_rest_day6', '0–10 points'),
              'COLAK_PAIN_DAY7_EA_USUAL': ('Colak 2010: pain at rest on day 7 (longest reported), EA vs usual care', 'pain_rest_day7', '0–10 points'),
              'RESCUE_METAMIZOLE_7D_EA_USUAL': ('Colak 2010: metamizole on request, days 0–7, EA vs usual care', 'rescue_analgesia', 'g metamizole'),
              'QoR15_SHAM_POD7': ('QoR-15: TEAS vs sham POD7', 'quality_of_recovery', 'QoR-15 points')}
    for m, (lab, fam, unit) in D3_AUD.items():   # Astra's D3 audit (finding 4), 3 Nov 2026: the other reported time points
        x = W97_MOD[m]
        assert x['k'] == '1', m
        oth.append(dict(model=m, label=lab, role='Additional', family=fam, measure='MD', unit=unit, k=x['k'], n=x['N'], eff=num(x['effect']),
                        lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='', i2='', status='Single trial, normal interval',
                        reports=x['reports'], parent='', basis='Decision D3; added 3 Nov 2026 after an independent AI audit', note=x['description']))
    left = D3_MOD - {r['model'] for r in oth} - {r['model'] for r in op} - {'opioid7d_pethidine_EA_usual_COLAK'}
""")
rep("note='Added 2 Nov 2026 (decision D3); 7-day window, outside every 0–24-h analysis',",
    "note='Added 2 Nov 2026 (decision D3); longest reported acute interval (0–7 days), outside every 0–24-h analysis; RoB 2 draft added 3 Nov 2026',")
rep("""    wb = new_wb(12, ['Every opioid analysis, every other outcome analysis""",
    """    relabelled = []
    for rows_ in (op, oth):   # Astra's D3 audit (finding 3), 3 Nov 2026: the Method label follows the final fit, not the archived row
        for r in rows_:
            k, st = int(float(r['k'] or 0)), r['status'] or ''
            new = ((st if st.startswith(('NO ELIGIBLE', 'Empty')) else 'NO ELIGIBLE QUANTITATIVE DATA') if k == 0 else
                   (st if 'single' in st.lower() else 'Single trial, normal interval') if k == 1 else
                   (st if 'REML' in st else 'REML + Hartung-Knapp (floored at 1)'))
            if new != st:
                relabelled.append(r['model']); r['status'] = new
            assert (k == 0) == st_empty(r['status']) and (k == 1) == ('single' in r['status'].lower()), (r['model'], k, r['status'])
    assert len(relabelled) == 10, relabelled
    wb = new_wb(12, ['Every opioid analysis, every other outcome analysis""")
rep("""def af12():
""",
    """def st_empty(st):
    return st.startswith(('NO ELIGIBLE', 'Empty'))


def af12():
""")
rep("""                  'analyses (ages 16–80 years). Analyses that Fu 2024 or Colak 2010 enter were refitted (Note column); without Fu 2024 '
                  'the rescue estimate is the earlier six-trial one (RESCUE_LOO_Fu_2024).'])""",
    """                  'analyses (eligible ages 16–80 years). Analyses that Fu 2024 or Colak 2010 enter were refitted (Note column); without Fu 2024 '
                  'the rescue estimate is the earlier six-trial one (RESCUE_LOO_Fu_2024).',
                  'Added on 3 Nov 2026 after an independent AI audit of the D3 work: single-trial estimates for Colak 2010 (rest pain on '
                  'days 2 to 7; metamizole over days 0–7) and Fu 2024 (QoR-15 on day 7).',
                  'The Method column follows the number of trials in the final fit: no eligible data (0 trials), single trial (1) or REML '
                  'with Hartung–Knapp (2 or more). Until 3 Nov 2026, ten rows refitted with Wang 1997 or the D3 reports kept their '
                  'earlier label.'])""")

# ---- AF9 -----------------------------------------------------------------------------------------------------------
rep("'rob_domain_summary_d3.csv', 'rob_key_analyses_d3.csv', 'stata_figures_d3.log')]",
    "'rob_domain_summary_d3.csv', 'rob_key_analyses_d3.csv', 'stata_figures_d3.log', 'd3_outcome_inventory.csv')]")
rep("          + [REV / 'recheck/D3_membership_dossier.md'],\n",
    "          + [REV / 'recheck/D3_membership_dossier.md'],\n"
    "    'audit_d3': [REV / 'audit_d3' / f for f in ('apply_audit_text.py', 'patch_af_audit.py', 'update_verify_audit.py')],\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after the D3 audit')
