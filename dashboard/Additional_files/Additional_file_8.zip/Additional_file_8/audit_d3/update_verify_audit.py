"""After Astra's audit of the D3 build (3 Nov 2026): adapt verification/verify_revision.py, as written by d3/update_verify_d3.py.

Run after d3/update_verify_d3.py. Counts the audit repairs change are updated (each replacement asserted once) and checks for
each repaired finding are added before the results are written. Re-run d3/update_verify_d3.py first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')
assert 'Astra audit of the D3 build' not in s, 'already applied: run d3/update_verify_d3.py first'


def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


rep("as TEAS; wang1997/) and D3 (Colak 2010, Fu 2024 and Chen 2016 included; d3/).",
    "as TEAS; wang1997/) and D3 (Colak 2010, Fu 2024 and Chen 2016 included; d3/), with the repairs after Astra's audit\nof the D3 build (3 Nov 2026; audit_d3/).")
rep("'27% were at high risk',", "'29% were at high risk',")
rep("'Of 169 assessed results']))", "'Of 178 assessed results', 'reported no 24-hour pain result']))")
rep("""check('RoB: 169 results; 2 low, 122 some concerns, 45 high; text matches', [int(rob['Overall'][k]) for k in ('Low', 'Some concerns', 'High')] == [2, 122, 45]
      and 'Of 169 assessed results, two (1%) were at low risk of bias, 122 (72%) had some concerns and 45 (27%)' in results
      and [int(rob['D4 Measurement of the outcome'][k]) for k in ('Low', 'Some concerns', 'High')] == [75, 79, 15]
      and 'Fourteen were rated high for outcome measurement' in results and int(rob['D3 Missing outcome data']['High']) == 31
      and 'Almost every result (166 of 169)' in results and int(rob['D5 Selection of the reported result']['Some concerns']) == 166
      and 'Just over half (88)' in results and int(rob['D1 Randomisation process']['Some concerns']) == 88)""",
    """check('RoB: 178 results; 2 low, 125 some concerns, 51 high; text matches', [int(rob['Overall'][k]) for k in ('Low', 'Some concerns', 'High')] == [2, 125, 51]
      and 'Of 178 assessed results, two (1%) were at low risk of bias, 125 (70%) had some concerns and 51 (29%)' in results
      and [int(rob['D4 Measurement of the outcome'][k]) for k in ('Low', 'Some concerns', 'High')] == [76, 81, 21]
      and 'Twenty were rated high for outcome measurement' in results and int(rob['D3 Missing outcome data']['High']) == 31
      and 'One was rated high for both' in results and 30 + 20 + 1 == 51
      and 'Almost every result (175 of 178)' in results and int(rob['D5 Selection of the reported result']['Some concerns']) == 175
      and 'Just over half (96)' in results and int(rob['D1 Randomisation process']['Some concerns']) == 96)""")
rep("""check('AF10: 169 judgements; 12 for Wang 1997 confirmed by SKP; 5 D3 drafts pending', len(j) == 169""",
    """check('AF10: 178 judgements; 12 for Wang 1997 confirmed by SKP; 14 D3 drafts pending', len(j) == 178""")
rep("""      and sum(x[1] in ('Colak 2010', 'Fu 2024') and 'second review by SKP pending' in str(x[-1]) for x in j) == 5)""",
    """      and sum(x[1] in ('Colak 2010', 'Fu 2024') and 'second review by SKP pending' in str(x[-1]) for x in j) == 14)""")
rep("""      and 'enrolled participants aged 14–59 years and was held from all pooled analyses; Chen 2016 enrolled participants aged 16–80 years and was held in the same way' in methods""",
    """      and 'enrolled participants aged 14–59 years and was held from all pooled analyses; Chen 2016, whose eligibility criteria admitted patients aged 16–80 years, was held in the same way' in methods""")
rep("""check('D3 RoB 2 (5) and GRADE (5) drafts marked AI drafts pending SKP, with PROVISIONAL markers in Results, Methods and Table 2',
      len(dr) == 5 and len(dg) == 5 and all('second review by SKP pending' in r['decision_status'] for r in dr)""",
    """check('D3 RoB 2 (14) and GRADE (7) drafts marked AI drafts pending SKP, with PROVISIONAL markers in Results, Methods and Table 2',
      len(dr) == 14 and len(dg) == 7 and all('second review by SKP pending' in r['decision_status'] for r in dr)""")
rep("""      and 'the five judgements for Colak 2010 and Fu 2024 are drafts awaiting second review' in results
      and 'the assessments for Colak 2010 and Fu 2024, drafted on 2 November 2026, await this check' in methods
      and 'SKP has not yet checked the extraction for Colak 2010, Fu 2024 and Chen 2016' in methods)""",
    """      and 'the 14 judgements for Colak 2010 and Fu 2024 are drafts awaiting second review' in results
      and 'checked and confirmed all of them except those for Colak 2010 and Fu 2024 [PROVISIONAL: drafted on 2 and 3 November 2026, they await this check]' in methods
      and 'of every report except Colak 2010, Fu 2024 and Chen 2016 [PROVISIONAL: their extraction, added on 2 and 3 November 2026, awaits this check]' in methods)""")
rep("t = (HERE / 'af9_unzip_test_d3_2026-11-02.txt').read_text()",
    "t = (HERE / 'af9_unzip_test_audit_2026-11-03.txt').read_text()   # clean unzip after the D3 audit repairs")
rep("check('AF9 unpacked into an empty folder: reproduction passed, including the Wang 1997 refit', 'Reproduction passed.' in t",
    "check('AF9 unpacked into an empty folder: reproduction passed, including the Wang 1997 and D3 refits (83)', 'Reproduction passed.' in t\n"
    "      and 'Refitted 83 analyses with Wang 1997 and the D3 reports' in t and 'exit 0' in t")
rep("check('AF11: D3 drafts sheet (5 profiles)', len(xl(11, 'D3 drafts', 'Analysis')) == 5)",
    "check('AF11: D3 drafts sheet (7 profiles)', len(xl(11, 'D3 drafts', 'Analysis')) == 7)")
rep("check('AF4: D3 decisions sheet (8) and D3 extracted results (11)', len(xl(4, 'D3 decisions', 'Covidence ID')) == 8 and len(xl(4, 'D3 extracted results', 'Result ID')) == 11)",
    "check('AF4: D3 decisions sheet (8) and D3 extracted results (21)', len(xl(4, 'D3 decisions', 'Covidence ID')) == 8 and len(xl(4, 'D3 extracted results', 'Result ID')) == 21)")

AUDIT = r'''
# Astra audit of the D3 build (ASTRA_recheck_2026-11-02/AUDIT_OF_CLAUDE_REVISION_2026-11-02.md; repairs 3 Nov 2026)
import openpyxl as _ox
_w12 = _ox.load_workbook(REV / 'additional_files/Additional_file_12.xlsx', read_only=True)
_bad = []
for _sh in ('Opioid analyses', 'Other outcomes'):
    _rows = [list(r) for r in _w12[_sh].iter_rows(values_only=True)]
    _h = _rows[0]; _ki, _mi = _h.index('Trials'), _h.index('Method')
    for _r in _rows[1:]:
        _k, _m = int(float(_r[_ki] or 0)), str(_r[_mi] or '')
        if (_k == 0) != _m.startswith(('NO ELIGIBLE', 'Empty')) or (_k == 1) != ('single' in _m.lower()) or (_k > 1 and 'REML' not in _m):
            _bad.append((_sh, _r[0], _k, _m))
check('Audit 3: AF12 Method labels follow the fitted number of trials (no k>0 row labelled empty, no k>1 row single-trial)', not _bad, str(_bad[:4]))
inv = recs(REV / 'd3/d3_outcome_inventory.csv')
_res = {r['result_id']: r for r in recs(REV / 'd3/d3_results.csv')}
check('Audit 4: D3 outcome inventory (29 rows) in AF4; Colak rest pain days 1-7 and Fu QoR-15 days 1, 3 and 7 extracted',
      len(inv) == 29 and len(xl(4, 'D3 outcomes', 'Report')) == 29
      and all(f'COLAK10-VAS-D{d}' in _res for d in range(1, 8)) and all(f'FU24-QOR-T{d}' in _res for d in (1, 2, 3))
      and 'COLAK10-METAM-7D' in _res and 'not entered as zero PONV' in ' '.join(r['reason'] for r in inv))
_new = ['COLAK_PAIN_DAY2_EA_USUAL', 'COLAK_PAIN_DAY3_EA_USUAL', 'COLAK_PAIN_DAY4_EA_USUAL', 'COLAK_PAIN_DAY5_EA_USUAL', 'COLAK_PAIN_DAY6_EA_USUAL',
        'COLAK_PAIN_DAY7_EA_USUAL', 'RESCUE_METAMIZOLE_7D_EA_USUAL', 'QoR15_SHAM_POD7']
_oth = {x[0] for x in xl(12, 'Other outcomes', 'Analysis')}
check('Audit 4: eight further single-trial estimates fitted (83 refits) and shown in AF12', len(mw) == 83 and all(mw[m]['k'] == '1' for m in _new)
      and set(_new) <= _oth and f2(mw['COLAK_PAIN_DAY3_EA_USUAL']['effect']) == '−1.17' and f2(mw['QoR15_SHAM_POD7']['effect']) == '9.10'
      and 'Its resting pain on days 2 to 7 and its 7-day pethidine and metamizole totals are reported as single-trial estimates' in results)
_dra = {r['analyses'] for r in dr}
check('Audit 4: every D3 result that enters an estimate has a RoB 2 draft (pethidine no longer "not assessed")',
      {'opioid7d_pethidine_EA_usual_COLAK', 'RESCUE_METAMIZOLE_7D_EA_USUAL', 'QoR15_SHAM_POD7'} | set(_new[:6]) <= _dra
      and not any(x[1] == 'COLAK10-PETH-7D' for x in xl(10, 'Not assessed', 'Analysis')))
_c5 = ' '.join(str(x[1]) for x in xl(5, 'Contradictions', 'Report') if x[0] == 'Fu 2024')
check('Audit 5: AF5 records Fu 2024 printed P values against its summaries (QoR-15, remifentanil, propofol, rescue, agitation) and the repeated dexmedetomidine row',
      all(p in _c5 for p in ('printed 0.004, 0.008 and 0.020', 'remifentanil ≈ 0.006', 'Fisher P ≈ 0.15', 'repeats the rescue-analgesic row')))
check('Audit 6: Fu 2024 locators are PDF pp6-7 (Tables 3 and 4), never p5', all(('p5' not in r['source_location']) for r in _res.values() if r['report'] == 'Fu 2024')
      and _res['FU24-QOR-T1']['source_location'] == 'Table 3, p6' and _res['FU24-REMI']['source_location'] == 'Table 4, p7')
_t1 = {r[0].split(' [')[0]: r for r in csv.reader(open(REV / 'sources/table1_REVISED.csv', encoding='utf-8'))}
check('Audit 6: Fu 2024 stimulation paused during microelectrode recording (Table 1, AF8, Results tally)',
      'paused during microelectrode recording' in _t1['Fu 2024'][11] and 'nine continuous through surgery, one through surgery with a pause during microelectrode recording (Fu 2024)' in results
      and 'ten continuous through surgery' not in results)
check('Audit 6: Chen 2016 16-80 years described as its eligible range', 'Chen 2016 enrolled participants aged 16' not in methods
      and 'eligibility criteria admitted patients aged 16–80 years' in methods and 'participants aged 16–80 years' not in _t)
check('Audit 7: abstract and Discussion say the primary trial reported no 24-hour pain result, not "no pain"', 'reported no pain.' not in abstract
      and 'reported no 24-hour pain result' in abstract and 'That trial reported no pain result at 24 hours' in discussion)
check('Audit 8: Methods state directly which assessments and extraction SKP checked (no blanket confirmation followed by an exception)',
      'checked and confirmed by a second reviewer (SKP). [PROVISIONAL' not in methods and 'were checked by a second reviewer (SKP). [PROVISIONAL' not in methods
      and 'A second reviewer (SKP) checked and confirmed all of them except those for Colak 2010 and Fu 2024' in methods
      and 'except the 14 for Colak 2010 and Fu 2024' in ' '.join(str(c) for r in _ox.load_workbook(REV / 'additional_files/Additional_file_10.xlsx',
                                                                                                read_only=True)['README'].iter_rows(values_only=True) for c in r if c))
'''
rep("\n(HERE / 'verification_results.txt').write_text(", AUDIT + "\n(HERE / 'verification_results.txt').write_text(")
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted for the D3 audit repairs')
