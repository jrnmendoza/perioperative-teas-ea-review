"""Author confirmations (reported by the review owner, 3 Nov 2026): the title page and Declarations.

These live in assemble_revision.py (authors, affiliations, title note) and build_docx.js (Declarations), which the chain
runs but does not regenerate, so this one-off script edits them in place; each edit is asserted once and skipped if done.
- SKP's affiliation is Region Skane, Sweden (as in PROSPERO); the other three stay at Lund University. The title-page
  CONFIRM marker is removed; the PROVISIONAL draft note stays.
- Data availability: nothing is deposited elsewhere; the CONFIRM marker is removed.
- Authors' contributions approved as drafted; the CONFIRM marker is removed.
- Acknowledgements: the external colleague's check is removed from the Methods (confirm/apply_confirm_text.py), so the
  section reads "Not applicable." """
from pathlib import Path

REV = Path(__file__).resolve().parent.parent
n = 0


def edit(path, old, new):
    global n
    p = REV / path
    s = p.read_text(encoding='utf-8')
    if old not in s and new in s:
        return
    assert s.count(old) == 1, (path, old[:80], s.count(old))
    p.write_text(s.replace(old, new), encoding='utf-8')
    n += 1


edit('assemble_revision.py',
     "    title=OCT['title'], authors=OCT['authors'], affiliations=OCT['affiliations'], corresponding=OCT['corresponding'],\n"
     "    title_note=OCT['title_note'] + ' [PROVISIONAL:",
     "    # author confirmations, 3 Nov 2026 (confirm/apply_confirm_static.py): SKP at Region Skane, as in PROSPERO\n"
     "    title=OCT['title'], authors=[[a, '2' if a == 'Siv Katrin Peters' else s] for a, s in OCT['authors']],\n"
     "    affiliations=OCT['affiliations'] + ['2 Region Skåne, Sweden'], corresponding=OCT['corresponding'],\n"
     "    title_note='[PROVISIONAL:")
edit('build_docx.js',
     " (Additional files 4 to 12). [CONFIRM: if the extraction records and analysis code are also deposited in a public repository (for example Zenodo), add \"and in the [repository name] repository, [persistent link]\".]'",
     " (Additional files 4 to 12).'")
edit('build_docx.js', "[\"Authors' contributions\", '[CONFIRM: draft wording.] JRNM", "[\"Authors' contributions\", 'JRNM")
s = (REV / 'build_docx.js').read_text(encoding='utf-8')
i = s.find("  ['Acknowledgements', '[CONFIRM: acknowledge, with their permission,")
if i >= 0:
    j = s.index("'],\n", i) + 4
    edit('build_docx.js', s[i:j], "  ['Acknowledgements', 'Not applicable.'],\n")
print(n, 'static edits for the author confirmations')
