"""Manuscript text after the author confirmations (reported by the review owner, 3 Nov 2026).

- The 508 automated exclusions: Covidence's RCT classifier, without a human check (Methods; Discussion limitation).
- AI tools: GPT-6 Astra (OpenAI, through the Codex agent) and Claude Opus 5.5 (Anthropic).
- The external colleague's check of three trials is removed from the Methods (no acknowledgement).
Runs after d10/apply_d10_text.py; edits sources/*_REVISED.md in place, each passage asserted once."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'methods': [
  ('508 records were marked ineligible by automation in Covidence [CONFIRM: name the automation tool (for example the Covidence '
   'RCT classifier) and any threshold or human check; if these were not recorded, say that the 508 exclusions cannot be '
   'reconstructed].',
   '508 records that Covidence\'s randomised-controlled-trial classifier marked as not randomised trials were excluded without '
   'a human check.'),
  ('Large language models [TOOLS: confirm names and versions] were used',
   'Large language models (GPT-6 Astra, OpenAI, used through the Codex agent; and Claude Opus 5.5, Anthropic) were used'),
  ('re-checked by the AI assistant against the source reports, and an external colleague checked all extracted values for three '
   'trials; arm-level outcome data',
   're-checked by the AI assistant against the source reports; arm-level outcome data'),
 ],
 'discussion': [
  ('Before screening, 508 records were removed by automation,',
   'Before screening, 508 records were removed by an automated classifier without a human check,'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after the author confirmations')
