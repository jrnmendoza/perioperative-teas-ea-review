"""Additional-files edits after the author confirmations (reported by the review owner, 3 Nov 2026).

AF1: item 8 states the automated exclusions (Covidence RCT classifier, no human check); item 24b points to the final
protocol sentence (decision D10). AF2 deviations: reference lists of included reports were not systematically checked and
experts were not contacted; the 30% relative threshold was examined descriptively for the primary trial only (Szmit 2021,
50.7%; registered_completion_2026_10_09/RESULTS_REGISTERED_QUESTIONS_UPDATED.md). AF9: this folder. Run after
d10/patch_af_d10.py; edits build_additional_files.py in place, each replacement asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


rep("Automation before screening: see the CONFIRM marker on the 508 automated exclusions.'",
    "Before screening, Covidence\\'s randomised-controlled-trial classifier excluded 508 records without a human check.'")
rep("'Methods: Protocol and registration (sentence proposed in this revision). [CONFIRM: wording.]'",
    "'Methods: Protocol and registration (the full protocol was not made publicly available; PROSPERO describes it as a team draft not yet released).'")
rep(" [CONFIRM: whether reference lists of all included reports were checked, and whether experts were contacted.]",
    " Reference lists of the included reports were not systematically checked, and experts were not contacted.")
rep("peer-review status, alternative estimators or interval methods. [CONFIRM: whether the 30% relative threshold was examined.]",
    "peer-review status, alternative estimators or interval methods. The 30% relative threshold was examined descriptively for the "
    "primary trial only (Szmit 2021: 50.7% below the control mean; not a pooled ratio of means).")
rep("    'd10': [REV / 'd10' / f for f in ('apply_d10_text.py', 'patch_af_d10.py', 'update_verify_d10.py')],\n",
    "    'd10': [REV / 'd10' / f for f in ('apply_d10_text.py', 'patch_af_d10.py', 'update_verify_d10.py')],\n"
    "    'confirm': [REV / 'confirm' / f for f in ('apply_confirm_static.py', 'apply_confirm_text.py', 'patch_af_confirm.py', 'update_verify_confirm.py')],\n")
rep("              '- `d10/`: decision D10 (JRNM, 3 Nov 2026): registration history stated in the Methods and Additional file 2.', '',\n",
    "              '- `d10/`: decision D10 (JRNM, 3 Nov 2026): registration history stated in the Methods and Additional file 2.',\n"
    "              '- `confirm/`: the author confirmations of 3 Nov 2026 (title page, Declarations, the 508 automated exclusions, AI '\n"
    "              'tools, the search questions in Additional file 2); no estimate changed.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after the author confirmations')
