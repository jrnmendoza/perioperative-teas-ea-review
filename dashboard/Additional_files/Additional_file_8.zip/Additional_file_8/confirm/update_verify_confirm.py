"""After the author confirmations (reported by the review owner, 3 Nov 2026): adapt verification/verify_revision.py, as
written by d10/update_verify_d10.py.

Added checks: no CONFIRM or TOOLS marker remains in the Word file or any Additional file; the title page gives SKP's
affiliation as Region Skane; the Methods name the automated classifier and the AI tools and no longer mention an external
colleague's check; the Declarations carry no marker (Acknowledgements: Not applicable); AF2 answers its two search
questions; and no estimate changed (snapshot confirm/pre_confirm/). Re-run the earlier update scripts first."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')

C = '''
# Author confirmations (reported 3 Nov 2026): title page, Declarations, automation, AI tools, AF2 search questions (confirm/)
_all = _t + ' ' + ' '.join(str(c) for f in sorted((REV / 'additional_files').glob('*.xlsx'))
                           for ws in openpyxl.load_workbook(f, read_only=True).worksheets for r in ws.iter_rows(values_only=True) for c in r if c)
_wd = _docx.Document(REV / 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx')
_ws = [p.text for p in _wd.paragraphs]
_ack = _ws[_ws.index('Acknowledgements') + 1] if 'Acknowledgements' in _ws else ''
check('Author confirmations: no CONFIRM or TOOLS marker left in the Word file or any Additional file',
      '[CONFIRM' not in _all and '[TOOLS' not in _all)
check('Author confirmations: SKP at Region Skane; automated classifier and AI tools named; no external-colleague check claimed; Acknowledgements not applicable; AF2 search questions answered',
      ['Siv Katrin Peters', '2'] in spec['authors'] and '2 Region Skåne, Sweden' in spec['affiliations']
      and "508 records that Covidence's randomised-controlled-trial classifier marked as not randomised trials were excluded without a human check" in methods
      and 'Large language models (GPT-6 Astra, OpenAI, used through the Codex agent; and Claude Opus 5.5, Anthropic) were used' in methods
      and 'colleague' not in methods and _ack == 'Not applicable.'
      and 'removed by an automated classifier without a human check' in discussion
      and 'Reference lists of the included reports were not systematically checked, and experts were not contacted.' in _t
      and 'The 30% relative threshold was examined descriptively for the primary trial only' in _t)
check('Author confirmations changed no estimate or Table 1 row (snapshot confirm/pre_confirm/)',
      all(filecmp.cmp(REV / f, REV / 'confirm/pre_confirm' / f, shallow=False) for f in ('wang1997/models_with_wang.csv', 'sources/table1_REVISED.csv'))
      and spec['abstract_words'] == 332)
'''
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, C + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after the author confirmations')
