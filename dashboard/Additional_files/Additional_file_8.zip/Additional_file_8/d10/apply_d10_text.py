"""Manuscript text after decision D10 (JRNM, reported 3 Nov 2026): registration history.

The PROSPERO record left screening unmarked although title-and-abstract screening was complete: an error in completing the
form, now acknowledged. Only search terminology and known reports were used from the team's earlier, broader review
(CRD420251090635; search decision log SD-001, 21 Jul 2026). The full protocol is still unreleased, as the PROSPERO record
says, so the Methods CONFIRM marker becomes a statement. Runs after d7/apply_d7_text.py; edits sources/*_REVISED.md in
place, each passage asserted once."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'methods': [
  ('but before final study selection, data extraction and analysis. It is distinct from a broader review by the same team '
   '(CRD420251090635). [CONFIRM: The full protocol was not made publicly available; the PROSPERO record describes it as a team '
   'draft not yet released.]',
   'but before final study selection, data extraction and analysis; the record did not mark screening as started, an error in '
   'completing the form. It is distinct from a broader review by the same team (CRD420251090635), from which only search '
   'terminology and known reports were used. The full protocol was not made publicly available; the PROSPERO record describes '
   'it as a team draft not yet released.'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after decision D10')
