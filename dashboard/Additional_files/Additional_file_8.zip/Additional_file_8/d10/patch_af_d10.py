"""Additional-files edits after decision D10 (JRNM, reported by the review owner on 3 Nov 2026): registration history.

AF2 section 14: the CONFIRM marker becomes the answer (the unmarked PROSPERO screening stage was an error in completing the
form; only terminology, known reports and reproducibility comparisons were taken from CRD420251090635, as the search decision
log records). AF9: this folder. Run after d7/patch_af_d7.py; edits build_additional_files.py in place, each replacement
asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


rep("            'September; confirmed-opioid criterion 9 October. The PROSPERO record (version 1.0) marks formal searching as '\n"
    "            'started and leaves screening unmarked, although title and abstract screening had been completed by then. '\n"
    "            '[CONFIRM: explain this discrepancy, and state what, if anything, was reused from the earlier broader review '\n"
    "            '(CRD420251090635); the search records show it was used only for terminology and known reports.]')",
    "            'September; confirmed-opioid criterion 9 October. The PROSPERO record (version 1.0) marks pilot work as completed '\n"
    "            'and formal searching as started but leaves screening unmarked, although title and abstract screening had been '\n"
    "            'completed and full-text screening had begun; this was an error in completing the form (decision D10, JRNM, '\n"
    "            '3 November 2026). The earlier, broader review by the same team (CRD420251090635) was used only for search '\n"
    "            'terminology, to identify known reports for testing the search and for reproducibility comparisons (search '\n"
    "            'decision log, 21 July 2026); its search exports, screening decisions and extracted data were not reused.')")
rep("    'd7': [REV / 'd7' / f for f in ('d7_mma_timing.csv', 'apply_d7_text.py', 'patch_af_d7.py', 'update_verify_d7.py')],\n",
    "    'd7': [REV / 'd7' / f for f in ('d7_mma_timing.csv', 'apply_d7_text.py', 'patch_af_d7.py', 'update_verify_d7.py')],\n"
    "    'd10': [REV / 'd10' / f for f in ('apply_d10_text.py', 'patch_af_d10.py', 'update_verify_d10.py')],\n")
rep("              'multimodal reports (`d7_mma_timing.csv`); the definition and counts are unchanged.', '',\n",
    "              'multimodal reports (`d7_mma_timing.csv`); the definition and counts are unchanged.',\n"
    "              '- `d10/`: decision D10 (JRNM, 3 Nov 2026): registration history stated in the Methods and Additional file 2.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after decision D10')
