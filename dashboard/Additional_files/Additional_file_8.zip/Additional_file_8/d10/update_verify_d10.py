"""After decision D10 (JRNM, reported 3 Nov 2026): adapt verification/verify_revision.py, as written by d7/update_verify_d7.py.

Added check: the Methods acknowledge the PROSPERO stage error, state what was used from CRD420251090635 and state the
protocol's availability without a CONFIRM marker; AF2 section 14 gives the answer in place of its CONFIRM marker; the
registration sentence and the mandated disclosure sentence are kept. Re-run the earlier update scripts first."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')

D10 = '''
# Decision D10 (JRNM, reported 3 Nov 2026): registration history (d10/)
check('D10: Methods and AF2 section 14 state the PROSPERO stage error, the limited use of CRD420251090635 and the unreleased protocol; their CONFIRM markers are gone',
      'the record did not mark screening as started, an error in completing the form' in methods
      and 'from which only search terminology and known reports were used' in methods
      and 'The full protocol was not made publicly available; the PROSPERO record describes it as a team draft not yet released.' in methods
      and '[CONFIRM: The full protocol' not in methods
      and 'this was an error in completing the form (decision D10, JRNM, 3 November 2026)' in _t
      and 'its search exports, screening decisions and extracted data were not reused' in _t
      and 'explain this discrepancy' not in _t
      and 'The review was registered with PROSPERO on 20 August 2026 (CRD420261452908), after the searches and initial screening had begun' in methods)
'''
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, D10 + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after decision D10')
