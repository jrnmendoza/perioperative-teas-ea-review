# D3: the eight remaining membership candidates

**Dossier (2 November 2026).** These are AI-assisted source readings; the decisions belong to JRNM and SKP.

**Sources.** Local full texts, `10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/<Covidence ID>.pdf`.

**Criteria applied.** Each report was checked against the review's eligibility rules:
- randomised trial; adults; surgery under general anaesthesia;
- TEAS or EA with at least one session before 24 h; sham, usual-care or active comparator; English full text;
- **filter A (14 Aug):** a 0–24-h systemic opioid quantity, or pain at about 24 h;
- **filter B (9 Oct):** a confirmed postoperative opioid result, meaning a named postoperative opioid or an author
  morphine-equivalent quantity. Rescue receipt of a named opioid counted for the included reports.

## Summary

| Report (Covidence ID) | Filter A | Filter B | Other criteria | Proposed disposition |
|---|---|---|---|---|
| Colak 2010 (1879897298) | Met: day-1 resting VAS | Met: pethidine, 7-day total | Randomised by random-number tables (despite the "case-control" label); CABG, extubated at about 8 h, so general anaesthesia | **Include** |
| Fu 2024 (1879896270) | Met: POD1 VAS (medians) | Met: rescue IV tramadol receipt, 2/30 vs 6/29 | TEAS vs sham; DBS stage 2 under general anaesthesia, with TEAS through both stages | **Include** |
| Chen 2016 (1879896981) | Met: VAS at 24 h (figure only) | Met: rescue "Sauteralgyl" = pethidine, mg/kg over 72 h | EA vs sham; age 16–80 y, so adult status not established | **Include, held from pooling** (as Lee 2011), or exclude for population |
| Tu 2018 (1879896817) | Met | Met | Control arm alone received scheduled oral tramadol 100 mg twice daily; TEAS arm received placebo tablets | **Exclude: wrong comparator** (relabel) |
| Zhou 2025 (1879896127) | Met: rest and movement VAS at 24 h | Not met: only "perioperative" morphine equivalents in the baseline table | 2×2 factorial; TEAS vs full sham eligible | **Exclude: no confirmed postoperative opioid result** (relabel) |
| Li 2017 (1879896900) | Met: NRS at the 24-h assessment | Not met: "Analgesics 0–48 h" 0 vs 0, no drug named; parecoxib routine | EA vs usual care, preoperative EA | **Exclude: no confirmed postoperative opioid result** (relabel) |
| Zhang 2022 (1879896437) | Not met: opioid as medians over a 24–48 h PCIA; NRS time not stated | Met: postoperative IV morphine equivalents (medians) | TEAS vs sham, age > 65 | **Exclude: original reason supported** |
| Poulain 1997 (1881841314) | Not met: pain complaint and analgesic requirement over 5 days only | Not met: postoperative analgesics non-narcotic; fentanyl intraoperative only | Study arm alone got postoperative TENS; unblinded | **Exclude: original reason supported** |

## Evidence by report

### Colak 2010 — Neurosciences 2010;15:7–10

- **Design:**
  - The paper calls it a "case-control study" (p8). But "Patients were randomized based on 'Tables of Random Numbers'
    to either the electroacupuncture and pharmacologic analgesia (acupuncture) group, or the pharmacologic analgesia
    alone (control) group" (p8).
  - 30 patients having CABG, 15 per arm, mean age 51–52.
- **Anaesthesia:** not described, but CABG with extubation at 8.1 ± 2.2 h (Table 1, p9) implies general anaesthesia.
- **Intervention:** needle EA at LI4, LI11, ST36, PC6 and LR3 (60 Hz, 20 min), first about 2 h after extubation, then
  daily for 7 days. Comparator: analgesia alone (usual care).
- **Results (Table 1, p9):**
  - VAS 0–100 at rest, day 1: 52.33 ± 15.22 (control) vs 50.33 ± 7.19 (EA).
  - Pethidine over 7 days: 223.33 ± 132.10 vs 76.67 ± 84.23 mg.
  - Metamizole: 2.0 vs 0.53 g.
- **Source oddity:** the exclusion criteria mention an epidural catheter, but none is described.
- **If included:**
  - EA vs usual care, rest pain at about 24 h: MD −0.20 points (−1.05 to 0.65), single trial. This would be the review's
    first EA pain result.
  - The 7-day pethidine total cannot enter any 0–24-h analysis; it would be an individual estimate in native units.

### Fu 2024 — Heliyon 2024;10:e30012

- **Design and population:**
  - Randomised by computer with concealed numbers; participants, surgeons and the anaesthesia team masked.
  - TEAS (2/10 Hz, 6–15 mA, bilateral ST36 and SP6) vs electrodes on a disabled stimulator.
  - 60 Parkinson's patients aged 40–80; 59 analysed.
- **Anaesthesia:**
  - Stage 1 (electrode placement) was done awake under local anaesthesia.
  - Stage 2 (pulse generator) "was performed under standardized general anesthesia" with a laryngeal mask, sevoflurane,
    and propofol and remifentanil infusions (p3).
  - The intervention ran through stage 1 and the whole of stage 2.
- **Analgesia:** tramadol 50 mg IV if VAS > 4, in PACU or on the ward (p3); flurbiprofen at the end of surgery.
- **Results:**
  - Rescue analgesic incidence: 2 (6.7%) vs 6 (20.7%) (Table 4). The printed P < 0.001 is implausible for these counts.
  - VAS-p at POD1 (T1): median 5.0 (4.0–6.0) vs 6.0 (5.0–7.0) (Table 3).
  - Intraoperative remifentanil: 572.3 ± 82.0 vs 662 ± 148.2 µg.
  - QoR-15 (timing to check).
- **If included:**
  - Rescue receipt, TEAS vs sham (window not stated, like Yu 2020): the pooled rescue analysis becomes 7 trials.
  - Intraoperative remifentanil, TEAS vs sham (an empty cell becomes one trial).
  - Pain medians: descriptive only.

### Chen 2016 — Evid Based Complement Alternat Med 2016

- **Design:** EA (2 Hz, 3–5 mA; 6 × 30 min over 3 days) vs non-penetrating sham needles with no current, randomised by
  random-number table; 92 thoracic surgery patients under general anaesthesia.
- **Age:** inclusion "age 16–80 years" (p2); mean 55.8 ± 15.8 vs 56.9 ± 14.6.
- **Analgesia:** a fixed-rate fentanyl and flurbiprofen infusion in both arms. If VAS > 4, "1 mg/kg of sauteralgyl was
  injected intramuscularly" (p3). Sauteralgyl is a trade name for pethidine (meperidine)
  ([PharmaCompass](https://www.pharmacompass.com/price/meperidine-hydrochloride)).
- **Results:**
  - Pethidine over 72 h: 9.2 ± 2.8 vs 11.5 ± 1.8 mg/kg (p3; Fig. 2c). This is weight-normalised and cannot be converted
    to an absolute dose (Additional file 7).
  - VAS at 24 h: figure only (Fig. 2a).
- **If included:** hold from pooled analyses, as for Lee 2011 (aged 14–59). The only alternative under the adult
  criterion is exclusion for the wrong population.

### Tu 2018 — Exclude: wrong comparator

- Group T: TEAS plus placebo tablets twice daily.
- Group C: sham TEAS plus "tramadol hydrochloride tablets for postoperative analgesia, 100 mg, twice daily" (p3).
- So the comparison is TEAS against a scheduled opioid regimen; the stimulation effect cannot be separated, and the
  tramadol outcome is fixed by design.

### Zhou 2025 (1879896127) — Exclude: no confirmed postoperative opioid result

- 2×2 factorial (acupoint dexamethasone injection × TEAS, each real or sham), 160 women aged 18–65, laparoscopic
  gynaecological surgery under general anaesthesia with TAP block.
- The only opioid figure is "Perioperative opioid consumption, mean (SD), mg" in morphine equivalents, in the baseline
  table (Table 1).
- Pain at rest and on movement at 24 h are reported. This is the kind of result lost to the 9 October criterion; see D6.

### Li 2017 — Exclude: no confirmed postoperative opioid result

- EA within 24 h before surgery vs usual care; 40 women, gynaecological laparoscopy under general anaesthesia.
- "Analgesics 0–48 h after surgery: 0 (0) vs 0 (0)", drug not named. Intraoperative sufentanil only; parecoxib routine.

### Zhang 2022 — Exclude: original reason supported

- "Postoperative opioid dosage, intravenous morphine equivalents, median (IQR)": 110 (90–110) vs 110 (90–110) mg, over a
  PCIA "for 24–48 h postoperatively, as necessary" (Table 1).
- NRS pain median 5 (4–6) in both arms, time not stated (Table 2).

### Poulain 1997 — Exclude: original reason supported

- Control: narcotic analgesia during surgery and non-narcotic analgesics afterwards.
- Study group: EA during surgery and TENS afterwards.
- Table 7: complaining of pain 81% vs 75%; requiring analgesics 26% vs 18% (over 5 days). Fentanyl: all control vs 5%
  of study patients, intraoperatively (Table 5).

## What changes if the proposals are accepted

**Inclusions (Colak 2010, Fu 2024, and Chen 2016 held):**
- 44 reports and 43 trials. Participants rise by 30 + 60 + 92 = 182 randomised.
- Each needs:
  - extraction, RoB 2 and GRADE for every result it enters (SKP to review);
  - Table 1 rows, references and Figs. 1–3;
  - refits: EA vs usual-care pain (new), rescue receipt (7 trials), intraoperative remifentanil (new).

**Exclusions:**
- The original "no eligible analgesic outcome" reason is supported for 2 (Zhang 2022, Poulain 1997).
- 3 are relabelled: Tu 2018 to wrong comparator; Zhou 2025 and Li 2017 to no confirmed postoperative opioid result.
- These feed D4, which tallies the relabels once D3 is decided.
