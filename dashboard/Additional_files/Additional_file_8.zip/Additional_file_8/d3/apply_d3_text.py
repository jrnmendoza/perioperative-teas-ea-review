"""Decision D3 (review owner, 2 Nov 2026): apply the membership decisions to the manuscript sources.

Included: Colak 2010 (EA vs usual care), Fu 2024 (TEAS vs sham) and Chen 2016 (EA vs sham; held from pooling, ages
16-80, as Lee 2011). Excluded: Tu 2018 (relabelled wrong comparator), Zhou 2025 [1879896127] and Li 2017 (relabelled no
confirmed postoperative opioid result), Zhang 2022 and Poulain 1997 (original reason supported). Evidence:
recheck/D3_membership_dossier.md; records: d3/. Estimates from wang1997/models_with_wang.csv (refit_with_wang.R).

Run after recheck/apply_recheck_text.py, which rewrites sources/ from the pre-recheck snapshot; this script then edits
sources/ in place and asserts each passage once, so run the two together."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / 'sources'

EDITS = {
'results_REVISED.md': [
    ('Forty-one reports of 40 trials were included [', 'Forty-four reports of 43 trials were included ['),
    ('@inc_chen2020; @inc_gao2022;', '@inc_chen2020; @inc_fu2024; @inc_gao2022;'),
    ('@inc_an2014; @inc_coura2011;', '@inc_an2014; @inc_chen2016; @inc_colak2010; @inc_coura2011;'),
    ('no 24-hour opioid or pain outcome (112 reports), no confirmed postoperative opioid result (30) and no English full text (12).',
     'no 24-hour opioid or pain outcome (106 reports), no confirmed postoperative opioid result (32) and no English full text (12).'),
    ('[PROVISIONAL: The other eight, and 45 that could not be re-checked because no full text was held, await adjudication by the review team, and the counts, estimates and certainty ratings below may change (Additional files 2 and 4).]',
     'On the same date, after the other eight were reread, the review owner included three (Colak 2010, Fu 2024 and Chen 2016) and kept five excluded: the recorded reason was supported for two, one had the wrong comparator (Tu 2018, whose control arm alone received scheduled tramadol) and two had no confirmed postoperative opioid result. [PROVISIONAL: 45 outcome exclusions could not be re-checked because no full text was held, and eight with a keyword signal have not been read in full; the counts, estimates and certainty ratings below may change (Additional files 2 and 4).]'),
    ('the 40 trials randomised 7,521 participants (7,611 across the 41 reports). Eligibility was not fully confirmed for three reports, which were retained but not pooled: Lee 2011 enrolled participants aged 14–59 years, general anaesthesia',
     'the 43 trials randomised 7,703 participants (7,793 across the 44 reports). Eligibility was not fully confirmed for four reports, which were retained but not pooled: Lee 2011 enrolled participants aged 14–59 years, Chen 2016 enrolled participants aged 16–80 years, general anaesthesia'),
    ('Twenty-seven evaluated TEAS, 13 evaluated EA and one could not be classified (Long 2025). Thirty-three reports came from Asia: China (25),',
     'Twenty-eight evaluated TEAS, 15 evaluated EA and one could not be classified (Long 2025). Thirty-five reports came from Asia: China (27),'),
    ('The remaining eight came from the USA (3), Brazil, Greece, Poland, Turkey and the UK (one each). The median trial randomised 89 participants (range 20 to 1,948). Thirty-three reports included a sham arm. Of the other eight, six compared',
     'The remaining nine came from the USA (3), Turkey (2), and Brazil, Greece, Poland and the UK (one each). The median trial randomised 88 participants (range 20 to 1,948). Thirty-five reports included a sham arm. Of the other nine, seven compared'),
    ('Seven reports stated a tertiary setting, 12 named a university', 'Seven reports stated a tertiary setting, 15 named a university'),
    ('was described in 12 reports, including Szmit 2021,', 'was described in 14 reports, including Szmit 2021,'),
    ('No routine non-opioid component was described in 26 reports,', 'No routine non-opioid component was described in 27 reports,'),
    ('Forty reports used at least one of PC6 (29 reports), ST36 (25) or LI4 (24);',
     'Forty-two reports used at least one of PC6 (30 reports), ST36 (27) or LI4 (25);'),
    ('2/100 Hz in 16 reports and 2/10 Hz in nine.', '2/100 Hz in 16 reports and 2/10 Hz in ten.'),
    ('Stimulation was given postoperatively only in 13 reports, preoperatively only in seven, intraoperatively only in five and',
     'Stimulation was given postoperatively only in 15 reports, preoperatively only in seven, intraoperatively only in six and'),
    ('Twenty reports used a single session: nine of 30 minutes, nine continuous through surgery',
     'Twenty-one reports used a single session: nine of 30 minutes, ten continuous through surgery'),
    ('Although all 41 reports contained postoperative opioid data', 'Although all 44 reports contained postoperative opioid data'),
    ('seven to rescue opioid receipt and 12 to nausea and vomiting. Thirty-three reports contributed to at least one main analysis, most to only one or two outcome domains. Eight contributed',
     'eight to rescue opioid receipt and 12 to nausea and vomiting. Thirty-five reports contributed to at least one main analysis, most to only one or two outcome domains. Nine contributed'),
    ('Of 164 assessed results, two (1%) were at low risk of bias, 118 (72%) had some concerns and 44 (27%) were at high risk (Fig. 3).',
     'Of 169 assessed results, two (1%) were at low risk of bias, 122 (72%) had some concerns and 45 (27%) were at high risk (Fig. 3). [PROVISIONAL: the five judgements for Colak 2010 and Fu 2024 are drafts awaiting second review.]'),
    ('Thirteen were rated high for outcome measurement', 'Fourteen were rated high for outcome measurement'),
    ('Almost every result (161 of 164)', 'Almost every result (166 of 169)'),
    ('Just over half (87) had some concerns about randomisation', 'Just over half (88) had some concerns about randomisation'),
    ('No eligible result was available for pain on movement or for EA.',
     'No eligible result was available for pain on movement. For EA, one usual-care-controlled trial reported resting pain on day 1 (Colak 2010; 30 participants): MD −0.20 points (−1.05 to 0.65); its upper limit excludes worsening of 1 point or more, but certainty is very low (one small unblinded trial). Its opioid result, a 7-day pethidine total, could not enter any 0–24-hour analysis.'),
    ('Six TEAS-versus-sham trials, five conducted in China and one in the USA, reported whether participants received rescue opioid (553 participants, 147 events). In this post-hoc exploratory analysis, fewer participants received rescue opioid with TEAS (risk ratio [RR] 0.52, 95% CI 0.37 to 0.74; I² = 0%; low certainty) (Fig. 5).',
     'Seven TEAS-versus-sham trials, six conducted in China and one in the USA, reported whether participants received rescue opioid (612 participants, 155 events). In this post-hoc exploratory analysis, fewer participants received rescue opioid with TEAS (risk ratio [RR] 0.51, 95% CI 0.37 to 0.71; I² = 0%; low certainty) (Fig. 5).'),
    ('and was not stated in one (Yu 2020); the five trials with stated follow-up gave RR 0.51 (0.32 to 0.81). At the observed comparator risk of 36.0%, the pooled ratio corresponds to about 17 fewer participants per 100 receiving rescue opioid (10 to 23 fewer);',
     'and was not stated in two (Yu 2020 and Fu 2024); the five trials with stated follow-up gave RR 0.51 (0.32 to 0.81). At the observed comparator risk of 34.5%, the pooled ratio corresponds to about 17 fewer participants per 100 receiving rescue opioid (10 to 22 fewer);'),
    ('Leave-one-out estimates ranged from 0.51 to 0.53. After excluding the two trials at high risk of bias, the RR was 0.53 (0.30 to 0.95; four trials, 318 participants).',
     'Leave-one-out estimates ranged from 0.50 to 0.52. After excluding the two trials at high risk of bias, the RR was 0.52 (0.32 to 0.84; five trials, 377 participants).'),
    ('to none in the sham arm gave RR 0.61 (0.45 to 0.85).', 'to none in the sham arm gave RR 0.61 (0.45 to 0.82).'),
    ('(QoR-40: MD 10.19 points, −13.26 to 33.63; QoR-15: MD 9.64 points, −57.20 to 76.47; two trials each; very low certainty).',
     '(QoR-40: MD 10.19 points, −13.26 to 33.63, two trials; QoR-15: MD 8.47 points, −5.18 to 22.12, three trials; very low certainty).'),
],
'methods_REVISED.md': [
    ('it was analysed only in the broader first-day analysis, as Chen 1998 was.',
     'it was analysed only in the broader first-day analysis, as Chen 1998 was. Three further reports from that recheck (Colak 2010 [@inc_colak2010], Fu 2024 [@inc_fu2024] and Chen 2016 [@inc_chen2016]) were included on the same date, when the review owner judged that they met both outcome requirements; five others remained excluded, three of them under a corrected reason.'),
    ('Lee 2011 [@inc_lee2011] enrolled participants aged 14–59 years and was held from all pooled analyses; general anaesthesia',
     'Lee 2011 [@inc_lee2011] enrolled participants aged 14–59 years and was held from all pooled analyses; Chen 2016 enrolled participants aged 16–80 years and was held in the same way; general anaesthesia'),
    ('and the narrative outcome tables were checked by a second reviewer (SKP).',
     'and the narrative outcome tables were checked by a second reviewer (SKP). [PROVISIONAL: SKP has not yet checked the extraction for Colak 2010, Fu 2024 and Chen 2016, added on 2 November 2026.]'),
    ('checked and confirmed by a second reviewer (SKP).',
     'checked and confirmed by a second reviewer (SKP). [PROVISIONAL: the assessments for Colak 2010 and Fu 2024, drafted on 2 November 2026, await this check.]'),
    ('and all of them were recomputed in an independent re-check.',
     'and all of them were recomputed in an independent re-check. The refits after the inclusion of Colak 2010 and Fu 2024 were run in R, and the pooled rescue model was also reproduced in Stata; these refits have not been independently re-checked.'),
],
'abstract_REVISED.md': [
    ('Forty-one reports of 40 trials (7,521 participants) were included.', 'Forty-four reports of 43 trials (7,703 participants) were included.'),
    ("(risk ratio 0.52, 0.37 to 0.74; six trials, 553 participants; exploratory; low certainty)",
     "(risk ratio 0.51, 0.37 to 0.71; seven trials, 612 participants; exploratory; low certainty)"),
    ('Of 164 assessed results, 27% were at high risk of bias.', 'Of 169 assessed results, 27% were at high risk of bias.'),
    ('[PROVISIONAL: eight historically excluded reports may meet both full-text outcome requirements and await adjudication by the review team; the counts and estimates above may change.]',
     '[PROVISIONAL: 53 historically excluded reports (45 without a local full text and eight not yet read in full) have not been re-checked against both full-text outcome requirements, and the assessments for two reports included on 2 November 2026 await second review; the counts and estimates above may change.]'),
],
'discussion_REVISED.md': [
    ('In 41 reports of 40 randomised trials,', 'In 44 reports of 43 randomised trials,'),
    ('The one rest-pain result came from a different trial,', 'The one TEAS rest-pain result came from a different trial,'),
    ('[PROVISIONAL: the selection question in the Results (eight historically excluded reports awaiting adjudication) could add trials to these analyses.]',
     '[PROVISIONAL: the historically excluded reports not yet re-checked (Results) could add trials to these analyses.]'),
    ('Five of the six trials were conducted in China, follow-up ranged from 6 hours to 3 days and was not stated in one trial,',
     'Six of the seven trials were conducted in China, follow-up ranged from 6 hours to 3 days and was not stated in two trials,'),
    ('the estimate was similar (RR 0.53, 0.30 to 0.95),', 'the estimate was similar (RR 0.52, 0.32 to 0.84),'),
    ('All 41 reports contained postoperative opioid data', 'All 44 reports contained postoperative opioid data'),
    ('Trials that randomised 7,521 participants', 'Trials that randomised 7,703 participants'),
    ('Routine multimodal analgesia was described in 12 reports,', 'Routine multimodal analgesia was described in 14 reports,'),
    ('no routine non-opioid component was described in 26.', 'no routine non-opioid component was described in 27.'),
    ('Of 164 assessed results, 27%', 'Of 169 assessed results, 27%'),
    ('PC6 was stimulated in 29 of the 41 reports.', 'PC6 was stimulated in 30 of the 44 reports.'),
    ('Thirty-three of the 41 reports came from Asia, 25 of them from China, and five of the six TEAS rescue trials',
     'Thirty-five of the 44 reports came from Asia, 27 of them from China, and six of the seven TEAS rescue trials'),
    ('One gave an eligible result for rest pain and none for pain on movement at about 24 hours; eight measured quality of recovery',
     'Two gave an eligible result for rest pain (one TEAS and one EA trial) and none for pain on movement at about 24 hours; nine measured quality of recovery'),
    ('one was included and eight await adjudication, and 45 excluded reports could not be re-checked.',
     'four were included and five remained excluded, three under a corrected reason; 45 excluded reports could not be re-checked and eight have not been read in full.'),
    ('and the inclusion of Wang 1997 and its assignment to the broader analysis.',
     'the inclusion of Wang 1997 and its assignment to the broader analysis, and the inclusion of three further reports after the recheck.'),
],
'conclusions_REVISED.md': [
    ('[PROVISIONAL: pending adjudication of eight historically excluded reports.]',
     '[PROVISIONAL: pending a re-check of 53 historically excluded reports and second review of the assessments for Colak 2010 and Fu 2024.]'),
],
'table2_REVISED.md': [
    ('| Rest pain, ~24 h (co-primary) | TEAS vs sham | 1 (60) | MD −1.03 points (−1.80 to −0.26) | Moderate* |',
     '| Rest pain, ~24 h (co-primary) | TEAS vs sham | 1 (60) | MD −1.03 points (−1.80 to −0.26) | Moderate* |\n'
     '|  | EA vs usual care | 1 (30) | MD −0.20 points (−1.05 to 0.65) | Very low* |'),
    ('| TEAS vs sham | 6 (553) | RR 0.52 (0.37 to 0.74); 17 fewer per 100 (10 to 23 fewer)‡ | Low |',
     '| TEAS vs sham | 7 (612) | RR 0.51 (0.37 to 0.71); 17 fewer per 100 (10 to 22 fewer)‡ | Low |'),
    ('*Certainty that TEAS does not worsen pain by 1 point or more; this result comes from a different trial from the primary opioid result.',
     '*Certainty that the intervention does not worsen pain by 1 point or more; neither result comes from a trial that reported the primary opioid outcome.'),
    ("over each trial's own follow-up (not stated in one trial); excluding the two trials at high risk of bias gave RR 0.53 (0.30 to 0.95).",
     "over each trial's own follow-up (not stated in two trials); excluding the two trials at high risk of bias gave RR 0.52 (0.32 to 0.84)."),
    ('(36.0% for rescue, 34.1% for PONV)', '(34.5% for rescue, 34.1% for PONV)'),
    ('[PROVISIONAL: estimates may change after adjudication of eight historically excluded reports.]',
     '[PROVISIONAL: estimates may change after a re-check of 53 historically excluded reports; certainty ratings for analyses that include Colak 2010 or Fu 2024 are drafts awaiting second review.]'),
],
'figures_REVISED.md': [
    ('Reasons are as recorded at screening, except for Wang 1997, which was included after a later check; that check found further reports in this category with a 24-hour pain or postoperative opioid result, which await adjudication (Additional file 4).',
     'Reasons are as recorded at screening, except for four reports included after a later check (Wang 1997, Colak 2010, Fu 2024 and Chen 2016) and three whose reason that check corrected (Additional file 4).'),
    ('none was located in the available report for 18, and for 12 the opioid identity, quantity or timing could not be confirmed',
     'none was located in the available report for 18, and for 14 the opioid identity, quantity or timing could not be confirmed'),
    ('across all 164 assessed results.',
     'across all 169 assessed results. † Draft judgement for Fu 2024 (included 2 November 2026), awaiting second review [PROVISIONAL].'),
    ('Five of the six trials were conducted in China and one in the USA. Follow-up was 6–24 hours, 24 hours, through the first postoperative day, 48 hours or 3 days, and was not stated in Yu 2020,',
     'Six of the seven trials were conducted in China and one in the USA. Follow-up was 6–24 hours, 24 hours, through the first postoperative day, 48 hours or 3 days, and was not stated in Yu 2020 or Fu 2024,'),
],
}

for name, edits in EDITS.items():
    p = SRC / name
    s = p.read_text(encoding='utf-8')
    for old, new in edits:
        assert s.count(old) == 1, (name, old[:70], s.count(old))
        s = s.replace(old, new)
    p.write_text(s, encoding='utf-8')

# The Additional-file descriptions are not rewritten by apply_recheck_text.py, so this edit is made once and then checked.
p = SRC / 'additional_files_REVISED.csv'
s = p.read_text(encoding='utf-8')
old, new = 'stimulation-protocol characteristics of the 41 reports."', 'stimulation-protocol characteristics of the 44 reports."'
assert s.count(old) + s.count(new) == 1, 'AF8 description not found'
p.write_text(s.replace(old, new), encoding='utf-8')
print(sum(len(e) for e in EDITS.values()), 'D3 replacements in', len(EDITS), 'files; AF8 description checked')
