"""Decision D3 (review owner, 2 Nov 2026): the eight remaining membership candidates from the outcome-exclusion recheck.
Included: Colak 2010 and Fu 2024. Included but held from pooled analyses: Chen 2016 (ages 16-80, as for Lee 2011).
Excluded: Tu 2018 (wrong comparator), Zhou 2025 [1879896127] and Li 2017 (no confirmed postoperative opioid result),
Zhang 2022 and Poulain 1997 (original reason supported). Evidence: recheck/D3_membership_dossier.md.

Writes, in this folder: d3_decisions.csv, d3_results.csv, d3_characteristics.csv, d3_rob2_DRAFT.csv,
d3_grade_DRAFT.csv, d3_outcome_inventory.csv and prisma_counts_current.json. The extraction, RoB 2 and GRADE are AI drafts
awaiting SKP's review.

After Astra's audit of the D3 build (3 Nov 2026; ASTRA_recheck_2026-11-02/AUDIT_OF_CLAUDE_REVISION_2026-11-02.md, findings
4-6): Fu 2024 locators corrected (Tables 3 and 4 are on pp6-7); Fu stimulation recorded as paused during microelectrode
recording (p3); Chen 2016's 16-80 years recorded as its eligible range (p2); the results at the other registered windows
added (Colak rest pain on days 2-7 and 7-day metamizole; Fu QoR-15 on day 7 and pain medians on days 3 and 7), with
RoB 2 drafts for every result that enters an estimate and GRADE drafts where comparable bodies are graded; and an inventory
giving the disposition of every result each D3 report gives. Pre-audit outputs: audit_d3/pre_audit/d3/.

After Astra's re-audit (3 Nov 2026; ASTRA_D3_audit_2026-11-03/, findings R03 and R06-R09): Fu 2024 randomisation drafted
Some concerns (sealed envelopes without opacity or sequential numbering, as Xiong 2021) and QoR-15 measurement Some
concerns (awake participants given current at the maximum tolerated intensity against a disabled stimulator, as Gu 2019
and Yao 2015); GRADE imprecision reasons state the rule applied; Chen 2016 defecation added and its pethidine text/figure
conflict recorded; the inventory lists Colak's atelectasis and every Chen 2016 result; characteristics complete from the
sources. Pre-re-audit outputs: reaudit_d3/pre_reaudit/d3/."""
import csv, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
SRC = '10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/'
SHA = {'Colak 2010': '', 'Fu 2024': '', 'Chen 2016': ''}
ST = 'AI draft (Claude), 2 Nov 2026 (decision D3); second review by SKP pending'
ST3 = 'AI draft (Claude), 3 Nov 2026 (decision D3, after Astra\'s audit); second review by SKP pending'
RV3 = '; revised 3 Nov 2026 after Astra\'s re-audit ({}), for consistency with confirmed assessments'
FU_P = ('The report\'s printed P values do not match its printed summaries, and two day-7 MMSE quartiles exceed the scale\'s '
        '30-point maximum (Additional file 5, Contradictions); whether its data can be relied on is for the second reviewer.')


def wr(name, rows):
    with open(HERE / name, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


import hashlib
for rep, cid in (('Colak 2010', '1879897298'), ('Fu 2024', '1879896270'), ('Chen 2016', '1879896981')):
    SHA[rep] = hashlib.sha256((REV.parents[2] / SRC / f'{cid}.pdf').read_bytes()).hexdigest()

D = [
 ('1879897298', 'Colak 2010', 'Include', 'Meets both outcome requirements (day-1 resting VAS; 7-day pethidine). Random allocation by random-number tables despite the "case-control" label; CABG with extubation establishes general anaesthesia.'),
 ('1879896270', 'Fu 2024', 'Include', 'Meets both outcome requirements (POD1 VAS; rescue IV tramadol receipt). TEAS vs sham; stage 2 of DBS under general anaesthesia, intervention through both stages (paused during microelectrode recording; descriptor corrected 3 Nov 2026).'),
 ('1879896981', 'Chen 2016', 'Include, held from pooled analyses', 'Meets both outcome requirements (VAS at 24 h; rescue pethidine, trade name Sauteralgyl). Eligible ages 16-80: adult status not established, as for Lee 2011.'),
 ('1879896817', 'Tu 2018', 'Exclude: wrong comparator', 'Control arm alone received scheduled oral tramadol 100 mg twice daily; TEAS arm received placebo tablets.'),
 ('1879896127', 'Zhou 2025 (1879896127)', 'Exclude: no confirmed postoperative opioid result', 'Only "perioperative opioid consumption" in morphine equivalents (baseline table).'),
 ('1879896900', 'Li 2017', 'Exclude: no confirmed postoperative opioid result', '"Analgesics 0-48 h" 0 vs 0, drug not named; parecoxib routine.'),
 ('1879896437', 'Zhang 2022', 'Exclude: original reason supported', 'Opioid only as medians over a 24-48 h PCIA; NRS time not stated.'),
 ('1881841314', 'Poulain 1997', 'Exclude: original reason supported', 'Postoperative analgesics non-narcotic; fentanyl intraoperative only; no pain at about 24 h.'),
]
wr('d3_decisions.csv', [dict(covidence_id=c, report=r, decision=d, basis=b, decided_by='Review owner, 2 Nov 2026 (D3), from recheck/D3_membership_dossier.md')
                        for c, r, d, b in D])

R = [
 # result_id, report, outcome, window, unit, comparison, n_i, mean_i/events_i, sd_i, n_c, mean_c/events_c, sd_c, data_type, location, source text, use
 ('COLAK10-VAS-D1', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 1', 'points (0-100)', 'EA vs usual care', 15, 50.33, 7.19, 15, 52.33, 15.22, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 1 52.33±15.22 [control] 50.33±7.19 [acupuncture]; pain evaluated at rest (Methods p8)', 'pain24_rest_EA_usual (divided by 10)'),
 ('COLAK10-VAS-D2', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 2', 'points (0-100)', 'EA vs usual care', 15, 33.33, 7.72, 15, 39.67, 13.43, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 2 39.67±13.43 [control] 33.33±7.72 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY2_EA_USUAL (about 48 h; divided by 10; single trial)'),
 ('COLAK10-VAS-D3', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 3', 'points (0-100)', 'EA vs usual care', 15, 21.67, 5.56, 15, 33.33, 14.96, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 3 33.33±14.96 [control] 21.67±5.56 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY3_EA_USUAL (about 72 h; divided by 10; single trial)'),
 ('COLAK10-VAS-D4', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 4', 'points (0-100)', 'EA vs usual care', 15, 18.33, 5.56, 15, 26.67, 13.45, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 4 26.67±13.45 [control] 18.33±5.56 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY4_EA_USUAL (divided by 10; single trial)'),
 ('COLAK10-VAS-D5', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 5', 'points (0-100)', 'EA vs usual care', 15, 11.00, 3.87, 15, 26.67, 17.59, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 5 26.67±17.59 [control] 11.00±3.87 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY5_EA_USUAL (divided by 10; single trial)'),
 ('COLAK10-VAS-D6', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 6', 'points (0-100)', 'EA vs usual care', 15, 10.67, 4.17, 15, 26.00, 17.65, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 6 26.00±17.65 [control] 10.67±4.17 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY6_EA_USUAL (divided by 10; single trial)'),
 ('COLAK10-VAS-D7', 'Colak 2010', 'Pain at rest, VAS 0-100', 'Postoperative day 7', 'points (0-100)', 'EA vs usual care', 15, 9.33, 1.76, 15, 23.33, 20.59, 'mean (SD)',
  'Table 1, p9', 'VAS* ... Day 7 23.33±20.59 [control] 9.33±1.76 [acupuncture]; pain evaluated at rest (Methods p8)', 'COLAK_PAIN_DAY7_EA_USUAL (longest reported acute time point; divided by 10; single trial)'),
 ('COLAK10-PETH-7D', 'Colak 2010', 'Pethidine, total', 'Postoperative days 0-7', 'mg pethidine', 'EA vs usual care', 15, 76.67, 84.23, 15, 223.33, 132.10, 'mean (SD)',
  'Table 1, p9; analgesia on request during the first 7 days (Methods p8)', 'Pethidine (mg)* 223.33±132.10 [control] 76.67±84.23 [acupuncture]',
  'Single-trial estimate in native units (longest reported acute interval, 0-7 days; not a 0-24-h analysis)'),
 ('COLAK10-METAM-7D', 'Colak 2010', 'Metamizole sodium, total (first-line analgesic on request)', 'Postoperative days 0-7', 'g metamizole', 'EA vs usual care', 15, 0.53, 0.51, 15, 2.0, 0.73, 'mean (SD)',
  'Table 1, p9; analgesia on request during the first 7 days (Methods p8)', 'Metamizole (g)* 2.0±0.73 [control] 0.53±0.51 [acupuncture]',
  'RESCUE_METAMIZOLE_7D_EA_USUAL (rescue analgesia, non-opioid, native units; single trial)'),
 ('FU24-RESCUE', 'Fu 2024', 'Patients given rescue analgesic (IV tramadol 50 mg if VAS > 4)', 'Postoperative; period not stated', 'patients', 'TEAS vs sham', 30, 2, '', 29, 6, '', 'events',
  'Table 4, p7; Results, p7; rescue protocol p3', 'Incidence of Rescue Analgesic n (%) 2 (6.7) [TEAS] 6 (20.7) [Con]', 'Rescue opioid receipt (window not stated, as Yu 2020)'),
 ('FU24-REMI', 'Fu 2024', 'Intraoperative remifentanil, stage 2', 'Intraoperative', 'µg remifentanil', 'TEAS vs sham', 30, 572.3, 82.0, 29, 662.0, 148.2, 'mean (SD)',
  'Table 4, p7', 'Remifentanil dosage (μg) 572.3 ± 82.0 [TEAS] 662 ± 148.2 [Con]', 'intraop_remifentanil_TEAS_sham (native units)'),
 ('FU24-QOR-T1', 'Fu 2024', 'QoR-15', 'Postoperative day 1 (T1)', 'QoR-15 points', 'TEAS vs sham', 30, 118.4, 3.5, 29, 112.0, 4.8, 'mean (SD)',
  'Table 3, p6', 'QOR-15 ... T1 118.4 ± 3.5 [TEAS] 112 ± 4.8 [Con]', 'QoR15_SHAM_24H'),
 ('FU24-QOR-T2', 'Fu 2024', 'QoR-15', 'Postoperative day 3 (T2)', 'QoR-15 points', 'TEAS vs sham', 30, 125.5, 4.9, 29, 119.1, 4.6, 'mean (SD)',
  'Table 3, p6', 'QOR-15 ... T2 125.5 ± 4.9 [TEAS] 119.1 ± 4.6 [Con]', 'QoR15_SHAM_POD3'),
 ('FU24-QOR-T3', 'Fu 2024', 'QoR-15', 'Postoperative day 7 (T3)', 'QoR-15 points', 'TEAS vs sham', 30, 134.9, 6.1, 29, 125.8, 4.5, 'mean (SD)',
  'Table 3, p6', 'QOR-15 ... T3 134.9 ± 6.1 [TEAS] 125.8 ± 4.5 [Con]', 'QoR15_SHAM_POD7 (single trial)'),
 ('FU24-VAS-T1', 'Fu 2024', 'Pain, VAS-p (rest or movement not stated)', 'Postoperative day 1 (T1)', 'points (0-10)', 'TEAS vs sham', 30, '5.0 (4.0-6.0)', '', 29, '6.0 (5.0-7.0)', '', 'median (IQR)',
  'Table 3, p6', 'VAS-p T1 5.0 (4.0,6.0) [TEAS] 6.0 (5.0,7.0) [Con]', 'Descriptive only (medians are not converted)'),
 ('FU24-VAS-T2', 'Fu 2024', 'Pain, VAS-p (rest or movement not stated)', 'Postoperative day 3 (T2)', 'points (0-10)', 'TEAS vs sham', 30, '3.0 (2.0-3.0)', '', 29, '4.0 (3.0-4.0)', '', 'median (IQR)',
  'Table 3, p6', 'VAS-p T2 3.0 (2.0,3.0) [TEAS] 4.0 (3.0,4.0) [Con]', 'Descriptive only (medians are not converted)'),
 ('FU24-VAS-T3', 'Fu 2024', 'Pain, VAS-p (rest or movement not stated)', 'Postoperative day 7 (T3)', 'points (0-10)', 'TEAS vs sham', 30, '1.0 (1.0-2.0)', '', 29, '1.0 (1.0-2.0)', '', 'median (IQR)',
  'Table 3, p6', 'VAS-p T3 1.0 (1.0,2.0) [TEAS] 1.0 (1.0,2.0) [Con]', 'Descriptive only (medians are not converted)'),
 ('CHEN16-PETH-72', 'Chen 2016', 'Pethidine (Sauteralgyl) rescue, total', '0-72 h', 'mg/kg', 'EA vs sham', 46, 9.2, 2.8, 46, 11.5, 1.8, 'mean (SD)',
  'Results p3 (values used); Fig. 2c p4 contradicts them', 'The total dose of supplementary sauteralgyl was 9.2 ± 2.8 mg/kg in the EA group and 11.5 ± 1.8 mg/kg in the sham group',
  'Held (ages 16-80); weight-normalised, not convertible. Fig. 2c plots about 3.7 vs 4.6 mg/kg on a 0-6 mg/kg axis, which cannot show these means (Additional file 5); the text is recorded, the figure not read'),
 ('CHEN16-VAS-24', 'Chen 2016', 'Pain, VAS (rest or movement not stated)', '24 h', 'points (0-10)', 'EA vs sham', 46, 'figure only', '', 46, 'figure only', '', 'figure',
  'Fig. 2a, p4', 'VAS at 24 h shown in Fig. 2a only', 'Held'),
 ('CHEN16-NV', 'Chen 2016', 'Nausea; vomiting', 'Postoperative (period not stated)', 'patients', 'EA vs sham', 46, '10; 3', '', 46, '22; 5', '', 'events',
  'Table 2, p4', 'Nausea 10 (21.7%) vs 22 (47.8%); Vomiting 3 (6.5%) vs 5 (10.9%)', 'Held'),
 ('CHEN16-FLATUS', 'Chen 2016', 'Time to first flatus', 'Postoperative', 'hours', 'EA vs sham', 46, 24.3, 8.2, 46, 35.7, 7.76, 'mean (SD)',
  'Table 2, p4', 'Flatus (h) 24.3 ± 8.2 vs 35.7 ± 7.76', 'Held'),
 ('CHEN16-DEFEC', 'Chen 2016', 'Time to first defecation', 'Postoperative', 'hours', 'EA vs sham', 46, 42.7, 13.9, 46, 59.2, 11.3, 'mean (SD)',
  'Table 2, p4', 'Defecation (h) 42.7 ± 13.9 vs 59.2 ± 11.3', 'Held'),   # added 3 Nov 2026 (Astra's re-audit, R07)
]
cols = ['result_id', 'report', 'outcome', 'window', 'unit', 'comparison', 'n_i', 'value_i', 'sd_i', 'n_c', 'value_c', 'sd_c', 'data_type',
        'source_location', 'source_text', 'use']
wr('d3_results.csv', [dict(zip(cols, r), source_sha256=SHA[r[1]]) for r in R])

C = [
 dict(report='Colak 2010', covidence_id='1879897298', pmid='20677584', country='Turkey', setting='University', setting_basis='Department of Cardiovascular Surgery, Firat University Faculty of Medicine, Elazig (Methods p8)',
      surgery='Thoracic & Cardiac', procedure='CABG via median sternotomy', n='30 (15/15)', analysed='30 (15/15)', age='52/52', female='37',
      modality='EA', comparator='Usual care', acupoints='LI4, LI11, ST36, PC6, LR3', frequency='60 Hz', timing='Post; 7 × 20 min (daily)',
      mma='No', mma_basis='Pethidine and metamizole only on request (rescue)', anaesthesia='Not described; CABG with extubation at 8.1 ± 2.2 h (Table 1) implies general anaesthesia',
      design_note='Called "case-control" but randomised by tables of random numbers (Methods p8)', held=''),
 dict(report='Fu 2024', covidence_id='1879896270', pmid='38707419', country='China', setting='University', setting_basis='The First Hospital of the University of Science and Technology of China (Anhui Provincial Hospital) (author affiliation; Results p5)',
      surgery='Neurosurgery', procedure='Two-stage subthalamic deep brain stimulation for Parkinson disease', n='60 (30/29)', analysed='59 (30/29)', age='61/62', female='39',
      modality='TEAS', comparator='Sham', acupoints='Bilateral ST36, SP6', frequency='2/10 Hz', timing='Intra; 1 through both stages, paused during microelectrode recording (p3)',
      mma='Yes', mma_basis='Flurbiprofen 100 mg IV at the end of surgery to all (p3)', anaesthesia='Stage 1 awake with local anaesthesia; stage 2 general anaesthesia with laryngeal mask (p3)',
      design_note='One control participant withdrew (Fig. 2)', held=''),
 dict(report='Chen 2016', covidence_id='1879896981', pmid='27073400', country='China', setting='University', setting_basis='Shuguang Hospital Affiliated to Shanghai University of Traditional Chinese Medicine (Methods p2)',
      surgery='Thoracic & Cardiac', procedure='Thoracic surgery', n='92 (46/46)', analysed='92 (46/46)', age='56/57', female='26',
      modality='EA', comparator='Sham', acupoints='Bilateral LR3, GB34, TE5, LU5', frequency='2 Hz', timing='Post; 6 × 30 min (every 12 h for 3 days)',
      mma='Yes', mma_basis='Fixed-rate IV infusion of fentanyl with flurbiprofen in both arms (p3)', anaesthesia='General anaesthesia (inclusion criterion, p2)',
      design_note='Eligible ages 16-80 (inclusion criteria, p2): held from pooled analyses (adult status not established)', held='yes'),
]
# 3 Nov 2026 (Astra's re-audit, R09): the remaining characteristics fields, from the sources; NR where the report gives nothing
MORE = {
 'Colak 2010': dict(setting_page='8', bmi='Not reported', asa='Not reported', intervention_arms='EA plus on-request analgesia (15)',
      control_arms='On-request analgesia alone (15)', intensity='Adjusted to a strong but comfortable tingling sensation (current not reported)',
      sessions='First session about 2 h after extubation, then daily after a 24-h rest interval through postoperative day 7 (p8); exact total not stated (Table 1 gives 7)',
      session_duration='20 min', cumulative_duration='About 140 min if 7 sessions (exact number not stated)', timing_category='Postoperative only',
      planned_minutes_24='20', coding_note='First session about 10 h after surgery (extubation at 8.1 ± 2.2 h, session about 2 h later); the 24-h rest interval places the next one after 24 h. Planned schedule, not measured adherence.',
      postop_analgesia='On request in both arms for 7 days: metamizole 1 g IV first, pethidine 0.2 mg/kg IV if pain was not controlled with metamizole (p8)',
      pca='None described', rescue='Metamizole 1 g IV on request; pethidine 0.2 mg/kg IV if pain was not controlled with metamizole (p8)',
      mma_quote='Patients could request further analgesia (pethidine hydrochloride [HCL] 0.2 mg/kg intravenously [IV] and metamizole sodium, 1 g IV) if necessary during the first 7 postoperative days.',
      mma_page='8'),
 'Fu 2024': dict(setting_page='1', bmi='TEAS 23.7 (3.2); control 22.9 (2.9) kg/m² (mean, SD; Table 2)', asa='II–III (TEAS 24/6, control 22/7; Table 2)',
      intervention_arms='TEAS at bilateral ST36 and SP6 during both surgical stages (30)', control_arms='Same electrodes connected to a disabled stimulator (30 randomised, 29 analysed)',
      intensity='Maximum tolerated, 6–15 mA (p3)', sessions='1, from the start of stage 1 through stage 2, paused during microelectrode recording (p3)',
      session_duration='Not reported (operating time is not stimulation time)', cumulative_duration='Not reported', timing_category='Intraoperative only',
      planned_minutes_24='Not determinable from current source schedule',
      coding_note='Stage 1 was done awake under local anaesthesia; active stimulation time cannot be derived from the surgery or anaesthesia durations.',
      postop_analgesia='Flurbiprofen ester 100 mg IV at the end of surgery to all; tramadol 50 mg IV if VAS > 4 in the PACU or on the ward (p3)',
      pca='None described', rescue='Tramadol 50 mg IV if VAS > 4 (p3)',
      mma_quote='At the end of surgery, IV palonosetron 0.1 mg and flurbiprofen ester 100 mg were administered to prevent PONV and postoperative pain, respectively.',
      mma_page='3'),
 'Chen 2016': dict(setting_page='2', bmi='Not reported (weight 63.0 (8.0) vs 60.5 (7.8) kg; Table 1)', asa='I–II (inclusion criterion, p2)',
      intervention_arms='EA at bilateral LR3, GB34, TE5 and LU5 (46)', control_arms='Sham: needles taped at similar acupoints without skin penetration; electrodes connected, no current (46)',
      intensity='3–5 mA, by tolerance (p3)', sessions='6, every 12 h for 3 days, starting 1 h after surgery (p2)', session_duration='30 min',
      cumulative_duration='180 min', timing_category='Postoperative only', planned_minutes_24='60',
      coding_note='Sessions at about 1, 13, 25, 37, 49 and 61 h after surgery; planned schedule, not measured adherence.',
      postop_analgesia='IV infusion of fentanyl 250 µg and flurbiprofen 25 mg in 100 mL at 2 mL/h (half the usual concentration) in both arms (p3)',
      pca='Fixed-rate infusion at 2 mL/h; no demand bolus described', rescue='Pethidine (Sauteralgyl) 1 mg/kg IM if VAS > 4 despite the infusion (p3)',
      mma_quote='In this study, the half dose of the conventional drug concentration, 250 μg of Fentanyl and 25 mg of Flurbiprofen, was used.',
      mma_page='3'),
}
for c in C:
    c.update(MORE[c['report']])
wr('d3_characteristics.csv', C)

D1C = 'Randomised by "Tables of Random Numbers" (Methods p8); allocation concealment not described; the report also calls the design "case-control". Age and sex similar (Table 1).'
D1F = ('Computer-generated randomisation table prepared by another investigator; each number concealed in a sealed envelope opened only by the '
       'acupuncturist on the day of intervention (p2). Opacity and sequential numbering are not described, so concealment is not fully '
       'documented (as Xiong 2021). Baseline characteristics similar (Table 2).')
D4FQ = ('Self-reported questionnaire. Participants were told they might not feel the stimulation (p2), but stage 1 was done awake with current '
        'raised to the maximum tolerated (6-15 mA) against a disabled stimulator (p3), and masking success was not checked (p8). '
        'Knowledge of allocation could influence the rating (as Gu 2019 and Yao 2015).')
D2F = 'Participants, neurosurgeons and the operating-room anaesthesia team masked (p2); control electrodes connected to a disabled stimulator (p3). No departures from the intended interventions reported.'
D3F = '59 of 60 randomised analysed; one control participant withdrew for personal reasons (Results p5; Fig. 2).'
D5F = 'No trial registration or prespecified analysis plan identified; outcomes reported for the stated time points.'
D2C = 'No sham; participants and the acupuncturist aware of allocation; analgesia on request in both arms; no deviations reported.'
D3C = '15 per arm in Table 1; no losses reported.'
D5C = 'No protocol or registration identified; pain reported at every stated day (Table 1).'
D4CP = 'Self-reported resting VAS by participants who knew whether they received EA.'
D4CA = ('Administered drug totals are recordable, but analgesia was given on request ("if necessary", Methods p8) by unmasked staff '
        'to participants who knew their allocation, so knowledge of allocation could influence it (as for Oztas 2019).')
RB = [
 ('D3-COLAK-PAIN-D1', 'COLAK10-VAS-D1', 'Colak 2010', 'Pain at rest (VAS)', 'Day 1', 'EA vs usual care', 'pain24_rest_EA_usual',
  [('Some concerns', D1C), ('Some concerns', 'No sham; participants and the acupuncturist aware of allocation; analgesia on request in both arms; no deviations reported.'),
   ('Low', '15 per arm in Table 1; no losses reported.'), ('High', 'Self-reported resting VAS by participants who knew whether they received EA.'),
   ('Some concerns', 'No protocol or registration identified; pain reported at every stated day (Table 1).')]),
 ('D3-FU-RESCUE', 'FU24-RESCUE', 'Fu 2024', 'Rescue analgesic (IV tramadol) receipt', 'Postoperative; period not stated', 'TEAS vs sham', 'Rescue opioid receipt',
  [('Some concerns', D1F), ('Low', D2F), ('Low', D3F),
   ('Low', 'Tramadol given by protocol when VAS > 4 (p3) by masked ward and PACU staff; a recorded event. The trigger is the '
           'participant\'s pain report, and masking success was not checked (p8); kept Low as for the identical VAS-triggered rules in '
           'Tu 2024 and Zhou 2025 (confirmed), a point for the second reviewer.'), ('Some concerns', D5F)]),
 ('D3-FU-REMI', 'FU24-REMI', 'Fu 2024', 'Intraoperative remifentanil (stage 2)', 'Intraoperative', 'TEAS vs sham', 'intraop_remifentanil_TEAS_sham',
  [('Some concerns', D1F), ('Low', D2F), ('Low', D3F), ('Low', 'Remifentanil titrated to a bispectral-index target by a masked anaesthesia team; dose recorded.'), ('Some concerns', D5F)]),
 ('D3-FU-QOR-T1', 'FU24-QOR-T1', 'Fu 2024', 'QoR-15', 'Postoperative day 1', 'TEAS vs sham', 'QoR15_SHAM_24H',
  [('Some concerns', D1F), ('Low', D2F), ('Low', D3F), ('Some concerns', D4FQ), ('Some concerns', D5F)]),
 ('D3-FU-QOR-T2', 'FU24-QOR-T2', 'Fu 2024', 'QoR-15', 'Postoperative day 3', 'TEAS vs sham', 'QoR15_SHAM_POD3',
  [('Some concerns', D1F), ('Low', D2F), ('Low', D3F), ('Some concerns', D4FQ), ('Some concerns', D5F)]),
 # 3 Nov 2026 (after Astra's audit): every further D3 result that enters an estimate
 ('D3-COLAK-PAIN-D2', 'COLAK10-VAS-D2', 'Colak 2010', 'Pain at rest (VAS)', 'Day 2', 'EA vs usual care', 'COLAK_PAIN_DAY2_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PAIN-D3', 'COLAK10-VAS-D3', 'Colak 2010', 'Pain at rest (VAS)', 'Day 3', 'EA vs usual care', 'COLAK_PAIN_DAY3_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PAIN-D4', 'COLAK10-VAS-D4', 'Colak 2010', 'Pain at rest (VAS)', 'Day 4', 'EA vs usual care', 'COLAK_PAIN_DAY4_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PAIN-D5', 'COLAK10-VAS-D5', 'Colak 2010', 'Pain at rest (VAS)', 'Day 5', 'EA vs usual care', 'COLAK_PAIN_DAY5_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PAIN-D6', 'COLAK10-VAS-D6', 'Colak 2010', 'Pain at rest (VAS)', 'Day 6', 'EA vs usual care', 'COLAK_PAIN_DAY6_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PAIN-D7', 'COLAK10-VAS-D7', 'Colak 2010', 'Pain at rest (VAS)', 'Day 7', 'EA vs usual care', 'COLAK_PAIN_DAY7_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('High', D4CP), ('Some concerns', D5C)]),
 ('D3-COLAK-PETH-7D', 'COLAK10-PETH-7D', 'Colak 2010', 'Pethidine, total', 'Days 0-7', 'EA vs usual care', 'opioid7d_pethidine_EA_usual_COLAK',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('Some concerns', D4CA),
   ('Some concerns', 'No protocol or registration identified; drug totals reported for the whole 7-day period only.')]),
 ('D3-COLAK-METAM-7D', 'COLAK10-METAM-7D', 'Colak 2010', 'Metamizole, total', 'Days 0-7', 'EA vs usual care', 'RESCUE_METAMIZOLE_7D_EA_USUAL',
  [('Some concerns', D1C), ('Some concerns', D2C), ('Low', D3C), ('Some concerns', D4CA),
   ('Some concerns', 'No protocol or registration identified; drug totals reported for the whole 7-day period only.')]),
 ('D3-FU-QOR-T3', 'FU24-QOR-T3', 'Fu 2024', 'QoR-15', 'Postoperative day 7', 'TEAS vs sham', 'QoR15_SHAM_POD7',
  [('Some concerns', D1F), ('Low', D2F), ('Low', D3F), ('Some concerns', D4FQ), ('Some concerns', D5F)]),
]
# Judgements changed on 3 Nov 2026 after Astra's re-audit (R06); the earlier draft had Low in these domains
REV3 = {'D3-FU-RESCUE': 'randomisation Low to Some concerns', 'D3-FU-REMI': 'randomisation Low to Some concerns',
        'D3-FU-QOR-T1': 'randomisation and measurement Low to Some concerns', 'D3-FU-QOR-T2': 'randomisation and measurement Low to Some concerns',
        'D3-FU-QOR-T3': 'randomisation and measurement Low to Some concerns'}
NEW3 = {'D3-COLAK-PAIN-D2', 'D3-COLAK-PAIN-D3', 'D3-COLAK-PAIN-D4', 'D3-COLAK-PAIN-D5', 'D3-COLAK-PAIN-D6', 'D3-COLAK-PAIN-D7', 'D3-COLAK-PETH-7D', 'D3-COLAK-METAM-7D', 'D3-FU-QOR-T3'}
rows = []
for aid, rid, st, outc, win, comp, an, d in RB:
    j = [x[0] for x in d]
    overall = 'High' if 'High' in j else ('Low' if all(x == 'Low' for x in j) else 'Some concerns')
    sc = [n for n, x in zip(('randomisation', 'deviations', 'missing data', 'measurement', 'selection of the reported result'), j) if x == 'Some concerns']
    orat = ('High because outcome measurement was rated High.' if overall == 'High' else
            'Some concerns in ' + (', '.join(sc[:-1]) + ' and ' + sc[-1] if len(sc) > 1 else sc[0]) + '; no domain at high risk'
            + ('; the concerns were considered together and not counted mechanically to High.' if len(sc) > 1 else '.'))
    rows.append(dict(assessment_id=aid, result_id=rid, study=st, outcome=outc, window=win, comparison=comp, analyses=an,
                     **{f'd{i+1}': j[i] for i in range(5)}, overall=overall, **{f'd{i+1}_rationale': d[i][1] for i in range(5)},
                     overall_rationale=orat + (' ' + FU_P if st == 'Fu 2024' else ''),
                     source_pdf=SRC + ('1879897298.pdf' if st.startswith('Colak') else '1879896270.pdf'), source_sha256=SHA[st],
                     decision_status=(ST3 if aid in NEW3 else ST) + (RV3.format(REV3[aid]) if aid in REV3 else '')))
assert len(rows) == 14 and [r['overall'] for r in rows].count('High') == 7 and [r['overall'] for r in rows].count('Some concerns') == 7
wr('d3_rob2_DRAFT.csv', rows)

QOR1 = ('Single sham-controlled trial of 59 with some concerns (allocation concealment; participant masking for a self-reported '
        'questionnaire; selective reporting). Imprecision one level, as for the single-trial QoR-40 body at 48 h (60 participants, '
        'confirmed): one small trial whose interval excludes no difference; the review defines no QoR-15 threshold.')
G = [
 ('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'Proportion given any rescue opioid over each trial\'s own follow-up (exploratory)', 'Low', 1, 0, 0, 1, 0,
  'Low (6 trials, confirmed by SKP 2 Nov)', 'Same domains as before: two of seven trials at high risk (missing data); imprecision serious (612 participants, below the about 830 needed for a 25% relative reduction from a 34% control risk). Fu 2024 adds a sham-controlled trial with follow-up not stated (some concerns, including allocation concealment).'),
 ('pain24_rest_EA_usual', 'Pain at rest at about 24 h, EA vs usual care; certainty that EA does not worsen pain by 1 point or more', 'Very low', 2, 0, 0, 1, 0,
  'No result (new)', 'Single unblinded trial of 30; self-reported pain by participants who knew their allocation (High). The interval (-1.05 to 0.65) excludes worsening of 1 point, but the trial is small.'),
 ('intraop_remifentanil_TEAS_sham', 'Intraoperative remifentanil (µg), TEAS vs sham', 'Low', 1, 0, 0, 1, 0,
  'Not rated (empty cell)', 'Single sham-controlled trial of 59 with some concerns (allocation concealment; selective reporting). Imprecision one level: '
  'the review defines no threshold for intraoperative remifentanil, so precision rests on the small sample; the interval (-151 to -28 µg) '
  'excludes no difference. Whether two levels are warranted is for the second reviewer.'),
 ('QoR15_SHAM_24H', 'QoR-15 at about 24 h, TEAS vs sham', 'Very low', 1, 1, 0, 2, 0, 'Very low (2 trials, second-reviewed)',
  'Three trials; effects differ (4.4 to 14.9 points); the interval is wide; Wu 2025 printed intention-to-treat values with unreported imputation; '
  'Fu 2024 has some concerns for allocation concealment and participant masking.'),
 ('QoR15_SHAM_POD3', 'QoR-15 on postoperative day 3, TEAS vs sham', 'Low', 1, 0, 0, 1, 0, 'Not rated (empty cell)',
  QOR1),
 # 3 Nov 2026 (after Astra's audit): bodies of the kinds graded elsewhere (QoR-15 at later days; non-opioid rescue amount)
 ('QoR15_SHAM_POD7', 'QoR-15 on postoperative day 7, TEAS vs sham', 'Low', 1, 0, 0, 1, 0, 'No result (new)',
  QOR1),
 ('RESCUE_METAMIZOLE_7D_EA_USUAL', 'Metamizole on request over postoperative days 0-7 (g), EA vs usual care', 'Low', 1, 0, 0, 1, 0, 'No result (new)',
  'Single unblinded trial of 30 with some concerns in four domains (analgesia on request by unmasked staff). Imprecision one level: the '
  'interval (-1.92 to -1.02 g) excludes no difference, but the trial is small and the review defines no threshold or optimal information '
  'size for metamizole amount; whether two levels are warranted is for the second reviewer (the Oztas 2019 dexketoprofen bodies had two '
  'because their intervals included no difference). Non-opioid analgesic given on request, as for Oztas 2019.'),
]
FU_G = {'RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'intraop_remifentanil_TEAS_sham', 'QoR15_SHAM_24H', 'QoR15_SHAM_POD3', 'QoR15_SHAM_POD7'}
wr('d3_grade_DRAFT.csv', [dict(model_id=m, target=t, certainty=c, rob=a, inc=b, ind=i, imp=p, pub=u, previous=pv,
                               reason=rs + (' Fu 2024: ' + FU_P if m in FU_G else ''),
                               status=(ST3 if m in ('QoR15_SHAM_POD7', 'RESCUE_METAMIZOLE_7D_EA_USUAL') else ST)
                               + ('' if m == 'pain24_rest_EA_usual' else '; reason revised 3 Nov 2026 after Astra\'s re-audit (rating unchanged)'))
                          for m, t, c, a, b, i, p, u, pv, rs in G])

# Every result each D3 report gives, with its disposition (as for Wang 1997; Astra's D3 audit, finding 4). Registered windows:
# pain at about 6, 24, 48 and 72 h and the longest reported acute time point; opioid over 0-48 h, 0-72 h and the longest
# reported acute interval; PONV over 0-24 h, 0-48 h and the longest interval; rescue analgesia; quality of recovery.
INV = [
 ('Colak 2010', 'Table 1 p9; Methods p8', 'Resting VAS, day 0', 'Narrative',
  'Day of surgery: the Methods describe a pre-treatment VAS about 1 h after extubation (at about 8 h) and a further rest evaluation on day 0, '
  'and the table does not say which is shown, so it may be a pre-treatment baseline; neither is at a stated time near 6 h. '
  '67.00 ± 8.41 (control) vs 69.33 ± 2.58 (EA).'),
 ('Colak 2010', 'Table 1 p9', 'Resting VAS, day 1', 'Existing analysis', 'Pain at rest at about 24 h, EA vs usual care (pain24_rest_EA_usual).'),
 ('Colak 2010', 'Table 1 p9', 'Resting VAS, day 2', 'Single-trial estimate', 'About 48 h (COLAK_PAIN_DAY2_EA_USUAL); not pooled with Ng 2013 on day 2, whose pain is not stated as rest or movement.'),
 ('Colak 2010', 'Table 1 p9', 'Resting VAS, day 3', 'Single-trial estimate', 'About 72 h (COLAK_PAIN_DAY3_EA_USUAL).'),
 ('Colak 2010', 'Table 1 p9', 'Resting VAS, days 4, 5 and 6', 'Single-trial estimate',
  'Not registered time points, but outcomes are analysed at each reported time point (Methods), as for Oztas 2019 and Gu 2019 '
  '(COLAK_PAIN_DAY4/5/6_EA_USUAL).'),
 ('Colak 2010', 'Table 1 p9', 'Resting VAS, day 7', 'Single-trial estimate', 'Longest reported acute time point (COLAK_PAIN_DAY7_EA_USUAL).'),
 ('Colak 2010', 'Table 1 p9; Methods p8', 'Pethidine, total over days 0-7', 'Single-trial estimate',
  'Longest reported acute opioid interval, in native units (opioid7d_pethidine_EA_usual_COLAK); no 0-24-, 0-48- or 0-72-h quantity is given.'),
 ('Colak 2010', 'Table 1 p9; Methods p8', 'Metamizole, total over days 0-7', 'Single-trial estimate',
  'Rescue analgesia (first-line, on request), non-opioid, in native units (RESCUE_METAMIZOLE_7D_EA_USUAL), as for Oztas 2019.'),
 ('Colak 2010', 'Table 1 p9', 'Extubation and "detubation" times', 'Narrative', 'Not registered outcomes; similar in both arms (8.1 vs 8.2 h; 23.1 vs 21.9 h).'),
 ('Colak 2010', 'Table 1 p9; abstract p7; Discussion p10', 'Complications (atelectasis)', 'Narrative (harms)',
  'Atelectasis in 1 (6.6%) per arm (Table 1 gives the counts; the abstract and Discussion name the complication).'),
 ('Colak 2010', 'Table 1 p9', 'Pulse, systolic and diastolic arterial pressure', 'Not a registered outcome',
  'Physiological values in Table 1 (no time point stated; not different between arms); no registered construct.'),
 ('Colak 2010', 'Table 1 p9', 'Pulmonary function (FEV1, FVC, FEV1/FVC) before and after surgery', 'Not a registered outcome', 'The report\'s own primary interest; no registered construct.'),
 ('Fu 2024', 'Table 4 p7; Results p7', 'Patients given rescue analgesic (IV tramadol)', 'Existing analysis', 'Rescue opioid receipt, TEAS vs sham (follow-up not stated, as Yu 2020).'),
 ('Fu 2024', 'Table 4 p7', 'Remifentanil, stage 2', 'Existing analysis', 'Intraoperative opioid (intraop_remifentanil_TEAS_sham), single trial.'),
 ('Fu 2024', 'Table 4 p7', 'Propofol, stage 2', 'Narrative', 'Non-opioid anaesthetic; not a registered outcome. 374.7 ± 61.2 vs 421.5 ± 81.9 mg.'),
 ('Fu 2024', 'Table 4 p7; Results p7', 'Patients given dexmedetomidine, stage 1', 'Narrative',
  'Sedative given for pain, anxiety or tremor while awake; not an opioid. The row repeats the rescue-analgesic row exactly (2 [6.7%] vs 6 [20.7%], P < 0.001) (Additional file 5).'),
 ('Fu 2024', 'Table 4 p7; Methods p3; Discussion p8', 'Patients given rescue antiemetic', 'Narrative',
  '0 vs 0. Antiemetic use after palonosetron prophylaxis for all, not PONV incidence (the authors did not assess PONV directly, p8); not entered as zero PONV.'),
 ('Fu 2024', 'Table 3 p6', 'VAS-p, T0 (baseline)', 'Narrative', 'Preoperative baseline.'),
 ('Fu 2024', 'Table 3 p6', 'VAS-p, T1 (day 1)', 'Descriptive only', 'Medians (IQR), rest or movement not stated; not converted.'),
 ('Fu 2024', 'Table 3 p6', 'VAS-p, T2 (day 3)', 'Descriptive only', 'About 72 h; medians (IQR), rest or movement not stated; not converted.'),
 ('Fu 2024', 'Table 3 p6', 'VAS-p, T3 (day 7)', 'Descriptive only', 'Longest reported acute time point; medians (IQR), rest or movement not stated; not converted.'),
 ('Fu 2024', 'Table 3 p6', 'QoR-15, T0 (baseline)', 'Narrative', 'Preoperative baseline.'),
 ('Fu 2024', 'Table 3 p6', 'QoR-15, T1 (day 1)', 'Existing analysis', 'QoR-15 at about 24 h, TEAS vs sham (QoR15_SHAM_24H).'),
 ('Fu 2024', 'Table 3 p6', 'QoR-15, T2 (day 3)', 'Existing analysis', 'QoR-15 on postoperative day 3 (QoR15_SHAM_POD3), single trial.'),
 ('Fu 2024', 'Table 3 p6', 'QoR-15, T3 (day 7)', 'Single-trial estimate', 'QoR-15 on postoperative day 7 (QoR15_SHAM_POD7).'),
 ('Fu 2024', 'Table 3 p6', 'MMSE, T0-T3', 'Narrative', 'Cognitive function as medians (IQR); not converted.'),
 ('Fu 2024', 'Tables 2-3 p6', 'Christensen fatigue score; severe fatigue at T3', 'Not a registered outcome', 'The report\'s primary outcome (postoperative fatigue).'),
 ('Fu 2024', 'Table 2 p6', 'Time to emergence; time to laryngeal-mask removal; postoperative agitation', 'Narrative',
  'Early recovery events; not registered outcomes. Agitation 3 (10.0%) vs 11 (37.9%).'),
 ('Fu 2024', 'Results p7; Fig. 3', 'Serum TNF-alpha and CRP', 'Not a registered outcome', 'Inflammatory biomarkers.'),
 # Chen 2016 is held from all analyses (eligible ages 16-80 years): every result is listed, none enters an analysis or was assessed
 ('Chen 2016', 'Results p3; Fig. 2c p4', 'Pethidine (Sauteralgyl) rescue, total over 0-72 h (mg/kg)', 'Held',
  '9.2 ± 2.8 vs 11.5 ± 1.8 mg/kg in the text; Fig. 2c plots about 3.7 vs 4.6 mg/kg (Additional file 5). Weight-normalised, not convertible.'),
 ('Chen 2016', 'Fig. 2a p4', 'Pain VAS at 1 h (before EA)', 'Held', 'Figure only; pre-treatment.'),
 ('Chen 2016', 'Fig. 2a p4', 'Pain VAS at 2 h', 'Held', 'Figure only; rest or movement not stated.'),
 ('Chen 2016', 'Fig. 2a p4', 'Pain VAS at 24 h', 'Held', 'Figure only; rest or movement not stated.'),
 ('Chen 2016', 'Fig. 2a p4', 'Pain VAS at 48 h', 'Held', 'Figure only; rest or movement not stated.'),
 ('Chen 2016', 'Fig. 2a p4', 'Pain VAS at 72 h', 'Held', 'Figure only; longest reported time point.'),
 ('Chen 2016', 'Fig. 2b p4', 'Cumulative VAS over 72 h', 'Held', 'Figure only.'),
 ('Chen 2016', 'Table 2 p4', 'Nausea; vomiting', 'Held', 'Nausea 10/46 vs 22/46; vomiting 3/46 vs 5/46 (period not stated).'),
 ('Chen 2016', 'Table 2 p4', 'Time to first flatus', 'Held', '24.3 ± 8.2 vs 35.7 ± 7.76 h.'),
 ('Chen 2016', 'Table 2 p4', 'Time to first defecation', 'Held', '42.7 ± 13.9 vs 59.2 ± 11.3 h.'),
 ('Chen 2016', 'Results p3; Fig. 3 p4', 'Plasma beta-endorphin and 5-HT at 1, 2, 24, 48 and 72 h', 'Held', 'Not registered outcomes; figure only.'),
]
wr('d3_outcome_inventory.csv', [dict(report=r, source=s, result=x, disposition=d, reason=y) for r, s, x, d, y in INV])
assert {x[3] for x in INV} <= {'Existing analysis', 'Single-trial estimate', 'Descriptive only', 'Narrative', 'Narrative (harms)', 'Not a registered outcome', 'Held'}

pc = json.loads((REV / 'wang1997/prisma_counts_with_wang1997.json').read_text())
r = pc['exclusion_reasons']; a = pc['additional_exclusion_reasons']
assert r['no perioperative analgesia outcome found'] == 112
r['no perioperative analgesia outcome found'] -= 6          # 3 included (Colak, Fu, Chen 2016) + 3 relabelled
r['Wrong comparator'] += 1                                    # Tu 2018
for k in (r, a):
    k['Opioid outcome identity, timing or treatment comparison unresolved'] += 2   # Zhou 2025 [1879896127], Li 2017
pc['additional_focused_exclusions'] += 2
pc['pending_outcome_clarification_outside_set'] += 2
pc['original_database_excluded'] -= 5
pc['database_excluded'] -= 3
pc['database_included'] += 3; pc['included_reports'] += 3; pc['operational_trial_families'] += 3
pc['version'] = 'REVISION_DRAFT_CURRENT (Wang 1997 and D3 applied; derived from opioid_only_review/prisma/prisma_counts.json; not a project record)'
pc['chart_status'] = ('Revision draft, 2 Nov 2026: the 9 Oct 40-report selection plus Wang 1997 (D1) and Colak 2010, Fu 2024 and Chen 2016 (D3; '
                      'Chen 2016 held from pooling); Tu 2018 relabelled wrong comparator; Zhou 2025 [1879896127] and Li 2017 relabelled to the '
                      '9 Oct opioid-result criterion. 44 reports, 43 provisional trial families.')
pc['caveats'].append('Decision D3 (2 Nov 2026): three included, five excluded; see manuscript/submission/BMC_revision_after_ASTRA_recheck/d3/.')
(HERE / 'prisma_counts_current.json').write_text(json.dumps(pc, indent=1))
print('decisions', len(D), '| results', len(R), '| RoB units', len(rows), '| GRADE', len(G), '| inventory', len(INV), '| included', pc['included_reports'],
      '| outcome exclusions', r['no perioperative analgesia outcome found'], '| opioid-result exclusions', pc['additional_focused_exclusions'])
