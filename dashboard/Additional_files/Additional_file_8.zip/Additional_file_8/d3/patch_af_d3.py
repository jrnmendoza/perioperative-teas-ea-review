"""Decision D3 (review owner, 2 Nov 2026): carry the membership decisions into the Additional-files builder.

Run after recheck/patch_af_recheck.py, which rewrites build_additional_files.py from the pre-recheck snapshot; this
script then edits build_additional_files.py in place (each replacement asserted once), so run the two together.

Sources: d3/ (decisions, extraction, RoB 2 and GRADE drafts, PRISMA counts, Fig. 3 domain summary) and
wang1997/models_with_wang.csv (refits, including D3). Nothing is re-estimated here."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# ---- shared facts --------------------------------------------------------------------------------------------------
rep('import csv, json, re, zipfile, hashlib, collections', 'import csv, json, math, re, zipfile, hashlib, collections')
rep("pc = json.loads((REV / 'wang1997/prisma_counts_with_wang1997.json').read_text())  # D1: one outcome exclusion moved to inclusion",
    "pc = json.loads((REV / 'd3/prisma_counts_current.json').read_text())  # D1 and D3 (2 Nov 2026): four outcome exclusions included")
rep("assert len(REPORTS) == 40 and pc['included_reports'] == 41  # the 40 project reports + Wang 1997 (records in wang1997/)",
    "assert len(REPORTS) == 40 and pc['included_reports'] == 44  # the 40 project reports + Wang 1997 (wang1997/) + three D3 reports (d3/)")
rep("W97_INV = recs(W97 / 'wang1997_outcome_inventory.csv')   # every reported Wang result and its disposition (re-check, M05)\n",
    "W97_INV = recs(W97 / 'wang1997_outcome_inventory.csv')   # every reported Wang result and its disposition (re-check, M05)\n"
    "# Decision D3 (2 Nov 2026): Colak 2010 and Fu 2024 included; Chen 2016 included and held from pooling (ages 16-80); Tu 2018,\n"
    "# Zhou 2025 [1879896127] and Li 2017 relabelled. Records in d3/; the RoB 2 and GRADE drafts await SKP's second review.\n"
    "D3 = REV / 'd3'\n"
    "D3_DEC = {r['covidence_id']: r for r in recs(D3 / 'd3_decisions.csv')}\n"
    "D3_RES = {r['result_id']: r for r in recs(D3 / 'd3_results.csv')}\n"
    "D3_CHAR = recs(D3 / 'd3_characteristics.csv')\n"
    "D3_PDF = {'Colak 2010': '1879897298', 'Fu 2024': '1879896270', 'Chen 2016': '1879896981'}\n"
    "D3_NOTE = 'included 2 Nov 2026 (decision D3)'\n"
    "D3_MOD = {m for m, x in W97_MOD.items() if 'Fu 2024' in x['description'] or 'Colak 2010' in x['description']}\n")

# ---- AF1 -----------------------------------------------------------------------------------------------------------
rep("'Yes (Results: 41 reports of 40 trials, 7,521 participants) [PROVISIONAL: membership awaits adjudication of eight reports]'",
    "'Yes (Results: 44 reports of 43 trials, 7,703 participants) [PROVISIONAL: 53 historical outcome exclusions not yet re-checked]'")

# ---- AF2 section 6, decision log and second-review record ------------------------------------------------------------
rep("'before Wang 1997 was included on 2 November 2026) '",
    "'before the recheck of 2 November 2026, after which four were included and three were excluded under another reason) '")
rep('identified {pc["additional_focused_exclusions"]} without one: \'', 'identified {pc["additional_focused_exclusions"] - 2} without one: \'')
rep('{a["Opioid outcome identity, timing or treatment comparison unresolved"]} \'',
    '{a["Opioid outcome identity, timing or treatment comparison unresolved"] - 2} \'')
rep("'confirmed opioid identity or formulation. The 40 remaining reports formed the review until Wang 1997 was '\n"
    "            'added on 2 November 2026 (below). Each excluded report '",
    "'confirmed opioid identity or formulation. Two further reports were excluded under this criterion on 2 November 2026 '\n"
    "            '(decision D3, below). The 40 remaining reports formed the review until Wang 1997, and then Colak 2010, Fu 2024 '\n"
    "            'and Chen 2016, were added on 2 November 2026 (below). Each excluded report '")
rep("""'"Wang 1997 outcomes") with its disposition. [PROVISIONAL: the '
            'review team must adjudicate the other eight membership candidates; SKP checked the Wang 1997 extraction and '
            'confirmed its RoB 2 and GRADE assessments on 2 November 2026; see AUTHOR_ACTIONS.md and Additional file 4.]')""",
    """'"Wang 1997 outcomes") with its disposition. SKP checked the Wang 1997 extraction and confirmed its RoB 2 and '
            'GRADE assessments on 2 November 2026.')
    para(d, '**Decision D3: the other eight candidates (2 November 2026).** After reading each report (evidence in '
            'Additional file 4, sheets "Outcome exclusions recheck" and "D3 decisions"), the review owner decided, with trial '
            'results known: Colak 2010 included (EA versus usual care after coronary artery bypass grafting; randomised by '
            'tables of random numbers although the report calls the design case-control; general anaesthesia implied by '
            'extubation at about 8 hours); Fu 2024 included (TEAS versus sham; the second, pulse-generator stage of deep brain '
            'stimulation was done under general anaesthesia, with stimulation through both stages); Chen 2016 included and '
            'held from pooled analyses, as Lee 2011 is, because it enrolled participants aged 16–80 years; Tu 2018 excluded as '
            'wrong comparator (only the control arm received scheduled oral tramadol); Zhou 2025 (Covidence 1879896127, not '
            'the included Zhou 2025) and Li 2017 excluded under the 9 October criterion (no confirmed postoperative opioid '
            'result); and Zhang 2022 and Poulain 1997 excluded for the recorded reason. Colak 2010 adds the only EA rest-pain '
            'result and a 7-day pethidine total (a single-trial estimate in native units); Fu 2024 enters rescue receipt '
            '(follow-up not stated, as in Yu 2020), QoR-15 and intraoperative remifentanil. [PROVISIONAL: SKP has not yet '
            'checked the extraction for the three reports or the five RoB 2 and five GRADE drafts for Colak 2010 and Fu 2024; '
            '45 outcome exclusions have no local full text and eight with a keyword signal have not been read in full; see '
            'AUTHOR_ACTIONS.md and Additional file 4.]')""")
rep("    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:",
    "    rows.append(['2 Nov', 'Decision D3 (review owner, results known): Colak 2010 and Fu 2024 included; Chen 2016 included and '\n"
    "                 'held from pooled analyses (ages 16–80 years); Tu 2018 relabelled wrong comparator; Zhou 2025 (1879896127) and '\n"
    "                 'Li 2017 relabelled to the 9 October criterion; Zhang 2022 and Poulain 1997 excluded for the recorded reason '\n"
    "                 '(section 6). Rescue receipt, QoR-15 at about 24 hours, EA-versus-usual-care rest pain and intraoperative '\n"
    "                 'remifentanil refitted in R; the rescue model (Fig. 5) reproduced in Stata. RoB 2 and GRADE drafted by the AI '\n"
    "                 'assistant; second review pending.', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:")
rep("        ['Not done', 'The 2 November 2026 triage of the outcome exclusions,",
    "        ['Pending', 'Decision D3 extraction (Colak 2010, Fu 2024, Chen 2016: characteristics, Table 1 rows and outcome values); 5 RoB 2 assessments and 5 GRADE profiles for Colak 2010 and Fu 2024', '[CONFIRM: second review pending]'],\n"
    "        ['Not done', 'The 2 November 2026 triage of the outcome exclusions,")

# ---- AF4 -----------------------------------------------------------------------------------------------------------
rep("""                    'outcome-exclusion recheck, when the review owner judged its stimulation to be TEAS (results known)')
""",
    """                    'outcome-exclusion recheck, when the review owner judged its stimulation to be TEAS (results known)')
        if r['covidence_id'] in D3_DEC:   # D3, 2 Nov 2026 (d3/d3_decisions.csv)
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']
            dec = D3_DEC[r['covidence_id']]
            note = ('Excluded at full-text screening (no eligible analgesic outcome); reread after the outcome-exclusion recheck. '
                    f'Decision D3 (review owner, 2 Nov 2026, results known): {dec["decision"]}. {dec["basis"]}')
            if dec['decision'].startswith('Include'):
                fd, r = 'INCLUDED', dict(r, registry_report=dec['report'])
            elif dec['decision'] == 'Exclude: wrong comparator':
                fr = 'Wrong comparator'
            elif dec['decision'] == 'Exclude: no confirmed postoperative opioid result':
                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', 'Opioid outcome identity, timing or treatment comparison unresolved'
                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-02')
""")
rep("assert sum(x['disp'] == 'Included' for x in rows) == pc['included_reports'] == 41",
    "assert sum(x['disp'] == 'Included' for x in rows) == pc['included_reports'] == 44")
rep("dict(reason='Included', n=41)]", "dict(reason='Included', n=44)]")
rep("""('Outcome exclusions recheck', 'AI-assisted triage (2 Nov 2026) of the 113 "No eligible analgesic outcome" exclusions under both dated outcome requirements; not a human screen [PROVISIONAL]'),""",
    """('Outcome exclusions recheck', 'AI-assisted triage (2 Nov 2026) of the 113 "No eligible analgesic outcome" exclusions under both dated outcome requirements, with the review owner decisions on the nine membership candidates (D1, D3); the triage itself is not a human screen [PROVISIONAL: 45 without a local full text and 8 keyword signals not yet read]'),""")
rep("""                 ('Wang 1997 outcomes', 'Every result reported by Wang 1997 (included 2 Nov 2026), with its disposition: existing analysis, single-trial estimate, narrative, hold or excluded by rule')],""",
    """                 ('Wang 1997 outcomes', 'Every result reported by Wang 1997 (included 2 Nov 2026), with its disposition: existing analysis, single-trial estimate, narrative, hold or excluded by rule'),
                 ('D3 decisions', 'Decision D3 (review owner, 2 Nov 2026) on the other eight membership candidates, with its basis'),
                 ('D3 extracted results', 'Results extracted from the three reports included by decision D3, with source location, quotation and use')],""")
rep("""            t['proposed_human_action'] += ' Decided 2 Nov 2026 by the review owner: TEAS; included (broader first-day analysis).'
""",
    """            t['proposed_human_action'] += ' Decided 2 Nov 2026 by the review owner: TEAS; included (broader first-day analysis).'
        if t['covidence_id'] in D3_DEC:   # D3, 2 Nov 2026
            assert t['category'] == 'MEMBERSHIP', t['covidence_id']
            dec = D3_DEC[t['covidence_id']]
            t['category'] = 'MEMBERSHIP: ' + ('included' if dec['decision'].startswith('Include') else 'excluded') + ' 2 Nov 2026 (D3)'
            t['proposed_human_action'] += f' Decided 2 Nov 2026 by the review owner (D3): {dec["decision"]}.'
""")
rep("""    sheet(wb, 'Wang 1997 outcomes', W97_INV,""",
    """    sheet(wb, 'D3 decisions', list(D3_DEC.values()), [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 22),
          ('decision', 'Decision', 30), ('basis', 'Basis', 80), ('decided_by', 'Decided by', 40)])
    sheet(wb, 'D3 extracted results', list(D3_RES.values()), [('result_id', 'Result ID', 16), ('report', 'Report', 12),
          ('outcome', 'Outcome', 34), ('window', 'Window', 18), ('unit', 'Unit', 14), ('comparison', 'Comparison', 16),
          ('n_i', 'N, intervention', 8), ('value_i', 'Value, intervention', 12), ('sd_i', 'SD', 8), ('n_c', 'N, control', 8),
          ('value_c', 'Value, control', 12), ('sd_c', 'SD', 8), ('data_type', 'Data type', 12), ('source_location', 'Source location', 22),
          ('source_text', 'Source text (verbatim)', 60), ('use', 'Use in this review', 40), ('source_sha256', 'Source SHA-256', 20)])
    sheet(wb, 'Wang 1997 outcomes', W97_INV,""")

# ---- AF5 -----------------------------------------------------------------------------------------------------------
rep("""    ('Xiong 2021', 'Postoperative interval not stated; route terminology in the Results is inconsistent.', 'Result held.'),
]""",
    """    ('Xiong 2021', 'Postoperative interval not stated; route terminology in the Results is inconsistent.', 'Result held.'),
    ('Colak 2010', 'Called a "case-control study", although participants were randomised by tables of random numbers; the exclusion criteria mention an epidural catheter that is not otherwise described.',
     'Treated as a randomised trial (decision D3, 2 Nov 2026); no epidural analgesia assumed. Randomisation domain judged Some concerns.'),
    ('Fu 2024', 'Rescue analgesic incidence of 2/30 versus 6/29 is printed with P < 0.001, which these counts cannot give.', 'Counts used; the printed P value is not used.'),
]""")
rep("    held.sort(key=lambda x: (x['study'], x['family'], x['result_id']))",
    "    for w in D3_RES.values():   # D3, 2 Nov 2026: Chen 2016 held (ages 16-80); Fu 2024 pain medians descriptive only\n"
    "        if w['report'] == 'Chen 2016' or w['use'].startswith('Descriptive'):\n"
    "            held.append(dict(result_id=w['result_id'], study=w['report'], family=w['outcome'], outcome=w['outcome'], window=w['window'],\n"
    "                             comparison=w['comparison'], decision='Hold', rationale=w['use'], qc='', loc=w['source_location']))\n"
    "    held.sort(key=lambda x: (x['study'], x['family'], x['result_id']))")

# ---- AF6 -----------------------------------------------------------------------------------------------------------
rep("""                   now='Included 2 Nov 2026'))
""",
    """                   now='Included 2 Nov 2026'))
    ta.append(dict(body='EA vs usual care', report='Colak 2010', result_ids='COLAK10-PETH-7D',
                   E1_disposition='EXCLUDE: pethidine total over postoperative days 0-7; no 0-24-h quantity', E2_disposition='NOT ADMITTED',
                   E2_basis='Window: a 7-day total does not give the first 24 hours', flags='Single-trial estimate in native units (Additional file 12)',
                   mandatory_sensitivity='', addendum_note='Colak 2010, ' + D3_NOTE, now='Included 2 Nov 2026'))
    ta.append(dict(body='EA vs sham', report='Chen 2016', result_ids='CHEN16-PETH-72',
                   E1_disposition='HOLD: participants aged 16-80 years (as Lee 2011); also a 72-h weight-normalised total', E2_disposition='NOT ADMITTED',
                   E2_basis='Window (0-72 h) and a weight-normalised dose (mg/kg), which cannot be converted to an absolute dose (Additional file 7)',
                   flags='Held from all pooled analyses', mandatory_sensitivity='', addendum_note='Chen 2016, ' + D3_NOTE + '; held',
                   now='Included 2 Nov 2026; held'))
""")
rep("""                          rationale=w['classification'], models=mods, loc=w['source_location'], quote=w['source_text']))
""",
    """                          rationale=w['classification'], models=mods, loc=w['source_location'], quote=w['source_text']))
    for rid, fam, dec, mods in (('COLAK10-PETH-7D', 'Postoperative opioid consumption', 'Individual estimate', 'opioid7d_pethidine_EA_usual_COLAK (single trial, native units)'),
                                ('FU24-RESCUE', 'Rescue opioid use', 'Include', 'RESCUE_TEAS_SHAM_* (not the known-period or first-day subsets: follow-up not stated)'),
                                ('FU24-REMI', 'Intraoperative opioid', 'Include', 'intraop_remifentanil_TEAS_sham (single trial)'),
                                ('CHEN16-PETH-72', 'Postoperative opioid consumption', 'Hold', 'None (held: participants aged 16-80 years)')):   # D3
        w = D3_RES[rid]
        allop.append(dict(result_id=rid, study=w['report'], family=fam, outcome=w['outcome'], window=w['window'], unit=w['unit'],
                          comparison=w['comparison'], decision=dec, rationale=w['use'] + '; ' + D3_NOTE, models=mods,
                          loc=w['source_location'], quote=w['source_text']))
""")
rep("'Classification of every candidate opioid result in the 41 reports against the registered primary '",
    "'Classification of every candidate opioid result in the 44 reports against the registered primary '")
rep("'Every opioid-related result in the 41 reports, with its disposition in the analyses'",
    "'Every opioid-related result in the 44 reports, with its disposition in the analyses'")
rep("'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY', 'nausea24_TEAS_sham', 'RESCUE_TEAS_USUAL']",
    "'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY', 'nausea24_TEAS_sham', 'RESCUE_TEAS_USUAL', 'pain24_rest_EA_usual']")
rep("    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(),",
    """    for m, rid, scale in (('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'FU24-RESCUE', 1), ('QoR15_SHAM_24H', 'FU24-QOR-T1', 1),
                          ('pain24_rest_EA_usual', 'COLAK10-VAS-D1', 10)):   # D3, 2 Nov 2026: values as reported and as modelled
        w = D3_RES[rid]
        ni, nc = int(w['n_i']), int(w['n_c'])
        if w['data_type'] == 'events':
            ei, ec = int(w['value_i']), int(w['value_c'])
            yi, vi = math.log((ei / ni) / (ec / nc)), 1 / ei - 1 / ni + 1 / ec - 1 / nc
            raw = mv = f'{ei}/{ni} vs {ec}/{nc}'
        else:
            mi, si, mc, sc = (float(w[k]) / scale for k in ('value_i', 'sd_i', 'value_c', 'sd_c'))
            yi, vi = mi - mc, si ** 2 / ni + sc ** 2 / nc
            raw = f"{w['value_i']} ({w['sd_i']}), n {ni} vs {w['value_c']} ({w['sd_c']}), n {nc}"
            mv = f'{num(mi, 3)} ({num(si, 3)}), n {ni} vs {num(mc, 3)} ({num(sc, 3)}), n {nc}'
        if m == 'pain24_rest_EA_usual':   # single trial: the modelled effect is this difference
            assert abs(yi - float(W97_MOD[m]['effect'])) < 1e-9
        out.append(dict(analysis=m, report=w['report'], result_id=rid, outcome=w['outcome'], window=w['window'], raw_unit=w['unit'],
                        raw_values=raw, factor='0.1 (0-100 to 0-10)' if scale == 10 else '', model_values=mv, yi=num(yi, 4), vi=num(vi, 5),
                        source_location=w['source_location'], source_quote=w['source_text'], source_sha256=w['source_sha256'][:16]))
    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(),""")

# ---- AF8 -----------------------------------------------------------------------------------------------------------
rep("""                     s_note=W97_NOTE + '; AI extraction, checked by SKP (reported 2 Nov 2026)', s_source_pdf=W97_PDF, sha=W97_SHA))
""",
    """                     s_note=W97_NOTE + '; AI extraction, checked by SKP (reported 2 Nov 2026)', s_source_pdf=W97_PDF, sha=W97_SHA))
    for c in D3_CHAR:   # D3, 2 Nov 2026: AI extraction from the source PDFs; second review by SKP pending
        sha = next(x['source_sha256'] for x in D3_RES.values() if x['report'] == c['report'])
        rows.append(dict(report_id=c['report'], year=c['report'][-4:], trial_family=c['report'], country=c['country'],
                         s_setting={'University': 'University or university-affiliated hospital'}.get(c['setting'], c['setting']),
                         s_setting_quote=c['setting_basis'], modality=c['modality'], comparator=c['comparator'],
                         comparator_class=c['comparator'], comp_desc=T1COMP[c['report']], randomized_n=c['n'].split(' ')[0],
                         analysed_n=c['analysed'], anaesthesia=c['anaesthesia'], surgical_category=c['surgery'], procedure=c['procedure'],
                         age='Mean ' + c['age'] + ' y (intervention/control)', female=c['female'] + '%', acupoints=c['acupoints'],
                         frequency=c['frequency'], timing=c['timing'], s_mma_all_groups=c['mma'], s_non_opioid_components=c['mma_basis'],
                         s_note=f"{c['report']}, {D3_NOTE}; {c['design_note']}; AI extraction, second review by SKP pending [PROVISIONAL]",
                         s_source_pdf=f"10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/{D3_PDF[c['report']]}.pdf", sha=sha))
""")
rep("'Study, participant, analgesic-regimen and stimulation-protocol characteristics of the 41 included reports, '",
    "'Study, participant, analgesic-regimen and stimulation-protocol characteristics of the 44 included reports, '")
rep("'checked by a second reviewer (SKP), including those of Wang 1997 (added and checked 2 Nov 2026).'],",
    "'checked by a second reviewer (SKP), including those of Wang 1997 (added and checked 2 Nov 2026); those of Colak 2010, '\n"
    "                    'Fu 2024 and Chen 2016 (added 2 Nov 2026, decision D3) await this check [PROVISIONAL].'],")
rep("'Lee 2011 (age 14–59 years), Jin 2023 (general anaesthesia not established) and Long 2025 (modality unclear) are retained but not pooled.'",
    "'Lee 2011 (age 14–59 years), Chen 2016 (age 16–80 years), Jin 2023 (general anaesthesia not established) and Long 2025 (modality unclear) are retained but not pooled.',\n"
    "                 'Colak 2010, Fu 2024 and Chen 2016 were added on 2 Nov 2026 (decision D3). Their rows give the fields extracted for the '\n"
    "                 'decision (setting source, anaesthesia, regimen and stimulation protocol); the other fields are blank, and SKP has not yet checked them.'")

# ---- AF10 ----------------------------------------------------------------------------------------------------------
rep("    assert len(units) == 164, len(units)\n",
    "    assert len(units) == 164, len(units)\n"
    "    for s in recs(REV / 'd3/d3_rob2_DRAFT.csv'):   # D3, 2 Nov 2026: AI drafts; second review pending\n"
    "        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],\n"
    "            s['decision_status'], rationale(s))\n"
    "    assert len(units) == 169, len(units)\n")
rep("fig = {r['domain']: r for r in recs(W97 / 'rob_domain_summary_2026-10-23.csv')}   # Fig. 3 rebuilt with Wang 1997",
    "fig = {r['domain']: r for r in recs(REV / 'd3/rob_domain_summary_d3.csv')}   # Fig. 3 rebuilt with Wang 1997 and the D3 drafts")
rep("reason='Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years); not counted among the 164.'))",
    "reason='Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years); not counted among the 169.'))\n"
    "    held.append(dict(model='All analyses', result='CHEN16-*', study='Chen 2016',\n"
    "                     reason='Included 2 Nov 2026 (decision D3) and held from all pooled analyses (participants aged 16–80 years, as Lee 2011); its results were not assessed.'))\n"
    "    held.append(dict(model='opioid7d_pethidine_EA_usual_COLAK', result='COLAK10-PETH-7D', study='Colak 2010',\n"
    "                     reason='Single-trial estimate in native units over postoperative days 0–7, outside every 0–24-h analysis; not assessed.'))\n"
    "    held.append(dict(model='Descriptive only', result='FU24-VAS-T1', study='Fu 2024',\n"
    "                     reason='Pain on postoperative day 1 reported as medians (rest or movement not stated); not converted or pooled, so not assessed.'))")
rep("'Result-specific RoB 2 judgements for all 164 results used in the analyses, with the rationale for each '",
    "'Result-specific RoB 2 judgements for all 169 results used in the analyses, with the rationale for each '")
rep("""The exception is '
                     'not an exception: the 12 assessments for Wang 1997 (included 2 Nov 2026) were revised after an independent AI '
                     're-check (sham rescue receipt: measurement domain Low to Some concerns; two length-of-stay results added) and '
                     'confirmed by SKP on 2 Nov 2026.'],""",
    """The 12 '
                     'assessments for Wang 1997 (included 2 Nov 2026) were revised after an independent AI '
                     're-check (sham rescue receipt: measurement domain Low to Some concerns; two length-of-stay results added) and '
                     'confirmed by SKP on 2 Nov 2026. The exception: the five assessments for Colak 2010 and Fu 2024 (included 2 Nov '
                     '2026, decision D3) are AI drafts awaiting second review by SKP [PROVISIONAL].'],""")
rep("[('Judgements', 'One row per assessed result (164), with domain judgements and rationales'),",
    "[('Judgements', 'One row per assessed result (169), with domain judgements and rationales'),")
rep("f'Signalling responses recorded for {n_with} of the 164 results'", "f'Signalling responses recorded for {n_with} of the 169 results'")

# ---- AF11 ----------------------------------------------------------------------------------------------------------
rep("""    wdr = []
    for g in recs(W97 / 'wang1997_grade_DRAFT.csv'):
        x = W97_MOD[g['model_id']]
""",
    """    d3g = recs(REV / 'd3/d3_grade_DRAFT.csv')   # D3, 2 Nov 2026: AI drafts awaiting SKP's second review
    D3_GRADE = {g['model_id'] for g in d3g}
    wdr = []
    for g in recs(W97 / 'wang1997_grade_DRAFT.csv'):
        # the confirmed rescue profile rated the six-trial body; with Fu 2024 that body is RESCUE_LOO_Fu_2024
        x = W97_MOD['RESCUE_LOO_Fu_2024' if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP' else g['model_id']]
""")
rep("""                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'], version='Current'))
""",
    """                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'],
                        version='Superseded by decision D3 (Fu 2024 added): current draft in sheet "D3 drafts"' if g['model_id'] in D3_GRADE else 'Current'))
    ddr = []
    for g in d3g:
        x = W97_MOD[g['model_id']]
        ab = ''
        if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':   # control risk = pooled sham events / sham participants (102/296)
            cr = 102 / 296
            ab = (f'Control {1000 * cr:.0f} per 1,000; with TEAS {1000 * cr * float(x["effect"]):.0f} '
                  f'({1000 * cr * float(x["ci_low"]):.0f} to {1000 * cr * float(x["ci_high"]):.0f}) per 1,000')
        ddr.append(dict(model=g['model_id'], target=g['target'], k=x['k'], n=x['N'], eff=num(x['effect'], 2), lo=num(x['ci_low'], 2),
                        hi=num(x['ci_high'], 2), cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'],
                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'], version='Current (draft) [PROVISIONAL]'))
""")
rep("""        r['version'] = SUP_TXT if RESC_SUP.get(r['outcome_comparison']) in SUPER else 'Current'
""",
    """        r['version'] = SUP_TXT if RESC_SUP.get(r['outcome_comparison']) in SUPER else 'Current'
    for rows_ in (prim, exp, oth):   # D3: earlier profiles of the bodies that Colak 2010 or Fu 2024 enter
        for r in rows_:
            if r['model'] in D3_GRADE and r['version'] == 'Current':
                r['version'] = 'Superseded: profile before decision D3 (2 Nov 2026). Current draft profile: sheet "D3 drafts"'
""")
rep("""'Current profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026): revised after an independent AI re-check and confirmed by SKP on 2 Nov 2026')],""",
    """'Current profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026): revised after an independent AI re-check and confirmed by SKP on 2 Nov 2026'),
                  ('D3 drafts', 'Profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): AI drafts awaiting second review by SKP [PROVISIONAL]')],""")
rep("""'The broader first-day TEAS-versus-sham profile was updated on 24 Oct 2026 for the Lee 2011 hold (6 trials, 547 participants); certainty unchanged.'])""",
    """'The broader first-day TEAS-versus-sham profile was updated on 24 Oct 2026 for the Lee 2011 hold (6 trials, 547 participants); certainty unchanged.',
                  'The rescue profile in sheet "With Wang 1997" rated the six-trial body that SKP confirmed before Fu 2024 was added; its numbers are that body (RESCUE_LOO_Fu_2024). The seven-trial draft is in sheet "D3 drafts".'])""")
rep("""           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])
    return save(wb, 11, '.xlsx')""",
    """           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])
    sheet(wb, 'D3 drafts', ddr, [('model', 'Analysis', 30), ('target', 'Target of the rating', 40), ('k', 'Trials', 7),
                                 ('n', 'Participants', 10), ('eff', 'Effect', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9),
                                 ('cert', 'Certainty', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('ab', 'Absolute effect (illustrative)', 36),
           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])
    return save(wb, 11, '.xlsx')""")

# ---- AF12 ----------------------------------------------------------------------------------------------------------
rep("            if m.startswith('opioid24_TEAS_sham_expanded'):   # re-check M03\n",
    "            if 'Fu 2024' in x['reports']:   # D3, 2 Nov 2026\n"
    "                row['note'] += '; refitted with Fu 2024 (decision D3, 2 Nov 2026)'\n"
    "            elif 'Fu 2024 not eligible' in x['description']:\n"
    "                row['note'] += '; Fu 2024 (decision D3) not eligible: follow-up not stated'\n"
    "            if m.startswith('opioid24_TEAS_sham_expanded'):   # re-check M03\n")
rep("role='Added 2 Nov 2026', note='Added with Wang 1997 (decision D1)')",
    "role='Added 2 Nov 2026', note='Added with Wang 1997 (decision D1)' + ('; includes Fu 2024 (decision D3)' if 'Fu 2024' in x['reports'] else ''))")
rep("        if m in have or not m.startswith(('E2', 'RESCUE', 'opioid')):",
    "        if m in have or m in D3_MOD or not m.startswith(('E2', 'RESCUE', 'opioid')):")
rep("    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']",
    """    x = W97_MOD['RESCUE_LOO_Fu_2024']   # D3, 2 Nov 2026
    row = dict(model='RESCUE_LOO_Fu_2024', family='Rescue opioid receipt', analysis=x['description'], measure='RR', k=x['k'], n=x['N'],
               eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'],
               reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)', post_hoc='Yes', role='Added 2 Nov 2026',
               note='Added with Fu 2024 (decision D3): the earlier six-trial estimate with Wang 1997')
    for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
        row[c] = '' if row[c] == 'NA' else num(row[c], dp)
    op.append(row)
    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']""")
rep("reports=x['reports'].replace('; ', ';'), note=(r['note'] + ' ' if r['note'] else '') + 'Refitted with Wang 1997 (included 2 Nov 2026).')",
    "reports=x['reports'].replace('; ', ';'), note=(r['note'] + ' ' if r['note'] else '') + ('Refitted with Fu 2024 (decision D3, 2 Nov 2026).' if r['model_id'] in D3_MOD else 'Refitted with Wang 1997 (included 2 Nov 2026).'))")
rep("""        if m in have:
            continue
        rr = m.startswith(('nausea', 'vomiting'))""",
    """        if m in have or m in D3_MOD:
            continue
        rr = m.startswith(('nausea', 'vomiting'))""")
rep("""    ind = []
""",
    """    have = {r['model'] for r in oth} | {r['model'] for r in op}
    D3_OTH = {'pain24_rest_EA_usual': ('Pain at rest at about 24 h, EA vs usual care', 'Additional', 'pain_rest_approximately24h', '0–10 points', ''),
              'QoR15_SHAM_24H_LOO_Fu_2024': ('QoR-15: TEAS vs sham 24H; omit Fu 2024', 'Diagnostic', 'quality_of_recovery', 'QoR-15 points', 'QoR15_SHAM_24H')}
    for m, (lab, role, fam, unit, parent) in D3_OTH.items():   # D3, 2 Nov 2026
        x = W97_MOD[m]
        oth.append(dict(model=m, label=lab, role=role, family=fam, measure='MD', unit=unit, k=x['k'], n=x['N'], eff=num(x['effect']),
                        lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='' if x['tau2'] == 'NA' else num(x['tau2'], 4),
                        i2='' if x['I2'] == 'NA' else num(x['I2'], 1),
                        status='Single trial, normal interval' if x['k'] == '1' else 'REML + Hartung-Knapp (floored at 1)',
                        reports=x['reports'], parent=parent, basis='Decision D3 (2 Nov 2026)', note=x['description']))
    left = D3_MOD - {r['model'] for r in oth} - {r['model'] for r in op} - {'opioid7d_pethidine_EA_usual_COLAK'}
    assert not left, left
    ind = []
""")
rep("    miss = recs(R / 'missing_outcome_assumptions.csv')\n",
    """    x, w = W97_MOD['opioid7d_pethidine_EA_usual_COLAK'], D3_RES['COLAK10-PETH-7D']   # D3, 2 Nov 2026
    ind.append(dict(report='Colak 2010', outcome='Pethidine, total', window='Postoperative days 0–7', opioid='Pethidine', unit='mg',
                    modality='EA', comparator='Usual care', effect_measure='MD', effect=num(x['effect']), ci_low=num(x['ci_low']),
                    ci_high=num(x['ci_high']), n_i=w['n_i'], n_c=w['n_c'], status='NATIVE_SINGLE_TRIAL',
                    note='Added 2 Nov 2026 (decision D3); 7-day window, outside every 0–24-h analysis',
                    derivation=f"Means (SD) as printed: {w['value_i']} ({w['sd_i']}) vs {w['value_c']} ({w['sd_c']}) mg", source_location=w['source_location']))
    miss = recs(R / 'missing_outcome_assumptions.csv')
""")
rep("""                         assumption='No missing outcomes; observed values used in every scenario (added 2 Nov 2026)'))
""",
    """                         assumption='No missing outcomes; observed values used in every scenario (added 2 Nov 2026)'))
    for sc, ev in (('NONE', '0'), ('ALL', '1'), ('UNFAVOURABLE_TO_TEAS', '0'), ('FAVOURABLE_TO_TEAS', '1')):   # Fu 2024 (D3)
        miss.append(dict(scenario=sc, report='Fu 2024', observed_n_i='30', observed_n_c='29', randomized_n_i='30', randomized_n_c='30',
                         missing_i='0', missing_c='1', imputed_events_i='0', imputed_events_c=ev,
                         assumption='One sham participant withdrew (Fig. 2 of the report); added 2 Nov 2026 (decision D3)'))
""")
rep("""                  'not the current one.'])""",
    """                  'not the current one.',
                  'Colak 2010 and Fu 2024 were included on 2 Nov 2026 (decision D3), and Chen 2016 was included and held from pooled '
                  'analyses (ages 16–80 years). Analyses that Fu 2024 or Colak 2010 enter were refitted (Note column); without Fu 2024 '
                  'the rescue estimate is the earlier six-trial one (RESCUE_LOO_Fu_2024).'])""")

# ---- AF9 -----------------------------------------------------------------------------------------------------------
rep("""    'recheck': [REV / 'recheck' / f for f in ('update_wang_records.py', 'apply_recheck_text.py', 'patch_af_recheck.py')],
""",
    """    'recheck': [REV / 'recheck' / f for f in ('update_wang_records.py', 'apply_recheck_text.py', 'patch_af_recheck.py')],
    'd3': [REV / 'd3' / f for f in ('build_d3_records.py', 'apply_d3_text.py', 'patch_af_d3.py', 'd3_decisions.csv', 'd3_results.csv',
                                    'd3_characteristics.csv', 'd3_rob2_DRAFT.csv', 'd3_grade_DRAFT.csv', 'prisma_counts_current.json',
                                    'rob_domain_summary_d3.csv', 'rob_key_analyses_d3.csv', 'stata_figures_d3.log')]
          + [REV / 'recheck/D3_membership_dossier.md'],
""")
rep("'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026) to every analysis it enters '",
    "'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026), and Colak 2010 and Fu 2024 '\n"
    "              '(decision D3, same date), to every analysis they enter '")

B.write_text(s, encoding='utf-8')

# reproduce_final.R (also rewritten by patch_af_recheck.py): name the D3 reports in the refit message
R = HERE.parent / 'reproduce/reproduce_final.R'
r = R.read_text(encoding='utf-8')
old = 'cat(sprintf("Refitted %d analyses with Wang 1997; maximum absolute difference from the archived refit %.2e\\n", nrow(wn), wd))'
assert r.count(old) == 1, r.count(old)
R.write_text(r.replace(old, old.replace('with Wang 1997;', 'with Wang 1997 and the D3 reports (Colak 2010, Fu 2024);')), encoding='utf-8')
print(n, 'D3 builder edits; 1 reproduction-script edit')
