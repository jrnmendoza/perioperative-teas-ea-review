"""Manuscript text after decision D4 (JRNM and SKP, reported 3 Nov 2026): nine outcome exclusions counted under a corrected reason.

Runs after skp_d3_review/apply_skp_text.py and edits sources/*_REVISED.md in place; every passage is asserted once and a
passage already edited is skipped. Fig. 1 counts: no eligible analgesic outcome 106 -> 97, no confirmed postoperative opioid
result 32 -> 40 (none located 18 -> 25; not confirmed 14 -> 15), wrong setting 8 -> 9. The mandated disclosure sentence and
the PROVISIONAL markers for the 53 reports not yet re-checked (D5) are unchanged."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'results': [
  ('no 24-hour opioid or pain outcome (106 reports), no confirmed postoperative opioid result (32) and no English full text (12).',
   'no 24-hour opioid or pain outcome (97 reports), no confirmed postoperative opioid result (40) and no English full text (12).'),
  ('and two had no confirmed postoperative opioid result. [PROVISIONAL: 45',
   'and two had no confirmed postoperative opioid result. On 3 November 2026, JRNM and SKP corrected the reason for nine other '
   'outcome exclusions, which remain excluded: eight give no postoperative opioid result, and Tzeng 2015 used spinal '
   'anaesthesia without general anaesthesia. [PROVISIONAL: 45'),
 ],
 'methods': [
  ('five others remained excluded, three of them under a corrected reason.',
   'five others remained excluded, three of them under a corrected reason. On 3 November 2026, JRNM and SKP corrected the '
   'recorded reason for nine more excluded reports from that recheck.'),   # no AF citation here: AF3 is cited first
 ],
 'discussion': [
  ('four were included and five remained excluded, three under a corrected reason;',
   'four were included and 14 remained excluded, 12 of them under a corrected reason;'),
 ],
 'figures': [
  ('and three whose reason that check corrected (Additional file 4).', 'and 12 whose reason that check corrected (Additional file 4).'),
  ('none was located in the available report for 18, and for 14 the opioid',
   'none was located in the available report for 25, and for 15 the opioid'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after decision D4')
