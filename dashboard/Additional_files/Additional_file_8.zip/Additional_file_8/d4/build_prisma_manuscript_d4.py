"""Manuscript PRISMA 2020 flow diagram for the 40-report set (Figure 1).

Reads prisma_counts.json (read-only; its hash is pinned elsewhere) and writes a clean
PRISMA 2020-template figure as PDF, SVG and PNG, plus the figure legend. The older
working chart (prisma_40_reports.*) and its dashboard use are left unchanged.
Run with the bundled Python that provides reportlab:
  ~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 build_prisma_manuscript.py
"""
import json, html, subprocess, shutil, hashlib
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth

HERE = Path(__file__).resolve().parent
C = json.loads((HERE / 'prisma_counts.json').read_text())

# ---- arithmetic checks -------------------------------------------------------
dups = C['automatic_duplicates'] + C['manual_duplicates']
assert C['references'] - dups - C['automation_exclusions'] - C['unmapped_import_difference'] == C['screened']
assert C['screened'] - C['title_abstract_excluded'] == C['database_sought']
assert C['database_sought'] - C['database_not_retrieved'] == C['database_assessed_records']
reasons = C['exclusion_reasons']
historical = {k: v for k, v in reasons.items() if k not in C['additional_exclusion_reasons']}
assert sum(historical.values()) == C['original_database_excluded']
assert sum(C['additional_exclusion_reasons'].values()) == C['additional_focused_exclusions']
excluded = C['late_duplicates'] + sum(reasons.values())
assert C['database_assessed_records'] - excluded == C['database_included']
assert C['database_included'] + C['citation_included'] == C['included_reports']
unresolved = C['additional_focused_exclusions'] - C['additional_exclusion_reasons']['No postoperative opioid result located in available report']
assert unresolved == C['pending_outcome_clarification_outside_set']

n = lambda v: f'{v:,}'
label = {'no perioperative analgesia outcome found': 'No eligible analgesic outcome^b',
         'Publication language': 'Publication language', 'Wrong setting': 'Wrong setting',
         'Wrong intervention': 'Wrong intervention', 'Wrong comparator': 'Wrong comparator',
         'Wrong patient population': 'Wrong population', 'Wrong study design': 'Wrong study design',
         'Abstract only': 'Abstract only'}
# The opioid-result criterion is listed with the other full-text reasons, in order of size (author decision, 24 Oct 2026);
# its timing is disclosed once, in the Methods deviations sentence.
full_text = {label[k]: v for k, v in historical.items()}
full_text['No confirmed postoperative opioid result^c'] = C['additional_focused_exclusions']
excl_lines = [f'Duplicate reports (n = {n(C["late_duplicates"])})']
excl_lines += [f'{k} (n = {n(v)})' for k, v in sorted(full_text.items(), key=lambda kv: -kv[1])]

db = C['databases']
# ---- layout (points; origin top-left, converted for PDF) --------------------
W, H = 662, 560
FONT, BOLD, FS, LH, PAD = 'Helvetica', 'Helvetica-Bold', 8.6, 11.6, 7
INK, LINE, BAND, FILL = '#1f2933', '#52606d', '#e4e9ef', '#ffffff'
XL, WL = 44, 200          # main column
XR, WR = 264, 222         # exclusion column
XO, WO = 506, 146         # other methods

boxes = []   # (x, y, w, h, heading, lines)
def box(x, y, w, heading, lines=(), h=None):
    hh = h or (PAD * 2 + LH * (1 + len(lines)) - 2)
    boxes.append((x, y, w, hh, heading, list(lines)))
    return (x, y, w, hh)

ident = box(XL, 56, WL, f'Records identified from databases (n = {n(C["references"])})',
            [f'Embase (n = {n(db["Embase"])})', f'CENTRAL (n = {n(db["CENTRAL"])})',
             f'PubMed (n = {n(db["PubMed"])})', f'CINAHL (n = {n(db["CINAHL"])})'])
removed = box(XR, 56, WR, 'Records removed before screening:',
              [f'Duplicate records (n = {n(dups)})',
               f'Marked ineligible by automation tools (n = {n(C["automation_exclusions"])})',
               f'Unmapped import difference (n = {n(C["unmapped_import_difference"])})^a'], h=ident[3])
other_id = box(XO, 56, WO, 'Citation searching', [f'Records identified (n = {n(C["citation_sought"])})'], h=ident[3])
y = 56 + ident[3] + 20
screened = box(XL, y, WL, f'Records screened (n = {n(C["screened"])})')
screened_x = box(XR, y, WR, f'Records excluded (n = {n(C["title_abstract_excluded"])})')
y += screened[3] + 20
sought = box(XL, y, WL, f'Reports sought for retrieval (n = {n(C["database_sought"])})')
notret = box(XR, y, WR, f'Reports not retrieved (n = {n(C["database_not_retrieved"])})')
other_sought = box(XO, y, WO, f'Reports sought (n = {n(C["citation_sought"])})', ['Not retrieved (n = 0)'], h=None)
y += max(sought[3], other_sought[3]) + 20
assessed = box(XL, y, WL, f'Reports assessed for eligibility (n = {n(C["database_assessed_records"])})')
excl = box(XR, y, WR, f'Reports excluded (n = {n(excluded)}):', excl_lines)
other_assessed = box(XO, y, WO, f'Reports assessed (n = {n(C["citation_assessed"])})',
                     [f'Excluded (n = {C["citation_assessed"] - C["citation_included"]})'])
y += excl[3] + 22
included = box(XL, y, XO + WO - XL, f'Studies included in review (n = {n(C["operational_trial_families"])})^d',
               [f'Reports of included studies (n = {n(C["included_reports"])})'], h=52)
H = included[1] + included[3] + 16

bands = [(XL, 20, XR + WR - XL, 'Identification of studies via databases and registers'),
         (XO, 20, WO, 'Identification via other methods')]
sides = [('Identification', 56, ident[1] + ident[3]), ('Screening', screened[1], excl[1] + excl[3]),
         ('Included', included[1], included[1] + included[3])]
arrows = [  # (x1, y1, x2, y2)
    (XL + WL / 2, ident[1] + ident[3], XL + WL / 2, screened[1]),
    (XL + WL / 2, screened[1] + screened[3], XL + WL / 2, sought[1]),
    (XL + WL / 2, sought[1] + sought[3], XL + WL / 2, assessed[1]),
    (XL + WL / 2, assessed[1] + assessed[3], XL + WL / 2, included[1]),
    (XL + WL, ident[1] + ident[3] / 2, XR, ident[1] + ident[3] / 2),
    (XL + WL, screened[1] + screened[3] / 2, XR, screened[1] + screened[3] / 2),
    (XL + WL, sought[1] + sought[3] / 2, XR, sought[1] + sought[3] / 2),
    (XL + WL, assessed[1] + assessed[3] / 2, XR, assessed[1] + assessed[3] / 2),
    (XO + WO / 2, other_id[1] + other_id[3], XO + WO / 2, other_sought[1]),
    (XO + WO / 2, other_sought[1] + other_sought[3], XO + WO / 2, other_assessed[1]),
    (XO + WO / 2, other_assessed[1] + other_assessed[3], XO + WO / 2, included[1]),
]

def segments(text):
    """Split 'abc^d xyz' into [(text, superscript?)]; a marker is one letter after ^."""
    out, i = [], 0
    while '^' in text[i:]:
        j = text.index('^', i)
        out.append((text[i:j], False)); out.append((text[j + 1], True)); i = j + 2
    out.append((text[i:], False))
    return [s for s in out if s[0]]

def width(text, font):
    return sum(stringWidth(t, font, FS * (0.72 if sup else 1)) for t, sup in segments(text))

for x, yy, w, h, head, lines in boxes:   # every line must fit inside its box
    for t, f in [(head, BOLD)] + [(l, FONT) for l in lines]:
        assert width(t, f) <= w - 2 * PAD + 0.01, (t, width(t, f), w - 2 * PAD)

# ---- PDF ---------------------------------------------------------------------
out_pdf = HERE / 'prisma_40_reports_manuscript.pdf'
cv = canvas.Canvas(str(out_pdf), pagesize=(W, H))
cv.setTitle('PRISMA 2020 flow diagram'); cv.setAuthor('Perioperative TEAS/EA review')
Y = lambda v: H - v
def pdf_text(x, yb, text, font):
    for t, sup in segments(text):
        size = FS * (0.72 if sup else 1)
        cv.setFont(font if not sup else FONT, size)
        cv.drawString(x, yb + (3.2 if sup else 0), t); x += stringWidth(t, font if not sup else FONT, size)
cv.setStrokeColor(HexColor(LINE)); cv.setLineWidth(0.8)
for x, yy, w, t in bands:
    cv.setFillColor(HexColor(BAND)); cv.rect(x, Y(yy + 24), w, 24, stroke=0, fill=1)
    cv.setFillColor(HexColor(INK)); cv.setFont(BOLD, FS); cv.drawCentredString(x + w / 2, Y(yy + 15.5), t)
for t, y1, y2 in sides:
    cv.setFillColor(HexColor(BAND)); cv.rect(10, Y(y2), 24, y2 - y1, stroke=0, fill=1)
    cv.saveState(); cv.translate(25.5, Y((y1 + y2) / 2)); cv.rotate(90)
    cv.setFillColor(HexColor(INK)); cv.setFont(BOLD, FS); cv.drawCentredString(0, 0, t); cv.restoreState()
for x, yy, w, h, head, lines in boxes:
    cv.setFillColor(HexColor(FILL)); cv.setStrokeColor(HexColor(LINE)); cv.rect(x, Y(yy + h), w, h, stroke=1, fill=1)
    cv.setFillColor(HexColor(INK))
    for i, (t, f) in enumerate([(head, BOLD)] + [(l, FONT) for l in lines]):
        pdf_text(x + PAD, Y(yy + PAD + 8.6 + i * LH), t, f)
def pdf_arrow(x1, y1, x2, y2):
    cv.setStrokeColor(HexColor(LINE)); cv.setFillColor(HexColor(LINE)); cv.line(x1, Y(y1), x2, Y(y2))
    if x1 == x2: p = [(x2, Y(y2)), (x2 - 3.2, Y(y2 - 6)), (x2 + 3.2, Y(y2 - 6))]
    else: p = [(x2, Y(y2)), (x2 - 6, Y(y2) + 3.2), (x2 - 6, Y(y2) - 3.2)]
    path = cv.beginPath(); path.moveTo(*p[0]); [path.lineTo(*q) for q in p[1:]]; path.close()
    cv.drawPath(path, stroke=0, fill=1)
for a in arrows: pdf_arrow(*a)
cv.showPage(); cv.save()

# ---- SVG ---------------------------------------------------------------------
e = html.escape
svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H:.0f}" viewBox="0 0 {W} {H:.0f}" '
       f'font-family="Helvetica, Arial, sans-serif" font-size="{FS}">',
       f'<rect width="{W}" height="{H:.0f}" fill="#ffffff"/>',
       f'<defs><marker id="ah" markerWidth="6" markerHeight="6.4" refX="6" refY="3.2" orient="auto">'
       f'<path d="M0,0 L6,3.2 L0,6.4 z" fill="{LINE}"/></marker></defs>']
def svg_text(x, yb, text, bold):
    parts = ''.join(f'<tspan font-size="{FS * 0.72:.2f}" baseline-shift="super" font-weight="normal">{e(t)}</tspan>' if sup
                    else f'<tspan>{e(t)}</tspan>' for t, sup in segments(text))
    return f'<text x="{x:.1f}" y="{yb:.1f}" fill="{INK}"{" font-weight=\"bold\"" if bold else ""}>{parts}</text>'
for x, yy, w, t in bands:
    svg.append(f'<rect x="{x}" y="{yy}" width="{w}" height="24" fill="{BAND}"/>')
    svg.append(f'<text x="{x + w / 2:.1f}" y="{yy + 15.5:.1f}" text-anchor="middle" font-weight="bold" fill="{INK}">{e(t)}</text>')
for t, y1, y2 in sides:
    svg.append(f'<rect x="10" y="{y1:.1f}" width="24" height="{y2 - y1:.1f}" fill="{BAND}"/>')
    cy = (y1 + y2) / 2
    svg.append(f'<text transform="translate(25.5 {cy:.1f}) rotate(-90)" text-anchor="middle" font-weight="bold" fill="{INK}">{e(t)}</text>')
for x, yy, w, h, head, lines in boxes:
    svg.append(f'<rect x="{x}" y="{yy:.1f}" width="{w}" height="{h:.1f}" fill="{FILL}" stroke="{LINE}" stroke-width="0.8"/>')
    for i, (t, b) in enumerate([(head, True)] + [(l, False) for l in lines]):
        svg.append(svg_text(x + PAD, yy + PAD + 8.6 + i * LH, t, b))
for x1, y1, x2, y2 in arrows:
    svg.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{LINE}" stroke-width="0.8" marker-end="url(#ah)"/>')
svg.append('</svg>')
(HERE / 'prisma_40_reports_manuscript.svg').write_text('\n'.join(svg) + '\n')

# ---- PNG (approx. 300 dpi at 170 mm full width) ------------------------------
png = HERE / 'prisma_40_reports_manuscript.png'
if shutil.which('qlmanage'):
    tmp = HERE / '_ql'; tmp.mkdir(exist_ok=True)
    subprocess.run(['qlmanage', '-t', '-s', '2010', '-o', str(tmp), str(out_pdf)], check=True, capture_output=True)
    (tmp / (out_pdf.name + '.png')).replace(png); tmp.rmdir()

# ---- legend --------------------------------------------------------------------
legend = f"""**Figure 1. PRISMA 2020 flow diagram.** Database searches were run in July 2026; one further report was identified by citation searching. ᵃ Difference between the references exported from the databases ({n(C['references'])}) and the records imported to the screening platform ({n(C['reported_import_records'])}), which could not be mapped to individual records. ᵇ At full text, eligibility required a 24-hour opioid or approximately 24-hour pain outcome, which is narrower than the registered eligibility (see Methods). ᶜ No named postoperative opioid or morphine-equivalent quantity could be confirmed in the source: none was located in the available report for {C['additional_exclusion_reasons']['No postoperative opioid result located in available report']}, and for {unresolved} the opioid identity, quantity or timing could not be confirmed (Additional file 4). ᵈ Two reports (Yeh 2010 and Yeh 2011) probably describe overlapping participants and are counted as one study. Adapted from Page et al. [@page2021statement].
"""
(HERE / 'FIGURE1_LEGEND.md').write_text(legend)
words = len(legend.replace('**', '').split())
assert words <= 300, words
manifest = {'inputs': {'prisma_counts.json': hashlib.sha256((HERE / 'prisma_counts.json').read_bytes()).hexdigest()},
            'outputs': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                        [out_pdf, HERE / 'prisma_40_reports_manuscript.svg', png, HERE / 'FIGURE1_LEGEND.md'] if p.exists()},
            'legend_words': words, 'arithmetic': 'PASS', 'text_fits_boxes': 'PASS'}
(HERE / 'manuscript_figure_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
