"""Additional-files edits after decision D4 (JRNM and SKP, reported by the review owner on 3 Nov 2026): nine outcome exclusions
counted under a corrected reason (d4/d4_decisions.csv).

Run after skp_d3_review/patch_af_skp.py (the chain rewrites build_additional_files.py from its snapshot each time); this
script edits build_additional_files.py in place, each replacement asserted once. AF4: the nine Reports rows move to their
corrected reason (eight to the 9 October criterion, Tzeng 2015 to wrong setting), their triage rows record the decision and
a "D4 decisions" sheet lists the decisions with their source basis. AF2: section 6 (the D4 paragraph; the 8 October audit
counts are kept as they were on that date, because the PRISMA counts now include the D4 relabels), the triage summary and
the decision log. AF9: this folder. The Fig. 1 counts follow d3/prisma_counts_current.json, which d4/record_d4.py edits."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# ---- records ----------------------------------------------------------------------------------------------------------
rep("D3_NOTE = 'included 2 Nov 2026 (decision D3)'\n",
    "D3_NOTE = 'included 2 Nov 2026 (decision D3)'\n"
    "# Decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected reason; all remain excluded.\n"
    "D4_DEC = {r['covidence_id']: r for r in recs(REV / 'd4/d4_decisions.csv')}\n")

# ---- AF2 section 6 ------------------------------------------------------------------------------------------------------
rep("'before the recheck of 2 November 2026, after which four were included and three were excluded under another reason) '",
    "'before the recheck of 2 November 2026; four were then included and 12 were counted under a corrected reason, decisions '\n"
    "            'D1, D3 and D4) '")
# the 8 October audit counts as on that date (the PRISMA counts now carry D3 and D4)
rep("f'8 October 2026) identified {pc[\"additional_focused_exclusions\"] - 2} without one: '\n"
    "            f'{a[\"No postoperative opioid result located in available report\"]} in which no postoperative opioid result '",
    "f'8 October 2026) identified {pc[\"additional_focused_exclusions\"] - 2 - 8} without one: '\n"
    "            f'{a[\"No postoperative opioid result located in available report\"] - 7} in which no postoperative opioid result '")
rep("f'{a[\"Pump requests/presses only; opioid quantity not verified\"]} reporting only pump requests or presses; and '",
    "f'{a[\"Pump requests/presses only; opioid quantity not verified\"] - 1} reporting only pump requests or presses; and '")
rep("'(decision D3, below). The 40 remaining reports",
    "'(decision D3, below), and eight more were counted under it on 3 November 2026 (decision D4, below). The 40 remaining reports")
rep("'postoperative opioid result (they remain excluded, under the 9 October criterion); 7 whose exclusion is '\n"
    "            'supported or fails another criterion first (Tzeng 2015: spinal anaesthesia without general anaesthesia); 8 '",
    "'postoperative opioid result (they remain excluded and, by decision D4, are counted under the 9 October criterion); 7 '\n"
    "            'whose exclusion is supported or fails another criterion first (Tzeng 2015: spinal anaesthesia without general '\n"
    "            'anaesthesia, counted as wrong setting by decision D4); 8 '")
rep("    head(d, '7. Outcomes')\n",
    "    para(d, '**Decision D4: corrected reasons for nine outcome exclusions (3 November 2026).** JRNM and SKP decided, with '\n"
    "            'trial results known, to count nine reports from the recheck under a corrected reason (evidence in Additional '\n"
    "            'file 4, sheets \"Outcome exclusions recheck\" and \"D4 decisions\"). All remain excluded and no estimate changed. '\n"
    "            'Eight give no postoperative opioid result and are now counted under the 9 October criterion: five report pain '\n"
    "            'at or near 24 hours (Hou 2023, Li 2025, Liu 2024, Tong 2022 and Yue 2023), so their recorded reason was not '\n"
    "            'supported, and for three it is unclear whether their pain result meets the 14 August rule (Liu 2008, the '\n"
    "            'number of patients with severe pain only; Qin 2023, pain over 6–24 hours; Zheng 2008, pain over 12–24 hours), '\n"
    "            'as for Li 2017 under decision D3. Tzeng 2015, done under spinal anaesthesia without general anaesthesia, is now '\n"
    "            'counted as wrong setting. In Fig. 1, no eligible analgesic outcome went from 106 to 97, no confirmed '\n"
    "            'postoperative opioid result from 32 to 40 and wrong setting from 8 to 9.')\n\n"
    "    head(d, '7. Outcomes')\n")

# ---- AF2 section 10: decision log -----------------------------------------------------------------------------------------
rep("    after('8 Oct', ['8 Oct',",
    "    rows.append(['3 Nov', 'Decision D4 (JRNM and SKP, results known): nine outcome exclusions counted under a corrected reason '\n"
    "                 '(section 6). Eight with no postoperative opioid result moved to the 9 October criterion; Tzeng 2015 (spinal '\n"
    "                 'anaesthesia without general anaesthesia) moved to wrong setting. All remain excluded; no estimate changed.', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct',")

# ---- AF4: Reports, triage, README, D4 decisions sheet ---------------------------------------------------------------------
rep("        if fd == 'INCLUDED':\n",
    "        if r['covidence_id'] in D4_DEC:   # D4, 3 Nov 2026 (d4/d4_decisions.csv)\n"
    "            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']\n"
    "            dec = D4_DEC[r['covidence_id']]\n"
    "            note = ('Excluded at full-text screening (no eligible analgesic outcome); reread after the outcome-exclusion recheck. '\n"
    "                    f'Decision D4 (JRNM and SKP, 3 Nov 2026, results known): {dec[\"decision\"]}. {dec[\"basis\"]}')\n"
    "            if dec['counted_as'] == 'Wrong setting':\n"
    "                fr = 'Wrong setting'\n"
    "            else:\n"
    "                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', dec['counted_as']\n"
    "                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-03')\n"
    "        if fd == 'INCLUDED':\n")
rep("            t['proposed_human_action'] += f' Decided 2 Nov 2026 by the review owner (D3): {dec[\"decision\"]}.'\n",
    "            t['proposed_human_action'] += f' Decided 2 Nov 2026 by the review owner (D3): {dec[\"decision\"]}.'\n"
    "        if t['covidence_id'] in D4_DEC:   # D4, 3 Nov 2026\n"
    "            assert t['category'] in ('REASON', 'STANDS'), t['covidence_id']\n"
    "            dec = D4_DEC[t['covidence_id']]\n"
    "            t['category'] += ': reason corrected 3 Nov 2026 (D4)'\n"
    "            t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D4): {dec[\"decision\"]}.'\n")
rep("with the review owner decisions on the nine membership candidates (D1, D3); the triage",
    "with the review owner decisions on the nine membership candidates (D1, D3) and the corrected reasons for nine others "
    "(D4, JRNM and SKP); the triage")
rep("'single-trial estimate, descriptive, narrative, not a registered outcome or held (added 3 Nov 2026)')],",
    "'single-trial estimate, descriptive, narrative, not a registered outcome or held (added 3 Nov 2026)'),\n"
    "                 ('D4 decisions', 'Decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected '\n"
    "                                  'reason, with the source basis; all remain excluded')],")
rep("'August 2026 outcome rule; JRNM and SKP screened the full texts independently (Methods).",
    "'August 2026 outcome rule, apart from the reports included or relabelled after the 2 November 2026 recheck '\n"
    "                 '(decisions D1, D3 and D4); JRNM and SKP screened the full texts independently (Methods).")
rep("                                      ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])\n    return save(wb, 4, '.xlsx')",
    "                                      ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])\n"
    "    sheet(wb, 'D4 decisions', list(D4_DEC.values()), [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 14),\n"
    "          ('previous_reason', 'Previous reason', 22), ('decision', 'Decision', 30), ('counted_as', 'Counted in Fig. 1 as', 30),\n"
    "          ('rule_14aug', '14 Aug outcome rule', 22), ('basis', 'Basis (source location)', 80), ('decided_by', 'Decided by', 40)])\n"
    "    return save(wb, 4, '.xlsx')")

# ---- AF9: this folder ---------------------------------------------------------------------------------------------------
rep("          + [REV / 'skp_d3_review/figure_builds/build_rob_figure_skp.py'],\n",
    "          + [REV / 'skp_d3_review/figure_builds/build_rob_figure_skp.py'],\n"
    "    'd4': [REV / 'd4' / f for f in ('record_d4.py', 'd4_decisions.csv', 'apply_d4_text.py', 'patch_af_d4.py', 'update_verify_d4.py')]\n"
    "          + [REV / 'd4/figure_builds/build_prisma_manuscript_d4.py'],\n")
rep("'English-abstract check. All were confirmed as made or drafted, so no judgement, value or estimate changed.', '',\n",
    "'English-abstract check. All were confirmed as made or drafted, so no judgement, value or estimate changed.',\n"
    "              '- `d4/`: decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected reason '\n"
    "              '(`d4_decisions.csv`), with the Fig. 1 counts, text and builder edits that follow; no estimate changed.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after decision D4')
