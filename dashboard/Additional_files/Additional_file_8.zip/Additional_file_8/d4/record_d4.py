"""Decision D4 (JRNM and SKP, reported by the review owner on 3 Nov 2026): corrected exclusion reasons for nine outcome exclusions.

The 2 Nov 2026 triage of the 113 "No eligible analgesic outcome" exclusions (C01_selection/) found eight reports with pain at
or near 24 hours, or pain over a 24-hour interval, but no postoperative opioid result, and Tzeng 2015, done under spinal
anaesthesia without general anaesthesia. The review owner reported that JRNM and SKP decided, with trial results known, to
count all eight under the 9 October 2026 opioid-result criterion (the failure that is certain for each; as for Li 2017 under
D3) and Tzeng 2015 as wrong setting. All nine remain excluded; no estimate changes.

Runs after d3/build_d3_records.py (which rewrites d3/prisma_counts_current.json each time) and edits that file in place;
writes d4/d4_decisions.csv. The bases were checked against the local full texts (10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/
exclusions/) by the AI assistant on 3 Nov 2026 before the decision."""
import csv, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
BY = 'JRNM and SKP (reported by the review owner, 3 Nov 2026; results known)'
OP, LOC, PRESS = ('Exclude: no confirmed postoperative opioid result', 'No postoperative opioid result located in available report',
                  'Pump requests/presses only; opioid quantity not verified')
D = [  # covidence_id, report, decision, counted as (PRISMA key), 14 Aug rule, basis
 ('1879896346', 'Hou 2023', OP, LOC, 'Met',
  'NRS at rest and on movement on postoperative days 1-3 (Fig. 3). PCIA sufentanil dosage is listed as a secondary outcome '
  '(Outcomes, PDF p4) but no value is reported.'),
 ('1879896126', 'Li 2025', OP, LOC, 'Met if an ordinal 0-4 scale counts',
  'Abdominal pain graded on the 0-4 Prince Henry scale at 12 and 24 h (Table 3, PDF p7); no postoperative opioid is named or quantified.'),
 ('1879896245', 'Liu 2024', OP, LOC, 'Met',
  'NRS at 24 h, median (IQR) 4 (3, 5) vs 5 (3, 6) (Table 2, PDF p5). Rescue analgesia was parecoxib, a non-opioid (Table 3); '
  'consumption of the sufentanil PCA is not reported.'),
 ('1879896482', 'Tong 2022', OP, LOC, 'Met',
  'VAS pain at 24 h, median (IQR) (Table 5, PDF p8); opioids were given only during anaesthesia.'),
 ('1879896360', 'Yue 2023', OP, LOC, 'Met approximately (day 1, possibly about 30 h)',
  'NRS on postoperative day 1 (Table 2, PDF p5). Analgesics were given only on request and no analgesic use is reported.'),
 ('1879897366', 'Liu 2008', OP, LOC, 'Unclear',
  'Only the number of patients with severe pain (Table 3) and a statement that pain was lower at 24 h; the only opioid dose '
  'reported is intraoperative fentanyl (Table 2).'),
 ('1879896407', 'Qin 2023', OP, LOC, 'Unclear',
  'NRS over the 6-24 h interval (Table 3, PDF p6); flurbiprofen axetil was given for analgesia; no postoperative opioid result.'),
 ('1879897384', 'Zheng 2008', OP, PRESS, 'Unclear',
  'VAS over the 12-24 h interval (Table 3, p63). Tramadol PCIA is reported only as button presses (Table 3); supplemental '
  'tramadol is not quantified.'),
 ('1879897043', 'Tzeng 2015', 'Exclude: wrong setting', 'Wrong setting', 'Not met',
  'Spinal (subarachnoid) anaesthesia for total knee arthroplasty, without general anaesthesia (Interventions, p2): fails the '
  'population criterion (surgery under general anaesthesia). Its fentanyl epidural PCA is neuraxial.'),
]
rows = [dict(covidence_id=c, report=r, previous_reason='No eligible analgesic outcome', decision=d, counted_as=k,
             rule_14aug=a, basis=b, decided_by=BY) for c, r, d, k, a, b in D]
with open(HERE / 'd4_decisions.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

tri = {t['covidence_id']: t for t in csv.DictReader(open(REV / 'C01_selection/C01_historical_outcome_exclusions_triage.csv', encoding='utf-8-sig'))}
assert all(tri[c]['category'] == 'REASON' for c, *_ in D[:8]) and tri['1879897043']['category'] == 'STANDS'
assert sum(t['category'] == 'REASON' for t in tri.values()) == 8

p = REV / 'd3/prisma_counts_current.json'
pc = json.loads(p.read_text())
r, a = pc['exclusion_reasons'], pc['additional_exclusion_reasons']
NO = 'no perioperative analgesia outcome found'
assert (r[NO], r['Wrong setting'], r[LOC], r[PRESS], pc['additional_focused_exclusions']) == (106, 8, 18, 4, 32), 'expected the D3 counts'
r[NO] -= 9
r['Wrong setting'] += 1
for k in (r, a):
    k[LOC] += 7
    k[PRESS] += 1
pc['additional_focused_exclusions'] += 8
pc['pending_outcome_clarification_outside_set'] += 1     # Zheng 2008: presses only
pc['original_database_excluded'] -= 8                     # the eight move to the 9 Oct criterion; Tzeng 2015 stays a screening reason
pc['date'] = '2026-11-03'
pc['version'] = pc['version'].replace('Wang 1997 and D3 applied', 'Wang 1997, D3 and D4 applied')
pc['chart_status'] += (' D4 (3 Nov 2026, JRNM and SKP): eight outcome exclusions relabelled to the 9 Oct opioid-result criterion '
                       'and Tzeng 2015 to wrong setting; all remain excluded.')
pc['caveats'].append('Decision D4 (3 Nov 2026): nine outcome exclusions counted under a corrected reason; see '
                     'manuscript/submission/BMC_revision_after_ASTRA_recheck/d4/.')
assert sum(r.values()) == pc['database_excluded'] == 173 and sum(a.values()) == pc['additional_focused_exclusions'] == 40
p.write_text(json.dumps(pc, indent=1))
print('D4 recorded:', len(rows), 'decisions | no eligible outcome', r[NO], '| no confirmed opioid result', pc['additional_focused_exclusions'],
      '| wrong setting', r['Wrong setting'])
