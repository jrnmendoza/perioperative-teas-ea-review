"""After decision D4 (JRNM and SKP, reported by the review owner on 3 Nov 2026): adapt verification/verify_revision.py, as
written by skp_d3_review/update_verify_skp.py.

Run after skp_d3_review/update_verify_skp.py. The PRISMA, Results and AF4 checks now expect the D4 counts (no eligible
analgesic outcome 97, no confirmed postoperative opioid result 40, wrong setting 9; footnote c 25 and 15), and Fig. 1 must be
built from the current counts (d4/figure_builds/). Added checks: the nine decisions are recorded as JRNM and SKP's and appear
in the AF4 Reports, triage and "D4 decisions" sheets; the text states the relabels (Results, Methods, Discussion, Fig. 1
legend, AF2 section 6 and decision log) and keeps the 8 October audit counts as on that date; and, against the snapshot taken
before D4 (d4/pre_d4/), no estimate, judgement, rating, Table 1 row or abstract word changed.
Re-run d3/update_verify_d3.py, audit_d3/update_verify_audit.py, reaudit_d3/update_verify_reaudit.py and
skp_d3_review/update_verify_skp.py first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')


def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


rep("""check('PRISMA after D1 and D3 = project counts with four outcome exclusions included and three relabelled (1 comparator, 2 opioid result)',
      c0['exclusion_reasons'][NO] - 7 == c['exclusion_reasons'][NO] == 106 and c['exclusion_reasons'][CMP] == c0['exclusion_reasons'][CMP] + 1 == 4
      and c['exclusion_reasons'][UNR] == c0['exclusion_reasons'][UNR] + 2 == 8
      and c['included_reports'] == c0['included_reports'] + 4 == 44 and c['operational_trial_families'] == 43
      and {k: v for k, v in c['exclusion_reasons'].items() if k not in (NO, CMP, UNR)}
      == {k: v for k, v in c0['exclusion_reasons'].items() if k not in (NO, CMP, UNR)})""",
    """SET, LOC, PRS = 'Wrong setting', 'No postoperative opioid result located in available report', 'Pump requests/presses only; opioid quantity not verified'
check('PRISMA after D1, D3 and D4 = project counts with four outcome exclusions included and 12 relabelled (D3: 1 comparator, 2 opioid result; D4: 8 opioid result, 1 setting)',
      c0['exclusion_reasons'][NO] - 16 == c['exclusion_reasons'][NO] == 97 and c['exclusion_reasons'][CMP] == c0['exclusion_reasons'][CMP] + 1 == 4
      and c['exclusion_reasons'][UNR] == c0['exclusion_reasons'][UNR] + 2 == 8 and c['exclusion_reasons'][SET] == c0['exclusion_reasons'][SET] + 1 == 9
      and c['exclusion_reasons'][LOC] == c0['exclusion_reasons'][LOC] + 7 == 25 and c['exclusion_reasons'][PRS] == c0['exclusion_reasons'][PRS] + 1 == 5
      and c['additional_focused_exclusions'] == c0['additional_focused_exclusions'] + 10 == 40 and c['pending_outcome_clarification_outside_set'] == 15
      and c['included_reports'] == c0['included_reports'] + 4 == 44 and c['operational_trial_families'] == 43
      and {k: v for k, v in c['exclusion_reasons'].items() if k not in (NO, CMP, UNR, SET, LOC, PRS)}
      == {k: v for k, v in c0['exclusion_reasons'].items() if k not in (NO, CMP, UNR, SET, LOC, PRS)})""")
rep("check('Exclusion reasons sum to 173 (106 + 32 + 12 + 23 other)'", "check('Exclusion reasons sum to 173 (97 + 40 + 12 + 24 other)'")
rep("""check('Results gives 106 outcome exclusions and 32 without a confirmed opioid result', 'no 24-hour opioid or pain outcome (106 reports), no confirmed postoperative opioid result (32)' in results)""",
    """check('Results gives 97 outcome exclusions and 40 without a confirmed opioid result', 'no 24-hour opioid or pain outcome (97 reports), no confirmed postoperative opioid result (40)' in results)""")
rep("""check('AF4 reconciles with Fig. 1 (44 included, 173 excluded, 106 outcome exclusions, 32 without an opioid result, 4 wrong comparator)',
      f1['Included'] == 44 and f1['Total excluded'] == 173 and f1['No eligible analgesic outcome'] == 106
      and f1['No confirmed postoperative opioid result'] == 32 and f1['Wrong comparator'] == 4)""",
    """check('AF4 reconciles with Fig. 1 (44 included, 173 excluded, 97 outcome exclusions, 40 without an opioid result, 4 wrong comparator, 9 wrong setting)',
      f1['Included'] == 44 and f1['Total excluded'] == 173 and f1['No eligible analgesic outcome'] == 97
      and f1['No confirmed postoperative opioid result'] == 40 and f1['Wrong comparator'] == 4 and f1['Wrong setting'] == 9)""")
rep("""man = json.loads((REV / 'd3/figure_builds/fig1_manifest_d3.json').read_text())
check('Fig. 1 built from d3/prisma_counts_current.json', man['inputs']['prisma_counts.json'] == hashlib.sha256((REV / 'd3/prisma_counts_current.json').read_bytes()).hexdigest())""",
    """man = json.loads((REV / 'd4/figure_builds/fig1_manifest_d4.json').read_text())   # rebuilt after decision D4
_svg = (REV / 'd4/figure_builds/prisma_40_reports_manuscript.svg').read_text(encoding='utf-8')
check('Fig. 1 built from d3/prisma_counts_current.json after D4 (97, 40, wrong setting 9); figures/Fig1.png is that build',
      man['inputs']['prisma_counts.json'] == hashlib.sha256((REV / 'd3/prisma_counts_current.json').read_bytes()).hexdigest()
      and man['outputs']['prisma_40_reports_manuscript.png'] == hashlib.sha256((REV / 'figures/Fig1.png').read_bytes()).hexdigest()
      and all(x in _svg for x in ('(n = 97)', '(n = 40)', 'Wrong setting (n = 9)')))""")

D4 = '''
# Decision D4 (JRNM and SKP, reported 3 Nov 2026): nine outcome exclusions counted under a corrected reason (d4/)
import filecmp
_P4 = REV / 'd4/pre_d4'
_d4 = recs(REV / 'd4/d4_decisions.csv')
_rep4 = {x[0]: x for x in xl(4, 'Reports', 'Covidence ID')}
_tri4 = {x[0]: x for x in xl(4, 'Outcome exclusions recheck', 'Covidence ID')}
check('D4: nine decisions recorded as JRNM and SKP\\'s; eight counted under the 9 Oct criterion and Tzeng 2015 as wrong setting in the AF4 Reports, triage and D4 sheets',
      len(_d4) == 9 and all(r['decided_by'].startswith('JRNM and SKP') for r in _d4)
      and [r['report'] for r in _d4 if r['counted_as'] == 'Wrong setting'] == ['Tzeng 2015']
      and all(_rep4[r['covidence_id']][9] == ('Wrong setting' if r['counted_as'] == 'Wrong setting' else 'No confirmed postoperative opioid result')
              and 'Decision D4 (JRNM and SKP' in str(_rep4[r['covidence_id']][-1]) for r in _d4)
      and all(str(_tri4[r['covidence_id']][4]).endswith(': reason corrected 3 Nov 2026 (D4)') for r in _d4)
      and sum(str(x[4]) == 'REASON' for x in _tri4.values()) == 0 and len(xl(4, 'D4 decisions', 'Covidence ID')) == 9)
check('D4 text: Results, Methods, Discussion (14 excluded, 12 relabelled), Fig. 1 legend (12; 25 and 15), AF2 section 6 and decision log; the 8 Oct audit counts stay as on that date',
      'On 3 November 2026, JRNM and SKP corrected the reason for nine other outcome exclusions' in results
      and 'JRNM and SKP corrected the recorded reason for nine more excluded reports' in methods
      and 'four were included and 14 remained excluded, 12 of them under a corrected reason' in discussion
      and 'and 12 whose reason that check corrected' in _t and 'for 25, and for 15 the opioid' in _t
      and 'Decision D4: corrected reasons for nine outcome exclusions (3 November 2026).' in _t
      and 'Decision D4 (JRNM and SKP, results known)' in _t and 'four were then included and 12 were counted under a corrected reason' in _t
      and 'identified 30 without one: 18 in which' in _t and '; 6 in which the opioid identity' in _t
      and '4 reporting only pump requests or presses' in _t and '2 reporting pump deliveries' in _t
      and 'The requirement for a confirmed postoperative opioid result was added after registration, with trial results known, because '
          'reports without such a result could not inform the primary question.' in methods)
check('D4 changed no estimate, judgement, rating, Table 1 row or abstract word (snapshot d4/pre_d4/)',
      all(filecmp.cmp(REV / f, _P4 / f, shallow=False) for f in ('wang1997/models_with_wang.csv', 'd3/rob_domain_summary_d3.csv',
          'd3/d3_rob2_DRAFT.csv', 'd3/d3_grade_DRAFT.csv', 'sources/table1_REVISED.csv', 'sources/abstract_REVISED.md',
          'sources/table2_REVISED.md', 'sources/conclusions_REVISED.md')))
'''
rep("\n(HERE / 'verification_results.txt').write_text(", D4 + "\n(HERE / 'verification_results.txt').write_text(")
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after decision D4')
