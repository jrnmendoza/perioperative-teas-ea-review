"""Manuscript text after decision D5 (JRNM and SKP, reported 3 Nov 2026): the 53 outcome exclusions not re-checked by the
2 Nov 2026 triage were sought and read; nine are counted under a corrected reason and six could not be retrieved.

Runs after d4/apply_d4_text.py and edits sources/*_REVISED.md in place; every passage is asserted once and a passage already
edited is skipped. Fig. 1 counts: no eligible analgesic outcome 97 -> 88, no confirmed postoperative opioid result 40 -> 42
(none located 25 -> 27), publication language 12 -> 19. The PROVISIONAL markers that named 53 reports now name the six that
could not be retrieved (the review owner's choice, 3 Nov 2026). The mandated disclosure sentence is unchanged."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'abstract': [
  ('[PROVISIONAL: 53 historically excluded reports (45 without a local full text and eight not yet read in full) have not been '
   're-checked against both full-text outcome requirements; the counts and estimates above may change.]',
   '[PROVISIONAL: six historically excluded reports could not be retrieved to re-check them against both full-text outcome '
   'requirements; the counts and estimates above may change.]'),
 ],
 'methods': [
  ('JRNM and SKP corrected the recorded reason for nine more excluded reports from that recheck.',
   'JRNM and SKP corrected the recorded reason for nine more excluded reports from that recheck and, after the remaining outcome '
   'exclusions were sought and read with AI assistance, for nine others; six could not be retrieved.'),
 ],
 'results': [
  ('no 24-hour opioid or pain outcome (97 reports), no confirmed postoperative opioid result (40) and no English full text (12).',
   'no 24-hour opioid or pain outcome (88 reports), no confirmed postoperative opioid result (42) and no English full text (19).'),
  ('and Tzeng 2015 used spinal anaesthesia without general anaesthesia. [PROVISIONAL: 45 outcome exclusions could not be re-checked '
   'because no full text was held, and eight with a keyword signal have not been read in full; the counts, estimates and certainty '
   'ratings below may change (Additional files 2 and 4).]',
   'and Tzeng 2015 used spinal anaesthesia without general anaesthesia. The 53 outcome exclusions that check could not assess (no '
   'full text held, or a keyword signal never read in full) were then sought and read with AI assistance; JRNM and SKP corrected the '
   'reason for nine of them: two give no postoperative opioid result (Chen 2018 and Luo 2024) and seven are '
   'published only in Chinese. [PROVISIONAL: six outcome exclusions published in English could not be retrieved and re-checked; the '
   'counts, estimates and certainty ratings below may change (Additional files 2 and 4).]'),
 ],
 'table2': [
  ('[PROVISIONAL: estimates may change after a re-check of 53 historically excluded reports.]',
   '[PROVISIONAL: estimates may change after a re-check of six historically excluded reports not yet retrieved.]'),
 ],
 'discussion': [
  ('[PROVISIONAL: the historically excluded reports not yet re-checked (Results) could add trials to these analyses.]',
   '[PROVISIONAL: the six historically excluded reports not yet retrieved (Results) could add trials to these analyses.]'),
  ('four were included and 14 remained excluded, 12 of them under a corrected reason; 45 excluded reports could not be re-checked and '
   'eight have not been read in full.',
   'four were included and 23 remained excluded, 21 of them under a corrected reason; six excluded reports could not be retrieved, '
   'and 29 published in Chinese were checked only against their English abstracts.'),
 ],
 'figures': [
  ('and 12 whose reason that check corrected (Additional file 4).', 'and 21 whose reason that check corrected (Additional file 4).'),
  ('none was located in the available report for 25, and for 15 the opioid',
   'none was located in the available report for 27, and for 15 the opioid'),
 ],
 'conclusions': [
  ('[PROVISIONAL: pending a re-check of 53 historically excluded reports.]',
   '[PROVISIONAL: pending six historically excluded reports that could not be retrieved.]'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after decision D5')
