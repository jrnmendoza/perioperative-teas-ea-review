"""D5 retrieval and reading log (3 Nov 2026): the 8 unread keyword signals and the 45 outcome exclusions without a local
full text (C01_selection/ triage categories UNREAD_SIGNAL and UNAVAILABLE).

AI-assisted (Claude), not a human read and not a decision. Sources: local full texts (10_FINAL_ADJUDICATION/01_SOURCE_
EVIDENCE/exclusions/), PubMed Central, publisher pages read in the review owner's Chrome (first without signing in, then through
the Lund library proxy after the review owner signed in), PubMed records, and the abstracts in the Covidence export (covidence_all_161_excluded.json). No new search was run and nothing was downloaded.
Writes d5/d5_retrieval_log.csv."""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
BY = 'AI assistant (Claude), 3 Nov 2026; not a human read'
ZH = 'Chinese-language journal (title bracketed in PubMed, or Chinese journal); no English full text expected'
L = []
def add(cid, rep, grp, lang, route, access, a14, b9, other, proposal):
    L.append(dict(covidence_id=cid, report=rep, set=grp, language=lang, route=route, access=access, rule_14aug=a14,
                  criterion_9oct=b9, other=other, ai_proposal=proposal, read_by=BY))

U, N = 'Unread keyword signal (local full text)', 'No local full text'
LOC = 'Local PDF/text'
# ---- the 8 unread keyword signals ----
add('1879896232', 'Luo 2024', U, 'English', LOC, 'Read in full',
    'Unclear: VAS over 6-24 h, 0.9 (0.8) vs 0.9 (0.9) (Table 3)',
    'Unclear: "Postoperative opioid use, n (%)" 4/66 in each arm sits in the baseline table among the Apfel risk factors (Table 1); oxycodone titration named in Methods, no dose reported; rescue was flurbiprofen',
    'TEAS at P6 + dexamethasone vs electrodes without stimulation + dexamethasone (sham), and vs granisetron + dexamethasone; mastectomy under general anaesthesia',
    'Decision needed: if the opioid row is a baseline Apfel item, the 9 Oct failure is certain and the reason would move as in D4 (as for Qin 2023); if it is an outcome, the report is a membership candidate')
add('1879897475', 'White 2002', U, 'English', LOC, 'Read in full', 'Not met: no 24-h pain or opioid quantity',
    'Not met: "Analgesic rescue n (%)" before discharge, drug not named (Table 2)', 'ReliefBand at P6 (modality to confirm); outpatient plastic surgery',
    'Recorded reason supported')
add('1879897193', 'Yang 2012', U, 'English', LOC, 'Read in full', 'Not met: no postoperative pain or opioid result',
    'Not met: intraoperative sufentanil fixed by protocol', 'EA vs sham EA, craniotomy', 'Recorded reason supported')
add('1879896934', 'Zhang 2017', U, 'English', LOC, 'Read in full', 'Not met: no pain result',
    'Not met: "rate of rescue analgesia" over 3 days, drug not named (Table 3)', 'EA vs control, valve replacement with bypass; QoR-40 on day 1',
    'Recorded reason supported')
add('1879896792', 'Zhang 2018', U, 'English', LOC, 'Read in full', 'Not met: VAS at 3 h and 72 h only (Fig. 2c)',
    'Not met', 'Transcutaneous neuromodulation vs sham, laparoscopic cholecystectomy', 'Recorded reason supported')
add('1879896246', 'Zhang 2024 (CABG)', U, 'English', LOC, 'Read in full', 'Not met: no postoperative pain or opioid result',
    'Not met: intraoperative sufentanil only (primary outcome)', 'TEAS vs sham, off-pump CABG', 'Recorded reason supported')
add('1879896300', 'Zhang 2024 (propofol)', U, 'English', LOC, 'Read in full', 'Not met: pain not assessed (Discussion)',
    'Not met: intraoperative only', 'QoR at 24 h', 'Recorded reason supported')
add('1879895897', 'Zhao 2026', U, 'English', LOC, 'Read in full', 'Not met: no pain result',
    'Not met: oxycodone PCIA used, consumption not reported', 'TEAS, VATS; hypothermia trial', 'Recorded reason supported')
# ---- English-language reports without a local full text ----
PMC, PUB, ABS = 'PubMed Central', 'Publisher page (Chrome, not signed in)', 'Covidence export abstract'
add('1879896823', 'Chen 2018', N, 'English', PMC + ' (PMC5827033)', 'Read in full',
    'Met: ESAS pain on day 1, 3.79 (1.35) vs 3.38 (1.50) (Table 3)', 'Not met: PCIA or PCEA, no consumption reported',
    'Transcutaneous EA vs control, gastrectomy', 'Reason would move to the 9 Oct criterion, as in D4')
add('1879896600', 'Qiu 2021', N, 'English', PMC + ' (PMC8026294)', 'Read in full', 'Not met: no pain result', 'Not met',
    'EA, pancreatectomy or gastrectomy; GI recovery', 'Recorded reason supported')
add('1879897177', 'Taghavi 2013', N, 'English', PMC + ' (PMC3546210)', 'Read in full',
    'Not met: VAS and PCA morphine to 6 h only (morphine 6.3 (1.3) vs 8.2 (2.0) mg, 0-6 h)', 'Met for 0-6 h (morphine named)',
    'EA vs needles without stimulation; ages 12-55 (minors enrolled)', 'Recorded reason supported (14 Aug rule)')
add('1879897113', 'Wang 2014', N, 'English', PUB + ' (BJA open archive)', 'Read in full', 'Not met: no postoperative pain result',
    'Not met: intraoperative remifentanil; parecoxib prophylaxis', 'TEAS vs sham, sinusotomy', 'Recorded reason supported')
add('1882882029', 'Frey 2009', N, 'English', PUB + ' (BJA open archive)', 'Read in full',
    'Not met: pain assessed at 2, 6 and 24 h but not reported', 'Not met: morphine recorded for 24 h but not reported by arm (covariate only)',
    'ReliefBand at P6 (modality to confirm)', 'Recorded reason supported')
add('1879896203', 'Chen 2024', N, 'English', PUB + ' (Taylor & Francis)', 'Read in full', 'Not met', 'Not met',
    'Comatose ICU patients (GCS 3-8) after cerebrovascular surgery; TEAS in ICU', 'Recorded reason supported')
add('1882881968', 'Ng 2010', N, 'English', ABS, 'Conference abstract (Gastroenterology 138(5):S869); no full report',
    'Not met', 'Not met', 'Interim analysis of Ng 2013, which is included', 'Recorded reason consistent; could count as abstract only')
LUND = 'Publisher page through the Lund library proxy (signed in by the review owner, 3 Nov 2026)'
add('1879896264', 'Hou 2024', N, 'English', LUND + ' (ScienceDirect; CC licence)', 'Read in full',
    'Unclear: headache NRS at 2-72 h (secondary outcome); no surgical-site pain score', 'Not met: oxycodone at induction only',
    'TEAS vs sham, microvascular decompression; dizziness trial', 'Recorded reason supported if headache is not the registered pain outcome; the 9 Oct criterion fails either way')
add('1879896229', 'Tong 2024', N, 'English', LUND + ' (ScienceDirect)', 'Read in full', 'Not met: no postoperative pain result',
    'Not met: intraoperative sufentanil only', 'EA, breast cancer surgery; four arms (conventional, preoperative, intraoperative, both): possibly the trial reported as Tong 2022',
    'Recorded reason supported')
add('1882975732', 'Wei 2025', N, 'English', LUND + ' (SAGE)', 'Read in full', 'Not met: VAS at rest at 4 h only (Fig. 3)',
    'Not met: sufentanil PCA used; "no significant differences in postoperative analgesic consumption", no values', 'EA, laparoscopic cholecystectomy',
    'Recorded reason supported')
add('1879896675', 'Huang 2019', N, 'English', 'Free PDF listed by PubMed LinkOut (journaltcm.cn); opened with the review owner\'s permission: '
    'the site returned a connection error, as did its article page', 'Not retrieved', 'Abstract signal: VAS at 4, 12, 24 and 48 h',
    'Abstract signal: PCIA; intraoperative remifentanil', '', 'Not resolved: the abstract reports pain at 24 h; full text not retrieved')
for cid, rep, where, abst in [
    ('1879896164', 'Li 2025', 'Bentham through the Lund proxy: abstract and references only (purchase needed)', 'Nutrition and GI recovery; no analgesic outcome named'),
    ('1879896651', 'Li 2020', 'Ovid through the Lund proxy: abstract only (no subscription)', 'Constipation; no analgesic outcome named'),
    ('1879897317', 'Wang 2010', 'Ovid (same journal as Xu 2012): abstract only through the Lund proxy', 'PONV after craniotomy; no analgesic outcome named'),
    ('1879897213', 'Xu 2012', 'Ovid through the Lund proxy: abstract only (no subscription)', 'PONV after craniotomy; no analgesic outcome named'),
    ('1879897495', 'Zárate 2001', 'Ovid through the Lund proxy: abstract only (no subscription)', 'ReliefBand, PONV after outpatient laparoscopic surgery; no analgesic outcome named')]:
    sig = 'Abstract signal: ' + abst
    add(cid, rep, N, 'English', where, 'Not retrieved', sig, sig, '', 'Recorded reason consistent with the abstract; full text not retrieved')
# ---- Chinese-language reports without a local full text: English abstract only ----
SIG = {'Ding 2013': 'VAS at 4, 6, 8, 24 and 44 h; PCIA', 'Ge 2021': 'VAS at 6-72 h including 24 h (TKA with adductor canal block)',
       'He 2024': 'Sufentanil PCIA doses delivered and attempted over 48 h; tramadol rescue rate',
       'Lu 2005': 'Analgesic dosage at 6, 24 and 48 h (drug not named in the abstract)', 'Tian 2026': 'VAS at 1, 6 and 24 h after emergence',
       'Yin 2013': 'VAS at 8, 24 and 72 h', 'Zhang 2023': 'VAS at 24, 48 and 72 h; PCA presses; flurbiprofen'}
WEAK = {'He 2022': 'Rate of wound pain on standing the next morning', 'Ding 2021': 'PCA presses over 48 h'}
# language of the seven with an outcome signal, checked 3 Nov 2026 (PubMed language field; CENTRAL record for the other two)
LANG = {'Ding 2013': 'Chinese (PubMed: chi; PMID 23980354)', 'Ge 2021': 'Chinese (PubMed: chi; PMID 34423619)',
        'Tian 2026': 'Chinese (PubMed: chi; PMID 41839586)', 'Yin 2013': 'Chinese (PubMed: chi; PMID 24579355)',
        'Zhang 2023': 'Chinese (PubMed: chi; PMID 37429652)',
        'He 2024': 'Chinese (Chinese Journal of Anesthesiology; CENTRAL CN-02788357; not in PubMed)',
        'Lu 2005': 'Chinese (Shanghai Journal of Acupuncture and Moxibustion; CENTRAL CN-01433777; not in PubMed)'}
for cid, rep in [('1879897288', 'An 2010'), ('1879897149', 'Ding 2013'), ('1879896683', 'Ding 2020'), ('1879896592', 'Ding 2021'),
                 ('1879897200', 'Fan 2012'), ('1879896642', 'Gao 2020'), ('1879896567', 'Ge 2021'), ('1879896119', 'Guan 2025'),
                 ('1879897377', 'He 2008'), ('1879896680', 'He 2020'), ('1879896535', 'He 2022'), ('1881841159', 'He 2024'),
                 ('1881840718', 'He 2025'), ('1879896669', 'Huang 2020'), ('1879897133', 'Jin 2013'), ('1881840820', 'Li 2016'),
                 ('1881842163', 'Lu 2005'), ('1879897007', 'Ma 2015'), ('1879896844', 'Mai 2017'), ('1879897339', 'Ni 2009'),
                 ('1879896678', 'Qu 2020'), ('1879896622', 'Sun 2020'), ('1879897164', 'Tang 2013'), ('1881840717', 'Tao 2023'),
                 ('1879895943', 'Tian 2026'), ('1879896849', 'Wang 2017'), ('1879897112', 'Yin 2013'), ('1879897094', 'Zhang 2014'),
                 ('1879896356', 'Zhang 2023')]:
    if rep in SIG:
        f, p = 'Abstract reports: ' + SIG[rep], 'Recorded reason not supported by the abstract; publication language would be the accurate reason (confirm the language)'
    elif rep in WEAK:
        f, p = 'Abstract reports: ' + WEAK[rep], 'Recorded reason probably supported; publication language also applies'
    else:
        f, p = 'Abstract names no 24-h pain or postoperative opioid result', 'Recorded reason consistent with the abstract; publication language also applies'
    add(cid, rep, N, LANG.get(rep, 'Chinese (presumed)'), ABS, 'Not sought: ' + ZH, f, f, '', p)

assert len(L) == 53 and len({x['covidence_id'] for x in L}) == 53
with open(HERE / 'd5_retrieval_log.csv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=list(L[0])); w.writeheader(); w.writerows(L)
import collections
print(collections.Counter(x['access'].split(':')[0] for x in L))
