"""Additional-files edits after decision D5 (JRNM and SKP, reported by the review owner on 3 Nov 2026): the 53 outcome
exclusions the 2 Nov 2026 triage could not assess were sought and read (d5/d5_retrieval_log.csv); nine are counted under a
corrected reason and six could not be retrieved (d5/d5_decisions.csv).

Run after d4/patch_af_d4.py (the chain rewrites build_additional_files.py from its snapshot each time); this script edits
build_additional_files.py in place, each replacement asserted once. AF1: item 7 marker. AF2: section 5 (seven more language
exclusions), section 6 (the D5 paragraph; the 8 October audit counts kept as on that date; the triage summary and the
PROVISIONAL marker now name the six not retrieved) and the decision log. AF4: the nine Reports rows, the 53 triage rows, a
"D5 re-check" sheet and the README. AF9: this folder. The Fig. 1 counts follow d3/prisma_counts_current.json, which
d5/record_d5.py edits."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


SIX = 'Huang 2019, Li 2020, Li 2025, Wang 2010, Xu 2012 and Zárate 2001'

# ---- records ----------------------------------------------------------------------------------------------------------
rep("D4_DEC = {r['covidence_id']: r for r in recs(REV / 'd4/d4_decisions.csv')}\n",
    "D4_DEC = {r['covidence_id']: r for r in recs(REV / 'd4/d4_decisions.csv')}\n"
    "# Decision D5 (JRNM and SKP, 3 Nov 2026): the 53 outcome exclusions the triage could not assess, sought and read with AI assistance.\n"
    "D5_DEC = {r['covidence_id']: r for r in recs(REV / 'd5/d5_decisions.csv')}\n"
    "D5_LOG = recs(REV / 'd5/d5_retrieval_log.csv')\n"
    "D5_LOGD = {x['covidence_id']: x for x in D5_LOG}\n")

# ---- AF1 item 7 ---------------------------------------------------------------------------------------------------------
rep("[PROVISIONAL: 53 historical outcome exclusions not yet re-checked]", "[PROVISIONAL: six historical outcome exclusions not retrieved]")

# ---- AF2 section 5 ------------------------------------------------------------------------------------------------------
rep("'**Applied.** Twelve reports were excluded for publication language. Their English abstracts were checked '",
    "'**Applied.** Twelve reports were excluded for publication language at screening; their English abstracts were checked '")
rep("'check (reported 3 Nov 2026). The English-language restriction was adopted",
    "'check (reported 3 Nov 2026). Seven more, recorded at screening as having no eligible analgesic outcome, were counted '\n"
    "            'under publication language on 3 November 2026 because their English abstracts report pain at about 24 hours or an '\n"
    "            'opioid result (decision D5, section 6). The English-language restriction was adopted")

# ---- AF2 section 6 ------------------------------------------------------------------------------------------------------
rep("'before the recheck of 2 November 2026; four were then included and 12 were counted under a corrected reason, decisions '\n"
    "            'D1, D3 and D4) '",
    "'before the recheck of 2 November 2026; four were then included and 21 were counted under a corrected reason, decisions '\n"
    "            'D1, D3, D4 and D5) '")
rep("{pc[\"additional_focused_exclusions\"] - 2 - 8} without one: '", "{pc[\"additional_focused_exclusions\"] - 2 - 8 - 2} without one: '")
rep("f'{a[\"No postoperative opioid result located in available report\"] - 7} in which",
    "f'{a[\"No postoperative opioid result located in available report\"] - 7 - 2} in which")
rep("'(decision D3, below), and eight more were counted under it on 3 November 2026 (decision D4, below). The 40 remaining reports",
    "'(decision D3, below), eight more were counted under it on 3 November 2026 (decision D4, below) and two more the same day '\n"
    "            '(decision D5, below). The 40 remaining reports")
rep("'with a keyword signal never followed by a full read; 36 with no signal; and 45 with no local full text. '",
    "'with a keyword signal never followed by a full read; 36 with no signal; and 45 with no local full text (the 53 in these '\n"
    "            'two groups were sought and read on 3 November 2026; decision D5, below). '")
rep("'45 outcome exclusions have no local full text and eight with a keyword signal have not been read in full; see '",
    f"'six outcome exclusions published in English could not be retrieved ({SIX}; decision D5, below); see '")
rep("            'postoperative opioid result from 32 to 40 and wrong setting from 8 to 9.')\n\n    head(d, '7. Outcomes')\n",
    "            'postoperative opioid result from 32 to 40 and wrong setting from 8 to 9.')\n"
    "    para(d, '**Decision D5: the 53 outcome exclusions the triage could not assess (3 November 2026).** The 45 without a local '\n"
    "            'full text and the 8 keyword signals never read in full were sought and read with AI assistance (Additional file 4, '\n"
    "            'sheet \"D5 re-check\"): the 8 from local full texts; the 16 published in English from PubMed Central, publisher pages '\n"
    "            'and the Lund University library; and the 29 published in Chinese from their English abstracts, since the English '\n"
    f"            'full-text criterion excludes them in any case. Six in English could not be retrieved ({SIX}); of these, only '\n"
    "            'Huang 2019\\'s abstract reports pain at about 24 hours. JRNM and SKP decided, with trial results known, to count nine '\n"
    "            'under a corrected reason, all still excluded: Chen 2018 (pain on day 1, no postoperative opioid result) and Luo 2024 '\n"
    "            '(pain over 6–24 hours only; its \"postoperative opioid use\" row is a baseline risk-score item) under the 9 October '\n"
    "            'criterion, and seven reports in Chinese whose English abstracts report pain at about 24 hours or an opioid result '\n"
    "            'under publication language (Ding 2013, Ge 2021, He 2024, Lu 2005, Tian 2026, Yin 2013 and Zhang 2023). Every other '\n"
    "            'recorded reason was kept; Hou 2024 scores headache, which is not the registered pain outcome, and reports no '\n"
    "            'postoperative opioid result. In Fig. 1, no eligible analgesic outcome went from 97 to 88, no confirmed postoperative '\n"
    "            'opioid result from 40 to 42 and publication language from 12 to 19. No estimate changed. [PROVISIONAL: the six '\n"
    "            'reports not retrieved have not been re-checked.]')\n\n"
    "    head(d, '7. Outcomes')\n")

# ---- AF2 section 10: decision log -----------------------------------------------------------------------------------------
rep("    after('8 Oct', ['8 Oct',",
    "    rows.append(['3 Nov', 'Decision D5 (JRNM and SKP, results known): the 53 outcome exclusions the triage could not assess were '\n"
    "                 'sought and read with AI assistance (section 6). Chen 2018 and Luo 2024 moved to the 9 October criterion; seven '\n"
    "                 'reports in Chinese moved to publication language; six in English could not be retrieved. All remain excluded; no '\n"
    "                 'estimate changed.', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct',")

# ---- AF4: Reports, triage, README, D5 sheet -------------------------------------------------------------------------------
rep("        if fd == 'INCLUDED':\n",
    "        if r['covidence_id'] in D5_DEC and D5_DEC[r['covidence_id']]['decision'].startswith('Exclude'):   # D5, 3 Nov 2026\n"
    "            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']\n"
    "            dec = D5_DEC[r['covidence_id']]\n"
    "            note = ('Excluded at full-text screening (no eligible analgesic outcome); sought and read after the outcome-exclusion '\n"
    "                    f'recheck. Decision D5 (JRNM and SKP, 3 Nov 2026, results known): {dec[\"decision\"]}. {dec[\"basis\"]}')\n"
    "            if dec['counted_as'] == 'Publication language':\n"
    "                fr = 'Publication language'\n"
    "            else:\n"
    "                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', dec['counted_as']\n"
    "                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-03')\n"
    "        if fd == 'INCLUDED':\n")
rep("            t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D4): {dec[\"decision\"]}.'\n",
    "            t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D4): {dec[\"decision\"]}.'\n"
    "        if t['covidence_id'] in D5_LOGD:   # D5, 3 Nov 2026\n"
    "            assert t['category'] in ('UNREAD_SIGNAL', 'UNAVAILABLE'), t['covidence_id']\n"
    "            dec = D5_DEC.get(t['covidence_id'])\n"
    "            if dec and dec['decision'].startswith('Exclude'):\n"
    "                t['category'] += ': reason corrected 3 Nov 2026 (D5)'\n"
    "                t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D5): {dec[\"decision\"]}.'\n"
    "            elif D5_LOGD[t['covidence_id']]['access'] == 'Not retrieved':\n"
    "                t['category'] += ': not retrieved 3 Nov 2026 (D5)'\n"
    "            else:\n"
    "                t['category'] += ': re-checked 3 Nov 2026 (D5); reason kept'\n")
rep("SKP checked it (reported 3 Nov 2026) [PROVISIONAL: 45 without a local full text and 8 keyword signals not yet read]'),",
    "SKP checked it (reported 3 Nov 2026); the 53 it could not assess were sought and read on 3 Nov 2026 (sheet \"D5 re-check\") '\n"
    "                                               '[PROVISIONAL: six not retrieved]'),")
rep("('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language; checked by SKP (reported 3 Nov 2026)'),",
    "('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language at screening; checked by SKP '\n"
    "                                         '(reported 3 Nov 2026). Seven more were counted under publication language by decision D5 '\n"
    "                                         '(sheet \"D5 re-check\")'),")
rep("                                  'reason, with the source basis; all remain excluded')],",
    "                                  'reason, with the source basis; all remain excluded'),\n"
    "                 ('D5 re-check', 'Decision D5 (JRNM and SKP, 3 Nov 2026): how each of the 53 outcome exclusions the triage could '\n"
    "                                 'not assess was sought and read (AI-assisted, not a human read), what it reports and the decision; '\n"
    "                                 'nine counted under a corrected reason, six not retrieved')],")
rep("'(decisions D1, D3 and D4); JRNM and SKP screened", "'(decisions D1, D3, D4 and D5); JRNM and SKP screened")
rep("          ('rule_14aug', '14 Aug outcome rule', 22), ('basis', 'Basis (source location)', 80), ('decided_by', 'Decided by', 40)])\n"
    "    return save(wb, 4, '.xlsx')",
    "          ('rule_14aug', '14 Aug outcome rule', 22), ('basis', 'Basis (source location)', 80), ('decided_by', 'Decided by', 40)])\n"
    "    d5 = [dict(x, decision=D5_DEC[x['covidence_id']]['decision'] if x['covidence_id'] in D5_DEC else\n"
    "               ('Not retrieved' if x['access'] == 'Not retrieved' else 'No change'),\n"
    "               decided_by=D5_DEC[x['covidence_id']]['decided_by'] if x['covidence_id'] in D5_DEC else '') for x in D5_LOG]\n"
    "    sheet(wb, 'D5 re-check', d5, [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 16), ('set', 'Triage group', 22),\n"
    "          ('language', 'Language', 22), ('route', 'Where sought', 40), ('access', 'Result', 18), ('rule_14aug', '14 Aug outcome rule', 40),\n"
    "          ('criterion_9oct', '9 Oct opioid-result criterion', 40), ('other', 'Other', 36), ('ai_proposal', 'AI proposal', 40),\n"
    "          ('decision', 'Decision', 30), ('decided_by', 'Decided by', 34), ('read_by', 'Read by', 30)])\n"
    "    return save(wb, 4, '.xlsx')")

# ---- AF9: this folder ---------------------------------------------------------------------------------------------------
rep("          + [REV / 'd4/figure_builds/build_prisma_manuscript_d4.py'],\n",
    "          + [REV / 'd4/figure_builds/build_prisma_manuscript_d4.py'],\n"
    "    'd5': [REV / 'd5' / f for f in ('build_d5_log.py', 'd5_retrieval_log.csv', 'record_d5.py', 'd5_decisions.csv', 'apply_d5_text.py',\n"
    "                                    'patch_af_d5.py', 'update_verify_d5.py')]\n"
    "          + [REV / 'd5/figure_builds/build_prisma_manuscript_d5.py'],\n")
rep("'(`d4_decisions.csv`), with the Fig. 1 counts, text and builder edits that follow; no estimate changed.', '',\n",
    "'(`d4_decisions.csv`), with the Fig. 1 counts, text and builder edits that follow; no estimate changed.',\n"
    "              '- `d5/`: decision D5 (JRNM and SKP, 3 Nov 2026): the 53 outcome exclusions the triage could not assess, sought '\n"
    "              'and read with AI assistance (`d5_retrieval_log.csv`); nine counted under a corrected reason (`d5_decisions.csv`), '\n"
    "              'six not retrieved; no estimate changed.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after decision D5')
