"""Decision D5 (JRNM and SKP, reported by the review owner on 3 Nov 2026): the 53 outcome exclusions the 2 Nov 2026 triage
could not re-check (45 without a local full text and 8 keyword signals never read in full).

They were sought and read with AI assistance on 3 Nov 2026 (d5/build_d5_log.py, d5/d5_retrieval_log.csv): the 8 from local
full texts; the 16 published in English from PubMed Central, open publisher pages and, after the review owner signed in, the
Lund library proxy; the 29 published in Chinese from their English abstracts, since the English full-text criterion excludes
them in any case. Six in English could not be retrieved. The review owner reported that JRNM and SKP decided, with trial
results known: Chen 2018 and Luo 2024 counted under the 9 October 2026 opioid-result criterion (as in D4; Luo 2024's
"postoperative opioid use" row is a baseline risk-score item); seven Chinese-language reports whose English abstracts report
pain at about 24 hours or an opioid result counted under publication language; every other recorded reason kept (Hou 2024's
headache score is not the registered pain outcome). All remain excluded; no estimate changes.

Runs after d4/record_d4.py and edits d3/prisma_counts_current.json in place; writes d5/d5_decisions.csv."""
import csv, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
BY = 'JRNM and SKP (reported by the review owner, 3 Nov 2026; results known)'
OP, LANG = 'Exclude: no confirmed postoperative opioid result', 'Exclude: publication language'
LOC, PL = 'No postoperative opioid result located in available report', 'Publication language'
D = [  # covidence_id, report, decision, counted as (PRISMA key), basis
 ('1879896823', 'Chen 2018', OP, LOC, 'ESAS pain on postoperative day 1 (Table 3), so the 14 Aug rule is met; PCIA or PCEA used, no consumption '
  'reported (PMC5827033).'),
 ('1879896232', 'Luo 2024', OP, LOC, 'VAS over 6-24 h only (Table 3). The "Postoperative opioid use, n (%)" row (4/66 per arm) is a baseline '
  'Apfel risk-score item (Table 1); oxycodone titration is named but no dose is reported; rescue was flurbiprofen.'),
 ('1879897149', 'Ding 2013', LANG, PL, 'Chinese (PubMed: chi). English abstract: VAS at 4, 6, 8, 24 and 44 h; PCIA.'),
 ('1879896567', 'Ge 2021', LANG, PL, 'Chinese (PubMed: chi). English abstract: VAS at 6-72 h including 24 h.'),
 ('1881841159', 'He 2024', LANG, PL, 'Chinese (Chinese Journal of Anesthesiology; CENTRAL CN-02788357). English abstract: sufentanil PCIA '
  'doses over 48 h; tramadol rescue rate.'),
 ('1881842163', 'Lu 2005', LANG, PL, 'Chinese (Shanghai Journal of Acupuncture and Moxibustion; CENTRAL CN-01433777). English abstract: '
  'analgesic dosage at 6, 24 and 48 h.'),
 ('1879895943', 'Tian 2026', LANG, PL, 'Chinese (PubMed: chi). English abstract: VAS at 1, 6 and 24 h after emergence.'),
 ('1879897112', 'Yin 2013', LANG, PL, 'Chinese (PubMed: chi). English abstract: VAS at 8, 24 and 72 h.'),
 ('1879896356', 'Zhang 2023', LANG, PL, 'Chinese (PubMed: chi). English abstract: VAS at 24, 48 and 72 h; PCA presses.'),
]
rows = [dict(covidence_id=c, report=r, previous_reason='No eligible analgesic outcome', decision=d, counted_as=k, basis=b, decided_by=BY)
        for c, r, d, k, b in D]
rows.append(dict(covidence_id='1879896264', report='Hou 2024', previous_reason='No eligible analgesic outcome',   # answered by the review owner
                 decision='Keep: recorded reason', counted_as='no perioperative analgesia outcome found',
                 basis='Headache NRS at 2-72 h is not the registered postoperative pain outcome; oxycodone at induction only, no postoperative '
                       'opioid result (ScienceDirect, through the Lund library proxy).',
                 decided_by='Review owner (reported 3 Nov 2026; results known)'))
with open(HERE / 'd5_decisions.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

log = {x['covidence_id']: x for x in csv.DictReader(open(HERE / 'd5_retrieval_log.csv', encoding='utf-8'))}
tri = {t['covidence_id']: t['category'] for t in csv.DictReader(open(REV / 'C01_selection/C01_historical_outcome_exclusions_triage.csv', encoding='utf-8-sig'))}
assert len(log) == 53 and all(tri[c] in ('UNREAD_SIGNAL', 'UNAVAILABLE') for c in log)
assert sum(t in ('UNREAD_SIGNAL', 'UNAVAILABLE') for t in tri.values()) == 53 and all(x['covidence_id'] in log for x in rows)
assert sum(x['access'] == 'Not retrieved' for x in log.values()) == 6

p = REV / 'd3/prisma_counts_current.json'
pc = json.loads(p.read_text())
r, a = pc['exclusion_reasons'], pc['additional_exclusion_reasons']
NO = 'no perioperative analgesia outcome found'
assert (r[NO], r[PL], r[LOC], pc['additional_focused_exclusions']) == (97, 12, 25, 40), 'expected the D4 counts'
r[NO] -= 9
r[PL] += 7
for k in (r, a):
    k[LOC] += 2
pc['additional_focused_exclusions'] += 2
pc['original_database_excluded'] -= 2                     # Chen 2018 and Luo 2024 move to the 9 Oct criterion
pc['version'] = pc['version'].replace('Wang 1997, D3 and D4 applied', 'Wang 1997, D3, D4 and D5 applied')
pc['chart_status'] += (' D5 (3 Nov 2026, JRNM and SKP): of the 53 outcome exclusions not re-checked by the triage, Chen 2018 and Luo 2024 '
                       'relabelled to the 9 Oct criterion and seven Chinese-language reports to publication language; six could not be retrieved.')
pc['caveats'].append('Decision D5 (3 Nov 2026): nine outcome exclusions counted under a corrected reason and six not retrieved; see '
                     'manuscript/submission/BMC_revision_after_ASTRA_recheck/d5/.')
assert sum(r.values()) == pc['database_excluded'] == 173 and sum(a.values()) == pc['additional_focused_exclusions'] == 42
p.write_text(json.dumps(pc, indent=1))
print('D5 recorded:', len(D), 'relabels and 1 kept | no eligible outcome', r[NO], '| no confirmed opioid result', pc['additional_focused_exclusions'],
      '| publication language', r[PL])
