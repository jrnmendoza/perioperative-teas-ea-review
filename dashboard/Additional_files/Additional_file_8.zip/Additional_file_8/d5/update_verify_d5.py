"""After decision D5 (JRNM and SKP, reported by the review owner on 3 Nov 2026): adapt verification/verify_revision.py, as
written by d4/update_verify_d4.py.

Run after d4/update_verify_d4.py. The PRISMA, Results, AF4 and Fig. 1 checks now expect the D5 counts (no eligible analgesic
outcome 88, no confirmed postoperative opioid result 42, publication language 19; footnote c 27 and 15), and the checks that
named the 53 reports not yet re-checked now expect the six not retrieved. Added checks: the nine relabels are recorded as JRNM
and SKP's and appear in the AF4 Reports, triage and "D5 re-check" sheets; every one of the 53 is logged as AI-assisted reading
with six not retrieved; the text states the re-check (Results, Methods, Discussion, Fig. 1 legend, AF1, AF2 sections 5, 6
and 10) and keeps the 8 October audit counts and the mandated sentence; and, against the snapshot taken before D5
(d5/pre_d5/), no estimate, judgement, rating or Table 1 row changed and the abstract prose still counts 332 words
(the Word count with headings and the registration line, at most 345, is checked separately).
Re-run the earlier update scripts first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:100], s.count(old))
    s = s.replace(old, new)


# ---- PRISMA, Results, AF4, Fig. 1 --------------------------------------------------------------------------------------
rep("SET, LOC, PRS = 'Wrong setting', 'No postoperative opioid result located in available report', 'Pump requests/presses only; opioid quantity not verified'\n",
    "SET, LOC, PRS = 'Wrong setting', 'No postoperative opioid result located in available report', 'Pump requests/presses only; opioid quantity not verified'\n"
    "LNG = 'Publication language'\n")
rep("check('PRISMA after D1, D3 and D4 = project counts with four outcome exclusions included and 12 relabelled (D3: 1 comparator, 2 opioid result; D4: 8 opioid result, 1 setting)',",
    "check('PRISMA after D1, D3, D4 and D5 = project counts with four outcome exclusions included and 21 relabelled (D3: 1 comparator, 2 opioid result; D4: 8 opioid result, 1 setting; D5: 2 opioid result, 7 language)',")
rep("c0['exclusion_reasons'][NO] - 16 == c['exclusion_reasons'][NO] == 97", "c0['exclusion_reasons'][NO] - 25 == c['exclusion_reasons'][NO] == 88")
rep("c['exclusion_reasons'][LOC] == c0['exclusion_reasons'][LOC] + 7 == 25", "c['exclusion_reasons'][LOC] == c0['exclusion_reasons'][LOC] + 9 == 27")
rep("c['additional_focused_exclusions'] == c0['additional_focused_exclusions'] + 10 == 40",
    "c['additional_focused_exclusions'] == c0['additional_focused_exclusions'] + 12 == 42\n"
    "      and c['exclusion_reasons'][LNG] == c0['exclusion_reasons'][LNG] + 7 == 19")
rep("(NO, CMP, UNR, SET, LOC, PRS)}", "(NO, CMP, UNR, SET, LOC, PRS, LNG)}", count=2)
rep("check('Exclusion reasons sum to 173 (97 + 40 + 12 + 24 other)'", "check('Exclusion reasons sum to 173 (88 + 42 + 19 + 24 other)'")
rep("""check('Results gives 97 outcome exclusions and 40 without a confirmed opioid result', 'no 24-hour opioid or pain outcome (97 reports), no confirmed postoperative opioid result (40)' in results)""",
    """check('Results gives 88 outcome exclusions, 42 without a confirmed opioid result and 19 without an English full text',
      'no 24-hour opioid or pain outcome (88 reports), no confirmed postoperative opioid result (42) and no English full text (19)' in results)""")
rep("""check('AF4 reconciles with Fig. 1 (44 included, 173 excluded, 97 outcome exclusions, 40 without an opioid result, 4 wrong comparator, 9 wrong setting)',
      f1['Included'] == 44 and f1['Total excluded'] == 173 and f1['No eligible analgesic outcome'] == 97
      and f1['No confirmed postoperative opioid result'] == 40 and f1['Wrong comparator'] == 4 and f1['Wrong setting'] == 9)""",
    """check('AF4 reconciles with Fig. 1 (44 included, 173 excluded, 88 outcome exclusions, 42 without an opioid result, 19 language, 4 wrong comparator, 9 wrong setting)',
      f1['Included'] == 44 and f1['Total excluded'] == 173 and f1['No eligible analgesic outcome'] == 88
      and f1['No confirmed postoperative opioid result'] == 42 and f1['Publication language'] == 19 and f1['Wrong comparator'] == 4
      and f1['Wrong setting'] == 9)""")
rep("man = json.loads((REV / 'd4/figure_builds/fig1_manifest_d4.json').read_text())   # rebuilt after decision D4\n"
    "_svg = (REV / 'd4/figure_builds/prisma_40_reports_manuscript.svg').read_text(encoding='utf-8')\n"
    "check('Fig. 1 built from d3/prisma_counts_current.json after D4 (97, 40, wrong setting 9); figures/Fig1.png is that build',",
    "man = json.loads((REV / 'd5/figure_builds/fig1_manifest_d5.json').read_text())   # rebuilt after decision D5\n"
    "_svg = (REV / 'd5/figure_builds/prisma_40_reports_manuscript.svg').read_text(encoding='utf-8')\n"
    "check('Fig. 1 built from d3/prisma_counts_current.json after D5 (88, 42, publication language 19, wrong setting 9); figures/Fig1.png is that build',")
rep("all(x in _svg for x in ('(n = 97)', '(n = 40)', 'Wrong setting (n = 9)'))",
    "all(x in _svg for x in ('(n = 88)', '(n = 42)', 'Publication language (n = 19)', 'Wrong setting (n = 9)'))")

# ---- earlier checks that named the 53 reports or the D4 totals -----------------------------------------------------------
rep("and '45 outcome exclusions could not be re-checked' in results",
    "and 'six outcome exclusions published in English could not be retrieved and re-checked' in results")
rep("check('SKP review: no D3, Wang 48-h or 2 Nov correction PROVISIONAL marker left in the Word file; the 53-report and membership markers remain',\n"
    "      not _d3prov and len(set(_prov)) == 7 and sum('53 historically excluded' in m for m in set(_prov)) == 3",
    "check('SKP review: no D3, Wang 48-h or 2 Nov correction PROVISIONAL marker left in the Word file; the unretrieved-report (D5) and membership markers remain',\n"
    "      not _d3prov and len(set(_prov)) == 7 and sum('six historically excluded' in m for m in set(_prov)) == 4\n"
    "      and not any('53 historically' in m for m in _prov)")
rep("check('D4 text: Results, Methods, Discussion (14 excluded, 12 relabelled), Fig. 1 legend (12; 25 and 15), AF2 section 6 and decision log; the 8 Oct audit counts stay as on that date',",
    "check('D4 text (totals as updated by D5): Results, Methods, Discussion (23 excluded, 21 relabelled), Fig. 1 legend (21; 27 and 15), AF2 section 6 and decision log; the 8 Oct audit counts stay as on that date',")
rep("'four were included and 14 remained excluded, 12 of them under a corrected reason' in discussion",
    "'four were included and 23 remained excluded, 21 of them under a corrected reason' in discussion")
rep("'and 12 whose reason that check corrected' in _t and 'for 25, and for 15 the opioid' in _t",
    "'and 21 whose reason that check corrected' in _t and 'for 27, and for 15 the opioid' in _t")
rep("'four were then included and 12 were counted under a corrected reason' in _t",
    "'four were then included and 21 were counted under a corrected reason' in _t")
rep("check('D4 changed no estimate, judgement, rating, Table 1 row or abstract word (snapshot d4/pre_d4/)',",
    "check('D4 changed no estimate, judgement, rating or Table 1 row (snapshot d4/pre_d4/; the abstract, Table 2 and Conclusions markers changed later under D5)',")
rep("          'd3/d3_rob2_DRAFT.csv', 'd3/d3_grade_DRAFT.csv', 'sources/table1_REVISED.csv', 'sources/abstract_REVISED.md',\n"
    "          'sources/table2_REVISED.md', 'sources/conclusions_REVISED.md')))",
    "          'd3/d3_rob2_DRAFT.csv', 'd3/d3_grade_DRAFT.csv', 'sources/table1_REVISED.csv')))")

D5 = '''
# Decision D5 (JRNM and SKP, reported 3 Nov 2026): the 53 outcome exclusions the triage could not assess (d5/)
_P5 = REV / 'd5/pre_d5'
_d5 = recs(REV / 'd5/d5_decisions.csv')
_l5 = recs(REV / 'd5/d5_retrieval_log.csv')
_rel5 = [r for r in _d5 if r['decision'].startswith('Exclude')]
_rep5 = {x[0]: x for x in xl(4, 'Reports', 'Covidence ID')}
_tri5 = {x[0]: x for x in xl(4, 'Outcome exclusions recheck', 'Covidence ID')}
check('D5: 53 logged as AI-assisted reading (six not retrieved); nine relabels recorded as JRNM and SKP\\'s (2 opioid result, 7 language) in the AF4 Reports, triage and D5 sheets; Hou 2024 kept',
      len(_l5) == 53 and all(x['read_by'].startswith('AI assistant') for x in _l5) and sum(x['access'] == 'Not retrieved' for x in _l5) == 6
      and len(_rel5) == 9 and all(r['decided_by'].startswith('JRNM and SKP') for r in _rel5)
      and sorted(r['report'] for r in _rel5 if r['counted_as'] != 'Publication language') == ['Chen 2018', 'Luo 2024']
      and sum(r['counted_as'] == 'Publication language' for r in _rel5) == 7
      and [r['decision'] for r in _d5 if r['report'] == 'Hou 2024'] == ['Keep: recorded reason']
      and all(_rep5[r['covidence_id']][9] == ('Publication language' if r['counted_as'] == 'Publication language' else 'No confirmed postoperative opioid result')
              and 'Decision D5 (JRNM and SKP' in str(_rep5[r['covidence_id']][-1]) for r in _rel5)
      and sum('(D5)' in str(x[4]) for x in _tri5.values()) == 53 and sum(str(x[4]).endswith('not retrieved 3 Nov 2026 (D5)') for x in _tri5.values()) == 6
      and len(xl(4, 'D5 re-check', 'Covidence ID')) == 53)
check('D5 text: Results, Methods, Discussion, Fig. 1 legend, AF1, AF2 sections 5, 6 and 10 state the re-check; no marker names 53 reports; 8 Oct audit counts and mandated sentence kept',
      'JRNM and SKP corrected the reason for nine of them: two give no postoperative opioid result (Chen 2018 and Luo 2024)' in results
      and 'after the remaining outcome exclusions were sought and read with AI assistance, for nine others; six could not be retrieved' in methods
      and 'six excluded reports could not be retrieved, and 29 published in Chinese were checked only against their English abstracts' in discussion
      and 'Decision D5: the 53 outcome exclusions the triage could not assess (3 November 2026).' in _t
      and 'Decision D5 (JRNM and SKP, results known)' in _t and 'Seven more, recorded at screening as having no eligible analgesic outcome' in _t
      and 'six historical outcome exclusions not retrieved' in _t and '53 historical outcome exclusions' not in _t
      and '45 outcome exclusions' not in _t and '45 outcome exclusions' not in json.dumps(spec, ensure_ascii=False)
      and 'identified 30 without one: 18 in which' in _t and '4 reporting only pump requests or presses' in _t
      and 'The requirement for a confirmed postoperative opioid result was added after registration, with trial results known, because '
          'reports without such a result could not inform the primary question.' in methods)
check('D5 changed no estimate, judgement, rating or Table 1 row, and the abstract prose still counts 332 words (snapshot d5/pre_d5/)',
      all(filecmp.cmp(REV / f, _P5 / f, shallow=False) for f in ('wang1997/models_with_wang.csv', 'd3/rob_domain_summary_d3.csv',
          'd3/d3_rob2_DRAFT.csv', 'd3/d3_grade_DRAFT.csv', 'sources/table1_REVISED.csv'))
      and spec['abstract_words'] == 332, str(spec['abstract_words']))
'''
rep("\n(HERE / 'verification_results.txt').write_text(", D5 + "\n(HERE / 'verification_results.txt').write_text(")
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after decision D5')
