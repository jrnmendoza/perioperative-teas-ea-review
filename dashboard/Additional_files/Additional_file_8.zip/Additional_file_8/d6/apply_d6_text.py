"""Manuscript text after decision D6 (JRNM and SKP with all authors agreeing, reported by the review owner on 3 Nov 2026).

Selection: not downgraded; the post-hoc what-ifs (d6/d6_scenarios.csv) are reported: rest pain with the two trials the
opioid-result requirement removed, MD -0.21 (-0.75 to 0.33); PONV with the two removed trials, RR 0.63 (0.51 to 0.77).
Yu 2020: certainty that pain is not worse lowered from moderate to low (imprecision: one trial of 60 participants).
Runs after d8/apply_d8_text.py and edits sources/*_REVISED.md in place; every passage is asserted once and a passage already
edited is skipped."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'abstract': [
  ('(−1.80 to −0.26; moderate certainty that pain was not worse)', '(−1.80 to −0.26; low certainty that pain was not worse)'),
 ],
 'methods': [
  ('and best- and worst-case assignment of missing outcomes.',
   'and best- and worst-case assignment of missing outcomes. Post hoc, the rest-pain and nausea-and-vomiting analyses were '
   'refitted with the trials that the opioid-result requirement had removed.'),
 ],
 'results': [
  ('Its upper confidence limit excludes worsening of 1 point or more (moderate certainty for that question).',
   'Its upper confidence limit excludes worsening of 1 point or more (low certainty for that question: one trial of 60 '
   'participants).'),
  ('with the abstract\'s, the MD was −1.03 (−1.77 to −0.29).',
   'with the abstract\'s, the MD was −1.03 (−1.77 to −0.29). In a post-hoc analysis adding the two rest-pain trials removed by '
   'the opioid-result requirement (Liu 2021 and Xing 2022), the MD was −0.21 points (−0.75 to 0.33; three trials, 218 '
   'participants); the upper limit still excluded a 1-point worsening.'),
  ('this corresponds to about 14 fewer patients per 100 (7 to 19 fewer).',
   'this corresponds to about 14 fewer patients per 100 (7 to 19 fewer). Adding the two trials removed by the opioid-result '
   'requirement (Zheng 2025 and Lu 2021) gave RR 0.63 (0.51 to 0.77; 11 trials, 3,509 participants) in a post-hoc analysis.'),
 ],
 'table2': [
  ('| MD −1.03 points (−1.80 to −0.26) | Moderate* |', '| MD −1.03 points (−1.80 to −0.26) | Low* |'),
  ('neither result comes from a trial that reported the primary opioid outcome.',
   'neither result comes from a trial that reported the primary opioid outcome. Adding the two rest-pain trials removed by the '
   'opioid-result requirement gave MD −0.21 (−0.75 to 0.33) in a post-hoc analysis.'),
 ],
 'discussion': [
  ('and 29 published in Chinese were checked only against their English abstracts.',
   'and 29 published in Chinese were checked only against their English abstracts. Pain, nausea and vomiting and the other '
   'secondary outcomes were assessed only in trials that reported an opioid result; adding the removed trials moved the '
   'rest-pain estimate from −1.03 to −0.21 points, still excluding a 1-point worsening, and changed nausea and vomiting little '
   '(RR 0.63).'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after decision D6')
