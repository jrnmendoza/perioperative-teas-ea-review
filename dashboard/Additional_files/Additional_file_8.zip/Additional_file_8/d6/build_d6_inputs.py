"""Inputs of the D6 post-hoc what-ifs (d6/d6_scenarios.R), written into this folder so that the what-ifs can be rerun from
Additional file 9 (Astra's check of 4 Nov 2026, finding 1).

Rows: rest pain, TEAS vs sham, as reported (Yu 2020) and PONV, TEAS vs sham, as reported (nine trials), from the review's
model inputs; and the four trials the opioid-result requirement removed (Liu 2021, Xing 2022 rest pain; Zheng 2025, Lu 2021
PONV), from the 70-report extraction (10_FINAL_ADJUDICATION/04_MODELS/model_inputs.csv; not re-checked for this revision).
Writes d6/d6_inputs.csv."""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
CUR = ROOT / 'opioid_only_review/forty_report_analysis/registered_completion_2026_10_09/model_inputs.csv'
OLD = ROOT / '10_FINAL_ADJUDICATION/04_MODELS/model_inputs.csv'
COLS = ['set', 'origin', 'model_id', 'study', 'result_id', 'outcome', 'window', 'n_i', 'n_c', 'mean_i', 'sd_i', 'mean_c', 'sd_c',
        'events_i', 'events_c', 'unit', 'yi', 'vi', 'source_location', 'source_quote']
rows = []
for path, origin, studies in ((CUR, 'review model inputs', None), (OLD, '70-report extraction (removed by the opioid-result requirement)',
                                                                     ('Liu 2021', 'Xing 2022', 'Zheng 2025', 'Lu 2021'))):
    for r in csv.DictReader(open(path, encoding='utf-8-sig')):
        if r.get('model_id') not in ('pain24_rest_TEAS_sham', 'ponv24_TEAS_sham'):
            continue
        if studies is not None and r['study'] not in studies:
            continue
        rows.append(dict({k: r.get(k, '') for k in COLS}, set='pain' if r['model_id'].startswith('pain') else 'ponv', origin=origin))
assert [sum(r['set'] == s and r['origin'] == 'review model inputs' for r in rows) for s in ('pain', 'ponv')] == [1, 9]
assert sorted(r['study'] for r in rows if r['origin'] != 'review model inputs') == ['Liu 2021', 'Lu 2021', 'Xing 2022', 'Zheng 2025']
with open(HERE / 'd6_inputs.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=COLS); w.writeheader(); w.writerows(rows)
print('D6 inputs written:', len(rows), 'rows')
