# What-if estimates for decision D6 (selection and the co-primary pain result). NOT results of the review: the added
# rows are trials removed by the 9 October 2026 opioid-result criterion, refitted only to show how much the selection
# moves the pain and PONV estimates. Same estimator as the review (REML, Hartung-Knapp variance floored at 1, t(k-1);
# single trials with a normal interval), as in C01_selection/c01_scenarios.R. Reads the review's final inputs and the
# 70-report extraction (values of the removed trials not re-checked for this revision), as gathered in d6_inputs.csv beside
# this script by build_d6_inputs.py; it reads nothing else, so it also runs from Additional file 9 (Astra, 4 Nov 2026).
# Writes d6_scenarios.csv beside this script, or to the path given as the first argument.
args <- commandArgs(trailingOnly = FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)])))
target <- commandArgs(trailingOnly = TRUE)
target <- if (length(target)) target[1] else file.path(here, "d6_scenarios.csv")
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^﻿", "", names(x)); x }
fit <- function(y, v) {
  k <- length(y)
  if (k == 1) return(c(k = 1, effect = y, lo = y - qnorm(.975) * sqrt(v), hi = y + qnorm(.975) * sqrt(v), I2 = NA))
  nll <- function(t) { w <- 1 / (v + t); mu <- sum(w * y) / sum(w); .5 * (sum(log(v + t)) + log(sum(w)) + sum(w * (y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2) * 10, max(v) * 10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1 / (v + tau); mu <- sum(w * y) / sum(w); q <- sum(w * (y - mu)^2) / (k - 1)
  se <- sqrt(max(1, q) / sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1 / v; C <- sum(w0) - sum(w0^2) / sum(w0)
  c(k = k, effect = mu, lo = mu - cr * se, hi = mu + cr * se, I2 = 100 * tau / (tau + (k - 1) / C))
}
inp <- rd(file.path(here, "d6_inputs.csv"))
cur <- inp[inp$origin == "review model inputs", ]
old <- inp[inp$origin != "review model inputs", ]
n <- function(d) sum(as.numeric(d$n_i) + as.numeric(d$n_c))
out <- list()
add <- function(id, desc, d, ratio) {
  f <- fit(as.numeric(d$yi), as.numeric(d$vi)); tr <- if (ratio) exp else identity
  out[[id]] <<- data.frame(scenario = id, assumption = desc, k = f[["k"]], N = n(d), measure = if (ratio) "RR" else "MD (0-10)",
                           effect = round(tr(f[["effect"]]), 3), ci_low = round(tr(f[["lo"]]), 3), ci_high = round(tr(f[["hi"]]), 3),
                           I2 = round(f[["I2"]], 1), reports = paste(d$study, collapse = "; "), stringsAsFactors = FALSE)
}
pain <- cur[cur$model_id == "pain24_rest_TEAS_sham", ]
pain_x <- old[old$model_id == "pain24_rest_TEAS_sham" & old$study %in% c("Liu 2021", "Xing 2022"), ]
ponv <- cur[cur$model_id == "ponv24_TEAS_sham", ]
ponv_x <- old[old$model_id == "ponv24_TEAS_sham" & old$study %in% c("Zheng 2025", "Lu 2021"), ]
stopifnot(nrow(pain) == 1, nrow(pain_x) == 2, nrow(ponv) == 9, nrow(ponv_x) == 2)
cols <- c("study", "n_i", "n_c", "yi", "vi")
add("P0", "As reported: rest pain at about 24 h, TEAS vs sham (Yu 2020)", pain, FALSE)
add("P1", "Plus the two rest-pain trials removed by the 9 Oct criterion (Liu 2021, Xing 2022)", rbind(pain[cols], pain_x[cols]), FALSE)
add("N0", "As reported: PONV 0-24 h, TEAS vs sham", ponv, TRUE)
add("N1", "Plus the two PONV trials removed by the 9 Oct criterion (Zheng 2025, Lu 2021)", rbind(ponv[cols], ponv_x[cols]), TRUE)
res <- do.call(rbind, out)
stopifnot(abs(res$effect[res$scenario == "P0"] - (-1.03)) < 1e-6, abs(res$effect[res$scenario == "N0"] - 0.60) < 0.005)
write.csv(res, target, row.names = FALSE)
print(res[, c("scenario", "k", "N", "measure", "effect", "ci_low", "ci_high", "I2")])
