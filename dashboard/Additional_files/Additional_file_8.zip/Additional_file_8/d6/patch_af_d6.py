"""Additional-files edits after decision D6 (JRNM and SKP with all authors agreeing, reported by the review owner on
3 Nov 2026): GRADE for selection and for the co-primary pain result.

AF11: the rest-pain profile (pain24_rest_TEAS_sham) goes from moderate to low (imprecision, one level); the PONV profile notes
its what-if; a "Selection what-ifs (D6)" sheet gives d6/d6_scenarios.csv. AF2: decision log. AF9: this folder.
Run after d9/patch_af_d9.py; edits build_additional_files.py in place, each replacement asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# ---- AF11 ---------------------------------------------------------------------------------------------------------------
rep("    wb = new_wb(11, ['GRADE evidence profiles",
    "    for r in oth:   # decision D6, 3 Nov 2026 (JRNM and SKP, all authors agreeing)\n"
    "        if r['model'] == 'pain24_rest_TEAS_sham':\n"
    "            assert r['cert'] == 'Moderate' and str(r['md']) == '0', (r['cert'], r['md'])\n"
    "            r.update(cert='Low', md='1', reason=r['reason'] + ' Decision D6 (3 Nov 2026): one level for imprecision (one trial of '\n"
    "                     '60 participants, below the about 70 needed to detect a 1-point difference with SD 1.5). With the two rest-pain '\n"
    "                     'trials removed by the opioid-result requirement, MD -0.21 (-0.75 to 0.33) in a post-hoc what-if; not '\n"
    "                     'downgraded for selection.', status=r['status'] + '; revised 3 Nov 2026 by decision D6 (JRNM and SKP, all '\n"
    "                     'authors agreeing): Moderate to Low')\n"
    "        if r['model'] == 'ponv24_TEAS_sham':\n"
    "            r['reason'] += (' Decision D6 (3 Nov 2026): with the two trials removed by the opioid-result requirement, RR 0.63 '\n"
    "                            '(0.51 to 0.77) in a post-hoc what-if; not downgraded for selection.')\n"
    "    d6w = recs(REV / 'd6/d6_scenarios.csv')\n"
    "    wb = new_wb(11, ['GRADE evidence profiles")
rep("                  ('With Colak and Fu', 'Current profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): revised after independent AI audits and confirmed by SKP on 3 Nov 2026')],",
    "                  ('With Colak and Fu', 'Current profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): revised after independent AI audits and confirmed by SKP on 3 Nov 2026'),\n"
    "                  ('Selection what-ifs (D6)', 'Post-hoc what-ifs for decision D6 (3 Nov 2026): rest pain and PONV, TEAS vs sham, with the trials the '\n"
    "                                             'opioid-result requirement removed; not results of the review and not graded')],")
rep("           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])\n    return save(wb, 11, '.xlsx')",
    "           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])\n"
    "    sheet(wb, 'Selection what-ifs (D6)', d6w, [('scenario', 'Scenario', 9), ('assumption', 'Assumption', 60), ('k', 'Trials', 7),\n"
    "          ('N', 'Participants', 10), ('measure', 'Measure', 10), ('effect', 'Effect', 8), ('ci_low', '95% CI low', 9),\n"
    "          ('ci_high', '95% CI high', 9), ('I2', 'I² (%)', 7), ('reports', 'Reports', 60)])\n"
    "    return save(wb, 11, '.xlsx')")

# ---- AF2 decision log ---------------------------------------------------------------------------------------------------
rep("    after('8 Oct', ['8 Oct',",
    "    rows.append(['3 Nov', 'Decision D6 (JRNM and SKP, all authors agreeing; results known): certainty that rest pain is not '\n"
    "                 'worse (Yu 2020) lowered from moderate to low for imprecision; no downgrade for selection. Post-hoc what-ifs '\n"
    "                 'refitted rest pain and PONV with the trials removed by the opioid-result requirement (Additional file 11).', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct',")

# ---- AF9 ----------------------------------------------------------------------------------------------------------------
rep("    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],\n",
    "    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],\n"
    "    'd6': [REV / 'd6' / f for f in ('d6_decision.csv', 'd6_scenarios.R', 'd6_scenarios.csv', 'apply_d6_text.py', 'patch_af_d6.py',\n"
    "                                    'update_verify_d6.py')],\n")
rep("              '- `d9/`: Additional file 6, sheet \"Analysis inputs\", now lists all seven rescue trials (3 Nov 2026); no value changed.', '',\n",
    "              '- `d9/`: Additional file 6, sheet \"Analysis inputs\", now lists all seven rescue trials (3 Nov 2026); no value changed.',\n"
    "              '- `d6/`: decision D6 (JRNM and SKP, all authors agreeing, 3 Nov 2026): rest-pain certainty lowered to low; '\n"
    "              '`d6_scenarios.R` refits rest pain and PONV with the trials the opioid-result requirement removed (post-hoc '\n"
    "              'what-ifs, not results; reads the review\\'s inputs and the 70-report extraction).', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after decision D6')
