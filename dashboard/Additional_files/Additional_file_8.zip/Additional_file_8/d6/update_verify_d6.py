"""After decision D6 (JRNM and SKP with all authors agreeing, reported 3 Nov 2026): adapt verification/verify_revision.py,
as written by d9/update_verify_d9.py.

Added checks: the post-hoc what-ifs (d6/d6_scenarios.csv) reproduce the reported rest-pain and PONV estimates and give the
values the text states; the rest-pain certainty reads low in the abstract, Results, Table 2 and AF11, with the D6 reason;
the what-ifs are reported in the Methods, Results, Table 2 legend, Discussion and AF11; and, against d6/pre_d6/, no
estimate, RoB 2 judgement, Table 1 row or abstract word count changed. Re-run the earlier update scripts first."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')

D6 = '''
# Decision D6 (JRNM and SKP, all authors agreeing, reported 3 Nov 2026): GRADE for selection and the co-primary pain result (d6/)
_sc = {r['scenario']: r for r in recs(REV / 'd6/d6_scenarios.csv')}
_f = lambda r: (round(float(r['effect']), 2), round(float(r['ci_low']), 2), round(float(r['ci_high']), 2))
check('D6 what-ifs: as-reported rows reproduce Yu 2020 (-1.03) and PONV (0.60); with the removed trials -0.21 (-0.75 to 0.33) and RR 0.63 (0.51 to 0.77)',
      _f(_sc['P0']) == (-1.03, -1.8, -0.26) and _f(_sc['N0']) == (0.6, 0.45, 0.79)
      and _f(_sc['P1']) == (-0.21, -0.75, 0.33) and _sc['P1']['k'] == '3' and _f(_sc['N1']) == (0.63, 0.51, 0.77) and _sc['N1']['k'] == '11')
_po = {x[0]: x for x in xl(11, 'Other outcomes', 'Analysis')}
check('D6: rest-pain certainty is low (imprecision one level) in the abstract, Results, Table 2 and AF11; no "moderate certainty" for pain remains',
      'low certainty that pain was not worse' in abstract and 'moderate certainty that pain' not in abstract
      and '(low certainty for that question: one trial of 60 participants)' in results and 'moderate certainty for that question' not in results
      and '| MD −1.03 points (−1.80 to −0.26) | Low* |' in open(REV / 'sources/table2_REVISED.md', encoding='utf-8').read()
      and _po['pain24_rest_TEAS_sham'][7] == 'Low' and str(_po['pain24_rest_TEAS_sham'][11]) == '1'
      and 'Decision D6' in str(_po['pain24_rest_TEAS_sham'][13]) and 'decision D6 (JRNM and SKP, all authors agreeing)' in str(_po['pain24_rest_TEAS_sham'][15])
      and _po['ponv24_TEAS_sham'][7] == 'Low' and 'Decision D6' in str(_po['ponv24_TEAS_sham'][13]))
check('D6: the what-ifs are reported (Methods, Results, Table 2 legend, Discussion, AF11 sheet, AF2 decision log)',
      'Post hoc, the rest-pain and nausea-and-vomiting analyses were refitted with the trials that the opioid-result requirement had removed.' in methods
      and 'the MD was −0.21 points (−0.75 to 0.33; three trials, 218 participants)' in results
      and 'gave RR 0.63 (0.51 to 0.77; 11 trials, 3,509 participants) in a post-hoc analysis' in results
      and 'Adding the two rest-pain trials removed by the opioid-result requirement gave MD −0.21 (−0.75 to 0.33)' in _t
      and 'moved the rest-pain estimate from −1.03 to −0.21 points, still excluding a 1-point worsening' in discussion
      and len(xl(11, 'Selection what-ifs (D6)', 'Scenario')) == 4 and 'Decision D6 (JRNM and SKP, all authors agreeing; results known)' in _t)
check('D6 changed no estimate, RoB 2 judgement or Table 1 row; abstract prose still 332 words (snapshot d6/pre_d6/)',
      all(filecmp.cmp(REV / f, REV / 'd6/pre_d6' / f, shallow=False) for f in ('wang1997/models_with_wang.csv', 'd3/rob_domain_summary_d3.csv',
          'sources/table1_REVISED.csv')) and spec['abstract_words'] == 332, str(spec['abstract_words']))
'''
for o, nw in [   # the D8 snapshot check compared the abstract file, whose pain certainty D6 changes
    ("check('D8 changed no estimate, judgement, rating, Table 1 row or abstract (snapshot d8/pre_d8/)',",
     "check('D8 changed no estimate, judgement, rating or Table 1 row (snapshot d8/pre_d8/; the abstract\\'s pain certainty changed later under D6)',"),
    ("'sources/table1_REVISED.csv', 'sources/abstract_REVISED.md'))\n      and spec['abstract_words'] == 332)",
     "'sources/table1_REVISED.csv'))\n      and spec['abstract_words'] == 332)"),
]:
    assert s.count(o) == 1, o[:80]
    s = s.replace(o, nw)
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, D6 + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after decision D6')
