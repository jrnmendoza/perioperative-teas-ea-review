"""Manuscript text after decision D7 (JRNM, reported 3 Nov 2026; the timing split checked by SKP): the multimodal-analgesia
definition keeps "a routine non-opioid at any perioperative time" (14 / 27 / 2 / 1), and the Results say when the routine
non-opioid was given (d7/d7_mma_timing.csv): after surgery in 6 of the 14, only before or at the end of surgery in 8,
including Szmit 2021. Runs after d6/apply_d6_text.py; edits sources/*_REVISED.md in place, each passage asserted once."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'results': [
  ('including Szmit 2021, in which every patient received 1 g metamizole before the end of surgery.',
   'including Szmit 2021, in which every patient received 1 g metamizole before the end of surgery. In eight of these 14 the '
   'routine non-opioid was given only before or at the end of surgery, as in Szmit 2021; in six it continued after surgery '
   '(Additional file 8).'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and new in s:   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after decision D7')
