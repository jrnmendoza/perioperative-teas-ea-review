"""Additional-files edits after decision D7 (JRNM, reported by the review owner on 3 Nov 2026; the timing split checked by
SKP): time boundary for multimodal analgesia.

The definition is unchanged (a routine non-opioid at any perioperative time). AF8: a column giving, for the 14 multimodal
reports, whether the routine non-opioid continued after surgery (6) or was given only before or at the end of surgery (8),
from d7/d7_mma_timing.csv, and a README note. AF2: the decision log and a section 12 row for SKP's check. AF9: this folder.
Run after d6/patch_af_d6.py; edits build_additional_files.py in place, each replacement asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


# ---- AF8 ----------------------------------------------------------------------------------------------------------------
rep("    eff = recs(C / 'dose_protocol_effect_directions.csv')\n",
    "    D7T = {r['report']: r for r in recs(REV / 'd7/d7_mma_timing.csv')}   # decision D7, 3 Nov 2026\n"
    "    for r in rows:\n"
    "        t = D7T.get(r['report_id'])\n"
    "        assert bool(t) == str(r['s_mma_all_groups']).startswith('Yes'), r['report_id']\n"
    "        r['s_mma_timing'] = f\"{t['timing']}: {t['basis']}\" if t else 'Not applicable (no routine multimodal analgesia in all groups)'\n"
    "    assert [sum(r['s_mma_timing'].startswith(k) for r in rows) for k in ('Continues after surgery', 'Before or at the end of surgery only')] == [6, 8]\n"
    "    eff = recs(C / 'dose_protocol_effect_directions.csv')\n")
rep("('s_non_opioid_components', 'Non-opioid components', 30), ('s_mma_quote', 'Multimodal analgesia: source text', 50),",
    "('s_non_opioid_components', 'Non-opioid components', 30),\n"
    "        ('s_mma_timing', 'Timing of the routine non-opioid (decision D7)', 40), ('s_mma_quote', 'Multimodal analgesia: source text', 50),")
rep("                ['Multimodal analgesia: a non-opioid analgesic or regional or local technique given routinely to all groups; drugs given only as rescue are not counted.',\n",
    "                ['Multimodal analgesia: a non-opioid analgesic or regional or local technique given routinely to all groups; drugs given only as rescue are not counted.',\n"
    "                 'Decision D7 (JRNM, 3 Nov 2026; the timing split checked by SKP): the definition counts a routine non-opioid given at any '\n"
    "                 'perioperative time. The timing column shows that it continued after surgery in 6 of the 14 multimodal reports and was '\n"
    "                 'given only before or at the end of surgery in 8, including Szmit 2021.',\n")

# ---- AF2: decision log and section 12 -------------------------------------------------------------------------------------
rep("    after('8 Oct', ['8 Oct',",
    "    rows.append(['3 Nov', 'Decision D7 (JRNM; split checked by SKP): multimodal analgesia keeps the definition \"a routine non-opioid '\n"
    "                 'at any perioperative time\" (14 reports); the Results and Additional file 8 now show that it continued after '\n"
    "                 'surgery in 6 and was given only before or at the end of surgery in 8, including Szmit 2021.', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct',")
rep("English-abstract check of the 12 language exclusions (24 October 2026)', 'Checked; no change reported'],\n    ]",
    "English-abstract check of the 12 language exclusions (24 October 2026)', 'Checked; no change reported'],\n"
    "        ['3 Nov', 'Timing of the routine non-opioid in the 14 multimodal reports (decision D7; Additional file 8)', 'Confirmed'],\n    ]")

# ---- AF9 ----------------------------------------------------------------------------------------------------------------
rep("    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],\n",
    "    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],\n"
    "    'd7': [REV / 'd7' / f for f in ('d7_mma_timing.csv', 'apply_d7_text.py', 'patch_af_d7.py', 'update_verify_d7.py')],\n")
rep("              'what-ifs, not results; reads the review\\'s inputs and the 70-report extraction).', '',\n",
    "              'what-ifs, not results; reads the review\\'s inputs and the 70-report extraction).',\n"
    "              '- `d7/`: decision D7 (JRNM, 3 Nov 2026; checked by SKP): when the routine non-opioid was given in the 14 '\n"
    "              'multimodal reports (`d7_mma_timing.csv`); the definition and counts are unchanged.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after decision D7')
