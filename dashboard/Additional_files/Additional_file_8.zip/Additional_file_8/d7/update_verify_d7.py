"""After decision D7 (JRNM, reported 3 Nov 2026; the timing split checked by SKP): adapt verification/verify_revision.py,
as written by d6/update_verify_d6.py.

The SKP check of AF2 section 12 now expects six rows dated 3 Nov (five Confirmed), with SKP's check of the D7 timing split.
Added checks: the definition and the 14 / 27 / 2 / 1 counts are unchanged; AF8 gives the timing for exactly the 14
multimodal reports (6 after surgery, 8 only before or at the end, Szmit 2021 among the 8); the Results state the split; and
the decision is in the AF2 decision log. Re-run the earlier update scripts first."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')

old = "      len(_n3) == 5 and not _open12 and sum(r[2] == 'Confirmed' for r in _n3) == 4"
assert s.count(old) == 1
s = s.replace(old, "      len(_n3) == 6 and not _open12 and sum(r[2] == 'Confirmed' for r in _n3) == 5\n"
                   "      and any('Timing of the routine non-opioid' in r[1] and r[2] == 'Confirmed' for r in _n3)   # D7, 3 Nov 2026")
D7 = '''
# Decision D7 (JRNM, reported 3 Nov 2026; the timing split checked by SKP): time boundary for multimodal analgesia (d7/)
import collections as _co
_t1 = recs(REV / 'sources/table1_REVISED.csv')
_c8 = {x[0]: x for x in xl(8, 'Characteristics', 'Report')}
_h8 = [r for r in openpyxl.load_workbook(REV / 'additional_files/Additional_file_8.xlsx', read_only=True)['Characteristics'].iter_rows(values_only=True)][0]
_it = list(_h8).index('Timing of the routine non-opioid (decision D7)')
_tm = {k: str(v[_it] or '') for k, v in _c8.items()}
check('D7: definition and counts unchanged (14 / 27 / 2 / 1); AF8 times the 14 multimodal reports (6 after surgery, 8 before or at the end, incl. Szmit 2021); Results state it',
      _co.Counter(r['MMA'] for r in _t1) == _co.Counter({'No': 27, 'Yes': 14, 'Cond.': 2, 'NR': 1})
      and 'given routinely to all groups at any time in the perioperative period' in methods
      and sum(v.startswith('Continues after surgery') for v in _tm.values()) == 6
      and sum(v.startswith('Before or at the end of surgery only') for v in _tm.values()) == 8
      and _tm['Szmit 2021'].startswith('Before or at the end of surgery only')
      and 'In eight of these 14 the routine non-opioid was given only before or at the end of surgery, as in Szmit 2021; in six it continued after surgery' in results
      and 'Decision D7 (JRNM; split checked by SKP)' in _t)
'''
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, D7 + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after decision D7')
