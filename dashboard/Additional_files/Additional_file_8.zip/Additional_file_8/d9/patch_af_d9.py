"""Additional-files edit for D9 (3 Nov 2026): complete the rescue rows of AF6, sheet "Analysis inputs".

Found while preparing the D9 source check: the sheet says it lists every value entering an analysis reported in the main
text, but for rescue opioid receipt (TEAS vs sham, 7 trials) it listed only Wang 1997 and Fu 2024 plus one row without a
report name (Tu 2024). The rescue model reads opioid_only_review/forty_report_analysis/rescue_model_inputs.csv, which the
sheet did not use. The five trials are now taken from that file (Tu 2024, Liu 2026 burn, Yu 2020, Liu 2026 ESD, Zhou 2025),
so the sheet has 59 rows and every analysis lists as many rows as its model has trials. No value, model or estimate changes.

Run after d8/patch_af_d8.py; edits build_additional_files.py in place, each replacement asserted once."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


rep("        if m not in MAIN_MODELS or r['study'] == 'Lee 2011' or (m, r['result_id']) in seen:\n",
    "        if m not in MAIN_MODELS or r['study'] == 'Lee 2011' or (m, r['result_id']) in seen or m == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':\n")
rep("    arm = {'sham': 'sham', 'usual care': 'PCA only'}\n",
    "    for r in recs(FA / 'rescue_model_inputs.csv'):   # D9, 3 Nov 2026: the rescue model's own inputs (five trials; Wang 1997 and Fu 2024 below)\n"
    "        if r['model_id'] != 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':\n"
    "            continue\n"
    "        ev = f\"{r['events_i']}/{r['n_i']} vs {r['events_c']}/{r['n_c']}\"\n"
    "        out.append(dict(analysis=r['model_id'], report=r['report'], result_id=r['outcome_id'], outcome=f\"{r['outcome']} ({r['opioid']})\",\n"
    "                        window=r['window'], raw_unit='patients', raw_values=ev, factor='', model_values=ev, yi=num(r['y'], 4),\n"
    "                        vi=num(r['variance'], 5), source_location=r['source_location'], source_quote='Not recorded (location only)',\n"
    "                        source_sha256=r['source_sha256'][:16]))\n"
    "    arm = {'sham': 'sham', 'usual care': 'PCA only'}\n")

rep("          + [REV / 'd8/figure_builds/build_prisma_manuscript_d8.py'],\n",
    "          + [REV / 'd8/figure_builds/build_prisma_manuscript_d8.py'],\n"
    "    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],\n")
rep("'screened and excluded (`d8_decisions.csv`), and the Fig. 1 builder with its other-methods column; no estimate changed.', '',\n",
    "'screened and excluded (`d8_decisions.csv`), and the Fig. 1 builder with its other-methods column; no estimate changed.',\n"
    "              '- `d9/`: Additional file 6, sheet \"Analysis inputs\", now lists all seven rescue trials (3 Nov 2026); no value changed.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits for D9 (AF6 rescue rows)')
