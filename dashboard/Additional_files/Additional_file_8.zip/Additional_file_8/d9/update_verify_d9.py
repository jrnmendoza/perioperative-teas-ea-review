"""D9 preparation (3 Nov 2026): adapt verification/verify_revision.py, as written by d8/update_verify_d8.py.

Run after d8/update_verify_d8.py. Added checks: AF6 "Analysis inputs" lists, for every main-text analysis, as many named
rows as the model has trials (the rescue analysis had 3 of 7 before d9/patch_af_d9.py); the D9 source-check workbook covers
every AF6 row and records no human check yet (its checker columns are empty until SKP's check is reported); and, against
d9/pre_d9/, no estimate changed. Re-run the earlier update scripts first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')

D9 = '''
# D9 preparation (3 Nov 2026): AF6 rescue rows and the source-check workbook (d9/)
_k = {r['model_id']: r['k'] for f in (FA / 'reviewer_rerun_2026_10_09/model_results.csv', FA / 'registered_completion_2026_10_09/model_results_python.csv')
      for r in recs(f) if r.get('model_id') and r.get('k')}
_k.update({r['model_id']: r['k'] for r in recs(REV / 'wang1997/models_with_wang.csv')})
_ai = xl(6, 'Analysis inputs', 'Analysis')
_per = {}
for x in _ai:
    _per[x[0]] = _per.get(x[0], 0) + 1
_bad = {m: (n, _k.get(m)) for m, n in _per.items() if str(n) != str(int(float(_k.get(m, -1))))}
_resc = sorted(x[1] for x in _ai if x[0] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP')
check('D9: AF6 "Analysis inputs" lists every trial of every main-text analysis (59 rows, all named; rescue 7 of 7)',
      len(_ai) == 59 and all(x[1] for x in _ai) and not _bad
      and _resc == sorted(next(r for r in recs(REV / 'wang1997/models_with_wang.csv') if r['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP')['reports'].split('; ')),
      str(_bad) if _bad else f'{len(_ai)} rows')
_d9 = recs(REV / 'd9/d9_checklist.csv')
check('D9: source-check workbook covers every AF6 row, and records no human check yet (checker columns empty)',
      (REV / 'd9/D9_source_check.xlsx').exists() and sum(r['origin'] == 'AF6 Analysis inputs' for r in _d9) == 59
      and not any(r['checked_by'] or r['date'] or r['matches'] or r['correct_value'] for r in _d9), f'{len(_d9)} rows')
check('D9 changed no estimate (snapshot d9/pre_d9/)', filecmp.cmp(REV / 'wang1997/models_with_wang.csv', REV / 'd9/pre_d9/wang1997/models_with_wang.csv', shallow=False))
'''
old = "\n(HERE / 'verification_results.txt').write_text("
assert s.count(old) == 1
s = s.replace(old, D9 + old)
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted for the D9 preparation')
