"""Exploratory 40-report scenario. Does not write to the canonical analyses.
Source-checked remaining extraction, native-unit estimates, and rescue RR synthesis.
Run with Python containing numpy, scipy and matplotlib.
"""
import csv, json, math, hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm, t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
def read(p):
    with p.open(newline='') as f: return list(csv.DictReader(f))
def write(name, rows):
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w', newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
audit=read(ROOT/'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv')
cohort={r['report']:r for r in audit if r['source_confirmed_named_opioid_or_author_MME']=='YES'}
assert len(cohort)==40 and len({r['trial_id'] for r in cohort.values()})==39
raw=[]
def add(report, outcome, window, drug, unit, modality, comparator, ni, nc,
        stats, vals, page, note='', status='NATIVE_SINGLE_TRIAL'):
    source=cohort[report]
    d=dict(outcome_id=f'NEW-{len(raw)+1:03}',report=report,trial_id=source['trial_id'],
           outcome=outcome,window=window,opioid=drug,unit=unit,modality=modality,
           comparator=comparator,n_i=ni,n_c=nc,statistics=stats,status=status,
           note=note,source_location=page,source_pdf=source['source_pdf'],source_sha256=source['source_sha256'])
    keys={'mean_SD':['mean_i','sd_i','mean_c','sd_c'],
          'median_IQR':['median_i','q1_i','q3_i','median_c','q1_c','q3_c'],
          'events':['events_i','events_c'],'graph_mean_SEM':['mean_i','sem_i','mean_c','sem_c'],
          'qualitative':[]}[stats]
    d.update(zip(keys,vals));raw.append(d);return d
add('Ao 2021','PCA solution delivered','0–48 h','Sufentanil','mL','TEAS','Sham',32,33,
    'mean_SD',[102.8,7.4,120.6,9.2],'Table III PDF p6; flow p4; formulation p2',
    '1.5 micrograms/kg in 150 mL. Analyzed denominators 32/33, not randomized 35/35.')
add('Chen 2015','Rescue administrations','0–24 h','IV morphine','administrations','TEAS','Sham',41,42,
    'median_IQR',[1,1,3,3.5,2,7],'Table 3 PDF p4; regimen p2',
    'IQR, not range. Each rescue administration is 2 mg. No mean/SD reconstruction.')
add('Chen 2015','Time to first rescue opioid','0–24 h','IV morphine','minutes','TEAS','Sham',41,42,
    'mean_SD',[69,8,37,9],'Table 3 PDF p4',
    'Reported arithmetic mean/SD. Individual estimate only; time origin and handling of nonrecipients not fully specified.')
add('Chen 2015 (Hyperalgesia)','Rescue administrations','0–24 h','IV sufentanil','administrations','TEAS','Sham',29,30,
    'median_IQR',[3,2,4,7,6,8],'Table 2 PDF p5; regimen p4',
    'Fixed 0.05 micrograms/kg per bolus; continuous infusion not allowed. IQR retained.')
add('Chen 2015 (Hyperalgesia)','Time to first rescue opioid','0–24 h','IV sufentanil','minutes','TEAS','Sham',29,30,
    'mean_SD',[35.6,7.1,20.5,6.2],'Table 2 PDF p5',
    'Individual estimate only; time origin and handling of nonrecipients not fully specified.')
add('Gao 2022','Pump opioid amount','0–24 h','Sufentanil','micrograms','TEAS','Sham',827,828,
    'median_IQR',[33,0,50,30,0,60],'Table 2 PDF p5',
    'Substantial floor at zero; no mean/SD imputation. Baseline Apfel opioid-use row is not this result.')
add('Gao 2022','Routine opioid pump receipt','Postoperative; pump amount assessed at 24 h','Sufentanil','risk ratio','TEAS','Sham',827,828,
    'events',[597,588],'Table 2 PDF p5', 'Routine pump receipt, not rescue receipt.')
# Pixel reading from original Figure 1B, full cohort. Preserve approximate SEMs.
# Detail rendering: PDF p3 clip (70,435,175,535), scale 5; y=469 is 0 mg,
# y=155 is 15 mg. Mean lines: EA y354.5, control y314.5.
# SEM caps: EA y320/390, control y282.5/346.5. +/-1 px reading tolerance.
scale=15/(469-155)
add('Grech 2016','PACU opioid amount','PACU only','Author morphine equivalents','mg author MME','EA','Sham',11,9,
    'graph_mean_SEM',[(469-354.5)*scale,35*scale,(469-314.5)*scale,32*scale],
    'Figure 1B PDF p3; n and sham description p2; demographics p4',
    'Approximate figure reading. SEM converted to SD using sqrt(n). Route-equivalence basis unspecified. '
    'Patient #11 exclusion described near cytokine methods creates denominator ambiguity. '
    'Figure uses full cohort; women-only panels are overlapping subgroups and not a second trial.',
    'GRAPH_APPROXIMATION_UNPOOLED')
for window,low,high,control in [
    ('0–6 h',(10.16,5.21),(11.49,4.21),(14.61,6.55)),
    ('0–12 h',(20.32,8.69),(22.09,8.32),(30.29,10.47)),
    ('0–24 h',(39.31,15.58),(45.72,16.92),(56.54,12.50)),
    ('0–48 h',(82.41,21.18),(83.76,17.91),(94.88,9.91))]:
    for arm,values in [('EA 2 Hz',low),('EA 20/100 Hz',high)]:
        add('Jin 2023','PCA solution delivered',window,'Fentanyl','mL',arm,'Sham',53,52,
            'mean_SD',list(values)+list(control),'Table 3 PDF p6',
            'Concentration absent from accessible main report. Anesthesia eligibility not established. '
            '174 randomized (58/arm); 16 dropouts (5/5/6) leave 158 completers (53/53/52). '
            'Table estimates use completers despite ITT labels; missing-data handling for claimed ITT unclear. '
            'Shared sham arm: combine active arms within each period for estimates.', 'NATIVE_VOLUME_ELIGIBILITY_UNRESOLVED')
add('Long 2025','PCA solution delivered','0–48 h','Sufentanil','mL','EA/TEAS unresolved','Sham',27,26,
    'mean_SD',[86.22,4.27,89.23,3.67],'Table 7/Figure 9 PDF p9; flow p3; formulation p2',
    '2 micrograms/kg in 100 mL. Group A=27, C=26. Author calls treatment EA, '
    'but describes needle or electrode patch. Figure 1 depicts pads and labels TEAS; '
    'cohort-wide patch-only use not established. Do not assign to TEAS or EA pooled model.')
for comp,nc,mc,sc in [('Sham',55,5.2,4.7),('Usual care',55,5.0,4.5)]:
    add('Ng 2013','Rescue injections','Postoperative stay; exact endpoint not restated','Pethidine','injections','EA',comp,55,nc,
        'mean_SD',[2.7,2.3,mc,sc],'Tables 3/4 PDF p4; regimen p2',
        'Tables call injections 50 mg; methods say 1 mg/kg. Preserve injection count and do not convert to mg. Shared EA arm.')
add('Ntritsou 2014','Rescue opioid use','45 min and reported postoperative assessment','IV tramadol','not numerically reported','EA','Sham',35,35,
    'qualitative',[],'Results PDF p3; anesthetic regimen p2; Table 1 p4',
    'Authors report decrease in rescue analgesia, p<0.001; exact postoperative arm quantities absent. '
    'Tramadol sum 443.7 vs 461.5 mg includes pre-end-of-surgery bolus and is not pure postoperative dose. '
    'No numerical treatment effect reconstructed.', 'QUALITATIVE_ONLY')
for window,mi,si,usual,susual,tens,stens in [
    ('0–24 h',20.66,27.89,33.12,42.69,33.75,56.55),
    ('24–48 h',10,20.70,6.25,17.07,6.31,17.05)]:
    for comp,mc,sc in [('Usual care',usual,susual),('Active TENS',tens,stens)]:
        add('Oztas 2019','Rescue opioid amount',window,'IM pethidine','mg','TEAS',comp,15,16,
            'mean_SD',[mi,si,mc,sc],'Table 4 PDF p11; groups/formulation methods',
            'Group 2=TEAS, group 1=nonacupoint TENS. Shared TEAS arm; native drug amount only.')
for comp,mc,sc in [('Usual care',265.65,96.71),('Active TENS',195.50,71.74)]:
    add('Oztas 2019','PCA opioid amount','24–48 h','Tramadol','mg','TEAS',comp,15,16,
        'mean_SD',[164.46,61.31,mc,sc],'Table 4 PDF p11',
        'Interval amount, not cumulative 0–48 h. No SD for sum of correlated periods.')
add('Wu 2016','Rescue opioid use','Postoperative follow-up; exact rescue period not restated','IV tramadol','not numerically reported','TEAS','Usual care',27,27,
    'qualitative',[],'Results PDF p7; regimen p3; Table I p4',
    'Lower rescue demands reported versus group 1, p<0.05. Exact quantities absent; '
    'sham rescue comparison not quantified. No numerical effect reconstructed.', 'QUALITATIVE_ONLY')
add('Wu 2025','Rescue opioid amount','0–24 h','Oral oxycodone/acetaminophen','tablets','TEAS','Sham',50,50,
    'mean_SD',[.3,.5,.3,.6],'Table 2 PDF p5; footnote and narrative p6',
    'Tablet strength unspecified. Three patients had missing 24 h follow-up; source reports ITT n=50/50. '
    'Nonopioid analgesic results not included.')
for comp,mc,sc,ec in [('Sham',133,7.0,6),('Usual care',134,5.9,7)]:
    add('Xie 2014','Opioid amount used for postoperative pain','Unspecified; regimen spans end of surgery to POD3','Sufentanil','micrograms','EA',comp,20,20,
        'mean_SD',[115,6.0,mc,sc],'Table 2 PDF p3; regimen p2',
        'Printed table 133/134 differs from abstract 133.5/134.3. Table values used. '
        'Infusion begins 30 min before surgery ends; total may include that period. '
        'Keep descriptive/held and do not classify as pure 24 h or 48 h.', 'HELD_WINDOW_AND_PERIOP_AMBIGUITY')
    add('Xie 2014','Rescue opioid receipt','Postoperative; exact rescue window unspecified','IV dezocine','risk ratio','EA',comp,20,20,
        'events',[1,ec],'Table 2 PDF p3; regimen p2',
        'Exact counts derived from 5%, 30%, 35% with n=20. Shared EA arm. '
        'No assignment to 48 h; individual estimates only.')
add('Xiong 2021','Postoperative opioid amount','Postoperative; exact period unspecified','Author morphine equivalents','mg/kg author MME','TEAS','Sham',31,31,
    'mean_SD',[.6,.2,.6,.1],'Table 2 PDF p5; methods p4',
    'IV versus oral equivalence basis unspecified. Preserve mg/kg without multiplying mean weight.')
add('Yao 2015','Rescue administrations','0–24 h','IV sufentanil','administrations','TEAS','Sham',35,36,
    'median_IQR',[1,1,3,3.5,2,7.8],'Table 3 PDF p4; fixed bolus methods p3',
    '0.05 micrograms/kg per rescue bolus. IQR retained; no mean/SD imputation.')
add('Yao 2015','Time to first rescue opioid','0–24 h','IV sufentanil','minutes','TEAS','Sham',35,36,
    'median_IQR',[59,31,1440,47,13,196],'Table 3 PDF p4',
    'Upper quartile at 1440 minutes may reflect follow-up censoring. No mean/SD conversion or pooled time model.')
for report,ni,usualn,mi,usualm,usualsd in [
    ('Yeh 2010',33,31,18.6,27.2,12.5),('Yeh 2011',30,30,19.3,28.0,12.1)]:
    for comp,nc,mc,sc in [('Sham',30,21.6,13.1),('Usual care',usualn,usualm,usualsd)]:
        add(report,'PCA opioid amount','0–24 h','Morphine','mg','TEAS',comp,ni,nc,
            'mean_SD',[mi,9.7,mc,sc], 'Table 4 PDF p6; route p2' if report=='Yeh 2010' else 'Table 3 PDF p5; IV route p2',
            '2010 explicitly says epidural; 2011 explicitly says IV central venous PCA. '
            'Very similar patients and identical sham mean/SD suggest shared family but not proven. '
            'Different totals/denominators unresolved. Alternative individual estimates only; neither pooled.',
            'HELD_SHARED_FAMILY_ROUTE_CONFLICT')
add('Zhang 2023','Postoperative opioid amount','0–48 h','Author IV morphine equivalents','mg IV MME','TEAS','Sham',922,916,
    'median_IQR',[110,80,110,110,90,110],'Table 1 PDF p5',
    'Medians equal. Does not establish equal means or absence of treatment effect. No mean/SD imputation.')
add('Zhang 2023','Routine opioid PCIA receipt','Postoperative; opioid amount assessed through 48 h','Opioid-containing PCIA','risk ratio','TEAS','Sham',922,916,
    'events',[837,838],'Table 1 PDF p5; PCIA regimen methods',
    'Routine pump receipt, not rescue receipt. Receipt period not separately restated.')
write('additional_source_extraction.csv',raw)

processed=[]
for r in raw:
    if r['report']=='Jin 2023':continue
    if r['statistics']=='graph_mean_SEM':
        d=dict(r);d['statistics']='mean_SD';d['sd_i']=r['sem_i']*math.sqrt(r['n_i']);d['sd_c']=r['sem_c']*math.sqrt(r['n_c']);d['derivation']='Approximate graph SEM multiplied by sqrt(n); no digitization uncertainty in interval.';processed.append(d)
    else: processed.append(dict(r))
for window in ['0–6 h','0–12 h','0–24 h','0–48 h']:
    arms=[r for r in raw if r['report']=='Jin 2023' and r['window']==window]
    n=sum(r['n_i'] for r in arms);mean=sum(r['n_i']*r['mean_i'] for r in arms)/n
    sd=math.sqrt(sum((r['n_i']-1)*r['sd_i']**2+r['n_i']*(r['mean_i']-mean)**2 for r in arms)/(n-1))
    d=dict(arms[0]);d.update(outcome_id=f'JIN-COMBINED-{window}',modality='EA combined',n_i=n,mean_i=mean,sd_i=sd,
                            derivation='Two active frequency arms combined with between-arm variance. Sham used once per period.')
    processed.append(d)
for report,outcome,factor,unit,explanation in [
    ('Ao 2021','PCA solution delivered',.01,'micrograms/kg sufentanil','(1.5 micrograms/kg / 150 mL) times volume; exact if stated individualized formulation delivered.'),
    ('Long 2025','PCA solution delivered',.02,'micrograms/kg sufentanil','(2 micrograms/kg / 100 mL) times volume; exact if stated individualized formulation delivered.'),
    ('Chen 2015','Rescue administrations',2,'mg rescue morphine','2 mg per administration times count; applies to rescue amount, not necessarily all opioid sources.'),
    ('Chen 2015 (Hyperalgesia)','Rescue administrations',.05,'micrograms/kg rescue sufentanil','0.05 micrograms/kg per bolus times count; exact weight-normalized rescue amount.'),
    ('Yao 2015','Rescue administrations',.05,'micrograms/kg rescue sufentanil','0.05 micrograms/kg per bolus times count; exact weight-normalized rescue amount.')]:
    r=next(r for r in raw if r['report']==report and r['outcome']==outcome);d=dict(r)
    d.update(outcome_id=r['outcome_id']+'-NORMALIZED',unit=unit,outcome='Derived '+outcome,derivation=explanation)
    for k in ['mean_i','sd_i','mean_c','sd_c','median_i','q1_i','q3_i','median_c','q1_c','q3_c']:
        if k in d:d[k]*=factor
    processed.append(d)
write('processed_outcomes.csv',processed)

# Reuse previously checked binary extraction, recalculating rather than copying effects.
binary=read(ROOT/'opioid_only_review/forty_report_preview/opioid_receipt_estimates.csv')
for r in binary:
    r.update(outcome_id='PREVIEW-'+r['report'],comparator=r['comparison'],outcome=r['construct'],statistics='events',note=r['source_location'],status='NATIVE_SINGLE_TRIAL')
    for k in ['events_i','events_c','n_i','n_c']:r[k]=int(r[k])
binary += [dict(r) for r in raw if r['statistics']=='events']
estimates=[]
for r in [r for r in processed if r['statistics']=='mean_SD']+binary:
    d={k:r.get(k,'') for k in ['outcome_id','report','trial_id','outcome','window','opioid','unit','modality','comparator','status','note','derivation','source_location','source_pdf','source_sha256']}
    d['n_i']=r['n_i'];d['n_c']=r['n_c']
    if r['statistics']=='events':
        a,c,ni,nc=(r[k] for k in ['events_i','events_c','n_i','n_c'])
        assert 0<a<=ni and 0<c<=nc
        y=math.log((a/ni)/(c/nc));v=1/a-1/ni+1/c-1/nc
        effect=math.exp(y);lo=math.exp(y-norm.ppf(.975)*math.sqrt(v));hi=math.exp(y+norm.ppf(.975)*math.sqrt(v))
        d.update(events_i=a,events_c=c,risk_i=a/ni,risk_c=c/nc,effect_measure='RR',effect=effect,ci_low=lo,ci_high=hi,y=y,variance=v)
    else:
        y=r['mean_i']-r['mean_c'];v=r['sd_i']**2/r['n_i']+r['sd_c']**2/r['n_c'];half=norm.ppf(.975)*math.sqrt(v)
        d.update(effect_measure='MD',effect=y,ci_low=y-half,ci_high=y+half,y=y,variance=v)
    estimates.append(d)
write('individual_estimates.csv',estimates)

def fit(rows,model_id,description):
    y=np.array([r['y'] for r in rows]);v=np.array([r['variance'] for r in rows]);k=len(y)
    assert k>1 and len({r['report'] for r in rows})==k
    def nll(tau):
        w=1/(v+tau);mu=np.sum(w*y)/np.sum(w)
        return .5*(np.sum(np.log(v+tau))+np.log(np.sum(w))+np.sum(w*(y-mu)**2))
    upper=max(1,np.var(y)*10,np.max(v)*10)
    opt=minimize_scalar(nll,bounds=(0,upper),method='bounded',options={'xatol':1e-12})
    tau=float(opt.x if opt.fun<nll(0) else 0)
    w=1/(v+tau);mu=float(np.sum(w*y)/np.sum(w));q=float(np.sum(w*(y-mu)**2)/(k-1))
    se=math.sqrt(max(1,q)/np.sum(w));crit=t.ppf(.975,k-1)
    w0=1/v;C=np.sum(w0)-np.sum(w0*w0)/np.sum(w0)
    return dict(model_id=model_id,description=description,k=k,N=sum(r['n_i']+r['n_c'] for r in rows),
                effect=math.exp(mu),ci_low=math.exp(mu-crit*se),ci_high=math.exp(mu+crit*se),
                log_rr=mu,se_log_rr=se,tau2=tau,I2=100*tau/(tau+(k-1)/C),hk_q=q,
                method='REML on log RR; modified Hartung-Knapp variance floor 1; t CI, k-1 df',
                reports=';'.join(r['report'] for r in rows),status='POST_HOC_EXPLORATORY')
rescue=[r for r in estimates if r['outcome']=='Rescue opioid receipt' and r['modality']=='TEAS' and r['comparator']=='Sham']
assert len(rescue)==5
models=[fit(rescue,'RESCUE_TEAS_SHAM_ANY_FOLLOWUP','Any rescue opioid during each trial reported follow-up; different periods; timing unclear in Yu 2020'),
        fit([r for r in rescue if r['report']!='Yu 2020'],'RESCUE_TEAS_SHAM_KNOWN_PERIODS','Remove Yu 2020 timing-unclear trial; remaining periods still differ'),
        fit([r for r in rescue if r['report'] in ['Tu 2024','Liu 2026 (burn)']],'RESCUE_TEAS_SHAM_FIRST_DAY_APPROX','Approximate first day only: 6–24 h / through POD1; not strict complete 0–24 h'),
        fit([r for r in rescue if r['report'] in ['Tu 2024','Liu 2026 (burn)','Yu 2020']],'RESCUE_TEAS_SHAM_EARLY_PLUS_UNCLEAR','Approximate first day plus Yu 2020 timing-unclear trial')]
write('rescue_model_results.csv',models)
write('rescue_model_inputs.csv',[dict(r,model_id=m['model_id']) for m in models for r in rescue if r['report'] in m['reports'].split(';')])

preview=read(ROOT/'opioid_only_review/forty_report_preview/forty_report_contribution_ledger.csv')
ledger=[]
for r in preview:
    name=r['report'];new=[a for a in raw if a['report']==name];calc=[a for a in estimates if a['report']==name]
    existing='EXISTING_AMOUNT_ESTIMATE' in r['preview_contribution']
    numerical=existing or any(a['statistics']!='qualitative' for a in new) or bool(calc)
    held=[a['status'] for a in calc if 'HELD_' in a['status']]
    ledger.append(dict(report=name,trial_id=r['trial_id'],outcome_category=r['outcome_category'],
                       numerical_result_available='YES' if numerical else 'NO',
                       contribution=('EXISTING_AMOUNT_ANALYSIS; ' if existing else '')+
                       ('NEW_INDIVIDUAL_ESTIMATES; ' if calc else '')+
                       ('MEDIAN_IQR_DESCRIPTION; ' if any(a['statistics']=='median_IQR' for a in new) else '')+
                       ('QUALITATIVE_ONLY' if not numerical else ''),
                       new_raw_rows=len(new),new_individual_estimates=len(calc),
                       remaining_issue='; '.join(sorted({a['note'] for a in new if a['note']})) if new else r['remaining_limitations'],
                       pooling_hold=';'.join(sorted(set(held))),source_pdf=r['source_pdf']))
assert len(ledger)==40
write('forty_report_final_contributions.csv',ledger)
for r in cohort.values():
    assert hashlib.sha256((ROOT/r['source_pdf']).read_bytes()).hexdigest()==r['source_sha256']
counts=dict(reports=40,provisional_trial_families=39,quantity_reports=28,other_opioid_use_reports=12,
            reports_with_numerical_results=sum(r['numerical_result_available']=='YES' for r in ledger),
            qualitative_only_reports=[r['report'] for r in ledger if r['numerical_result_available']=='NO'],
            additional_raw_rows=len(raw),individual_estimate_rows=len(estimates),rescue_any_followup_trials=5,
            source_hashes_checked=40)
(OUT/'analysis_counts.json').write_text(json.dumps(counts,indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,ax=plt.subplots(figsize=(12,6.8));fig.subplots_adjust(left=.39,right=.77,top=.78,bottom=.27)
for i,r in enumerate(rescue):
    y=5-i
    ax.errorbar(r['effect'],y,xerr=[[r['effect']-r['ci_low']],[r['ci_high']-r['effect']]],fmt='o',color='#0f766e',capsize=4)
    ax.text(1.04,y,f"{r['effect']:.2f} ({r['ci_low']:.2f}–{r['ci_high']:.2f})",transform=ax.get_yaxis_transform(),va='center',fontsize=10)
m=models[0]
ax.errorbar(m['effect'],0,xerr=[[m['effect']-m['ci_low']],[m['ci_high']-m['effect']]],fmt='D',color='#1d4ed8',capsize=5,markersize=8)
ax.text(1.04,0,f"{m['effect']:.2f} ({m['ci_low']:.2f}–{m['ci_high']:.2f})",transform=ax.get_yaxis_transform(),va='center',fontsize=10,fontweight='bold')
ax.set_yticks([5,4,3,2,1,0],labels=[f"{r['report']}\n{r['window']}" for r in rescue]+['Exploratory combined result\n5 trials, 478 participants'])
ax.set_xscale('log');ax.set_xlim(.08,2.5);ax.axvline(1,color='#94a3b8',ls='--');ax.set_ylim(-.6,5.6)
ax.set_xticks([.1,.25,.5,1,2],labels=['0.10','0.25','0.50','1.00','2.00'])
ax.set_xlabel('Risk ratio for needing a rescue opioid (95% interval)')
for edge in ['top','right','left']:ax.spines[edge].set_visible(False)
ax.tick_params(axis='y',length=0,pad=12);ax.grid(axis='x',alpha=.12)
fig.suptitle('Fewer patients needed rescue opioids in these TEAS trials',x=.04,ha='left',fontsize=17,fontweight='bold')
fig.text(.04,.86,'TEAS versus sham. Follow-up periods differ; this is not a complete 24-hour endpoint.',fontsize=11,color='#475569')
fig.text(.04,.065,'Below 1 = fewer patients needed a rescue opioid. Bars crossing 1 include no difference.\n'
         'Combined result uses each trial’s reported follow-up. Routine pump receipt is excluded.\n'
         'REML with modified Hartung-Knapp interval. Source tables and qualifications accompany the data.',fontsize=10,color='#475569')
fig.savefig(OUT/'rescue_opioid_results.png',dpi=180);plt.close(fig)
print(json.dumps(counts))
for m in models:print(m['model_id'],m['k'],m['N'],round(m['effect'],5),round(m['ci_low'],5),round(m['ci_high'],5))

# Detailed results are separate from the plain-language report.
lines=['# Additional extracted opioid results','',
       '8 October 2026. Individual calculations for the 40-report scenario. '
       'Different periods, drugs, units and comparators remain separate. '
       'These tables include held/descriptive rows and do not establish eligibility for pooling. '
       'Existing amount models are documented in [the earlier dose display](../BROADER_RESULTS.md).','',
       '## Individual mean differences','',
       'Treatment minus comparator. Negative values mean a lower amount/count; positive values for first-rescue time mean a longer wait. '
       'Intervals are approximate 95% intervals. Graph approximations and held rows are explicitly identified.','',
       '| Report | Comparison | Period | Outcome / unit | Difference (95% interval) | Qualification |',
       '|---|---|---|---|---|---|']
for r in estimates:
    if r['effect_measure']!='MD':continue
    lines.append(f"| {r['report']} | {r['modality']} vs {r['comparator']} | {r['window']} | {r['outcome']}; {r['opioid']}; {r['unit']} | {r['effect']:.3f} ({r['ci_low']:.3f} to {r['ci_high']:.3f}) | {r['status']} |")
lines += ['', '## Medians and interquartile ranges','',
          'Medians describe the middle patient, not the arithmetic mean. No mean/SD or confidence interval is invented. '
          'Derived rows use the stated fixed dose/formulation. Original and derived rows represent the same participants.','',
          '| Report | Period | Outcome / unit | Treatment median (Q1–Q3) | Comparator median (Q1–Q3) |',
          '|---|---|---|---|---|']
for r in processed:
    if r['statistics']!='median_IQR':continue
    lines.append(f"| {r['report']} | {r['window']} | {r['outcome']}; {r['unit']} | {r['median_i']:g} ({r['q1_i']:g}–{r['q3_i']:g}) | {r['median_c']:g} ({r['q1_c']:g}–{r['q3_c']:g}) |")
lines += ['', '## Individual opioid receipt comparisons','',
          'RR below 1 means fewer treatment patients received the opioid. Rescue, routine pump receipt and any-opioid receipt are different constructs. '
          'Do not sum these overlapping comparisons or combine them into a single pool.','',
          '| Report | Comparison | Outcome | Period | Treatment | Comparator | RR (95% interval) |',
          '|---|---|---|---|---:|---:|---|']
for r in estimates:
    if r['effect_measure']!='RR':continue
    lines.append(f"| {r['report']} | {r['modality']} vs {r['comparator']} | {r['outcome']} | {r['window']} | {r['events_i']}/{r['n_i']} | {r['events_c']}/{r['n_c']} | {r['effect']:.3f} ({r['ci_low']:.3f}–{r['ci_high']:.3f}) |")
lines += ['', '## Qualitative evidence','']
for r in raw:
    if r['statistics']=='qualitative':lines.append(f"- **{r['report']}:** {r['note']} Source: {r['source_location']}.")
lines += ['', 'Source values, denominators, page locations, SHA256 and limitations are in '
          '[additional_source_extraction.csv](additional_source_extraction.csv), '
          '[processed_outcomes.csv](processed_outcomes.csv), and '
          '[individual_estimates.csv](individual_estimates.csv). '
          'The [method notes](METHODS_AND_LIMITATIONS.md) explain source conflicts, held rows and graph approximation.']
(OUT/'ADDITIONAL_RESULTS.md').write_text('\n'.join(lines)+'\n')
