"""Evidence contribution map: how each of the 40 included reports contributed to each outcome domain (23 October 2026).

Read-only on all analysis files. Cell codes, in order of precedence:
  P = in a pooled main analysis (two or more trials)        1 = single-trial main estimate
  I = individual estimate in original units, not pooled    S = sensitivity or diagnostic analysis only
  H = held from synthesis                                   Q = qualitative finding only
'Main' means a registered primary or additional analysis. The broader first-day dose column has its own main models,
although the review treats the whole column as a sensitivity analysis.
Writes contribution_map_2026-10-23.csv and contribution_map_2026-10-23.md.
"""
import csv, collections
from pathlib import Path

HERE = Path(__file__).resolve().parent
C = HERE / 'registered_completion_2026_10_09'
RR = HERE / 'reviewer_rerun_2026_10_09'
def read(p): return list(csv.DictReader(p.open(encoding='utf-8-sig', newline='')))

DOMAINS = ['Primary 24-h opioid', 'Broader first-day dose', 'Rescue opioid receipt', 'Other opioid / analgesic',
           'Pain', 'Nausea and vomiting', 'Quality of recovery', 'GI recovery', 'Mobility, stay, satisfaction', 'Harms']
RANK = {'P': 6, '1': 5, 'I': 4, 'S': 3, 'H': 2, 'Q': 1, '': 0}
reports = [r['report'] for r in read(HERE / 'forty_report_final_contributions.csv')]
assert len(reports) == 40
cell = {(r, d): '' for r in reports for d in DOMAINS}
def mark(report, domain, code):
    assert report in reports, report
    if RANK[code] > RANK[cell[(report, domain)]]: cell[(report, domain)] = code

# --- reviewer rerun: primary, broader dose, other opioid, rescue -------------------------------------------------
rk = {r['model_id']: int(r['k']) for r in read(RR / 'model_results.csv')}
rin = read(RR / 'model_inputs.csv')
PRIMARY = {'opioid24_TEAS_sham', 'opioid24_TEAS_usual', 'opioid24_EA_usual'}
E2MAIN = {'E2_opioid24_TEAS_sham', 'E2_opioid24_TEAS_usual', 'E2_opioid24_EA_sham', 'E2_opioid24_EA_usual'}
OTHER_MAIN = ('opioid48_EA_usual_PCA', 'opioid72_EA_sham_PCA', 'opioid72_EA_usual_PCA', 'opioid_partial_',
              'pethidine24_', 'tramadol24_')
OTHER_NATIVE = ('opioid24_EA_sham_weight_normalized', 'opioid24_EA_sham_fentanyl_per_kg')
for r in rin:
    m, rep = r['model_id'], r.get('report') or r['study']
    main_code = 'P' if rk.get(m, 0) >= 2 else '1'
    if m in PRIMARY: mark(rep, 'Primary 24-h opioid', main_code)
    elif m.startswith('opioid24_') and m.startswith(OTHER_NATIVE): mark(rep, 'Other opioid / analgesic', 'I')
    elif m.startswith('opioid24_'): mark(rep, 'Primary 24-h opioid', 'S')
    elif m in E2MAIN: mark(rep, 'Broader first-day dose', main_code)
    elif m.startswith('E2_'): mark(rep, 'Broader first-day dose', 'S')
    elif m == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP': mark(rep, 'Rescue opioid receipt', 'P')
    elif m.startswith('RESCUE_'): mark(rep, 'Rescue opioid receipt', 'S')
    elif m.startswith(OTHER_MAIN): mark(rep, 'Other opioid / analgesic', main_code)
    elif m.startswith('opioid48_TEAS_sham_uncertain'): mark(rep, 'Other opioid / analgesic', 'S')
    else: raise ValueError('unmapped rerun model ' + m)
# EA rescue receipt (Xie 2014), graded as single-trial bodies in the rescue certainty profile
for g in read(HERE / 'certainty_and_manuscript/grade_rescue_evidence_profile.csv'):
    if g['outcome_comparison'].startswith('EA/'): mark(g['reports'], 'Rescue opioid receipt', '1')

# --- individual estimates in original units ---------------------------------------------------------------------
for e in read(HERE / 'individual_estimates.csv'):
    # classify by the outcome name only: notes such as 'routine pump receipt, not rescue' must not count as rescue
    dom = 'Rescue opioid receipt' if e['outcome'].lower().startswith('rescue opioid receipt') else 'Other opioid / analgesic'
    mark(e['report'], dom, 'I')

# --- completion: pain, nausea/vomiting, recovery, harms -----------------------------------------------------------
spec = {s['model_id']: s for s in read(C / 'model_specs.csv')}
ck = {r['model_id']: int(float(r['k'] or 0)) for r in read(C / 'model_results_python.csv')}
def domain_of(fam, outcome):
    f = (fam + ' ' + outcome).lower()
    if 'quality_of_recovery' in f or 'qor' in f: return 'Quality of recovery'
    if any(k in f for k in ['ponv', 'nausea', 'vomit']): return 'Nausea and vomiting'
    if 'pain' in f or 'mmse' in f: return 'Pain'
    if any(k in f for k in ['flatus', 'defecation', 'bowel', 'gi_recovery', 'distention', 'drain', 'liquid', 'solid', 'diet']): return 'GI recovery'
    if any(k in f for k in ['functional', 'length_of_stay', 'satisfaction', 'ambulation', 'mobil', 'walk', 'hospital', 'stay', 'discharge', 'extubation']): return 'Mobility, stay, satisfaction'
    if any(k in f for k in ['harm', 'adverse', 'complication', 'rubefaction', 'hydroderma', 'hypotension', 'hypertension',
                            'tachycardia', 'hypoxemia', 'headache', 'delirious', 'death', 'bleed', 'allcause', 'urinary']): return 'Harms'
    if any(k in f for k in ['intraop', 'remifentanil', 'alfentanil', 'sufentanil', 'opioid', 'rescue']): return 'Other opioid / analgesic'
    return None
unmapped = collections.Counter()
for r in read(C / 'model_inputs.csv'):
    s = spec[r['model_id']]; dom = domain_of(s['family'], r.get('outcome', '') + ' ' + r['model_id'])
    if dom is None: unmapped[(s['family'], r['model_id'])] += 1; continue
    role = s['role']
    code = ('P' if ck.get(r['model_id'], 0) >= 2 else '1') if role == 'ADDITIONAL' else ('H' if role == 'HELD' else 'S')
    mark(r['study'], dom, code)
assert not unmapped, unmapped

# --- author decision 23 October 2026: Lee 2011 (ages 14-59) held from all pooled analyses ------------------------
for d in DOMAINS:
    if cell[('Lee 2011', d)] == 'P': cell[('Lee 2011', d)] = 'H'

# --- qualitative-only reports ---------------------------------------------------------------------------------------
for f in read(HERE / 'forty_report_final_contributions.csv'):
    if f['contribution'].startswith('QUALITATIVE_ONLY'): mark(f['report'], 'Other opioid / analgesic', 'Q')

# --- outputs --------------------------------------------------------------------------------------------------------
chars = {c['report']: c for c in read(RR / 'forty_report_characteristics.csv')}
rows = []
for rep in reports:
    c = chars[rep]
    rows.append(dict(report=rep, modality=c['modality'], comparator='Sham' if c['comparator'].startswith('Sham') else 'Usual care',
                     country=c['country'], **{d: cell[(rep, d)] for d in DOMAINS},
                     main_domains=sum(cell[(rep, d)] in ('P', '1') for d in DOMAINS)))
order = {'TEAS': 0, 'EA': 1, 'UNCLEAR': 2}
rows.sort(key=lambda r: (order[r['modality']], -r['main_domains'], r['report']))
with (HERE / 'contribution_map_2026-10-23.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)
summary = {d: collections.Counter(r[d] for r in rows) for d in DOMAINS}
md = ['| Report | Modality | ' + ' | '.join(DOMAINS) + ' |', '|' + '---|' * (len(DOMAINS) + 2)]
md += ['| ' + r['report'] + ' | ' + r['modality'] + ' | ' + ' | '.join(r[d] or '–' for d in DOMAINS) + ' |' for r in rows]
md += ['| **Reports in a main analysis (P or 1)** | | ' + ' | '.join(str(summary[d]['P'] + summary[d]['1']) for d in DOMAINS) + ' |']
(HERE / 'contribution_map_2026-10-23.md').write_text('\n'.join(md) + '\n')
print('\n'.join(md))
print('\nReports with no main-analysis contribution:', [r['report'] for r in rows if r['main_domains'] == 0])
print('Distribution of main domains per report:', collections.Counter(r['main_domains'] for r in rows))
