"""Risk-of-bias figure (RoB 2 traffic-light plot plus domain summary), 23 October 2026.

Panel A: result-specific RoB 2 judgements for the key analyses: the broader first-day opioid analyses (which include
the three primary-outcome trials), rescue opioid receipt, and composite PONV over 0-24 h for TEAS versus sham.
Panel B: domain-level distribution across all 152 assessed results used in the analyses.
Read-only on all assessment files. Writes rob_key_analyses_2026-10-23.csv and rob_domain_summary_2026-10-23.csv
(Python 3 standard library), and renders rob_figure_2026-10-23.pdf/.png when run with the bundled Python with reportlab:
  ~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 build_rob_figure_2026_10_23.py
"""
import csv, collections, subprocess, shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
C = HERE / 'registered_completion_2026_10_09'
R = HERE / 'reviewer_rerun_2026_10_09'
def read(p): return list(csv.DictReader(Path(p).open(encoding='utf-8-sig', newline='')))

link = {r['result_id']: r for r in read(ROOT / 'FINAL_RESULT_ROB2_LINKAGE.csv')}
dom = {}
for f in [ROOT / '10_FINAL_ADJUDICATION/08_QOR_ANALYSIS/qor_rob2.csv', ROOT / '10_FINAL_ADJUDICATION/08_QOR_ANALYSIS/qor_rob2_later.csv',
          C / 'provisional_new_rob2_domains.csv']:
    for r in read(f): dom[r['result_id']] = r
units = {}
def add(key, study, r, analysis):
    d = [r[f'd{i}'] for i in range(1, 6)]
    assert all(d) and r['overall'] in ('Low', 'Some concerns', 'High'), key
    units[key] = dict(study=study, d=d, overall=r['overall'], analysis=analysis)
for b in read(C / 'completion_bias_links.csv'):
    if not b['overall'].startswith('UNLINKED'):
        add(b['result_id'], b['study'], dom.get(b['result_id']) or link[b['result_id']], b['model_id'])
for s in read(C / 'supplement_rob2_domains_2026-10-23.csv'): add(s['result_id'], s['study'], s, 'sensitivity')
for s in read(HERE / 'certainty_and_manuscript/rob2_rescue_assessments.csv'): add(s['assessment_id'], s['report'], s, 'rescue')
dose_sup = {s['result_id']: s for s in read(R / 'dose_rob2_supplement_2026-10-23.csv')}
for d in read(R / 'dose_bias_linkage.csv'):
    if d['report'] == 'Lee 2011': continue  # held from all pooled analyses (author decision 23 October 2026)
    first = d['result_ids'].split('+')[0]
    src = dose_sup.get(first) or (link[first] if d['outcome_specific_rob'] in ('Low', 'Some concerns', 'High') else None)
    assert src is not None, d['result_ids']
    add(d['result_ids'], d['report'], src, d['model_id'])
assert len(units) == 152, len(units)  # Lin 2002 arm contrasts are one combined result; Lee 2011 dose result held
# Second-reviewed revisions (24 Oct 2026: Chen 2020 D3, after an external check of Fig 1). V33-OD-0014's home record is
# the canonical v38 linkage, which this layer does not edit, so the revision is applied here.
for rv in read(C / 'rob2_revisions_2026-10-24.csv'):
    u = units[rv['result_id']]
    assert u['d'][2] == rv['d3_previous'] or u['d'][2] == rv['d3'], rv['result_id']
    u['d'] = [rv[f'd{i}'] for i in range(1, 6)]
    assert u['overall'] == rv['overall'], rv['result_id']

# ---- panel A rows ---------------------------------------------------------------------------------------------
PRIMARY = {('E2_opioid24_TEAS_sham', 'Szmit 2021'), ('E2_opioid24_TEAS_usual', 'Szmit 2021'),
           ('E2_opioid24_EA_usual', 'El-Rakshy 2009'), ('E2_opioid24_EA_usual', 'Seevaunnamtum 2016')}
LABEL = {'E2_opioid24_TEAS_sham': 'TEAS vs sham', 'E2_opioid24_TEAS_usual': 'TEAS vs usual care',
         'E2_opioid24_EA_sham': 'EA vs sham', 'E2_opioid24_EA_usual': 'EA vs usual care'}
panel = []
for key, u in units.items():
    if u['analysis'] in LABEL:
        panel.append(dict(group='First-day opioid consumption', comparison=LABEL[u['analysis']], study=u['study'] + (' *' if (u['analysis'], u['study']) in PRIMARY else ''), **{f'd{i+1}': u['d'][i] for i in range(5)}, overall=u['overall']))
for s in read(HERE / 'certainty_and_manuscript/rob2_rescue_assessments.csv'):
    u = units[s['assessment_id']]
    panel.append(dict(group='Rescue opioid receipt', comparison=('EA vs ' + s['comparison'].lower()) if s['report'] == 'Xie 2014' else 'TEAS vs sham',
                      study=u['study'], **{f'd{i+1}': u['d'][i] for i in range(5)}, overall=u['overall']))
ponv_ids = [b['result_id'] for b in read(C / 'completion_bias_links.csv') if b['model_id'] == 'ponv24_TEAS_sham']
assert len(ponv_ids) == 9 and all(i in units for i in ponv_ids)  # membership from the model's own links, not unit labels
for key in ponv_ids:
    u = units[key]
    if True:
        panel.append(dict(group='Nausea and vomiting, 0-24 h', comparison='TEAS vs sham', study=u['study'], **{f'd{i+1}': u['d'][i] for i in range(5)}, overall=u['overall']))
GORDER = ['First-day opioid consumption', 'Rescue opioid receipt', 'Nausea and vomiting, 0-24 h']
CORDER = ['TEAS vs sham', 'TEAS vs usual care', 'EA vs sham', 'EA vs usual care']
panel.sort(key=lambda r: (GORDER.index(r['group']), CORDER.index(r['comparison']), r['study']))
with (HERE / 'rob_key_analyses_2026-10-23.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, list(panel[0])); w.writeheader(); w.writerows(panel)
LEVELS = ['Low', 'Some concerns', 'High']
summ = []
for i, name in enumerate(['D1 Randomisation process', 'D2 Deviations from intended interventions', 'D3 Missing outcome data',
                          'D4 Measurement of the outcome', 'D5 Selection of the reported result', 'Overall']):
    c = collections.Counter(u['d'][i] if i < 5 else u['overall'] for u in units.values())
    summ.append(dict(domain=name, **{l: c[l] for l in LEVELS}))
with (HERE / 'rob_domain_summary_2026-10-23.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, list(summ[0])); w.writeheader(); w.writerows(summ)
assert len(panel) == 28, len(panel)
print(len(panel), 'panel rows;', summ)

# ---- figure (needs reportlab) ---------------------------------------------------------------------------------
try:
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor
    from reportlab.pdfbase.pdfmetrics import stringWidth
except ImportError:
    raise SystemExit('reportlab not available: CSVs written, figure not rendered')
COL = {'Low': '#2e8b57', 'Some concerns': '#e0a800', 'High': '#c0392b'}
SYM = {'Low': '+', 'Some concerns': '–', 'High': '×'}
F, B, FS = 'Helvetica', 'Helvetica-Bold', 7.6
X0, STW, CMW, CW, RH = 14, 140, 92, 30, 12.4
W = X0 + STW + CMW + CW * 6 + 20
heads = ['D1', 'D2', 'D3', 'D4', 'D5', 'Overall']
groups = [(g, [r for r in panel if r['group'] == g]) for g in GORDER]
H = 40 + sum(len(rs) + 1 for _, rs in groups) * RH + 250
out = HERE / 'rob_figure_2026-10-23.pdf'
cv = canvas.Canvas(str(out), pagesize=(W, H)); Y = lambda y: H - y
ink = HexColor('#1f2933')
cv.setFillColor(ink); cv.setFont(B, 9); cv.drawString(X0, Y(16), 'A  Key analyses: result-specific judgements')
cv.setFont(B, FS)
cv.drawString(X0, Y(34), 'Trial'); cv.drawString(X0 + STW, Y(34), 'Comparison')
for i, h in enumerate(heads): cv.drawCentredString(X0 + STW + CMW + CW * i + CW / 2, Y(34), h)
y = 40
def dot(cx, cy, level):
    cv.setFillColor(HexColor(COL[level])); cv.circle(cx, Y(cy), 4.6, stroke=0, fill=1)
    cv.setFillColor(HexColor('#ffffff')); cv.setFont(B, 7.4); cv.drawCentredString(cx, Y(cy) - 2.5, SYM[level])
for g, rs in groups:
    cv.setFillColor(HexColor('#e4e9ef')); cv.rect(X0, Y(y + RH), W - X0 - 20, RH, stroke=0, fill=1)
    cv.setFillColor(ink); cv.setFont(B, FS); cv.drawString(X0 + 3, Y(y + RH - 3.4), g); y += RH
    for r in rs:
        cv.setFillColor(ink); cv.setFont(F, FS)
        cv.drawString(X0 + 3, Y(y + RH - 3.4), r['study']); cv.drawString(X0 + STW, Y(y + RH - 3.4), r['comparison'])
        for i, k in enumerate(['d1', 'd2', 'd3', 'd4', 'd5', 'overall']):
            dot(X0 + STW + CMW + CW * i + CW / 2, y + RH / 2, r[k])
        y += RH
cv.setFillColor(ink); cv.setFont(F, 6.8)
cv.drawString(X0, Y(y + 11), '* Also contributes to the primary 0-24-h analysis. D1 randomisation process; D2 deviations from intended interventions;')
cv.drawString(X0, Y(y + 20), 'D3 missing outcome data; D4 measurement of the outcome; D5 selection of the reported result.')
y += 40
cv.setFont(B, 9); cv.drawString(X0, Y(y), f'B  All {len(units)} assessed results, by domain'); y += 12
BX, BW, BH = X0 + 170, W - X0 - 20 - 170, 13
for s in summ:
    tot = sum(s[l] for l in LEVELS); x = BX
    cv.setFillColor(ink); cv.setFont(B if s['domain'] == 'Overall' else F, FS); cv.drawString(X0, Y(y + BH - 3.6), s['domain'])
    for l in LEVELS:
        wseg = BW * s[l] / tot
        if wseg > 0:
            cv.setFillColor(HexColor(COL[l])); cv.rect(x, Y(y + BH), wseg, BH, stroke=0, fill=1)
            if wseg > 18:
                cv.setFillColor(HexColor('#ffffff')); cv.setFont(B, 6.8); cv.drawCentredString(x + wseg / 2, Y(y + BH - 3.8), str(s[l]))
        x += wseg
    y += BH + 5
y += 8; kx = BX
for l in LEVELS:
    dot(kx + 5, y, l); cv.setFillColor(ink); cv.setFont(F, 7); cv.drawString(kx + 13, Y(y) - 2.4, l + ' risk' if l != 'Some concerns' else l)
    kx += 26 + stringWidth(l + ' risk', F, 7) + 12
cv.showPage(); cv.save()
png = HERE / 'rob_figure_2026-10-23.png'
if shutil.which('qlmanage'):
    tmp = HERE / '_ql'; tmp.mkdir(exist_ok=True)
    subprocess.run(['qlmanage', '-t', '-s', '2200', '-o', str(tmp), str(out)], check=True, capture_output=True)
    (tmp / (out.name + '.png')).replace(png); tmp.rmdir()
print(out.name, png.name)
