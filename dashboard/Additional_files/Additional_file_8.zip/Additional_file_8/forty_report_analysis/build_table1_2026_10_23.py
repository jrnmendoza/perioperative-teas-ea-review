"""Table 1 (characteristics of included reports), generated from the second-reviewed characteristics files (23 October 2026).

Inputs (read-only): registered_completion_2026_10_09/protocol_characteristics.csv,
reviewer_rerun_2026_10_09/forty_report_characteristics.csv.
Outputs: ../../manuscript/TABLE1_DRAFT_2026-10-23.md and .csv, plus table1_review_flags_2026-10-23.csv listing every row
where condensing dropped information, for checking by hand.
"""
import csv, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1] / 'manuscript'
def read(p): return list(csv.DictReader(p.open(encoding='utf-8-sig', newline='')))
P = read(HERE / 'registered_completion_2026_10_09/protocol_characteristics.csv')
C = {c['report']: c for c in read(HERE / 'reviewer_rerun_2026_10_09/forty_report_characteristics.csv')}
assert len(P) == 40 and set(p['report_id'] for p in P) == set(C)

flags = []
CODE = re.compile(r'\b(?:LI|PC|ST|SP|HT|GV|CV|BL|GB|LR|KI|SJ|TE|SI|LU|DU|RN)\s?\d{1,2}\b|\bEX-[A-Z]+\d*\b', re.I)
def acupoints(s, rep):
    codes = list(dict.fromkeys(c.upper().replace(' ', '') for c in CODE.findall(s)))
    if not codes:
        flags.append((rep, 'acupoints', s)); return s
    extra = re.sub(CODE, '', s)
    if re.search(r'[A-Za-z]{4,}', re.sub(r'(?i)bilateral|ipsilateral|contralateral|unilateral|and|points?|acupoints?|zusanli|neiguan|hegu|sanyinjiao|needle|EA|TEAS|\(|\)', '', extra)):
        flags.append((rep, 'acupoints (codes kept; other text dropped)', s))
    side = 'Bilateral ' if re.search(r'(?i)bilateral', s) else ''
    return side + ', '.join(codes)
def frequency(s, rep):
    m = re.findall(r'\d+(?:\.\d+)?(?:\s?/\s?\d+(?:\.\d+)?)?\s?Hz', s)
    if not m:
        flags.append((rep, 'frequency', s)); return s or 'NR'
    return '; '.join(dict.fromkeys(x.replace(' ', '').replace('Hz', ' Hz') for x in m))
def phases(s):
    t = s.lower(); out = []
    if re.search(r'pre-?operative|before (induction|anaesth|anesth|surgery)|preinduction|pre-induction', t): out.append('Pre')
    if re.search(r'intra-?operative|during (surgery|the operation)|from induction|until the end of (the )?(surgery|operation)|to end of surgery|throughout surgery', t): out.append('Intra')
    if re.search(r'post-?operative|pacu|recovery|pod ?\d|after surgery|postop', t): out.append('Post')
    return ' + '.join(out)
def timing(p, rep):
    ph = phases(p['timing'])
    if not ph: flags.append((rep, 'timing', p['timing']))
    n = re.match(r'\s*(\d+)', p['sessions'] or '')
    dur = re.match(r'\s*(\d+\s?min)', p['session_duration'] or '')
    tail = (n.group(1) + ' × ' if n else '') + (dur.group(1) if dur else (p['session_duration'][:30] if p['session_duration'] else ''))
    if not n or not dur: flags.append((rep, 'sessions/duration', f"{p['sessions']} | {p['session_duration']}"))
    return f'{ph or p["timing"][:40]}; {tail}'.strip('; ')
def comparator(p):
    arms = (p['control_arms'] + ' ' + p['comparator']).lower()
    has_sham = 'sham' in arms or 'no current' in arms or 'placebo' in arms
    has_uc = bool(re.search(r'usual|no (acupuncture|stimulation|treatment|intervention)|control group|standard care|routine', arms)) and \
             ('|' in p['control_arms'] or not has_sham)
    return 'Sham; usual care' if has_sham and has_uc else ('Sham' if has_sham else 'Usual care')
def n_text(p):
    a = re.sub(r'\s*/\s*', '/', p['analysed_n'].replace(' vs ', '/'))
    return f"{p['randomized_n']} ({a})"

# Manual condensations, checked against the source text in protocol_characteristics.csv (23 October 2026).
# Each replaces an automatic condensation that was truncated, lost an arm or phase, or was inconsistently formatted.
OVR = {
 'timing': {
  'An 2014': 'Intra; 1, induction to end of surgery', 'He 2026 (hepatectomy/JIS)': 'Intra; 1, induction to end of surgery',
  'El-Rakshy 2009': 'Intra; 1, duration of surgery', 'Seevaunnamtum 2016': 'Intra; 1, duration of surgery',
  'Chen 1998': 'Post; self-applied every 2–3 h × 30 min', 'Szmit 2021': 'Post; 30 min every 2 h to 24 h',
  'Gu 2019': 'Pre + Intra + Post; 1 continuous + 6 × 30 min', 'Jiang 2026': 'Pre + Intra; 1 continuous to end of surgery',
  'Xie 2014': 'Pre + Intra; 1 continuous to end of surgery', 'Zhang 2025': 'Pre + Intra; 1 continuous to end of surgery',
  'Liu 2026 (ESD)': 'Pre + Intra; 1 continuous to end of procedure', 'Zhang 2023': 'Pre + Intra + Post; 1 continuous to 45 min after surgery',
  'Xiong 2021': 'Pre + Intra + Post; 1 continuous + 2 postoperative (duration NR)', 'Jin 2023': 'Post; 4 (6, 12, 24, 48 h), duration NR',
  'Ng 2013': 'Post; up to 4 × 20 min (daily)', 'Wu 2016': 'Pre + Post; 6 × 30 min', 'Yeh 2010': 'Pre + Post; 3 × 20 min',
  'Ntritsou 2014': 'Intra + Post; 2 × 30 min', 'Sim 2002': 'Pre or Post (separate arms); 1 × 45 min',
  'Chen 2020': 'Pre + Intra + Post; 1 continuous + 4 × 30 min'},  # 30 min pre-induction, continuous intraoperative, 30 min at 6, 24, 48 h (PDF p2); added 24 Oct 2026
 'frequency': {
  'Lee 2011': '100 Hz or 3/10/20 Hz (two arms)', 'Lin 2002': '2 Hz or 100 Hz (two arms)', 'Jin 2023': '2 Hz or 20/100 Hz (two arms)',
  'Wu 2025': '2/10 Hz', 'Zhou 2021': '20/100 Hz', 'Ntritsou 2014': '100 Hz intra; 4 Hz post', 'Sim 2002': '2 Hz (acupoints); 100 Hz (incision)'},
 'n': {'Wu 2025': '100 (50/50)', 'Oztas 2019': '48 (15/16)', 'El-Rakshy 2009': '107 (42/53)', 'Grech 2016': '20 (9/9)',
       'Yeh 2010': '99 (33/30)', 'Lin 2002': '100 (25 per arm)', 'Long 2025': '60 (27/26)'},
 'comparator': {'Szmit 2021': 'Sham; usual care', 'Lin 2002': 'Sham; usual care', 'Yeh 2010': 'Sham; usual care',
                'Oztas 2019': 'Active TENS; usual care', 'Chen 1998': 'Sham; active TENS'},
 'acupoints': {'Szmit 2021': 'Bilateral LI4 + 2 peri-incisional points', 'Sim 2002': 'Bilateral ST36, PC6 + incision-line needles',
               'El-Rakshy 2009': 'Operation-specific (GV2, GV4, BL23, BL32, LI4, PC6; or LR3, SP6, LI4, PC6)'},
 'surgery': {'Wu 2016': 'Thoracic & Cardiac'},  # lung-cancer thoracotomy, Wu 2016 PDF p4 Table 1
}
def age_text(s, rep):
    """Arm means (or medians, marked ‡) in report order; whole-trial value where only that is reported."""
    if not s.strip():
        return 'NR'
    if rep == 'Lee 2011':
        return '42.0 (range 14–59)'
    vals = re.findall(r'(\d{2}(?:\.\d+)?)\s*(?:±|\()', s)
    if not vals:
        flags.append((rep, 'age', s)); return s[:30]
    med = '‡' if 'median' in s.lower() else ''
    return '/'.join(str(int(float(v) + 0.5)) for v in vals[:4]) + med  # round half up
def female_text(s, rep):
    low = s.lower()
    if low.startswith('all female'): return '100'
    if 'all male' in low: return '0'
    fr = [(int(a), int(b)) for a, b in re.findall(r'(\d+)\s*/\s*(\d+)', s)]
    if not fr:
        flags.append((rep, 'female', s)); return 'NR'
    return str(int(100 * sum(a for a, _ in fr) / sum(b for _, b in fr) + 0.5))
SMMA = {r['report']: r for r in read(HERE / 'setting_mma_2026-10-24.csv')}
SET_SHORT = {'Tertiary (stated)': 'Tertiary', 'Multicentre (level not stated)': 'Multicentre',
             'University or university-affiliated hospital': 'University', 'Named hospital, level not stated': 'Hospital',
             'Site not stated (affiliation only)': 'NS'}
MMA_SHORT = {'Yes': 'Yes', 'Conditional': 'Cond.', 'No': 'No', 'Not reported': 'NR'}
ORDER = {'TEAS': 0, 'EA': 1, 'UNCLEAR': 2}
rows = []
for p in P:
    rep = p['report_id']; c = C[rep]
    g = lambda k, f: OVR[k].get(rep) or f()
    rows.append({'Study': rep, 'Country': c['country'], 'Setting': SET_SHORT[SMMA[rep]['setting']], 'Surgery': g('surgery', lambda: p['surgical_category']),
                 'N randomised (analysed)': g('n', lambda: n_text(p)), 'Age, y': age_text(p['age'], rep), 'Female, %': female_text(p['female'], rep), 'Modality': p['modality'] if p['modality'] != 'UNCLEAR' else 'Unclear',
                 'Comparator': g('comparator', lambda: comparator(p)), 'Acupoints': g('acupoints', lambda: acupoints(p['acupoints'], rep)),
                 'Frequency': g('frequency', lambda: frequency(p['frequency'], rep)), 'Timing; sessions': g('timing', lambda: timing(p, rep)), 'MMA': MMA_SHORT[SMMA[rep]['mma_all_groups']]})
rows.sort(key=lambda r: (ORDER[r['Modality'].upper()], r['Study']))
cols = list(rows[0])
with (OUT / 'TABLE1_DRAFT_2026-10-23.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, cols); w.writeheader(); w.writerows(rows)
md = ['**Table 1. Characteristics of the included reports**', '',
      '| ' + ' | '.join(cols) + ' |', '|' + '---|' * len(cols)]
md += ['| ' + ' | '.join(r[c] for c in cols) + ' |' for r in rows]
md += ['', 'Setting as stated in the report: Tertiary, stated tertiary hospital(s); Multicentre, level not stated; University, university or university-affiliated hospital; Hospital, other named hospital; NS, trial site not stated. MMA, routine multimodal analgesia in all groups (a non-opioid analgesic or regional/local technique by protocol; rescue drugs not counted); Cond., non-opioid only within a PCIA used if needed. '
       'N, number randomised (analysed in intervention/control arms as reported). Age: mean by arm in report order; ‡ median. Female: percentage of analysed participants. Acupoints use WHO standard codes. '
       'Frequency: a/b Hz denotes alternating (dense-disperse) stimulation. Timing: Pre, preoperative; Intra, intraoperative; '
       'Post, postoperative; sessions × duration where reported. EA, electroacupuncture; NR, not reported; TEAS, transcutaneous '
       'electrical acupoint stimulation. Full characteristics are in Additional file 10.']
(OUT / 'TABLE1_DRAFT_2026-10-23.md').write_text('\n'.join(md) + '\n')
with (HERE / 'table1_review_flags_2026-10-23.csv').open('w', newline='') as f:
    w = csv.writer(f); w.writerow(['report', 'field', 'source_text']); w.writerows(flags)
unresolved = [fl for fl in flags if not any(fl[0] in OVR[k] for k in OVR)]
print(len(rows), 'rows;', len(flags), 'condensing flags;', len(unresolved), 'without an override (codes kept as shown):')
for fl in unresolved: print(' ', fl[0], '|', fl[1], '|', fl[2][:110])
