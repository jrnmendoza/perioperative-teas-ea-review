"""Outcome-specific rescue RoB 2 records and additional, post-hoc robustness checks.
Manual source-informed judgments, not a validated RoB 2 algorithm. No canonical writes.
Run with /tmp/teas-broad-opioid-plot/bin/python.
"""
import csv, json, math, hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm, t

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATE = '2026-10-08'
def read(path):
    with path.open(newline='') as f: return list(csv.DictReader(f))
def write(name, rows):
    with (HERE/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
        w.writeheader();w.writerows(rows)

inventory = {r['report']:r for r in read(ROOT/'opioid_only_review/source_audit/source_inventory.csv')}
inputs=read(HERE.parent/'rescue_model_inputs.csv')
main=[r for r in inputs if r['model_id']=='RESCUE_TEAS_SHAM_ANY_FOLLOWUP']
assert len(main)==5
Q={r['question_id']:r['short_question'] for r in read(ROOT/'10_FINAL_ADJUDICATION/02_DECISIONS/v38/rob2_signalling_questions.csv')[:22]}

# Domain rationales reflect this opioid-receipt result, rather than pain/PONV ratings.
records=[
('Tu 2024','Sham','6–24 h',
 ['Low','Low','High','Low','Some concerns'],
 ['Computer sequence and sealed opaque sequential envelopes; no clear baseline evidence of randomization failure.',
  'Participant, clinical and observer masking reported; common rescue rule. No evidence of trial-context departures affecting receipt. Missing complete-case outcomes assessed in D3.',
  '120 randomized; 57/58 analyzed. Three active omissions: cognitive impairment (1), persistent coma (2); two sham omissions: intracranial-hypertension vomiting (1), coma (1). Neurological complications plausibly determine pain reporting and receipt; no outcome-specific missing-data correction. Only nine observed rescue events, making these omissions consequential.',
  'Tramadol receipt is a recorded medication event; identical VAS-triggered rescue rule and masked observers/clinical care reported. Table 4 specifies 6–24 h, not complete 0–24 h.',
  '2013 protocol names PONV-related endpoints and rescue antiemetics, without an explicit tramadol-receipt analysis. Exact prospective opioid analysis not verified. No direct evidence establishing result-based selection.'],
 'PDF pp2–3 randomization/masking/flow; Table 4 p5; 2013 protocol',
 'https://link.springer.com/article/10.1186/1745-6215-14-153'),
('Liu 2026 (burn)','Sham','Through POD1',
 ['Low','Low','Low','Low','Some concerns'],
 ['Computer sequence and independently prepared opaque envelopes; source flow supports 88 randomized, not 102 (screened).',
  'Credible sensation-producing sham; patients, anesthetists, collectors and analysts masked. Shared PCA and rescue regimen; no material trial-context departure identified.',
  '44/44 randomized; 43/43 analyzed after one skin-intolerance withdrawal per arm. Small balanced loss for an intervention-site reaction, without evidence of relationship to postoperative rescue receipt.',
  'Identical rescue threshold (FVAS >50 or unrelieved pain after repeated pump presses), fixed 5 mg IM dezocine; masked clinical team and recorded receipt. POD1 is not an explicitly elapsed complete 24-hour window.',
  'Authors explicitly describe retrospective registration in December 2023. Prospective analysis of this binary POD1 result not verified. Retrospective registration alone does not prove selective reporting.'],
 'PDF pp2–5 methods; flow p6; Table 2 p7',
 'Main report: retrospective registration stated; original time-stamped SAP not available'),
('Yu 2020','Sham','Postoperative follow-up; exact rescue period unspecified',
 ['Some concerns','Low','Low','Low','Some concerns'],
 ['Computer randomization by a nurse reported, but an adequately concealed allocation mechanism not sufficiently described.',
  'Patients, clinical team and outcome collector reported masked; acupuncturist aware. No evidence of a trial-context departure affecting rescue use.',
  'All 60 randomized patients included, with 30 per arm and no reported missing rescue outcomes.',
  'Sufentanil rescue receipt recorded under common postoperative care, with masked collector and clinical team. Unspecified window affects review grouping, not evidence of differential measurement.',
  'NCT02619578 first submitted November 2015 after trial completion November 2014. Registry lists postoperative pain-medication incidence with a one-year timeframe; it does not verify this exact short-window analysis. No direct evidence of result-based selection.'],
 'PDF pp2–4 methods; Table 3 p7; ClinicalTrials.gov API',
 'https://clinicaltrials.gov/study/NCT02619578'),
('Liu 2026 (ESD)','Sham','Through 48 h',
 ['Low','Low','High','Low','Some concerns'],
 ['Computer block randomization and opaque envelope allocation reported; no clear baseline evidence of failure.',
  'Anesthetist/acupuncturist aware; patients, surgeons and follow-up physicians masked. Shared postoperative morphine rule; no evidence that provider awareness generated outcome-affecting trial-context deviations. Missing outcomes addressed in D3.',
  '129 randomized (64/65), but 58/62 analyzed. Exclusions include conversion to laparotomy (1 each arm), postoperative bleeding (2 active/1 sham) and consent withdrawal (3 active/1 sham). Surgical complications likely influence opioid needs; no valid binary-outcome adjustment supplied. Complete-case exclusion threatens assignment-effect estimate.',
  'Same 1 mg IV morphine rule (NRS >=4 or patient request); masked follow-up physicians and recorded medication receipt. Unmasked intraoperative operators do not alone establish biased postoperative measurement.',
  '2023 published protocol and its registration-summary supplement mention morphine consumption, but not the exact binary-recipient analysis. Protocol publication followed recruitment onset; original registry history/SAP not verified. Supplement says first enrollment March 2022, while main report/protocol narrative indicate December 2021. No proof of result-based selective reporting.'],
 'PDF pp2–4 methods/flow; Table 2 p5; protocol and registration-summary supplement',
 'https://link.springer.com/article/10.1186/s12906-023-04075-9'),
('Zhou 2025','Sham','First 3 postoperative days',
 ['Low','Low','Some concerns','Low','Some concerns'],
 ['Computer sequence and independently managed opaque envelopes; no clear baseline evidence of randomization failure.',
  'Patients, anesthetists, surgeons and collectors masked; practitioner instructed to use neutral interaction. Common analgesic care. No evidenced trial-context deviation affecting receipt.',
  '100 randomized (50 each); 48/49 analyzed following three consent withdrawals. Few losses, but reasons do not establish independence from rescue need; 19 observed events and no binary missing-data correction. Some concerns rather than an automatic attrition threshold.',
  'Tramadol receipt logged; clinical care and collectors masked. Prescriber discretion under a shared regimen is not evidence of differential measurement.',
  'Paper names additional analgesic receipt over three days, but a pre-unblinding analysis plan for this exact result was not independently verified. No direct evidence proving selected favorable reporting.'],
 'PDF methods pp2–4; withdrawal text p5; Table 3 p8',
 'Published outcome naming; original time-stamped registry/SAP not independently available'),
]

for comparison in ['Sham','Usual care']:
    records.append(('Xie 2014',comparison,'Postoperative; exact rescue period unspecified',
      ['Some concerns','Some concerns','Low','Some concerns','Some concerns'],
      ['Computer-generated randomization reported; allocation concealment not sufficiently described.',
       'Practitioners necessarily aware; patient/care-provider masking not established for rescue request and administration, especially versus usual care. Trial-context departures uncertain, without enough evidence to establish high risk.',
       '20 patients per group reported in outcome table; no missing rescue data or postrandomization exclusions identified.',
       'Receipt recorded and collectors/analysts masked, but rescue depends on patient request and nurse administration. Masking of those deciding/requesting rescue is unverified; awareness could affect receipt. No evidence sufficient to say such influence was likely.',
       'No prospectively verified analysis plan for the exact rescue proportion/window. Lack of a protocol does not by itself establish selective choice.'],
      'PDF p2 methods; p3 rescue rule/masking/Table 2',
      'No original prospective registry/SAP located in available evidence'))

assessments=[];signals=[]
for i,(report,comparison,window,domains,why,loc,external) in enumerate(records,1):
    inv=inventory[report]
    assessment_id=f'OPIOID-RESCUE-20261008-{i:02}'
    overall='High' if 'High' in domains else ('Some concerns' if 'Some concerns' in domains else 'Low')
    a=dict(assessment_id=assessment_id,report=report,comparison=comparison,
           outcome='Receipt of an additional postoperative rescue opioid',window=window,
           effect_of_interest='Effect of assignment to intervention',overall=overall,
           reviewer='Codex AI source-informed assessment',date=DATE,human_signoff='SP, 2026-10-23: confirmed',
           judgment_basis='Manual judgments, not output of a validated RoB 2 algorithm',
           source_pdf=inv['pdf'],source_sha256=inv['sha256'],source_text=inv['fresh_text'],
           source_location=loc,protocol_registry_evidence=external)
    a.update({f'd{j+1}':v for j,v in enumerate(domains)})
    a.update({f'd{j+1}_rationale':v for j,v in enumerate(why)})
    assessments.append(a)
    ans={'1.1':'Y','1.2':'Y' if domains[0]=='Low' else 'NI','1.3':'PN',
         '2.1':'PN','2.2':'PN','2.3':'PN','2.4':'NA','2.5':'NA','2.6':'PY','2.7':'NA',
         '3.1':'PY' if domains[2]=='Low' else 'N','3.2':'NA' if domains[2]=='Low' else 'N',
         '3.3':'NA' if domains[2]=='Low' else 'PY','3.4':'NA' if domains[2]=='Low' else ('PY' if domains[2]=='High' else 'NI'),
         '4.1':'PN','4.2':'PN','4.3':'PN','4.4':'NA','4.5':'NA',
         '5.1':'NI','5.2':'NI','5.3':'NI'}
    if report=='Xie 2014':
        ans.update({'2.1':'NI' if comparison=='Sham' else 'PY','2.2':'NI','2.3':'NI',
                    '2.4':'NI','2.5':'NI','4.3':'NI','4.4':'PY','4.5':'NI'})
    for question_id,short in Q.items():
        domain=int(question_id[0])
        signals.append(dict(assessment_id=assessment_id,report=report,comparison=comparison,
             question_id=question_id,short_question=short,answer=ans[question_id],
             justification=why[domain-1],final_domain_judgment=domains[domain-1],
             source_location=loc,source_pdf=inv['pdf'],source_sha256=inv['sha256'],
             reviewer=a['reviewer'],date=DATE,human_signoff=a['human_signoff']))
write('rob2_rescue_assessments.csv',assessments)
write('rob2_rescue_signalling_questions.csv',signals)

def fit(rows,model_id):
    yi=np.array([math.log((int(r['events_i'])/int(r['n_i']))/(int(r['events_c'])/int(r['n_c']))) for r in rows])
    vi=np.array([1/int(r['events_i'])-1/int(r['n_i'])+1/int(r['events_c'])-1/int(r['n_c']) for r in rows])
    k=len(rows)
    def nll(tau):
        w=1/(vi+tau);mu=np.sum(w*yi)/sum(w)
        return .5*(sum(np.log(vi+tau))+math.log(sum(w))+sum(w*(yi-mu)**2))
    opt=minimize_scalar(nll,bounds=(0,max(1,np.var(yi)*10,max(vi)*10)),method='bounded',options={'xatol':1e-12})
    tau=float(opt.x if opt.fun<nll(0) else 0);w=1/(vi+tau);mu=float(sum(w*yi)/sum(w))
    se=math.sqrt(max(1,sum(w*(yi-mu)**2)/(k-1))/sum(w));crit=t.ppf(.975,k-1)
    return dict(model_id=model_id,k=k,N=sum(int(r['n_i'])+int(r['n_c']) for r in rows),
        effect=math.exp(mu),ci_low=math.exp(mu-crit*se),ci_high=math.exp(mu+crit*se),
        tau2=tau,method='REML log RR; modified Hartung-Knapp floor 1; t k-1',
        reports=';'.join(r['report'] for r in rows),status='ADDITIONAL_POST_HOC_ROBUSTNESS_CHECK')
specs=[('RESCUE_EXCLUDE_ESD',[r for r in main if r['report']!='Liu 2026 (ESD)']),
       ('RESCUE_EXCLUDE_HIGH_ROB',[r for r in main if r['report'] not in ['Tu 2024','Liu 2026 (ESD)']])]
write('rescue_robustness_results.csv',[fit(rows,id) for id,rows in specs])
write('rescue_robustness_inputs.csv',[dict(r,model_id=id) for id,rows in specs for r in rows])
variance=[1/int(r['events_i'])-1/int(r['n_i'])+1/int(r['events_c'])-1/int(r['n_c']) for r in main]
weights=(1/np.array(variance))/sum(1/np.array(variance))
write('main_model_bias_weights.csv',[dict(report=r['report'],weight_percent=100*float(w),overall_rob=next(a['overall'] for a in assessments if a['report']==r['report'])) for r,w in zip(main,weights)])
control_events=sum(int(r['events_c']) for r in main);control_n=sum(int(r['n_c']) for r in main)
p0=control_events/control_n
ois=[]
for rrr in [.2,.25]:
    p1=p0*(1-rrr);pm=(p0+p1)/2
    n=math.ceil((norm.ppf(.975)*math.sqrt(2*pm*(1-pm))+norm.ppf(.8)*math.sqrt(p0*(1-p0)+p1*(1-p1)))**2/(p0-p1)**2)
    ois.append(dict(assumed_control_risk=p0,post_hoc_relative_reduction_threshold=rrr,
                   alpha=.05,power=.8,participants_per_arm=n,total_participants=2*n))
write('information_size_scenarios.csv',ois)
models={r['model_id']:r for r in read(HERE.parent/'rescue_model_results.csv')}
individual=read(HERE.parent/'individual_estimates.csv')
profile=[]
for label,key,reports,precision,reason in [
    ('TEAS/sham: each trial postoperative follow-up','RESCUE_TEAS_SHAM_ANY_FOLLOWUP',None,1,
     '135 events / 478 participants; below illustrative post-hoc information sizes for 20–25% relative reductions; risk of sparse-data overestimation despite interval excluding 1.'),
    ('TEAS/sham: approximate first day','RESCUE_TEAS_SHAM_FIRST_DAY_APPROX',None,2,
     '20 events / 201 participants; safeguarded HK interval spans extreme benefit and harm; very serious imprecision.'),
    ('TEAS/sham: 48 h ESD',None,['Liu 2026 (ESD)'],1,
     '59 events / 120 participants; limited information for a clinically useful moderate relative reduction despite interval excluding 1.'),
    ('TEAS/sham: 3 postoperative days',None,['Zhou 2025'],2,
     '19 events / 97 participants; extremely limited information for a modest reduction and interval spanning large benefit to no benefit. Very serious on sparse information, not merely p-value.'),
    ('EA/sham: postoperative period unspecified',None,['Xie 2014','Sham'],2,
     '7 events / 40 participants; extremely limited information; interval includes no benefit and possible clinically important harm.'),
    ('EA/usual care: postoperative period unspecified',None,['Xie 2014','Usual care'],2,
     '8 events / 40 participants; extremely limited information and interval spanning large benefit to no benefit.')]:
    if key:
        result=models[key]
        selected=[r for r in main if r['report'] in result['reports'].split(';')]
        ni=sum(int(r['n_i']) for r in selected);nc=sum(int(r['n_c']) for r in selected)
        ei=sum(int(r['events_i']) for r in selected);ec=sum(int(r['events_c']) for r in selected)
        N=int(result['N']);k=int(result['k']);effect=float(result['effect']);lo=float(result['ci_low']);hi=float(result['ci_high'])
        source_reports=result['reports']
    else:
        result=next(r for r in individual if r['report']==reports[0] and r['outcome']=='Rescue opioid receipt' and r['comparator']==(reports[1] if len(reports)>1 else 'Sham'))
        ni=int(result['n_i']);nc=int(result['n_c']);ei=int(result['events_i']);ec=int(result['events_c'])
        N=ni+nc;k=1;effect=float(result['effect']);lo=float(result['ci_low']);hi=float(result['ci_high']);source_reports=reports[0]
    certainty='Low' if precision==1 else 'Very low';baseline=ec/nc
    profile.append(dict(outcome_comparison=label,reports=source_reports,trials=k,analyzed_N=N,
        events_i=ei,n_i=ni,events_c=ec,n_c=nc,effect_measure='RR',effect=effect,ci_low=lo,ci_high=hi,
        initial_certainty='High (randomized trials)',risk_of_bias_deduction=1,
        risk_of_bias_reason='Outcome-specific ratings: informative postrandomization exclusions or concerns about concealment, prespecification or rescue decision masking; see linked RoB records.',
        inconsistency_deduction=0,inconsistency_reason='No detected heterogeneity in pooled body; limited power. Not assessable between trials for single-trial row.',
        indirectness_deduction=0,indirectness_reason='Applies only to this expressly labeled outcome/window; not transferable to strict complete 24-hour quantity.',
        imprecision_deduction=precision,imprecision_reason=reason,publication_bias_deduction=0,
        publication_bias_reason='Uncertain; insufficient evidence to justify an additional deduction; no funnel test with five trials.',
        final_certainty=certainty,illustrative_control_per_1000=baseline*1000,
        corresponding_intervention_per_1000=baseline*effect*1000,
        corresponding_low_per_1000=baseline*lo*1000,corresponding_high_per_1000=min(1000,baseline*hi*1000),
        absolute_risk_note='Model-based illustration at this body control risk; upper absolute risk bounded at 1000. Not a pooled RD. Nested subsets/shared arms must not be counted again.',
        threshold_status='Information-size reduction thresholds chosen post hoc, not protocol-defined',
        assessor='Codex AI (delegated); second review SP, 2026-10-23 (confirmed)',date=DATE))
write('grade_rescue_evidence_profile.csv',profile)
details=dict(date=DATE,assessments=len(assessments),signalling_question_rows=len(signals),
    main_N=478,main_events=sum(int(r['events_i'])+int(r['events_c']) for r in main),
    control_events=control_events,control_N=control_n,control_risk=p0,
    grade_outcome_bodies=len(profile),independent_human_review='Second review SP, 2026-10-23 (confirmed); a check of the first assessment, not an independent duplicate assessment',
    assessment_scope='Five TEAS/sham rescue-receipt trials and two Xie EA comparisons; other new native/median/delay outcomes are not newly graded here.')
(HERE/'assessment_counts.json').write_text(json.dumps(details,indent=2)+'\n')
assert len(signals)==154
for r in assessments:
    assert hashlib.sha256((ROOT/r['source_pdf']).read_bytes()).hexdigest()==r['source_sha256']
print(json.dumps(details,indent=2))
print((HERE/'rescue_robustness_results.csv').read_text())
print((HERE/'information_size_scenarios.csv').read_text())
