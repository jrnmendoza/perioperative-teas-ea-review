"""Hospital setting and multimodal analgesia for the 40 included reports (24 October 2026), in response to BMJ Open
Reviewer 2 (Myles): "how do we know the hospitals were all tertiary-level, and whether or not each study incorporated
multimodal analgesia - these aspects need to be checked and reported in Table 1".

Definitions
- Setting: recorded as the report states it. 'Tertiary' only where the report says tertiary. Where the trial site is not
  stated in Methods, the authors' affiliation or approving ethics committee is given and labelled as such.
- Multimodal analgesia (MMA) in all groups: a non-opioid analgesic (paracetamol, NSAID/COX-2 inhibitor, metamizole,
  ketamine) or a regional/local anaesthetic technique given routinely to every group by protocol. Drugs given only as
  rescue do not count. Dexamethasone or dexmedetomidine alone are not counted as analgesics. 'Conditional' means the
  non-opioid was part of a PCIA solution used only 'if needed'.
Every quote is checked against the page-tagged text extracted from the hash-pinned source PDF (argument 1: directory
of extracted texts). AI extraction (delegated); second review SP, 2026-10-24 (confirmed).
"""
import csv, re, sys, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TXT = Path(sys.argv[1])
audit = {r['report']: r for r in csv.DictReader((ROOT / 'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv').open(newline=''))
         if r['source_confirmed_named_opioid_or_author_MME'] == 'YES'}
R = []
def rec(report, setting, setting_basis, setting_quote, setting_page, mma, components, mma_quote, mma_page, note=''):
    R.append(dict(report=report, setting=setting, setting_basis=setting_basis, setting_quote=setting_quote, setting_page=setting_page,
                  mma_all_groups=mma, non_opioid_components=components, mma_quote=mma_quote, mma_page=mma_page, note=note))

T, M, U, H, A = 'Tertiary (stated)', 'Multicentre (level not stated)', 'University or university-affiliated hospital', 'Named hospital, level not stated', 'Site not stated (affiliation only)'
rec('Zhou 2025', U, 'Methods', 'This study was conducted at the Second Affiliated Hospital of Guilin Medical University', 2,
    'Yes', 'Flurbiprofen axetil; ropivacaine incision infiltration', 'Ropivacaine (0.5%, 10 mL) was infiltrated at the abdominal incision site', 3)
rec('An 2014', A, 'Affiliation', 'Department of Anesthesia, Beijing Tiantan Hospital', 1,
    'No', 'None routine (fentanyl PCIA)', 'At the end of the operation, sevo', 3)
rec('Ao 2021', U, 'Methods', "Tangshan People's Hospital and Tangshan Cancer Hospital, North Chin", 2,
    'No', 'None routine (sufentanil PCA)', 'patient‑controlled analgesia (PCA) pump for postoperative pain control', 2)
rec('Chen 1998', H, 'Ethics approval', 'The study protocol was approved by the institutional review board at Cedars Sinai Medical Center', 2,
    'No', 'None routine during PCA (oral acetaminophen only after PCA)', 'programmed to deliver bolus doses of HM 0.2-0.4 mg IV on demand', 1)
rec('Chen 2015', H, 'Methods', 'was conducted at Fujian Provincial Hospital', 1,
    'No', 'None routine (morphine rescue)', 'intrave - nous morphine 2 mg as rescue analgesia', 2)
rec('Chen 2015 (Hyperalgesia)', A, 'Affiliation', 'Fujian Provincial Hospital', 6,
    'No', 'None routine (sufentanil PCIA)', 'set to deliver suf - entanil 0.05 μg/kg as a bolus', 4)
rec('Chen 2020', U, 'Methods', 'Peking Unive', 2,
    'No', 'None routine (sufentanil PCIA)', '10 μg sufentanil was administered for analgesia transition', 3)
rec('Coura 2011', H, 'Methods', 'conducted at Unimed Hospital Centre in Joinville', 1,
    'No', 'None routine (fentanyl PCA)', 'PCA pump with continuous injection of 0,4 pg/ kg/h fentanyl', 2)
rec('El-Rakshy 2009', H, 'Methods', 'was conducted in Scunthorpe & Goole Hospitals', 1,
    'No', 'None routine (morphine PCA; no local anaesthetic)', 'No local anaesthetics were used at the end of surgery', 3)
rec('Gao 2022', M, 'Methods', 'multicenter, evaluator-blinded, an d randomized controlled study', 1,
    'Yes', 'Flurbiprofen axetil or parecoxib', 'parecoxib at the end of surgery', 3)
rec('Grech 2016', A, 'Affiliation', 'New Jersey Medical School, Rutgers University', 1,
    'Not reported', 'Postoperative regimen not reported', 'All analgesic treatments were converted to morphine equivalents', 3)
rec('Gu 2019', A, 'Affiliation ("our hospital")', "Tangshan People ’s Hospital", 1,
    'Yes', 'Flurbiprofen axetil in PCIA', 'dexmedetomidine, 100 mg ﬂurbiprofen axetil', 2)
rec('He 2026 (hepatectomy/JIS)', T, 'Methods', 'conducted across three tertiary hospitals in china', 2,
    'Yes', 'Parecoxib', 'Preemptive analgesia was provided with parecoxib sodium (40 mg IV)', 4)
rec('Jiang 2026', T, 'Methods', 'carried out at the tertiary Nankai Hospital', 2,
    'Conditional', 'Flurbiprofen in PCIA, if PCIA used', 'Postoperative analgesia included sufentanil and flurbiprofen via patient-controlled intravenous analgesia (PCIA) for 24 – 48 h if needed', 3)
rec('Jin 2023', T, 'Methods', 'conducted at a tertiary uni- versity hospital in China', 1,
    'No', 'None routine (fentanyl PCIA; anti-inflammatory drugs as rescue only)', 'anti- inﬂammatory analgesics as rescue medi- cation for unbearable pain', 2)
rec('Lee 2011', U, 'Methods', 'Hysterectomized patients at the China Medical University Hospital were invited', 1,
    'No', 'None routine (morphine PCA)', 'All subjects in each group received PCA postoperatively', 2)
rec('Lin 2002', A, 'Affiliation', 'Acupuncture Research Center, China Medical College', 1,
    'No', 'None (morphine PCA; no other analgesics)', 'No other analgesics were administered during the PCA control period', 3)
rec('Liu 2026 (ESD)', U, 'Methods', 'conducted at Beijing Friendship Hospital affiliated to Capital Medical University', 2,
    'No', 'None routine (tramadol, morphine)', 'A total of 50 mg tramadol', 3)
rec('Liu 2026 (burn)', U, 'Ethics approval; single centre', 'First Affiliated Hospital of Shihezi University', 2,
    'No', 'None routine (sufentanil-butorphanol PCIA with dexamethasone)', 'As this was a single-center study', 7)
rec('Long 2025', U, 'Methods', 'in the Second Affiliated Hospital of Zhejiang Chinese Medical University Xinhua Hospital', 2,
    'No', 'None routine (sufentanil PCIA)', 'The PCIA regimen consisted of 2 µ g/kg sufentanil diluted in 100 ml of saline', 2)
rec('Ng 2013', U, 'Methods', 'at the Prince of Wales Hospital, a university teaching hospital in Hong Kong', 2,
    'No', 'None routine (pethidine on demand)', 'Pethidine 1 mg/kg as postoperative analgesia was given every 4 hours on demand', 2)
rec('Ntritsou 2014', A, 'Affiliation', 'General Hospital of Thessaloniki', 1,
    'Yes', 'Parecoxib; paracetamol; ketamine', 'All patients received 40 mg parecoxib intravenously 1 h before the end of surgery and 20 mg/kg paracetamol', 2)
rec('Oztas 2019', H, 'Methods', 'conducted at the Department of General Surgery of the Gülhane Training and Research Hospital', 3,
    'No', 'None routine (tramadol PCA; dexketoprofen as rescue only)', 'were used as rescue analgesic drugs', 4)
rec('Seevaunnamtum 2016', T, 'Methods', 'multidisciplinary tertiary govern- ment hospital in Malaysia', 2,
    'No', 'None routine (morphine PCA)', 'The total morphine demand and usage from the patient-controlled analgesia Morphine (PCAM)', 1)
rec('Sim 2002', A, 'Affiliation', 'National University Hospital Singapore', 1,
    'No', 'None routine (morphine PCA)', 'All patients received intravenous morphine for postoperative pain management via a patient-controlled analgesia device', 2)
rec('Szmit 2021', U, 'Methods', 'was conducted at Wroclaw University Hospital', 2,
    'No', 'None routine (morphine PCA; metamizole only if needed before PCA)', 'PCA + sham-TEAS (no electrical stimulation)', 1)
rec('Tu 2024', U, 'Methods', 'at the West China Hospital, Sichuan University', 2,
    'No', 'None routine (tramadol for VAS > 6)', 'received an intramuscular injection of 10 mg tramadol', 2)
rec('Wong 2006', T, 'Methods', 'tertiary referral university-teaching hospital in Hong Kong', 2,
    'Yes', 'Oral acetaminophen (with dextropropoxyphene)', 'prescribed oral analgesics containing 640 mg of acetaminophen', 2)
rec('Wu 2016', U, 'Methods', 'at the Cancer Hospital of Harbin Medical University', 2,
    'No', 'None routine (tramadol rescue)', 'was used for postoperative pain rescue, as required', 3)
rec('Wu 2025', T, 'Methods', 'at a tertiary hospital in Shanghai', 1,
    'Yes', 'Thoracic paravertebral block (ropivacaine)', 'Ultrasound-guided thoracic paravertebral nerve blocks were performed at T4-7 levels', 3)
rec('Xie 2014', A, 'Not identifiable from the extracted text', '', '',
    'No', 'None routine (sufentanil infusion; dezocine rescue)', 'The breakthrough pain was treated with dezocine', 3)
rec('Xiong 2021', A, 'Affiliation ("our medical center")', 'our medical center', 7,
    'Yes', 'Parecoxib; ropivacaine incision infiltration', 'all patients received intravenous parecoxib (40 mg) and incision infiltration of 0.5% ropivacaine', 3)
rec('Yang 2024', H, 'Ethics approval', 'Ethics Committee of Jiangsu Province Hospital of Chinese Medicine', 2,
    'Yes', 'Parecoxib; paravertebral block; celecoxib; ketamine in PCA', 'paravertebral nerve block with 20 ml of 0.375 % ropivacaine were used for all patients', 2)
rec('Yao 2015', A, 'Acknowledgement', 'Fujian Provincial Hospital', 5,
    'No', 'None routine (sufentanil rescue)', 'asrescueanalgesia', 2)
rec('Yeh 2010', H, 'Methods', 'orthopedic departments of a 4000-bed', 4,
    'No', 'None routine (epidural morphine PCA)', 'All had consented to an epidural PCA with a 1-mg holus of morphine', 2)
rec('Yeh 2011', H, 'Methods', 'at a 3000-bed medical center in northern Taiwan', 2,
    'No', 'None routine (IV morphine PCA)', 'patient-controlled analgesia (PCA)', 1)
rec('Yu 2020', H, 'Ethics approval', "Guizhou Provincial People’s Hospital", 8,
    'No', 'None routine (sufentanil rescue)', 'required sufentanil as analgesic rescue therapy', 5)
rec('Zhang 2023', T, 'Methods', 'Nankai Hospital, a tertiary hospital', 2,
    'Conditional', 'Flurbiprofen in PCIA, as necessary', 'with sufentanil combined with ﬂurbiprofen was administered for 24–48 h postoperatively as necessary', 3)
rec('Zhang 2025', U, 'Methods', 'First Affiliated Hospital of Wenzhou Medical University', 1,
    'Yes', 'Flurbiprofen axetil; ropivacaine incision infiltration', 'local anesthetic infiltration was performed at the surgical incision site', 4)
rec('Zhou 2021', A, 'Affiliation', 'The Affiliated Hospital of Qingdao University', 1,
    'Yes', 'Epidural-assisted general anaesthesia; scheduled flurbiprofen axetil on POD1', 'once on POD 1 regularly', 3,
    'Eligibility excluded incision infiltration and anaesthesia without epidural assistance (p2), so all included patients had '
    'epidural-assisted general anaesthesia. The characteristics record states "incision infiltration (ERAS protocol)", which '
    'reversed an exclusion criterion; corrected in the 40-report characteristics files on 2026-10-24.')

# ---- checks -------------------------------------------------------------------------------------------------
assert len(R) == 40 and {r['report'] for r in R} == set(audit), set(audit) ^ {r['report'] for r in R}
def page_text(report, page):
    t = (TXT / (report.replace(' ', '_').replace('(', '').replace(')', '').replace('/', '-') + '.txt')).read_text()
    parts = re.split(r'=== PAGE (\d+) ===', t)
    return re.sub(r'\s+', ' ', dict(zip(parts[1::2], parts[2::2])).get(str(page), ''))
bad = []
for r in R:
    for q, pg in [(r['setting_quote'], r['setting_page']), (r['mma_quote'], r['mma_page'])]:
        if q and q not in page_text(r['report'], pg): bad.append((r['report'], pg, q[:60]))
for r in R:
    pdf = ROOT / audit[r['report']]['source_pdf']
    assert hashlib.sha256(pdf.read_bytes()).hexdigest() == audit[r['report']]['source_sha256'], r['report']
    r.update(source_pdf=audit[r['report']]['source_pdf'], source_sha256=audit[r['report']]['source_sha256'],
             decision_status='AI extraction (delegated); second review SP, 2026-10-24 (confirmed)')
print('quotes not found on the stated page:', bad)
out = HERE / 'setting_mma_2026-10-24.csv'
with out.open('w', newline='') as f:
    w = csv.DictWriter(f, list(R[0])); w.writeheader(); w.writerows(R)
import collections
print(collections.Counter(r['setting'] for r in R)); print(collections.Counter(r['mma_all_groups'] for r in R))
