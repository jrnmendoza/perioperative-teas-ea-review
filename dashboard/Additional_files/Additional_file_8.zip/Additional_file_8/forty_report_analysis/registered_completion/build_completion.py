"""Complete available registered outcomes within the fixed 40-report dataset.

Original extraction/adjudication is preserved. New admissions and limitations are
explicit; no median conversion, invented SD, cohort expansion, or new source review
is implied. Official Stata refits and plots are produced by run_stata.do.
"""
from pathlib import Path
import csv, json, hashlib, math, collections
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm, t, beta

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
D=ROOT/'10_FINAL_ADJUDICATION'
OLD=OUT.parent/'reviewer_rerun_2026_10_09'
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protected=[D/'03_CANONICAL/results.csv',D/'03_CANONICAL/grade.csv',D/'04_MODELS/model_inputs.csv',D/'04_MODELS/model_outputs.csv',
           D/'08_QOR_ANALYSIS/qor_inputs.csv',D/'08_QOR_ANALYSIS/qor_inputs_later.csv',OLD/'model_results.csv',ROOT/'opioid_only_review/prisma/prisma_counts.json']
hashes={str(p.relative_to(ROOT)):sha(p) for p in protected}
cohort={r['report']:r for r in read(ROOT/'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv') if r['source_confirmed_named_opioid_or_author_MME']=='YES'}
assert len(cohort)==40
for r in cohort.values():assert sha(ROOT/r['source_pdf'])==r['source_sha256']
raw=[r for r in read(D/'03_CANONICAL/results.csv') if r['study'] in cohort]
byid={r['result_id']:r for r in raw}
links={r['result_id']:r for r in read(ROOT/'FINAL_RESULT_ROB2_LINKAGE.csv')}
for name in ['qor_rob2.csv','qor_rob2_later.csv']:
    for r in read(D/'08_QOR_ANALYSIS'/name):links[r['result_id']]=r
if (OUT/'provisional_new_rob2_domains.csv').exists():
    for r in read(OUT/'provisional_new_rob2_domains.csv'):links[r['result_id']]=r
inputs=[];specs=[];results=[];admissions=[]

def rederive(r,measure):
    r=dict(r)
    ni,nc=float(r['n_i']),float(r['n_c'])
    assert ni>0 and nc>0
    if measure=='RR':
        a,c=float(r['events_i']),float(r['events_c'])
        assert 0<=a<=ni and 0<=c<=nc
        if a==c==0:raise ValueError('DOUBLE ZERO: report arm risks; no informative RR')
        cc=.5 if min(a,ni-a,c,nc-c)==0 else 0.
        r['continuity_correction']=cc
        r['yi']=math.log(((a+cc)/(ni+2*cc))/((c+cc)/(nc+2*cc)))
        r['vi']=1/(a+cc)-1/(ni+2*cc)+1/(c+cc)-1/(nc+2*cc)
    else:
        mi,mc,si,sc=[float(r[k]) for k in ['mean_i','mean_c','sd_i','sd_c']]
        assert si>=0 and sc>=0
        if measure=='SMD':
            df=ni+nc-2;sp=math.sqrt(((ni-1)*si*si+(nc-1)*sc*sc)/df)
            j=math.exp(math.lgamma(df/2)-.5*math.log(df/2)-math.lgamma((df-1)/2))
            g=j*(mi-mc)/sp;r['yi']=g;r['vi']=(ni+nc)/(ni*nc)+g*g/(2*(ni+nc))
        else:r['yi']=mi-mc;r['vi']=si*si/ni+sc*sc/nc
    assert r['vi']>0
    r['report']=r['study'];r['effect_measure']=measure
    r['source_sha256']=r.get('source_sha256') or r.get('source_pdf_sha256') or cohort[r['study']]['source_sha256']
    return r

def fit(rows,s):
    k=len(rows);z=dict(s,k=k,N=sum(float(r['n_i'])+float(r['n_c']) for r in rows),reports=';'.join(r['study'] for r in rows))
    if not k:return dict(z,status='NO ELIGIBLE QUANTITATIVE DATA')
    assert len({r['trial_id'] for r in rows})==k,(s['model_id'],'dependent inputs')
    y=np.array([r['yi'] for r in rows]);v=np.array([r['vi'] for r in rows]);tau=0.;q=None;i2=None
    if k>1:
        def objective(tau):
            w=1/(v+tau);m=np.sum(w*y)/np.sum(w)
            return .5*(np.sum(np.log(v+tau))+math.log(np.sum(w))+np.sum(w*(y-m)**2))
        opt=minimize_scalar(objective,bounds=(0,max(1,np.var(y)*10,max(v)*10)),method='bounded',options={'xatol':1e-12})
        tau=float(opt.x if opt.fun<objective(0)-1e-12 else 0.)
        w=1/(v+tau);mu=float(sum(w*y)/sum(w));q=float(sum(w*(y-mu)**2)/(k-1))
        se=math.sqrt(max(1,q)/sum(w));crit=t.ppf(.975,k-1)
        w0=1/v;C=sum(w0)-sum(w0*w0)/sum(w0);i2=100*tau/(tau+(k-1)/C)
    else:mu=float(y[0]);se=math.sqrt(v[0]);crit=norm.ppf(.975)
    lo,hi=mu-crit*se,mu+crit*se
    tf=math.exp if s['measure']=='RR' else float
    z.update(effect=tf(mu),ci_low=tf(lo),ci_high=tf(hi),theta=mu,se=se,theta_low=lo,theta_high=hi,tau2=tau,I2=i2,hk_scale=q,
             status='REML + safeguarded Hartung-Knapp' if k>1 else 'SINGLE TRIAL; NOT POOLED')
    if k>=5:
        half=t.ppf(.975,k-1)*math.sqrt(tau+se*se);z.update(pi_low=tf(mu-half),pi_high=tf(mu+half))
    return z

def add(mid,rows,measure,unit,label,role='ADDITIONAL',basis='Subset of adjudicated existing inputs',family='',note='',parent=''):
    assert mid not in {s['model_id'] for s in specs},mid
    data=[rederive(r,measure) for r in rows]
    s=dict(model_id=mid,measure=measure,unit=unit,label=label,role=role,basis=basis,family=family,note=note,parent_model_id=parent)
    specs.append(s);results.append(fit(data,s));inputs.extend(dict(r,model_id=mid) for r in data)

# Refit every non-opioid canonical estimand, including empty cells. Original arms
# already have analysis-unit transformations applied; they are not converted twice.
canon=read(D/'04_MODELS/model_inputs.csv')
oldout=read(D/'04_MODELS/model_outputs.csv')
for s in oldout:
    if s['model_id'].startswith(('opioid','pethidine','tramadol')):continue
    rows=[r for r in canon if r['model_id']==s['model_id'] and r['study'] in cohort]
    if rows and s['measure'] in ['MD','RR','SMD']:
        for r in rows:
            rr=rederive(r,s['measure']);assert abs(rr['yi']-float(r['yi']))<1e-8;assert abs(rr['vi']-float(r['vi']))<1e-8
    role=s['role']
    note='Same adjudicated construct and rules; membership restricted to the fixed 40 reports.'
    if rows and any(r['study']=='Lee 2011' for r in rows):
        assert all(r['study']=='Lee 2011' for r in rows), 'Mixed Lee body requires explicit removal and refit'
        role='HELD'
        note='Adult eligibility unresolved: source age range includes 14 years; proportion aged >=18 not established. Descriptive as-printed result only.'
    if 'diagnostic' in s['model_id'].lower():
        note='Measured before the assigned postoperative intervention. Descriptive diagnostic only; cannot estimate a causal stimulation effect.'
    add(s['model_id'],rows,s['measure'],s['unit'],s['model_id'].replace('_',' '),role,family=s['construct'],note=note)

# Global QoR scales and timepoints remain separate. Empty usual-care cells are
# retained instead of copying results from the broader 70-report review.
qorin=[r for r in read(D/'08_QOR_ANALYSIS/qor_inputs.csv')+read(D/'08_QOR_ANALYSIS/qor_inputs_later.csv') if r['study'] in cohort]
for instrument,comp,period in [('QoR-40','sham','24H'),('QoR-15','sham','24H'),('QoR-40','usual_care','24H'),
                              ('QoR-40','sham','48H'),('QoR-15','sham','48H'),('QoR-15','sham','POD3')]:
    rows=[r for r in qorin if r['instrument']==instrument and r['comparator']==comp and (('LATER' not in r['result_id']) if period=='24H' else ('LATER' in r['result_id'] and (('POD2' in r['window'] or '48 h' in r['window']) if period=='48H' else 'POD3' in r['window'])))]
    add(instrument.replace('-','')+'_'+comp.upper()+'_'+period,rows,'MD',instrument+' points',instrument+': TEAS vs '+comp.replace('_',' ')+' '+period,
        family='quality_of_recovery',basis='Source-verified global QoR additive inputs',note='Positive MD favours TEAS; reported result-specific denominators.')
# Zhou POD3 was previously not fitted; printed means/SDs conflict with printed P.
zhou=next(r for r in qorin if r['study']=='Zhou 2025' and 'LATER' in r['result_id'])
zp=dict(zhou,result_id='QOR-ZHOU2025-POD3-AS-PRINTED',window='POD3 (~72 h)',mean_i=124.82,sd_i=9.60,mean_c=124.84,sd_c=9.60)
add('QOR15_SHAM_POD3_AS_PRINTED',[zp],'MD','QoR-15 points','QoR-15 at POD3: Zhou 2025 printed table',role='SENSITIVITY',family='quality_of_recovery',
    basis='Recovery coverage Table 3, PDF p7',note='Source P=.275 conflicts with printed near-identical means/SDs. Descriptive as-printed calculation; no resolution claimed.')

def admit(ids,mid,measure,unit,label,family,role='ADDITIONAL',note='',modality=None,comparator=None):
    rows=[]
    for rid in ids:
        r=dict(byid[rid])
        if modality:r['modality']=modality
        if comparator:r['comparator_class']=comparator
        rows.append(r)
        admissions.append(dict(result_id=rid,study=r['study'],new_model_id=mid,original_decision=byid[rid]['decision'],original_rationale=byid[rid]['rationale'],
          completion_disposition='NEW DESCRIPTIVE/ADDITIONAL CALCULATION; original source hold remains where noted',reason=note or 'Registered additional outcome; original exclusion was outside earlier defined quantitative estimands.'))
    add(mid,rows,measure,unit,label,role,basis='Explicit additional source-row admission; no silent canonical edit',family=family,note=note)

# Single-trial measurements are not pooled across different times/settings.
admit(['V33-OD-0275'],'PAIN24_GAO_UNSPECIFIED','MD','0-10 points','Gao 2022: reported 24-hour pain','pain','SENSITIVITY',note='Rest/movement setting unclassified; source labels assessment 24 h. Not the registered joint pain criterion.')
for rid,mid,label in [('V33-OD-0354','PAIN_DISCHARGE_SZMIT_SHAM','Szmit 2021: pain at discharge vs sham'),('V33-OD-0355','PAIN_DISCHARGE_SZMIT_USUAL','Szmit 2021: pain at discharge vs usual care')]:
    admit([rid],mid,'MD','0-10 points',label,'pain','SENSITIVITY',note='Discharge clock time and rest/movement not established. Same opioid trial, but not verified approximately-24-hour paired pain.')
admit(['V33-OD-0368'],'PAIN48_YU_TABLE','MD','0-10 points','Yu 2020: POD2 rest pain, table values','pain','SENSITIVITY',note='Unresolved abstract/table SD and significance discrepancies; as-printed sensitivity, not pooled evidence.')
yu=dict(byid['V33-OD-0368'],sd_i=.88)
add('PAIN48_YU_ABSTRACT_SD',[yu],'MD','0-10 points','Yu 2020: POD2 rest pain, alternate abstract SD','SENSITIVITY',family='pain',basis='Existing source conflict inventory',note='Alternative SD sensitivity; no source conflict resolved.')
yu24=dict(byid['V33-OD-0367'],sd_i=1.41)
add('PAIN24_YU_ABSTRACT_SD',[yu24],'MD','0-10 points','Yu 2020: POD1 rest pain, alternate abstract SD','SENSITIVITY',family='pain',basis='Existing source conflict inventory',note='Primary transcription uses table SD=1.53; alternate abstract SD=1.41.')
for rid,h in [('AUDIT-0151','4H'),('AUDIT-0152','8H')]:admit([rid],'PAIN_'+h+'_GU','MD','0-10 points','Gu 2019: pain at '+h,'pain',note='Separate explicit timepoint; neither relabelled as 6 h.')
for rid,h,comp in [('V33-OD-0311','2H','USUAL'),('V33-OD-0312','2H','ACTIVE'),('V33-OD-0313','18H','USUAL'),('V33-OD-0314','18H','ACTIVE'),('V33-OD-0315','22H','USUAL'),('V33-OD-0316','22H','ACTIVE'),('V33-OD-0317','42H','USUAL'),('V33-OD-0318','42H','ACTIVE'),('V33-OD-0319','46H','USUAL'),('V33-OD-0320','46H','ACTIVE')]:
    admit([rid],'PAIN_'+h+'_OZTAS_'+comp,'MD','VAS points','Oztas 2019: resting pain '+h+' vs '+comp.lower(),'pain','SENSITIVITY',note='Methods label VAS 1-10 but tables include 0; native-scale descriptive result, timing kept exact.',comparator='usual_care' if comp=='USUAL' else 'active_electrical')
for rid,period in [('AUDIT-0260','PRE'),('AUDIT-0261','POST')]:admit([rid],'PAIN_MEAN24_SIM_'+period,'MD','0-10 points','Sim 2002: mean pain over 24 h, '+period.lower()+'operative EA','pain','SENSITIVITY',note='Average across repeated measurements, not the 24-hour point; the two EA arms share a control and are not pooled together.')
for rid,mid in [('V33-OD-0110','INTRAOP_ALFENTANIL_SIM_PRE'),('AUDIT-0319','INTRAOP_ALFENTANIL_SIM_POST_DIAGNOSTIC')]:
    admit([rid],mid,'MD','micrograms/kg/min','Sim 2002: intraoperative alfentanil rate '+('preoperative EA' if rid=='V33-OD-0110' else 'postoperative EA diagnostic'),'intraoperative_opioid','ADDITIONAL' if rid=='V33-OD-0110' else 'SENSITIVITY',note='Postoperative-only intervention cannot explain a preceding intraoperative dose. Rate is not converted to total opioid mass.')
for rid,period in [('AUDIT-0361','24H'),('AUDIT-0362','48H')]:admit([rid],'MMSE_YU_'+period,'MD','MMSE points','Yu 2020: MMSE '+period,'functional_recovery','SENSITIVITY',note='Printed means favour TEAS although narrative direction conflicts; supplementary cognitive outcome, not QoR or mobilisation.')
for rid,comp in [('V33-OD-0271','ACTIVE'),('V33-OD-0272','USUAL')]:admit([rid],'LOS_WU2016_'+comp,'MD','days','Wu 2016: hospital stay vs '+comp.lower(),'length_of_stay',note='Active nonacupoint electrical and no-TEAS controls kept separate; three post-randomisation exclusions per arm.',comparator='active_electrical' if comp=='ACTIVE' else 'usual_care')
for rid,label in [('V33-OD-0041','Zhang 2025: moderate-to-severe visceral pain POD1'),('V33-OD-0076','Wu 2025: moderate-to-severe pain within 12 h'),('V33-OD-0157','Liu 2026 ESD: NRS >=4 within 24 h')]:
    admit([rid],'PAIN_BINARY_'+rid,'RR','risk ratio',label,'pain','SENSITIVITY',note='Binary threshold outcome; not a continuous rest/movement pain margin.')
for rid,label in [('V33-OD-0094','Tu 2024: vomiting 2-6 h'),('V33-OD-0095','Tu 2024: vomiting 6-24 h'),('AUDIT-0199','Tu 2024: vomiting 0-2 h'),('V33-OD-0160','Liu 2026 ESD: postoperative PONV, window unspecified'),('AUDIT-0156','Gu 2019: postoperative PONV, window unspecified'),('V33-OD-0352','Szmit 2021: nausea, postoperative observation vs sham'),('V33-OD-0353','Szmit 2021: nausea, postoperative observation vs usual care')]:
    admit([rid],'PONV_NATIVE_'+rid,'RR','risk ratio',label,'ponv','SENSITIVITY',note='Exact source period retained; separate components/time bins not summed into a cumulative patient incidence.',comparator='usual_care' if rid=='V33-OD-0353' else 'sham')
for rid,label in [('V33-OD-0043','Zhang 2023: delayed urinary recovery'),('V33-OD-0044','Zhang 2023: urinary retention')]:
    admit([rid],'URINARY_'+rid,'RR','risk ratio',label,'functional_recovery',note='Distinct urinary outcomes, not time to mobilisation.')
admit(['V33-OD-0031'],'PAIN_AVERAGE_ZHOU2021','MD','source pain-score points','Zhou 2021: average pain over POD1-5','pain','SENSITIVITY',note='Longer-period average, not an exact timepoint or verified 0-10 rest/movement margin.')
admit(['V33-OD-0077'],'INTRAOP_SUF_WU_PREINTERVENTION_DIAGNOSTIC','MD','micrograms sufentanil','Wu 2025: intraoperative sufentanil before PACU intervention','intraoperative_opioid','SENSITIVITY',note='Precedes first assigned postoperative stimulation; not a treatment-effect endpoint.')
for rid,label,comp in [('V33-OD-0269','Wu 2016: PONV vs active electrical','active_electrical'),('V33-OD-0270','Wu 2016: PONV vs usual care','usual_care'),('V33-OD-0057','Xiong 2021: clinically important PONV within 48 h','sham')]:
    admit([rid],'PONV_NATIVE_'+rid,'RR','risk ratio',label,'ponv','SENSITIVITY',note='Source comparator and endpoint retained; unspecified follow-up not relabelled as 24 h.',comparator=comp)
admit(['AUDIT-0180'],'GI_DISTENTION_JIANG','RR','risk ratio','Jiang 2026: abdominal distention','gi_recovery','SENSITIVITY',note='Symptom incidence, not time to flatus/defecation.')
admit(['V33-OD-0040'],'RESCUE_ANY_ZHANG2025','RR','risk ratio','Zhang 2025: any rescue analgesia demand','rescue_analgesia','SENSITIVITY',note='Not necessarily opioid-specific rescue; raw counts used because printed RR and P conflict.')
for rid,period,comp in [('V33-OD-0307','0-24H','USUAL'),('V33-OD-0308','0-24H','ACTIVE'),('V33-OD-0309','24-48H','USUAL'),('V33-OD-0310','24-48H','ACTIVE')]:
    admit([rid],'RESCUE_DEXKETOPROFEN_'+period+'_'+comp,'MD','mg dexketoprofen','Oztas 2019: nonopioid rescue '+period+' vs '+comp.lower(),'rescue_analgesia',note='Nonopioid rescue retained for registered rescue-analgesia question; not added to opioid quantity.',comparator='usual_care' if comp=='USUAL' else 'active_electrical')
for rid,period in [('V33-OD-0247','DAY0'),('V33-OD-0248','DAY1'),('V33-OD-0249','DAY2')]:
    admit([rid],'OPIOID_WONG_'+period,'MD','mg IV morphine','Wong 2006: PCA morphine '+period,'postoperative_opioid','SENSITIVITY',note='Source calendar-day interval is not necessarily elapsed 0-24/24-48/48-72 h. Correlated periods not combined as independent studies.')
admit(['V33-OD-0253'],'OPIOID_ELRAKSHY_4H','MD','mg IV morphine','El-Rakshy 2009: opioid during first 4 h','postoperative_opioid','SENSITIVITY',note='Outcome-specific N differs from 24-hour result. Partial period remains separate.')

# Valid source-defined satisfaction threshold, separate from four-category Gu data.
sat=next(r for r in read(D/'07_OUTCOME_COVERAGE/recovery_evidence.csv') if r['study']=='Yao 2015' and r['kind']=='Satisfaction')
r=dict(result_id='SAT-YAO2015-GE8',study='Yao 2015',trial_id=cohort['Yao 2015']['trial_id'],modality='TEAS',comparator_class='sham',n_i=35,n_c=36,events_i=18,events_c=6,source_pdf=sat['source_pdf'],source_sha256=sat['source_pdf_sha256'],source_location='Table 2, PDF p4',window='24 h')
add('SATISFACTION_YAO_GE8',[r],'RR','risk ratio','Yao 2015: satisfaction score >=8/10',family='satisfaction',basis='Previously source-verified satisfaction coverage',note='Source-defined threshold; one trial, not a common threshold pool.')
for rid,label in [('AUDIT-0157','very satisfied'),('AUDIT-0158','satisfied'),('AUDIT-0159','moderately satisfied'),('AUDIT-0160','not satisfied')]:
    admit([rid],'SATISFACTION_GU_'+rid,'RR','risk ratio','Gu 2019: '+label+' at 36 h','satisfaction','SENSITIVITY',note='Descriptive source category, not an invented composite. Four rows concern the same patients; table/prose conflict retained.')

# Eligible nonzero harm comparisons remain endpoint-specific; no generic all-harm
# pool mixes device skin reactions, postoperative bleeding, and all-cause death.
admit(['AUDIT-0183'],'HARMS_JIANG_ANY','RR','risk ratio','Jiang 2026: any reported adverse event','harms',note='Source safety-table denominator 294/293, not all 614 randomised. Components not added as independent patients.')
for rid,label in [('AUDIT-0186','rubefaction'),('AUDIT-0187','hydroderma')]:admit([rid],'HARMS_JIANG_'+rid,'RR','risk ratio','Jiang 2026: '+label,'harms','SENSITIVITY',note='Last two labels/values are vertically misaligned in the source table; descriptive as-printed, not definitive category adjudication.')
safety=read(D/'07_OUTCOME_COVERAGE/safety_evidence.csv')
def safetyrow(study,rid,ni,nc,ei,ec,window):
    src=next(r for r in safety if r['study']==study)
    return dict(study=study,result_id=rid,trial_id=cohort[study]['trial_id'],modality='TEAS',comparator_class='sham',n_i=ni,n_c=nc,events_i=ei,events_c=ec,window=window,source_pdf=src['source_pdf'],source_sha256=src['source_pdf_sha256'],source_location='PDF p'+src['pdf_pages'])
for r,label,note in [
 (safetyrow('Liu 2026 (burn)','HARMS-BURN-SKIN',44,44,1,1,'Electrode application'),'Burn trial: withdrawal for skin intolerance','Randomised denominators; not zero events among efficacy completers.'),
 (safetyrow('Zhang 2023','HARMS-ZHANG-RED',922,916,2,1,'Trial follow-up'),'Zhang 2023: treatment-related redness','Redness and itching are separate; unique affected patients cannot be summed.'),
 (safetyrow('Zhang 2023','HARMS-ZHANG-ITCH',922,916,0,1,'Trial follow-up'),'Zhang 2023: treatment-related itching','0.5 continuity correction; sparse single-trial result.'),
 (safetyrow('Liu 2026 (ESD)','ALLCAUSE-ESD-BLEED',64,65,2,1,'Postoperative follow-up'),'ESD trial: postoperative bleeding withdrawals','All-cause surgical complication; treatment attribution unreported.'),
 (safetyrow('He 2026 (hepatectomy/JIS)','ALLCAUSE-HE-DEATH',80,79,2,0,'6 months'),'Hepatectomy trial: all-cause deaths at 6 months','Attribution unreported; not treatment-caused mortality. 0.5 continuity correction.')]:
    add(r['result_id'],[r],'RR','risk ratio',label,role='SENSITIVITY' if r['result_id'].startswith('ALLCAUSE') else 'ADDITIONAL',family='harms',basis='Previously source-verified safety coverage',note=note)

# Unresolved modality remains separate; these are native, held descriptive rows.
for rid,label,measure,unit in [('V33-OD-0147','Long: pain 24 h','MD','0-10 points'),('AUDIT-0306','Long: pain 48 h','MD','0-10 points'),('AUDIT-0307','Long: hospital stay','MD','days'),('AUDIT-0308','Long: extubation time','MD','minutes'),('V33-OD-0150','Long: PONV','RR','risk ratio')]:
    admit([rid],'HELD_LONG_'+rid,measure,unit,label,'held_descriptive','HELD',note='EA/TEAS intervention identity remains unresolved. Not admitted to eligible modality-specific synthesis or efficacy conclusion.')
for rid,label in [('AUDIT-0311','stomach pain/distension'),('AUDIT-0312','hypotension'),('AUDIT-0313','hypertension'),('AUDIT-0314','tachycardia/bradycardia'),('AUDIT-0315','hypoxemia'),('AUDIT-0316','headache/vertigo'),('AUDIT-0317','delirious agitation')]:
    admit([rid],'HELD_LONG_'+rid,'RR','risk ratio','Long: '+label,'held_descriptive','HELD',note='Modality unresolved and denominators conflict elsewhere in report; native as-printed calculation only.')

# Complete leave-one-out and exact-link RoB restrictions for every new pooled
# principal/additional body. A missing assessment is never treated as low risk.
from new_source_data import sources, DESCRIPTIVE
fresh=sources(cohort)
freshid={r['result_id']:r for r in fresh}
write('new_source_extractions.csv',fresh)
write('new_descriptive_source_findings.csv',[dict(study=s,outcome=o,window=w,source_values=v,source_location=l,limitation=n,source_pdf=cohort[s]['source_pdf'],source_sha256=cohort[s]['source_sha256']) for s,o,w,v,l,n in DESCRIPTIVE])
def freshadd(ids,mid,measure,unit,label,family,role='ADDITIONAL',note=''):
    add(mid,[freshid[i] for i in ids],measure,unit,label,role,basis='New source-table extraction with visual page check',family=family,note=note or '; '.join(freshid[i]['source_qc'] for i in ids))
def extend(mid,rows):
    index=next(i for i,s in enumerate(specs) if s['model_id']==mid)
    data=[dict(r) for r in inputs if r['model_id']==mid]+[rederive(r,specs[index]['measure']) for r in rows]
    assert len({r['trial_id'] for r in data})==len(data),mid
    inputs[:]=[r for r in inputs if r['model_id']!=mid]+[dict(r,model_id=mid) for r in data]
    specs[index]['basis']='Adjudicated inputs plus explicitly logged source-table additions'
    specs[index]['note']='Fixed 40-report membership. Additional source tables checked; source and reporting limitations retained.'
    results[index]=fit(data,specs[index])
for mid in ['ponv24_TEAS_sham','ponv24_TEAS_sham_point_window_sensitivity','ponv24_TEAS_broad_sham_sensitivity']:extend(mid,[freshid['NEW-XIONG-PONV24']])
extend('vomiting24_TEAS_sham',[freshid['NEW-XIONG-VOMIT24']])
extend('flatus_TEAS_sham',[freshid['NEW-XIONG-FLATUS'],freshid['NEW-ZHANG25-FLATUS']])
extend('flatus_TEAS_sham_SMD_sensitivity',[freshid['NEW-XIONG-FLATUS'],freshid['NEW-ZHANG25-FLATUS']])
extend('flatus_TEAS_sham_with_Zheng2025_as_printed',[freshid['NEW-XIONG-FLATUS'],freshid['NEW-ZHANG25-FLATUS']])
ng=dict(freshid['NEW-NG-FLATUS-usual_care'])
for key in ['mean_i','mean_c','sd_i','sd_c']:ng[key]=ng[key]*24
extend('flatus_EA_usual',[ng])
extend('flatus_EA_usual_SMD_sensitivity',[ng])
freshadd(['NEW-XIONG-VOMIT48'],'VOMITING48_XIONG','RR','risk ratio','Xiong 2021: cumulative vomiting 0-48 h','ponv')
for period in ['24','48']:freshadd(['NEW-XIONG-ONLYNAUSEA'+period],'ONLY_NAUSEA'+period+'_XIONG','RR','risk ratio','Xiong 2021: only nausea 0-'+period+' h','ponv')
freshadd(['NEW-ZHOU-AMB','NEW-ZHANG25-AMB'],'FIRST_AMBULATION_TEAS_SHAM','MD','hours','Time to first ambulation: TEAS vs sham','functional_recovery',note='Two compatible first-ambulation mean/SD results; reporting conflicts in Zhang retained. Lee held separately for unresolved adult eligibility.')
for suffix,unit,label,family in [('LOS','days','postoperative discharge','length_of_stay'),('DRAIN','hours','pelvic drain removal','functional_recovery'),('LIQUID','hours','first oral liquid','gi_recovery'),('SOLID','hours','first solid food tolerance','gi_recovery')]:
    freshadd(['NEW-ZHANG25-'+suffix],'RECOVERY_ZHANG25_'+suffix,'MD',unit,'Zhang 2025: '+label,family,'SENSITIVITY',note=freshid['NEW-ZHANG25-'+suffix]['source_qc'])
freshadd(['NEW-ZHANG25-PONV'],'PONV_ZHANG25_UNSPECIFIED','RR','risk ratio','Zhang 2025: PONV, unspecified window','ponv','SENSITIVITY')
freshadd(['NEW-ZHANG23-MOB24'],'MOBILISATION24_ZHANG23','RR','risk ratio','Zhang 2023: mobilisation within 24 h','functional_recovery',note=freshid['NEW-ZHANG23-MOB24']['source_qc'])
freshadd(['NEW-ZHANG23-VOMIT'],'VOMITING_ZHANG23_UNSPECIFIED','RR','risk ratio','Zhang 2023: postoperative vomiting, window unspecified','ponv','SENSITIVITY')
for period in ['48','72']:freshadd(['NEW-ZHOU-PONV'+period],'PONV_ZHOU_POD'+period,'RR','risk ratio','Zhou 2025: PONV at POD'+('2' if period=='48' else '3'),'ponv','SENSITIVITY')
for comp in ['sham','usual_care']:
    for key,fam,lab in [('LOS','length_of_stay','hospital stay'),('WALK','functional_recovery','independent walking'),('DIET','gi_recovery','normal diet')]:
        freshadd(['NEW-NG-'+key+'-'+comp],'NG_'+key+'_'+comp.upper(),'MD','days','Ng 2013: '+lab+' vs '+comp.replace('_',' '),fam)
    for period in (['POD2','POD3'] if comp=='sham' else ['POD1','POD2','POD3']):
        freshadd(['NEW-NG-PAIN-'+period+'-'+comp],'NG_PAIN_'+period+'_'+comp.upper(),'MD','0-10 points','Ng 2013: pain '+period+' vs '+comp.replace('_',' '),'pain','SENSITIVITY')
# Held Lee combined arms: pool participants within trial, shared comparator once.
for comp in ['sham','usual_care']:
    a=freshid['NEW-LEE-AMB-HIGH-'+comp];b=freshid['NEW-LEE-AMB-LOW-'+comp]
    n=a['n_i']+b['n_i'];mean=(a['n_i']*a['mean_i']+b['n_i']*b['mean_i'])/n
    sd=math.sqrt(sum((x['n_i']-1)*x['sd_i']**2+x['n_i']*(x['mean_i']-mean)**2 for x in [a,b])/(n-1))
    combined=dict(a,n_i=n,mean_i=mean,sd_i=sd,result_id=a['result_id']+'+'+b['result_id'])
    add('HELD_LEE_AMB_'+comp.upper(),[combined],'MD','hours','Lee 2011: combined active-arm ambulation vs '+comp.replace('_',' '),'HELD',family='held_descriptive',basis='Source Tables 1/2/4, PDF p2/3; compatible arm combination',note='Age range includes 14; proportion aged >=18 not established. No adult-only main synthesis admission.')
freshadd(['NEW-XIONG-MOBILITY'],'HELD_XIONG_MOBILITY','MD','days as printed','Xiong 2021: mobility, unresolved printed unit','held_descriptive','HELD')
main_specs=list(specs)
for s in main_specs:
    rows=[dict(r) for r in inputs if r['model_id']==s['model_id']]
    if len(rows)<2 or s['role'] not in ['ADDITIONAL','PRINCIPAL']:continue
    for r in rows:
        add(s['model_id']+'_LOO_'+r['trial_id'],[x for x in rows if x['trial_id']!=r['trial_id']],s['measure'],s['unit'],s['label']+'; omit '+r['study'],
            'DIAGNOSTIC',family=s['family'],parent=s['model_id'],basis='Post-hoc complete leave-one-out analysis')
    for suffix,keep in [('NOT_HIGH_LINKED',{'Low','Some concerns'}),('LOW_ONLY',{'Low'})]:
        kept=[]
        for r in rows:
            ratings=[links.get(x,{}).get('overall','UNLINKED') for x in r['result_id'].split('+')]
            if all(x in keep for x in ratings):kept.append(r)
        add(s['model_id']+'_'+suffix,kept,s['measure'],s['unit'],s['label']+'; '+suffix,'DIAGNOSTIC',family=s['family'],parent=s['model_id'],
            note='Unassessed results excluded separately from high risk; no automatic study-level substitution.',basis='Exact outcome-specific RoB linkage')
# QoR denominator stress test is explicitly hypothetical, not recovered data.
rows=[dict(r) for r in inputs if r['model_id']=='QOR15_SHAM_24H']
for r in rows:
    if r['study']=='Wu 2025':r.update(n_i=48,n_c=49)
add('QOR15_WU_DENOMINATOR_STRESS',rows,'MD','QoR-15 points','QoR-15: hypothetical Wu denominator sensitivity','DIAGNOSTIC',family='quality_of_recovery',parent='QOR15_SHAM_24H',note='Printed means/SDs unchanged; not an observed complete-case analysis.')

write('model_inputs.csv',inputs);write('model_results_python.csv',results);write('model_specs.csv',specs);write('new_admission_decisions.csv',admissions)
used=collections.defaultdict(set)
for r in inputs:
    for rid in r['result_id'].split('+'):used[rid].add(r['model_id'])
previous=collections.defaultdict(set)
for r in read(OLD/'model_inputs.csv'):
    for rid in r.get('result_id','').split('+'):previous[rid].add(r['model_id'])
native_previous=read(OLD/'reextraction/processed_outcomes.csv')
for r in raw:
    if used[r['result_id']] or previous[r['result_id']]:continue
    if not any(k in r['family'].lower() for k in ['opioid','pcia','rescue analgesia']):continue
    for n in native_previous:
        if n['report']!=r['study']:continue
        keys=['n_i','n_c','mean_i','sd_i','mean_c','sd_c'] if r['data_type']=='Mean/SD' else (['n_i','n_c','events_i','events_c'] if r['data_type']=='Events/total' else [])
        if keys and all(r.get(k) and n.get(k) and abs(float(r[k])-float(n[k]))<1e-9 for k in keys):
            previous[r['result_id']].add('PREVIOUS_NATIVE_'+n['outcome_id'])
inventory=[]
roles={s['model_id']:s['role'] for s in specs}
for r in raw:
    status='QUANTITATIVE_COMPLETION' if used[r['result_id']] else ('PREVIOUS_OPIOID_ANALYSIS' if previous[r['result_id']] else ('PLACEHOLDER_NOT_AN_OBSERVED_OUTCOME' if r['data_type'] in ['Not reported','Not calculable'] else 'DESCRIPTIVE_OR_HELD'))
    mids=sorted(used[r['result_id']])
    if mids and all(roles[m]=='HELD' or 'DIAGNOSTIC' in m.upper() for m in mids):
        status='DESCRIPTIVE_OR_HELD'
    inventory.append(dict(r,completion_status=status,completion_models=';'.join(mids),completion_roles=';'.join(sorted({roles[m] for m in mids})),previous_models=';'.join(sorted(previous[r['result_id']]))))
write('all_40_result_inventory.csv',inventory)
write('recovery_and_satisfaction_inventory.csv',[r for r in read(D/'07_OUTCOME_COVERAGE/recovery_evidence.csv') if r['study'] in cohort])
write('safety_inventory.csv',[r for r in safety if r['study'] in cohort])
write('report_outcome_coverage.csv',[r for r in read(D/'07_OUTCOME_COVERAGE/report_coverage.csv') if r['study'] in cohort])
write('paired_opioid_pain_audit.csv',[r for r in read(D/'10_PAIRED_PAIN/paired_pain_registry.csv') if r['study'] in cohort])
write('protocol_characteristics.csv',[r for r in read(D/'14_CHARACTERISTICS/report_characteristics_wide.csv') if r['report_id'] in cohort])
zero=[]
for r in raw:
    if r['data_type']=='Events/total' and r['events_i'] and float(r['events_i'])==float(r['events_c'])==0:
        for arm in ['i','c']:
            n=int(float(r['n_'+arm]));zero.append(dict(result_id=r['result_id'],study=r['study'],outcome=r['outcome'],window=r['window'],arm=arm,events=0,N=n,risk=0,ci_low=0,ci_high=beta.ppf(.975,1,n),
                disposition='Double-zero: no informative RR; exact binomial arm CI only',source_pdf=r['source_pdf'],source_location=r['source_location']))
write('double_zero_arm_risks.csv',zero)
write('result_specific_bias_links.csv',[dict(model_id=r['model_id'],result_id=r['result_id'],study=r['study'],overall=';'.join(links.get(x,{}).get('overall','UNLINKED') for x in r['result_id'].split('+')),
    basis='Exact result link; existing assessment retained, no fresh human adjudication') for r in inputs if not next(s for s in specs if s['model_id']==r['model_id'])['parent_model_id']])

assert hashes=={str(p.relative_to(ROOT)):sha(p) for p in protected}
manifest=dict(date='2026-10-09',registration='CRD420261452908',scope='Registered outcomes restored within fixed 40 reports; post-hoc population restriction retained',
    reports=40,provisional_families=39,raw_result_rows=len(raw),model_count=len(results),fitted_models=sum(r['k']>0 for r in results),
    pooled_models=sum(r['k']>1 for r in results),empty_models=sum(r['k']==0 for r in results),source_hashes_verified=40,protected_hashes=hashes,
    source_inventory_counts=dict(collections.Counter(r['completion_status'] for r in inventory)),new_source_rows=len(fresh),new_human_adjudication=False)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='protected_hashes'},indent=2))
