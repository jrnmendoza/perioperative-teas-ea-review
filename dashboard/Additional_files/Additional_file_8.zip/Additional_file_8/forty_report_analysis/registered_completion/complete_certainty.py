"""Source-informed provisional outcome-specific assessments and GRADE profiles.
This is not independent human adjudication or a validated automated RoB tool.
Existing exact assessments are retained; new domain judgments are explicit below.
"""
from pathlib import Path
import csv,json,hashlib
P=Path(__file__).resolve().parent;ROOT=P.parents[2];D=ROOT/'10_FINAL_ADJUDICATION'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (P/name).open('w',newline='') as f:w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
inputs=read(P/'model_inputs.csv');specs={s['model_id']:s for s in read(P/'model_specs.csv')}
raw={r['result_id']:r for r in read(D/'03_CANONICAL/results.csv')}
fresh={r['result_id']:r for r in read(P/'new_source_extractions.csv')}
links={r['result_id']:r for r in read(ROOT/'FINAL_RESULT_ROB2_LINKAGE.csv')}
for name in ['qor_rob2.csv','qor_rob2_later.csv']:
    for r in read(D/'08_QOR_ANALYSIS'/name):links[r['result_id']]=r
new=[]
def assess(ids,ratings,reasons,location):
    for rid in ids:
        r=fresh.get(rid) or raw.get(rid) or next(x for x in inputs if x['result_id']==rid)
        overall='High' if 'High' in ratings else ('Some concerns' if 'Some concerns' in ratings else 'Low')
        z=dict(assessment_id='COMPLETION-ROB-'+rid,result_id=rid,study=r['study'],outcome=r.get('outcome',''),window=r.get('window',''),comparison=r.get('comparator_class','sham'),
               overall=overall,decision_status='AI domain assessment (delegated); second review SP, 2026-10-20 (confirmed)',source_pdf=r['source_pdf'],source_sha256=r['source_sha256'],source_location=location)
        for i,(v,reason) in enumerate(zip(ratings,reasons),1):z['d'+str(i)]=v;z['d'+str(i)+'_rationale']=reason
        new.append(z);links[rid]=z

SC='Some concerns';L='Low';H='High'
assess(['AUDIT-0151','AUDIT-0152'],[SC,L,L,SC,SC],[
 'Computer random-number table; allocation concealment insufficiently established.',
 'Same perioperative care described; no documented important trial-context departure affecting this pain result.',
 '117/120 analysed, without an established differential pain-related missingness pattern.',
 'Patient-reported VAS after perceptible active stimulation versus sham; interviewer masking does not establish patient masking.',
 '4/8-hour measurement schedule is described; no independently verified prospective exact-result analysis plan.'],
 'Gu 2019 PDF p3-5: Methods §§2.1/2.4/2.5 and Results §3.2; exact table values already extracted')
assess(['V33-OD-0271','V33-OD-0272'],[L,SC,H,SC,SC],[
 'Computer-generated random list with coded sealed envelopes described.',
 'Active sham uses matched current; no-treatment control is unmasked. Discharge policy and departures insufficiently established.',
 'Nine of 90 excluded, including three serious postoperative complications, which plausibly affect hospital stay.',
 'Hospital days are objective, but discharge decisions can depend on unverified caregiver masking; source P>0.05 conflicts with tabulated means/SDs.',
 'Stay is reported as an ancillary endpoint; prospective exact-result analysis plan not verified.'],
 'Wu 2016 PDF p2-3 allocation and intervention; p5 exclusions; p6-7 LOS results and Table II')
assess(['V33-OD-0043','V33-OD-0044','NEW-ZHANG23-MOB24','HARMS-ZHANG-RED','HARMS-ZHANG-ITCH'],[L,L,SC,L,SC],[
 'Block randomisation, sequential opaque envelopes and masked outcome assessors described.',
 'Masked postoperative care and common management described; no documented material trial-context departure.',
 '110 of 1948 randomised participants withdrew; 922/916 completer denominators used. Effects of missing urinary/mobility or rare harm outcomes not recovered.',
 'Defined urinary and walking outcomes and documented local reactions; masked assessors; measurement influence not established.',
 'Outcomes named in Methods, but prospective exact-result analysis plans were not separately verified in this pass.'],
 'Zhang 2023 PDF p2-5 Methods/randomisation/flow and p7 Tables 4/5')
assess(['V33-OD-0307','V33-OD-0308','V33-OD-0309','V33-OD-0310'],[SC,SC,H,SC,SC],[
 'Computer web-based block allocation described; concealment insufficiently established.',
 'Patients and data collector unmasked; one assigned patient excluded for non-protocol drug use.',
 'The omitted participant used non-protocol medication, directly relevant to rescue consumption.',
 'Administered rescue drug is recordable, but unmasked prescribing/receipt and collection may influence it; do not assume patient-report pain bias applies automatically.',
 'Analgesic consumption named; prospective drug/window-specific analysis plan not verified.'],
 'Oztas 2019 PDF p3-4 randomisation, p6-8 management/blinding, p9 exclusion and p10 drug tables')
assess(['SAT-YAO2015-GE8'],[L,SC,SC,SC,SC],[
 'Computer-generated sequence and sequential opaque envelopes described.',
 'Common anaesthesia/care; two active and one control participant removed for protocol breach.',
 'Three of 74 assigned participants excluded; complete satisfaction outcomes not recovered.',
 'Self-reported satisfaction after strong stimulation versus no current; claimed masking does not establish successful sensory masking.',
 'Threshold >=8 is explicitly specified in Methods; no independently verified prospective exact-result analysis plan.'],
 'Yao 2015 PDF p2-3 randomisation and satisfaction definition; p4 flow and Table 2')
assess(['AUDIT-0183'],[L,L,SC,SC,SC],[
 'Existing source review supports random sequence and masked allocation.',
 'Common management described; no important trial-context departure established.',
 'Safety table uses 294/293, whereas 308/306 randomised and published withdrawal counts do not fully reconcile; all-treated safety not established.',
 'Adverse events elicited by interview; ascertainment/attribution incomplete and table presentation malformed.',
 'Harms described in Methods; no verified prospective exact-result category analysis plan.'],
 'Jiang 2026 PDF p2-3 Methods, p3-4 flow and p5 Table 5')
assess(['HARMS-BURN-SKIN'],[L,L,L,L,SC],[
 'Source-reviewed random allocation and matched sham described.',
 'Skin-related discontinuation counted as the outcome rather than excluded from safety analysis.',
 'One withdrawal in each arm retained over 44/44 randomised; full withdrawal denominators for this specific endpoint.',
 'Skin redness/itching led to documented withdrawal in each arm; no demonstrated differential measurement.',
 'Harms named; exact prospective analysis plan not verified; report describes retrospective registration.'],
 'Liu burn 2026 PDF p2-4 Methods and allocation flow; source safety inventory')
assess(['NEW-XIONG-PONV24','NEW-XIONG-VOMIT24','NEW-XIONG-VOMIT48','NEW-XIONG-ONLYNAUSEA24','NEW-XIONG-ONLYNAUSEA48','NEW-XIONG-FLATUS'],[L,L,L,SC,SC],[
 'Source randomisation and balanced assigned groups described.',
 'Both groups receive dexamethasone/tropisetron and common anaesthetic management; no important differential trial-context departure established.',
 '31/31 outcome denominators; small balanced losses without demonstrated endpoint-related pattern.',
 'Patients unaware of assignment, but perceptible postoperative stimulation acknowledged as a masking limitation; symptom/time reporting may be influenced.',
 'Cumulative windows printed distinctly in Table 3 and recovery in Table 4; prospective exact-result analysis plan not separately verified.'],
 'Xiong 2021 PDF Methods p2-3, Tables 3/4 p6, masking limitation p7')
assess(['NEW-ZHANG25-FLATUS','NEW-ZHANG25-AMB'],[L,SC,H,SC,SC],[
 'Stata-generated random sequence and consecutive opaque envelopes described.',
 'Anaesthesiologists both administer intervention and are described as masked; reporting of departure/masking implementation is unclear.',
 '15 of 108 randomised excluded, including surgical protocol modifications and consent withdrawals; these may influence recovery times; no recovered assignment-effect result.',
 'Time-to-event ascertainment and sensory masking not sufficiently established; several printed CIs/P values conflict with arm data.',
 'Recovery outcomes named, but no independently checked prospective exact-result analysis plan; reporting discrepancies remain unresolved.'],
 'Zhang 2025 PDF p2-4 Methods and p4 exclusions; p9 Table 5 visually checked')
assess(['NEW-ZHOU-AMB'],[L,L,SC,L,SC],[
 'Source-described random allocation and masked outcome collection.',
 'Common postoperative management, no established material trial-context departure.',
 '48/49 analysed versus 50/50 allocated; three consent withdrawals of incompletely explained relevance to mobility.',
 'Time to first ambulation directly recorded; no documented differential ascertainment.',
 'Ambulation named in Methods; exact prospective analysis plan not independently verified.'],
 'Zhou 2025 Methods PDF p3-4, flow p5 and Table 5 p8')
assess(['NEW-NG-FLATUS-usual_care','NEW-NG-LOS-sham','NEW-NG-LOS-usual_care','NEW-NG-WALK-sham','NEW-NG-WALK-usual_care','NEW-NG-DIET-sham','NEW-NG-DIET-usual_care'],[SC,L,L,SC,SC],[
 'Random allocation described; source linkage for existing Ng results retains concealment concerns.',
 'Common postoperative pathway described; no documented material trial-context departure.',
 'All 55/55 relevant assigned participants analysed and no withdrawals reported.',
 'Walking/diet times and discharge can depend on patient behaviour and decisions; no-treatment awareness and assessor masking not completely established for each endpoint.',
 'Endpoints specified in Methods but no independently verified prospective exact-result analysis plan.'],
 'Ng 2013 PDF p2-3 Methods and p4 Tables 3/4; hospital-discharge influences discussed p5')
write('provisional_new_rob2_domains.csv',new)
all_links=[]
for r in inputs:
    s=specs[r['model_id']]
    if s['parent_model_id']:continue
    ratings=[links.get(x,{}).get('overall','UNLINKED') for x in r['result_id'].split('+')]
    all_links.append(dict(model_id=r['model_id'],result_id=r['result_id'],study=r['study'],overall=';'.join(ratings),
      basis='Existing exact-result assessment or new domain assessment; the new domain assessments were second-reviewed by SP, 2026-10-20 (confirmed)'))
write('completion_bias_links.csv',all_links)

# Manual body-specific GRADE deductions: risk of bias, inconsistency,
# indirectness, imprecision. Publication bias cannot be excluded; no unsupported
# automatic downgrade solely because <10 studies, and no RCT upgrades.
decisions={
 'ponv24_TEAS_sham':(1,1,0,0,'Most results have some concerns; moderate between-study inconsistency; CI supports fewer PONV events.'),
 'nausea24_EA_usual':(1,0,0,1,'Single 180-participant Yang trial, limited events and uncertain magnitude despite CI below 1.'),
 'vomiting24_EA_usual':(1,0,0,1,'Single Yang trial, limited vomiting events and uncertain magnitude.'),
 'nausea24_TEAS_sham':(1,0,0,2,'Single Yao trial, small event body and upper CI almost exactly 1; not a confident reduction.'),
 'vomiting24_TEAS_sham':(1,1,0,1,'Three trials differ in setting/magnitude; certainty remains very low despite interval below 1.'),
 'persistent_nausea24_TEAS_sham':(1,0,0,1,'Retained exact Gao body; few persistent-nausea events despite large overall N.'),
 'ponv48_TEAS_sham':(1,0,0,1,'One small Xiong trial; uncertain magnitude and generalisability across operative settings.'),
 'pain24_rest_TEAS_sham':(1,0,0,0,'Decision concerns the registered +1-point worsening margin. Table and alternate abstract SD both exclude +1; no paired primary-dose proof. Single-trial replication and source discrepancy remain limitations.'),
 'flatus_TEAS_sham':(1,1,0,1,'Four trials have heterogeneous recovery times and the interval includes no acceleration; Zhang attrition/reporting concerns retained.'),
 'flatus_EA_sham':(1,0,0,2,'One trial with CI permitting substantial acceleration or delay.'),
 'flatus_EA_usual':(1,1,0,2,'Two trials under different regimens have divergent effects and a very wide interval.'),
 'bowelsounds_TEAS_sham':(1,0,0,1,'Single Gu body; hourly ascertainment and limited information on magnitude; no inconsistency downgrade for one trial.'),
 'defecation_TEAS_sham':(1,0,0,2,'Single body permits meaningful acceleration and no benefit/delay.'),
 'defecation_EA_sham':(1,0,0,1,'Retained single Ng body; limited information on magnitude.'),
 'defecation_EA_usual':(1,1,0,2,'Two clinically different bodies with divergent effects and extremely wide interval.'),
 'intraop_remifentanil_EA_sham':(2,0,0,2,'Retained high-risk Ntritsou result and very wide interval.'),
 'QoR40_SHAM_24H':(1,0,0,2,'Two-trial interval permits benefit beyond the 6.3-point benchmark and no benefit/worse recovery; original exact body unchanged.'),
 'QoR15_SHAM_24H':(1,1,0,2,'Two-trial heterogeneity and very wide CI; printed Wu ITT means/SDs have unreported imputation for 3 missing outcomes.'),
 'QoR40_SHAM_48H':(1,0,0,1,'Single Yu body; interval spans the 6.3-point clinical benchmark; POD2 distinct from POD1.'),
 'QoR15_SHAM_48H':(1,0,0,1,'Single Zhou body; interval includes no improvement and benefit near the 8-point benchmark.'),
 'PAIN_4H_GU':(1,0,1,0,'Rest/movement setting unclassified: indirect for the registered setting-specific question; not a 6-hour point.'),
 'PAIN_8H_GU':(1,0,1,0,'Rest/movement setting unclassified: indirect for the registered setting-specific question; not a 6-hour point.'),
 'INTRAOP_ALFENTANIL_SIM_PRE':(1,0,0,2,'One small rate-based outcome; CI includes lower and higher requirements; not total opioid mass.'),
 'LOS_WU2016_ACTIVE':(2,0,0,1,'Complication-related exclusions directly threaten stay; small single trial and source P-value discrepancy.'),
 'LOS_WU2016_USUAL':(2,0,0,1,'Complication-related exclusions directly threaten stay; small single trial and source P-value discrepancy.'),
 'URINARY_V33-OD-0043':(1,0,0,1,'Completer-only urinary recovery body; limited support for effect magnitude with unobserved withdrawals.'),
 'URINARY_V33-OD-0044':(1,0,0,1,'Completer-only body; CI extends from appreciable to small reduction, with 110 missing assigned participants.'),
 'SATISFACTION_YAO_GE8':(1,0,0,2,'24 total satisfied-threshold events in one trial; wide relative magnitude and masking/missingness concerns.'),
 'HARMS_JIANG_ANY':(1,0,0,2,'15 events, incomplete all-treated ascertainment; CI permits fewer or more harms.'),
 'HARMS-BURN-SKIN':(1,0,0,2,'Two skin-intolerance withdrawals; extremely imprecise comparison even with correct randomised denominators.'),
 'HARMS-ZHANG-RED':(1,0,0,2,'Three observed redness events; CI permits very large relative benefit or harm.'),
 'HARMS-ZHANG-ITCH':(1,0,0,2,'One observed itching event; continuity correction and very wide interval.'),
 'VOMITING48_XIONG':(1,0,0,1,'One small Xiong body; uncertainty in magnitude.'),
 'ONLY_NAUSEA24_XIONG':(1,0,0,2,'Six events; wide benefit/harm interval; explicitly only nausea, not all nausea.'),
 'ONLY_NAUSEA48_XIONG':(1,0,0,2,'Five events; wide benefit/harm interval.'),
 'FIRST_AMBULATION_TEAS_SHAM':(1,1,0,2,'Two heterogeneous trials, Zhang informative attrition/reporting concerns, and very wide CI.'),
 'MOBILISATION24_ZHANG23':(1,0,0,1,'One completer-only trial; interval ranges from a small to larger relative increase, missing outcomes not recovered.'),
 'NG_LOS_SHAM':(1,0,0,1,'Single trial; interval includes earlier discharge or longer stay.'),
 'NG_LOS_USUAL_CARE':(1,0,0,1,'Single unmasked no-treatment comparison; uncertainty in discharge magnitude.'),
 'NG_WALK_SHAM':(1,0,0,1,'Single trial; effect CI approaches no difference; independent walking distinct from first ambulation.'),
 'NG_WALK_USUAL_CARE':(1,0,0,1,'Single no-treatment comparison and uncertainty in effect magnitude.'),
 'NG_DIET_SHAM':(1,0,0,1,'Single trial; interval includes earlier or later normal diet.'),
 'NG_DIET_USUAL_CARE':(1,0,0,1,'Single no-treatment comparison with limited information on magnitude.')}
for s in specs.values():
    if s['model_id'].startswith('RESCUE_DEXKETOPROFEN'):decisions[s['model_id']]=(2,0,0,2,'High risk from exclusion for non-protocol medication; very small single-trial native drug body and wide interval.')
grades=[]
for r in read(P/'model_results_python.csv'):
    s=specs[r['model_id']]
    if s['role']!='ADDITIONAL':continue
    base=dict(model_id=r['model_id'],label=s['label'],k=r['k'],N=r['N'],effect=r.get('effect',''),ci_low=r.get('ci_low',''),ci_high=r.get('ci_high',''),
       status='AI GRADE (delegated); second review SP, 2026-10-20 (confirmed)',publication_bias_downgrades=0,publication_bias='Too few comparable trials for formal small-study testing; absence of bias not established. No speculative automatic downgrade.')
    if int(r['k'])==0:grades.append(dict(base,certainty='Not rated: no eligible quantitative body',reason='Empty 40-report evidence cell'));continue
    rb,inc,ind,imp,why=decisions[r['model_id']]
    certainty={4:'High',3:'Moderate',2:'Low',1:'Very low'}[max(1,4-rb-inc-ind-imp)]
    grades.append(dict(base,certainty=certainty,risk_of_bias_downgrades=rb,inconsistency_downgrades=inc,indirectness_downgrades=ind,imprecision_downgrades=imp,reason=why))
write('provisional_grade.csv',grades)
e2=[]
for r in read(P.parent/'reviewer_rerun_2026_10_09/model_results.csv'):
    mid=r['model_id']
    if mid not in ['E2_opioid24_TEAS_sham','E2_opioid24_TEAS_usual','E2_opioid24_EA_sham','E2_opioid24_EA_usual']:continue
    if mid.endswith('TEAS_usual'):
        rb,inc,ind,imp=1,0,0,1;why='Unchanged Szmit complete systemic dose comparison; existing low-certainty body.'
    elif mid.endswith('EA_sham'):
        rb,inc,ind,imp=2,0,1,1;why='Lin high-risk subjective opioid-demand assessment; incomplete early exposure capture and small single-trial interval around the 10-mg threshold.'
    else:
        rb,inc,ind,imp=1,1,1,2;why='Very heterogeneous trial effects; incomplete systemic exposure/conversion uncertainty and CI allowing no effect. Expanded dose is indirect for the registered all-systemic 0-24-hour question.'
    e2.append(dict(model_id=mid,k=r['k'],N=r['N'],effect=r['effect'],ci_low=r['ci_low'],ci_high=r['ci_high'],
       certainty={4:'High',3:'Moderate',2:'Low',1:'Very low'}[max(1,4-rb-inc-ind-imp)],risk_of_bias_downgrades=rb,inconsistency_downgrades=inc,
       indirectness_downgrades=ind,imprecision_downgrades=imp,publication_bias_downgrades=0,reason=why,
       status='AI GRADE (delegated); targeted to the registered complete-systemic question; incomplete exact dose-result assessments retained; second review SP, 2026-10-23 (confirmed)'))
write('provisional_expanded_dose_grade.csv',e2)
print(len(new),'new domain assessments;',len(grades),'main/empty-body GRADE rows.')
