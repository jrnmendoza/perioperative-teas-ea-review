from pathlib import Path
import csv,json,math,hashlib,collections,re
P=Path(__file__).resolve().parent;ROOT=P.parents[2];OLD=P.parent/'reviewer_rerun_2026_10_09'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
    with (P/name).open('w',newline='') as f:
        fields=list(dict.fromkeys(k for r in rows for k in r));w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
py={r['model_id']:r for r in read(P/'model_results_python.csv')}
st={r['model_id']:r for r in read(P/'stata/model_results.csv')}
rr={r['model_id']:r for r in read(P/'independent_R_results.csv')}
assert (P/'stata/COMPLETED.txt').exists()
assert set(py)==set(st)==set(rr)
checks=[]
for name,other in [('Stata',st),('independent base R',rr)]:
    for mid,r in py.items():
        assert int(r['k'])==int(other[mid]['k']) and float(r['N'])==float(other[mid]['N'])
        for field in ['effect','ci_low','ci_high','tau2','I2']:
            if int(r['k'])==0 or r.get(field) in ['',None] or other[mid].get(field) in ['',None,'NA','.']:continue
            d=abs(float(r[field])-float(other[mid][field]));tol=1e-4+1e-7*abs(float(r[field]))
            checks.append(dict(engine=name,model_id=mid,field=field,absolute_difference=d,tolerance=tol,passed=d<=tol))
assert all(c['passed'] for c in checks)
write('numerical_verification.csv',checks)
z=read(P/'double_zero_arm_risks.csv');zz=read(P/'stata/double_zero_arm_risks.csv')
assert len(z)==len(zz)
for a,b in zip(z,zz):assert abs(float(a['ci_high'])-float(b['stata_ci_high']))<1e-7
log=(P/'stata/run.log').read_text()
assert not re.search(r'^r\(\d+\);',log,re.M)
captions=read(P/'figure_captions.csv')
for c in captions:
    for ext in ['pdf','svg','png','gph']:assert (P/'stata/figures'/f"{c['file']}.{ext}").exists()
manifest=json.loads((P/'manifest.json').read_text())
for filename,digest in manifest['protected_hashes'].items():assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()==digest
manifest.update(stata_models_verified=len(st),R_models_verified=len(rr),stata_figures=len(captions),numerical_verification_passed=True,
    max_effect_ci_engine_difference=max(c['absolute_difference'] for c in checks if c['field'] in ['effect','ci_low','ci_high']),
    double_zero_arm_CIs_verified=len(z),provisional_new_domain_assessments=len(read(P/'provisional_new_rob2_domains.csv')),
    provisional_grade_rows=len(read(P/'provisional_grade.csv')),provisional_expanded_dose_grade_rows=len(read(P/'provisional_expanded_dose_grade.csv')))
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
grades={r['model_id']:r for r in read(P/'provisional_grade.csv')}
tables=[]
for mid,r in py.items():
    if r['role']!='ADDITIONAL':continue
    s=st[mid]
    tables.append(dict(model_id=mid,outcome=r['label'],k=r['k'],N=r['N'],measure=r['measure'],unit=r['unit'],effect=s['effect'],ci_low=s['ci_low'],ci_high=s['ci_high'],
       I2=s['I2'],certainty=grades[mid]['certainty'],certainty_status=grades[mid]['status'],reports=r['reports'],note=r['note']))
write('registered_additional_results.csv',tables)

# Before-24-hour moderator coding is conservative. Original whole-course
# cumulative duration is not mistaken for delivered stimulation before endpoint.
chars=read(P/'protocol_characteristics.csv');coding=[]
exact={'Zhou 2025':30,'Chen 2015':30,'Chen 2015 (Hyperalgesia)':30,'Coura 2011':30,'Lee 2011':60,'Lin 2002':20,'Liu 2026 (burn)':30,
       'Long 2025':60,'Tu 2024':30,'Wu 2025':30,'Yao 2015':30,'Yu 2020':30,'Yeh 2010':60,'Yeh 2011':40,'Oztas 2019':120,'Wu 2016':60,'Sim 2002':45}
for r in chars:
    study=r['report_id'];text=r['timing'].lower()
    if 'arm-specific' in text:timing='Arm-specific preoperative/postoperative'
    elif 'perioperative' in text or ('preoperative' in text and ('postoperative' in text or 'intraoperative' in text)) or study in ['Wu 2016','Yang 2024']:timing='Multiple perioperative phases'
    elif 'intraoperative' in text:timing='Intraoperative-inclusive'
    elif 'preoperative' in text:timing='Preoperative only'
    elif 'postoperative' in text:timing='Postoperative only'
    else:timing='Insufficiently reported'
    before=exact.get(study,'Not determinable from current source schedule')
    if study=='Chen 2020':before='60 min plus intraoperative duration; exclude sessions starting at 24/48 h'
    if study=='Yang 2024':before='60 min completed before 24 h; separate 24-h session excluded pending endpoint-order verification'
    if study=='Seevaunnamtum 2016':before='Mean surgical duration 149 min: protocol-duration proxy, not individual delivered stimulation'
    if study=='An 2014':before='Induction to surgery completion: operative/anesthetic duration proxy, not a fixed dose'
    note='Planned source schedule, not independently measured adherence. Whole-course cumulative duration may include sessions after 24 h.'
    if study=='Lee 2011':note+=' Adult proportion unresolved: source age minimum 14 years; new pain and mobility calculations remain held.'
    if study=='Long 2025':note+=' Modality unresolved.'
    if study.startswith('Yeh'):note+=' Potential cohort overlap unresolved.'
    coding.append(dict(r,timing_before24_category=timing,planned_active_minutes_before24=before,before24_coding_note=note))
write('moderators_before24_descriptive.csv',coding)
primary=read(OLD/'model_results.csv')
dose={r['model_id']:r for r in primary}
newinputs=read(P/'model_inputs.csv');oldinputs=read(OLD/'model_inputs.csv')
direction=[]
for mid in ['opioid24_TEAS_sham','opioid24_EA_sham','opioid24_TEAS_usual','opioid24_EA_usual','E2_opioid24_TEAS_sham','E2_opioid24_EA_sham','E2_opioid24_TEAS_usual','E2_opioid24_EA_usual']:
    for r in oldinputs:
        if r['model_id']!=mid:continue
        y=float(r['yi']);se=math.sqrt(float(r['vi']));c=next(x for x in coding if x['report_id']==(r.get('report') or r['study']))
        direction.append(dict(model_id=mid,study=c['report_id'],modality=c['modality'],timing=c['timing_before24_category'],minutes_before24=c['planned_active_minutes_before24'],frequency=c['frequency'],intensity=c['intensity'],
             effect=y,ci_low=y-1.95996398454*se,ci_high=y+1.95996398454*se,descriptive_direction='Lower point estimate' if y<0 else ('Higher point estimate' if y>0 else 'Equal point estimate'),
             limitation='Descriptive association only; no protocol-effect coefficient or best regimen identified. Shared-arm comparisons must not be counted independently.'))
write('dose_protocol_effect_directions.csv',direction)
matrix=[
 (1,'Complete 0-24h systemic opioid dose','Already completed; retained','One TEAS/sham trial; EA/sham empty; dose figures unchanged.'),
 (2,'Approximately 24h rest and movement pain','Completed available quantitative/descriptive synthesis','One TEAS/sham rest-pain trial; unclassified-setting sensitivity separate; movement/EA rest quantitative cells empty.'),
 (3,'Timing, repetition, duration, frequency, intensity associations','Descriptive synthesis and feasibility check completed','40-report protocol table plus before-24h coding and dose effect directions. Primary dose strata <10 estimates: meta-regression not justified.'),
 (4,'10mg opioid reduction and pain worsening margin; 8mg/30% sensitivities','Paired audit and threshold assessment completed','No qualifying joint proof. Pain restoration does not change 7.70mg primary opioid point estimate.'),
 (5,'Usual care/no stimulation and active electrical comparators','Completed/retained separate comparisons','No cross-modality or cross-comparator overall pool.'),
 (6,'Later postoperative opioid and rescue analgesia','Completed/retained','Existing later-dose/rescue analyses retained; additional calendar-day and nonopioid rescue results added.'),
 (6,'Intraoperative opioid','Completed feasible native analyses','EA remifentanil and preoperative-EA alfentanil rate; postoperative-only intervention comparisons diagnostic, not treatment effects.'),
 (6,'Additional pain timepoints','Completed available native/descriptive analyses','Times/settings remain separate; medians/graph-only/unclear timing not converted into invented mean/SDs.'),
 (6,'PONV, nausea, vomiting','Completed','Nine-trial 24h TEAS/sham PONV; components and cumulative/POD windows separate.'),
 (6,'Global quality of recovery','Completed feasible scale/timepoint-specific analyses','QoR-40/QoR-15 separate; unavailable Gao supplement/Grech denominators and source-statistic conflicts remain held/descriptive.'),
 (6,'Satisfaction/acceptability','Completed feasible single-trial and descriptive analyses','Yao source-defined threshold; Gu categories; medians and mean-rank conflict separate.'),
 (6,'GI recovery, functional recovery, mobilisation and stay','Completed feasible analyses','Additional mobility/stay source tables located; unresolved unit or adult eligibility holds remain separate.'),
 (6,'Persistent opioid >30 days','Source coverage checked; no eligible result located','No effect estimate possible; day-30 complications or long-term pain do not establish persistent opioid use.'),
 (6,'Treatment harms and serious events','Completed descriptive/endpoint-specific analyses','19 pre-existing source harm inventory reports; rare-event CIs wide; all-cause deaths/bleeding not attributed to intervention.'),
 (7,'RoB 2/GRADE','Existing exact links plus provisional completion assessments','32 new domain assessments, 63 main/empty-body profiles and four expanded-dose profiles. The 32 domain assessments and 63 profiles were second-reviewed by SP on 2026-10-20 and the four expanded-dose profiles on 2026-10-23 (confirmed).'),
 (7,'Small-study tests and diagnostics','Feasibility and available diagnostics completed','Complete leave-one-out and risk restrictions for new main pools; all comparable groups <10, so funnel asymmetry tests not justified.')]
write('registered_question_completion.csv',[dict(objective=i,question=q,status=s,answer_or_limit=a) for i,q,s,a in matrix])

def fmt(mid,dec=2):
    r=st[mid];return f"{float(r['effect']):.{dec}f} ({float(r['ci_low']):.{dec}f} to {float(r['ci_high']):.{dec}f})"
report=f'''# Registered outcome completion within the 40-report dataset

9 October 2026. Correct registration: **CRD420261452908**. The owner requested all previously missing analyses for the current version. Registered pain and other secondary outcomes were restored within the same fixed 40 reports. The post-hoc restriction to opioid-reporting studies remains; this does not restore the original broader registered eligible population.

The numerical completion contains **202 model/check rows: 172 fitted estimates and 30 empty evidence cells**. This is not a count of trials. There are 47 fitted additional-outcome bodies; other rows are sensitivities, held descriptive calculations and diagnostics. The previous opioid analyses remain separate and unchanged. Stata and independent base R both verified all 202 rows, including identical trial and participant counts. Maximum effect/CI disagreement was {manifest['max_effect_ci_engine_difference']:.3g}. All 40 source PDF hashes and protected baseline hashes match.

## What changed in the results

| Outcome | Current 40-report estimate, 95% CI | Trials / participants | Certainty/status |
|---|---|---|---|
| Registered complete 24h opioid dose, TEAS/sham | −7.70 (−10.62 to −4.78) mg IV MME | 1 / 48 | Existing low; unchanged |
| Rest pain, approximately 24h, TEAS/sham | {fmt('pain24_rest_TEAS_sham')} points | 1 / 60 | Provisional moderate for +1 worsening-margin decision; source SD conflict disclosed |
| Unclassified-setting 24h pain, TEAS/sham | {fmt('pain24_unclassified_TEAS_sham')} points | 4 / 417 | Sensitivity only; I² 97.9%; cannot substitute for rest/movement co-outcome |
| Composite PONV 0-24h, TEAS/sham | RR {fmt('ponv24_TEAS_sham')} | 9 / 2848 | Provisional low |
| Vomiting 0-24h, TEAS/sham | RR {fmt('vomiting24_TEAS_sham')} | 3 / 1788 | Provisional very low |
| Global QoR-40 approximately 24h, TEAS/sham | {fmt('QoR40_SHAM_24H')} points | 2 / 131 | Provisional very low |
| Global QoR-15 approximately 24h, TEAS/sham | {fmt('QoR15_SHAM_24H')} points | 2 / 197 | Provisional very low |
| Time to first flatus, TEAS/sham | {fmt('flatus_TEAS_sham')} hours | 4 / 369 | Provisional very low |
| Time to first ambulation, TEAS/sham | {fmt('FIRST_AMBULATION_TEAS_SHAM')} hours | 2 / 190 | Provisional very low |
| Mobilisation within 24h, TEAS/sham | RR {fmt('MOBILISATION24_ZHANG23')} | 1 / 1838 | Provisional low |
| Satisfaction >=8/10, TEAS/sham | RR {fmt('SATISFACTION_YAO_GE8')} | 1 / 71 | Provisional very low |

Negative pain/dose/time MDs favour intervention; positive QoR MDs and mobilisation/satisfaction RRs above 1 favour intervention. Participant counts cannot be added across outcomes or shared-arm comparisons.

## Registered primary conclusion

Restoring pain did **not** establish the registered joint clinical criterion. The complete primary opioid point estimate remains below 10 mg and 8 mg. Its descriptive relative reduction exceeds 30%, but corresponding approximately-24-hour rest/movement pain is not established in that same primary-dose comparison. The paired audit contains 21 rows: 12 not usable for the registered criterion and nine with no same-trial pain result in the canonical register. Szmit discharge pain is now calculated separately and is not silently relabelled as a 24-hour measurement. EA/sham remains empty for complete systemic 0-24h opioid quantity.

Protocol characteristics are described for all 40 reports, with conservative before-24h coding and dose-effect direction tables. Sessions at 24/48h are not simply included in a before-24h stimulation total. No primary dose stratum reaches the registered meta-regression study-number requirement; no best regimen or moderator effect was estimated.

## Source additions and reviewer-relevant checks

The source discovery check located 36 additional table rows, including Xiong cumulative 24h PONV/vomiting, Zhang 2023 mobilisation, Zhou/Zhang 2025 first ambulation, and Ng hospital stay/independent walking/diet. Selected table pages were visually compared with PDFs. The 24h PONV body is therefore nine trials, rather than the initial eight-trial subset refit. All nine PONV leave-one-out CIs remain below RR=1; the exact-link low-risk-only restriction contains one trial and includes no effect. This low-risk result does not confirm the main-body benefit.

Means/SDs and event counts are recalculated rather than copying inconsistent source P values or intervals. Specific unresolved issues are retained: Yu table/abstract pain SDs; Zhang 2025 recovery CIs/P values; Zhou POD3 QoR P value; Wu 2016 hospital-stay significance; Jiang flow/safety denominator and table formatting; Xiong mobility units; Lee adult percentage; Jin GA/dose concentration; Long modality; Yeh overlap. As-printed sensitivity calculations do not resolve these ambiguities.

No additional records were added or removed from the PRISMA working selection. No author queries, external database search update or public PROSPERO amendment was performed. On the review owner's reports, SP second-reviewed and confirmed the 32 new domain assessments and 63 main/empty-body GRADE profiles (20 October 2026) and the rescue assessments, the four expanded-dose profiles and 62 sensitivity-result assessments (23 October 2026) and the three broader-dose assessments (Gu 2019, Zhang 2025, Lin 2002 versus usual care), also on 23 October 2026. Numerical replication does not validate source transcription or eliminate trial bias.

## All registered questions and outputs

The [completion matrix](registered_question_completion.csv) addresses every registered objective. Detailed [additional results](registered_additional_results.csv), [model inputs](model_inputs.csv), [Stata results](stata/model_results.csv), [source inventory](all_40_result_inventory.csv), [new table extractions](new_source_extractions.csv), [paired audit](paired_opioid_pain_audit.csv), [moderator table](moderators_before24_descriptive.csv), [provisional GRADE](provisional_grade.csv) and [expanded-dose GRADE](provisional_expanded_dose_grade.csv) document what is estimable and what remains unavailable. Held or descriptive findings are not counted as eligible pooled effects.

The [updated manuscript Results](RESULTS_REGISTERED_QUESTIONS_UPDATED.md) replaces the previous statements that pain, recovery, PONV and harms were outside this version's synthesis. The [new figure book](../../../output/pdf/registered_outcomes_40_report_stata_figures.pdf) and [editable Stata package](../../../output/figures/registered_outcomes_40_report_stata_figures.zip) contain 133 Stata-generated plots; [captions](figure_captions.csv) explain outcome/eligibility status. Some plots are explicitly held descriptive calculations or pre-treatment diagnostics, not efficacy evidence. The original opioid Stata figure book remains valid for its original outcomes.
'''
(P/'COMPLETION_REPORT.md').write_text(report)

# Preserve earlier manuscript paragraphs while replacing statements made obsolete
# by this explicitly authorised restoration of registered secondary outcomes.
draft=(OLD/'RESULTS_REGISTERED_QUESTIONS_DRAFT.md').read_text()
pain=f'''## Corresponding pain outcomes and clinical importance

Within the 40-report dataset, one TEAS-versus-sham trial provided a usable approximately-24-hour resting-pain mean/SD result (Yu 2020; 60 participants; MD {fmt('pain24_rest_TEAS_sham')} on a 0–10 scale). The table SD differed from the abstract SD; both transcriptions were examined separately, and both upper confidence limits remained below the registered +1-point pain-worsening margin. The certainty assessment was moderate for that margin-specific question. This single-trial pain finding did not provide corresponding pain evidence for the complete primary opioid-dose trial. No usable mean/SD body was available for approximately-24-hour movement pain or EA rest/movement pain within the focused dataset. Median-based rest/exercise pain, including Zhou 2025, was retained descriptively.

Four TEAS-versus-sham trials with unclassified rest/movement settings contributed to a separate 24-hour sensitivity analysis (417 participants; MD {fmt('pain24_unclassified_TEAS_sham')} points; I² = 97.9%). This highly heterogeneous sensitivity body did not replace the registered setting-specific pain outcomes. Pain at discharge in Szmit 2021 was analysed separately because its clock time and rest/movement setting were not established.

The registered TEAS-versus-sham complete opioid point estimate, a reduction of 7.70 mg, did not reach either the 10 mg threshold or the sensitivity threshold of 8 mg. Its descriptive reduction relative to the comparator mean was 50.7%, exceeding the alternative 30% relative threshold. This was a within-trial descriptive calculation, not a pooled ratio of means. The same-trial opioid–pain audit did not establish corresponding approximately-24-hour pain in this primary-dose contrast; therefore, restoring pain outcomes did not establish the registered joint clinical criterion. No registered EA-versus-sham assessment of clinical importance was possible.

'''
start=draft.index('## Corresponding pain outcomes and clinical importance');end=draft.index('## Protocol characteristics associated',start)
draft=draft[:start]+pain+draft[end:]
start=draft.index('### Other registered outcomes');end=draft.index('## Outcome-specific risk of bias and certainty',start)
secondary=f'''### Intraoperative opioid requirements and additional pain time points

EA versus sham intraoperative remifentanil consumption was supported by Ntritsou 2014 (70 participants; MD {fmt('intraop_remifentanil_EA_sham')} micrograms), with very-low-certainty evidence. Preoperative EA versus sham alfentanil requirement rate in Sim 2002 was imprecise (60 participants; MD {fmt('INTRAOP_ALFENTANIL_SIM_PRE')} micrograms/kg/min). Intraoperative doses measured before postoperative-only stimulation were retained as diagnostics rather than treatment effects. Additional pain measurements were analysed at their reported times and settings, without combining repeated observations as independent trials or converting unresolved medians/graphs into means and SDs.

### Postoperative nausea and vomiting

Nine TEAS-versus-sham trials with 2,848 participants contributed to cumulative 0–24-hour PONV (RR {fmt('ponv24_TEAS_sham')}; I² = 55.0%), with low-certainty evidence. All nine leave-one-out intervals remained below 1. A restriction to the single result assessed as low risk of bias was imprecise and included no difference (159 participants; RR {fmt('ponv24_TEAS_sham_LOW_ONLY')}). Vomiting was analysed separately (three trials, 1,788 participants; RR {fmt('vomiting24_TEAS_sham')}; very low certainty). Nausea in the single Yao trial was uncertain (71 participants; RR {fmt('nausea24_TEAS_sham')}); its upper confidence limit was close to 1.

EA versus usual care 0–24-hour nausea and vomiting were supported by one trial with 180 participants: RR {fmt('nausea24_EA_usual')} and RR {fmt('vomiting24_EA_usual')}, respectively, both low certainty. Later cumulative, postoperative-day, only-nausea and unspecified-window results were reported separately; interval counts were not summed into cumulative patient incidence.

### Quality of recovery and satisfaction

Two trials contributed to each sham-controlled approximately-24-hour global quality-of-recovery body. QoR-40 yielded MD {fmt('QoR40_SHAM_24H')} points (131 participants), and QoR-15 yielded MD {fmt('QoR15_SHAM_24H')} points (197 participants; I² = 91.8%). Both bodies were very low certainty and did not establish improved global recovery. A Wu denominator sensitivity retained the printed means/SDs while reducing denominators to reported follow-up counts; it was hypothetical rather than recovered complete-case evidence.

At approximately 48 hours, separate single-trial estimates were MD {fmt('QoR40_SHAM_48H')} QoR-40 points (60 participants) and MD {fmt('QoR15_SHAM_48H')} QoR-15 points (97 participants), each low certainty. Median/range, domain-only and uncertain-denominator QoR reports remained descriptive. The as-printed Zhou POD3 contrast was shown separately because its reported P value conflicted with the nearly identical means.

Yao 2015 reported greater receipt of a satisfaction score ≥8/10 with TEAS (71 participants; RR {fmt('SATISFACTION_YAO_GE8')}; very low certainty). Other satisfaction evidence comprised medians, four-category counts or narrative acceptability. The Liu ESD table/prose disagreement over means versus mean ranks remained unresolved; no common satisfaction pool was formed.

### Gastrointestinal recovery, mobilisation and hospital stay

Four TEAS-versus-sham trials with 369 participants contributed to time to first flatus (MD {fmt('flatus_TEAS_sham')} hours; I² = 71.4%; very low certainty). EA versus sham was supported by one trial (110 participants; MD {fmt('flatus_EA_sham')} hours); EA versus usual care included two trials (290 participants; MD {fmt('flatus_EA_usual')} hours). Both EA bodies were very low certainty. Bowel sounds, defecation, oral liquids, solid-food tolerance and normal diet were kept as separate outcomes.

Two TEAS-versus-sham trials provided compatible first-ambulation mean/SD results (190 participants; MD {fmt('FIRST_AMBULATION_TEAS_SHAM')} hours; I² = 78.9%; very low certainty). In a separate large trial, mobilisation within 24 hours was more frequent with TEAS (1,838 completers; RR {fmt('MOBILISATION24_ZHANG23')}; low certainty). This incidence outcome was not combined with time to first ambulation. EA versus sham and EA versus usual care independent-walking results were each single-trial estimates, rather than protocol moderator effects.

Hospital-stay evidence remained comparator- and source-specific. Ng 2013 showed MD {fmt('NG_LOS_SHAM')} days versus sham and MD {fmt('NG_LOS_USUAL_CARE')} days versus usual care (110 participants in each shared-arm comparison; low certainty). Wu 2016 showed shorter stays in calculations from printed means/SDs, but the source reported a non-significant overall comparison and excluded patients with serious complications; these findings were very low certainty. Zhang 2025 discharge results were retained as an as-printed sensitivity because the published effect/CI/P values did not reconcile. Median-based stay results were not converted to means. Lee pain and mobility calculations remained held from the adult-only main synthesis because the source age range included 14 years and the adult proportion was not established; Long modality and Xiong mobility-unit questions also remained unresolved.

### Treatment-related adverse events and persistent opioid use

Harms reporting was incomplete and heterogeneous. Source descriptions were retained separately from clinical complication outcomes, and rare nonzero events were analysed using their own denominators. Jiang 2026 reported eight versus seven adverse events (587 safety-table participants; RR {fmt('HARMS_JIANG_ANY')}); one participant per randomised arm withdrew for skin intolerance in the burn trial (1/44 versus 1/44). Zhang 2023 reported redness in two versus one participant and itching in zero versus one. These comparisons were very low certainty and did not establish a difference in harm risk. Double-zero findings were described using observed arm risks and exact binomial intervals, without creating an informative pooled RR.

Two deaths at six months in the TEAS arm versus none in the hepatectomy control arm, and postoperative bleeding withdrawals in the ESD trial, were recorded as all-cause findings without attributing them to stimulation. Reported absence of selected local events did not establish treatment safety. No eligible persistent postoperative opioid-use result beyond 30 days was located in the included source material.

'''
draft=draft[:start]+secondary+draft[end:]
start=draft.index('## Outcome-specific risk of bias and certainty')
draft=draft[:start]+'''## Outcome-specific risk of bias and certainty

Outcome-specific RoB 2 assessments and GRADE profiles were conducted by an AI assistant under the review team's delegation and checked by a second reviewer (SP), who confirmed them without changes. This includes the 32 domain assessments and 63 GRADE profiles added in the completion, the rescue-receipt assessments, and the certainty profiles for the broader first-day dose analyses: very low for TEAS/sham, EA/sham and EA/usual care, and low for the TEAS/usual-care Szmit comparison. Sensitivity-analysis results without an earlier exact assessment were assessed on 23 October 2026 and likewise confirmed by SP. Results held from synthesis were not assessed. A second reviewer's check of a first assessment is not an independent duplicate assessment.

Complete leave-one-out and exact-result risk restrictions were calculated for all newly pooled main bodies. TEAS and EA, comparator classes, outcome constructs and measurement periods remained separate; repeated observations and shared arms were not counted as independent trials. Funnel asymmetry tests and protocol meta-regression were not justified by the available numbers of comparable trials. The post-hoc 40-report population restriction, source holds and retrospective analytical additions remained explicit limitations.
'''
draft=draft.replace('## Study selection and characteristics\n\n','## Study selection and characteristics\n\nThe registered pain and other secondary outcomes were restored within the fixed opioid-reporting dataset for this completion; the post-hoc restriction of eligible reports remained.\n\n',1)
draft=draft.replace('Formal GRADE assessments were not completed for every expanded dose body.','Certainty profiles for these broader dose analyses are reported below.')
# 23 October 2026: dose restriction rerun after three new dose assessments (../reviewer_rerun_2026_10_09/
# dose_restriction_rerun_2026-10-23.csv) and second review of all assessments (SECOND_REVIEW_2026-10-23.md).
draft=draft.replace('Restriction to five trials with established outcome-specific assessments of low risk or some concerns yielded an MD of −8.43 mg (95% CI −17.78 to 0.91; 371 participants). This restriction excluded results lacking an exact risk-of-bias assessment as well as high-risk results; no low-risk-only quantitative body remained.',
    'Excluding results at high risk of bias left six trials and 488 participants (MD −7.11 mg, 95% CI −14.69 to 0.48). Every result in this analysis had an outcome-specific assessment; none was at low risk of bias, so a low-risk-only analysis was not possible.')
for _a,_b in [('provisional very-low-certainty','very-low-certainty'),('provisional low-certainty','low-certainty'),
              ('provisional very low certainty','very low certainty'),('provisional low certainty','low certainty'),
              ('provisionally very low certainty','very low certainty'),('provisionally low certainty','low certainty')]:
    draft=draft.replace(_a,_b)
(P/'RESULTS_REGISTERED_QUESTIONS_UPDATED.md').write_text(draft)
print('Verified and wrote completion report, manuscript Results, results table and registered-question matrix.')
