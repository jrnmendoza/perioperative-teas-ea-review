capture program drop niceaxis
program define niceaxis, rclass
    args lo hi ef
    local pad = (`hi'-`lo')*.05
    local lo = `lo'-`pad'
    local hi = `hi'+`pad'
    if "`ef'" == "1" {
        foreach set in ".25 .5 .75 1 1.5 2 3" ".1 .2 .5 1 2 5 10" ".01 .1 1 10 100" ".001 .01 .1 1 10 100 1000" {
            local labs ""
            local n=0
            local cmin=.
            local cmax=0
            foreach c of local set {
                if ln(`c') >= `lo' & ln(`c') <= `hi' {
                    local s = strtrim(string(`c',"%9.0g"))
                    if substr("`s'",1,1)=="." local s "0`s'"
                    local labs `"`labs' `c' "`s'""'
                    local ++n
                    local cmin=min(`cmin',`c')
                    local cmax=max(`cmax',`c')
                }
            }
            if `n'<=8 & `n'>=2 & ln(`cmax')-ln(`cmin')>=.5*(`hi'-`lo') continue,break
        }
        return local range = "`=exp(`lo')' `=exp(`hi')'"
        return local labels `"`labs'"'
    }
    else {
        local raw=(`hi'-`lo')/3
        local p=10^floor(log10(`raw'))
        local step ""
        foreach m in 1 2 2.5 5 10 {
            if "`step'"=="" & `m'*`p'>=`raw' local step=`m'*`p'
        }
        local a=floor(`lo'/`step')*`step'
        local b=ceil(`hi'/`step')*`step'
        return local range "`a' `b'"
        return local labels "`a'(`step')`b'"
    }
end

capture program drop exportfigure
program define exportfigure
    args name
    graph save "$ST/figures/`name'.gph", replace
    graph export "$ST/figures/`name'.pdf", as(pdf) replace
    graph export "$ST/figures/`name'.svg", as(svg) replace
    graph export "$ST/figures/`name'.png", as(png) replace width(2600)
end

capture program drop forest
program define forest
    args mid name title subtitle customaxis
    use "$ST/inputs.dta", clear
    keep if model_id == "`mid'"
    local k = _N
    assert `k' > 0
    quietly summarize n_i
    local N = r(sum)
    quietly summarize n_c
    local N = `N' + r(sum)
    local ef ""
    local axis "Mean difference (mg IV morphine equivalents)"
    local null = 0
    if effect_measure[1] == "RR" {
        local ef "eform"
        local axis "Risk ratio"
        local null = 1
    }
    if "`customaxis'" != "" local axis "`customaxis'"
    meta set s_yi s_se, studylabel(studylabel) random(reml)
    local opt se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
    local summ noosigtest
    local cols _id _plot _esci _weight
    local notes "`k' trial(s), `N' analyzed participants. REML; safeguarded Knapp-Hartung 95% confidence intervals."
    local hstats ""
    quietly gen double individual_lb = s_yi-invnormal(.975)*s_se
    quietly gen double individual_ub = s_yi+invnormal(.975)*s_se
    quietly summarize individual_lb
    local xlo=min(r(min),0)
    quietly summarize individual_ub
    local xhi=max(r(max),0)
    if `k' == 1 {
        local summ nooverall noohetstats noohomtest noosigtest
        local cols _id _plot _esci
        local notes "One trial, `N' participants. Within-trial normal 95% confidence interval; not pooled."
    }
    else {
        preserve
        use "$ST/model_results.dta", clear
        keep if model_id == "`mid'"
        local xlo=min(`xlo',ci_lb[1])
        local xhi=max(`xhi',ci_ub[1])
        local i2text = strtrim(string(I2[1],"%4.1f"))
        local tau = strtrim(string(tau2[1],"%7.3f"))
        local summ ohetstatstext("Heterogeneity: I{superscript:2} = `i2text'%, {&tau}{superscript:2} = `tau'") noohomtest noosigtest
        if `k' >= 5 {
            local xlo=min(`xlo',pi_lb[1])
            local xhi=max(`xhi',pi_ub[1])
            local lo = pi_lb[1]
            local hi = pi_ub[1]
            if "`ef'" != "" {
                local lo = exp(`lo')
                local hi = exp(`hi')
            }
            local lo = strtrim(string(`lo',"%7.2f"))
            local hi = strtrim(string(`hi',"%7.2f"))
            local hstats "Approximate prediction interval: `lo' to `hi' (t, k-1 df). Sparse-study estimate."
        }
        restore
    }
    local xline ""
    if "`mid'" == "opioid24_TEAS_sham" local xline xline(-10,lpattern(shortdash) lcolor(orange))
    if "`mid'" == "opioid24_TEAS_sham" local xlo=min(`xlo',-10)
    niceaxis `xlo' `xhi' `=cond("`ef'"=="",0,1)'
    local axisopts `"xscale(range(`r(range)')) xlabel(`r(labels)',labsize(small))"'
    local ys = max(3.6,2.6+.35*`k')
    meta forestplot `cols', `opt' `ef' `summ' nullrefline `xline' `axisopts' ///
        columnopts(_esci, supertitle("Effect")) ///
        title("`title'",size(medium)) subtitle("`subtitle'",size(small)) ///
        xtitle("`axis'") note("`notes'" "`hstats'",size(vsmall)) ///
        xsize(10) ysize(`ys') name(g,replace)
    exportfigure "`name'"
    meta clear
end

