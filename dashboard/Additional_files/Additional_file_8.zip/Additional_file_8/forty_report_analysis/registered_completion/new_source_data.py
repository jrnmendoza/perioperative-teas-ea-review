"""Additional registered outcomes located by the 40-report source-text check.
Selected table pages were visually checked against the PDF before admission.
"""
def sources(cohort):
    rows=[]
    def row(study,rid,outcome,window,page,modality,comp,ni,nc,mi=None,si=None,mc=None,sc=None,ei=None,ec=None,unit='',note=''):
        r=dict(study=study,result_id=rid,trial_id=cohort[study]['trial_id'],outcome=outcome,window=window,source_location=page,
          source_pdf=cohort[study]['source_pdf'],source_sha256=cohort[study]['source_sha256'],modality=modality,comparator_class=comp,n_i=ni,n_c=nc,
          mean_i=mi,sd_i=si,mean_c=mc,sd_c=sc,events_i=ei,events_c=ec,unit=unit,source_qc=note,source_review='Source table transcription; PDF page visually checked')
        rows.append(r);return r
    for rid,outcome,window,ei,ec in [('NEW-XIONG-PONV24','PONV','0-24 h',12,24),('NEW-XIONG-VOMIT24','Vomiting','0-24 h',10,20),
           ('NEW-XIONG-VOMIT48','Vomiting','0-48 h',11,21),('NEW-XIONG-ONLYNAUSEA24','Only nausea','0-24 h',2,4),('NEW-XIONG-ONLYNAUSEA48','Only nausea','0-48 h',2,3)]:
        row('Xiong 2021',rid,outcome,window,'Table 3, PDF p6','TEAS','sham',31,31,ei=ei,ec=ec,unit='participants',
           note='Cumulative rows are printed separately from interval rows. Only-nausea excludes vomiting and is not interchangeable with any nausea.')
    row('Xiong 2021','NEW-XIONG-FLATUS','Time to first flatus','Postoperative','Table 4, PDF p6','TEAS','sham',31,31,23.6,7.7,32.3,13.2,unit='hours')
    row('Xiong 2021','NEW-XIONG-MOBILITY','Time to mobility','Postoperative','Table 4, PDF p6','TEAS','sham',31,31,27.5,11.9,29.6,13.7,unit='days as printed',note='Table labels d despite values 27.5/29.6 and a 3-day hospital stay. Unit unresolved; held native calculation only.')
    for rid,outcome,mi,si,mc,sc,unit in [('NEW-ZHANG25-FLATUS','Time to first flatus',13.14,10.53,16.60,10.36,'hours'),
          ('NEW-ZHANG25-AMB','Time to first ambulation',19.91,5.88,28.31,19.01,'hours'),('NEW-ZHANG25-LOS','Time to postoperative discharge',4.07,1.68,6.06,4.28,'days'),
          ('NEW-ZHANG25-DRAIN','Time to pelvic drain removal',19.95,7.89,29.10,17.51,'hours'),('NEW-ZHANG25-LIQUID','Time to first oral liquid intake',7.11,5.66,9.16,5.39,'hours'),
          ('NEW-ZHANG25-SOLID','Time to first solid food tolerance',13.11,7.53,15.16,5.79,'hours')]:
        row('Zhang 2025',rid,outcome,'Postoperative','Table 5, PDF p9','TEAS','sham',45,48,mi,si,mc,sc,unit=unit,
           note='Several printed MDs/CIs/P values fail to reconcile with arm means/SDs. Unadjusted as-printed arm contrast, not a resolution of source reporting discrepancies.')
    row('Zhang 2025','NEW-ZHANG25-PONV','PONV','Postoperative; exact complication window unspecified','Table 6, PDF p9','TEAS','sham',45,48,ei=14,ec=25,unit='participants')
    row('Zhou 2025','NEW-ZHOU-AMB','Time to first ambulation','Postoperative','Table 5, PDF p8','TEAS','sham',48,49,17.50,3.40,19.42,4.03,unit='hours')
    for rid,window,ei,ec in [('NEW-ZHOU-PONV48','POD2 (~48 h)',5,9),('NEW-ZHOU-PONV72','POD3 (~72 h)',2,3)]:
        row('Zhou 2025',rid,'PONV',window,'Table 4, PDF p8','TEAS','sham',48,49,ei=ei,ec=ec,unit='participants',note='POD-specific incidence, not cumulative 0-48/0-72 h.')
    row('Zhang 2023','NEW-ZHANG23-MOB24','Mobilisation within 24 h','0-24 h','Table 4, PDF p7','TEAS','sham',922,916,ei=573,ec=517,unit='participants',note='Defined weight-bearing activities outside ward, total walking distance 250-500 m. Positive RR favours TEAS; not time-to-first-mobilisation.')
    row('Zhang 2023','NEW-ZHANG23-VOMIT','Vomiting','Postoperative; Table 4 does not establish cumulative 0-24 h','Table 4, PDF p7','TEAS','sham',922,916,ei=231,ec=246,unit='participants')
    for comp,mc,sc in [('sham',2.3,1.1),('usual_care',2.6,1.1)]:
        row('Ng 2013','NEW-NG-FLATUS-'+comp,'Time to first flatus','Postoperative','Tables 3/4, PDF p4','EA',comp,55,55,2.0,.9,mc,sc,unit='days',note='Multiply both arm means and SDs by 24 for an hours MD; no pooled mean/SD substitution.')
    for comp,mc,sc in [('sham',6.8,1.7),('usual_care',8.5,4.8)]:
        row('Ng 2013','NEW-NG-LOS-'+comp,'Hospital stay','Hospitalisation','Tables 3/4, PDF p4','EA',comp,55,55,6.5,2.2,mc,sc,unit='days')
    for comp,mc,sc in [('sham',3.3,1.1),('usual_care',3.8,1.8)]:
        row('Ng 2013','NEW-NG-WALK-'+comp,'Time to walk independently','Postoperative','Tables 3/4, PDF p4','EA',comp,55,55,2.8,1.5,mc,sc,unit='days',note='Independent walking kept separate from any first ambulation.')
    for comp,mc,sc in [('sham',4.1,.8),('usual_care',4.8,2.0)]:
        row('Ng 2013','NEW-NG-DIET-'+comp,'Time to resume normal diet','Postoperative','Tables 3/4, PDF p4','EA',comp,55,55,4.0,1.1,mc,sc,unit='days')
    for comp,period,mi,si,mc,sc in [('sham','POD2',3.2,1.6,4.6,2.0),('sham','POD3',2.1,1.2,3.4,2.2),('usual_care','POD1',5.6,2.0,5.5,2.3),
           ('usual_care','POD2',3.2,1.6,4.2,2.0),('usual_care','POD3',2.1,1.2,3.2,1.8)]:
        row('Ng 2013','NEW-NG-PAIN-'+period+'-'+comp,'VAS pain intensity',period,'Tables 3/4, PDF p4','EA',comp,55,55,mi,si,mc,sc,unit='0-10 points',note='Rest/movement not classified. POD kept as published, not exact elapsed clock hours.')
    # Lee population includes a 14-year-old minimum; adult proportion is unverified.
    for comp,nc,mc,sc in [('sham',12,33.75,3.11),('usual_care',13,32.50,2.41)]:
        row('Lee 2011','NEW-LEE-AMB-HIGH-'+comp,'Time to first ambulation','Postoperative','Table 4, PDF p3','TEAS',comp,12,nc,33.13,3.18,mc,sc,unit='hours',note='Age range 14-59; adult proportion unverified. Two active arms may be combined, shared comparator once.')
        row('Lee 2011','NEW-LEE-AMB-LOW-'+comp,'Time to first ambulation','Postoperative','Table 4, PDF p3','TEAS',comp,10,nc,29.90,2.95,mc,sc,unit='hours',note='Age range 14-59; adult proportion unverified. Two active arms may be combined, shared comparator once.')
    return rows

DESCRIPTIVE=[
 ('Zhang 2023','Hospital stay','Hospitalisation','Median (IQR), days: 7 (6-10) vs 8 (6-10)','Table 4, PDF p7','No mean/SD conversion; skewed distribution.'),
 ('Yang 2024','Time to ambulation','Postoperative','Median (IQR), h: 6 (5-7) vs 6 (5-7)','Table 3, PDF p6','No mean/SD conversion.'),
 ('Yang 2024','Hospital stay','Hospitalisation','Median (IQR), days: 6 (5-7) vs 6 (5-7)','Table 3, PDF p6','No mean/SD conversion.'),
 ('Wu 2025','Hospital stay categories','Acute hospitalisation','<24 h: 1/50 vs 0/50; 24-36 h: 9/50 vs 9/50; 36-48 h: 40/50 vs 40/50; 48-72 h: 0/50 vs 1/50','Table 2, PDF p6','No mean stay calculated from category midpoints.'),
 ('Xiong 2021','Hospital stay','Hospitalisation','Median (IQR), days: 3 (3-4) vs 3 (3-4)','Table 4, PDF p6','No mean/SD conversion.'),
 ('Xiong 2021','Time to oral diet','Postoperative','Median (IQR), h: 47.6 (42-75) vs 46 (42-51)','Table 4, PDF p6','No mean/SD conversion.'),
 ('Zhou 2025','Rest and exercise pain','POD1/2/3','Rest medians: POD1 3 (3-4) vs 4 (4-5); POD2 2 (1-2) vs 2 (2-2); POD3 1 (1-1) vs 1 (1-1). Exercise: POD1 4 (4-5) vs 5 (4-6); POD2 2 (2-3) vs 4 (3-4); POD3 2 (2-2) vs 2 (2-2)','Table 3, PDF p8','Median/IQR cannot supply mean-difference pain margin.'),
]
