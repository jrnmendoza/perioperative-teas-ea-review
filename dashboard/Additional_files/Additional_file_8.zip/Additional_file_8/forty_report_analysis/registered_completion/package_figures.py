"""Merge unmodified vector Stata figures and package reproducible outputs."""
from pathlib import Path
import csv, json, hashlib, zipfile
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from pypdf import PdfReader, PdfWriter

P = Path(__file__).resolve().parent
ROOT = P.parents[2]
OUT = ROOT / 'output'
(OUT / 'pdf').mkdir(parents=True, exist_ok=True)
(OUT / 'figures').mkdir(parents=True, exist_ok=True)
QA = P / 'stata' / 'qa'
QA.mkdir(exist_ok=True)
rows = list(csv.DictReader((P / 'figure_captions.csv').open()))
cover = QA / 'cover.pdf'
c = canvas.Canvas(str(cover), pagesize=(720, 480))
c.setTitle('Registered outcomes within the 40-report dataset: Stata figures')
c.setFillColor(HexColor('#142b3c'))
c.setFont('Helvetica-Bold', 22)
c.drawString(38, 429, 'Registered outcomes within the 40-report dataset')
c.setFont('Helvetica', 15)
c.drawString(38, 404, 'Stata forest plots and source-specific sensitivity results')
style = ParagraphStyle('body', fontName='Helvetica', fontSize=11, leading=16,
                       textColor=HexColor('#253746'))
paras = [
    '<b>9 October 2026 | PROSPERO CRD420261452908</b>',
    'These 133 additional figures accompany the completed analyses within the fixed '
    '40-report working dataset (39 provisional trial families). They cover registered '
    'secondary outcomes, sensitivities, diagnostics and held descriptive calculations. '
    'The original opioid figure book remains a separate companion.',
    '<b>Study selection:</b> restriction to opioid-reporting articles was post hoc. '
    'Restoring secondary outcomes within these reports does not restore the full '
    'registered eligible population. The 40 reports are not pooled together.',
    '<b>Interpretation:</b> plot subtitles identify additional outcomes, sensitivities '
    'and held values. Held results have unresolved eligibility or source issues and '
    'must not be cited as established treatment effects. Risk-of-bias and certainty '
    'updates remain provisional pending independent human adjudication.',
    '<b>Methods:</b> Stata 19.5 SE; REML and safeguarded Knapp-Hartung intervals for '
    'pooled bodies; normal intervals for individual trials. All 202 model/check rows '
    'were verified against independent R and Python calculations. Numerical agreement '
    'does not resolve source-reporting ambiguities.',
    '<b>Navigation:</b> PDF bookmarks identify each figure. The companion ZIP contains '
    'editable Stata graphs, PDF/SVG/PNG exports, inputs, code, captions and results. '
    'Figure numbers are working-book identifiers, not final manuscript numbering.',
]
y = 367
for text in paras:
    obj = Paragraph(text, style)
    _, height = obj.wrap(644, 460)
    obj.drawOn(c, 38, y-height)
    y -= height+14
assert y > 10, y
c.save()
writer = PdfWriter()
writer.append(PdfReader(cover))
writer.add_outline_item('Overview and interpretation', 0)
for row in rows:
    src = P / 'stata' / 'figures' / (row['file']+'.pdf')
    doc = PdfReader(src)
    assert len(doc.pages) == 1, src
    writer.append(doc, import_outline=False)
    writer.add_outline_item(f"{row['figure']}. {row['title']} [{row['role']}]", len(writer.pages)-1)
writer.add_metadata({'/Title': '40-report registered outcome completion: Stata figures',
                     '/Subject': 'CRD420261452908; provisional working selection and assessments',
                     '/Author': 'Perioperative TEAS/EA review working analysis'})
book = OUT / 'pdf' / 'registered_outcomes_40_report_stata_figures.pdf'
with book.open('wb') as f:
    writer.write(f)
assert len(PdfReader(book).pages) == len(rows)+1
manifest = json.loads((P/'manifest.json').read_text())
manifest.update(figure_book=str(book.relative_to(ROOT)),
                figure_zip='output/figures/registered_outcomes_40_report_stata_figures.zip',
                figure_book_pages=len(rows)+1,
                figure_book_sha256=hashlib.sha256(book.read_bytes()).hexdigest())
(P/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
files = ['manifest.json', 'COMPLETION_REPORT.md', 'RESULTS_REGISTERED_QUESTIONS_UPDATED.md',
         'registered_question_completion.csv', 'registered_additional_results.csv',
         'model_inputs.csv', 'model_specs.csv', 'figure_captions.csv',
         'numerical_verification.csv', 'independent_R_results.csv',
         'run_stata.do', 'forest_program.do', 'forest_calls.do', 'refresh_figures.do',
         'prepare_figures.py', 'verify_completion.R', 'build_completion.py',
         'new_source_data.py', 'complete_certainty.py', 'finalize_completion.py',
         'package_figures.py', 'refresh_labels.do', 'new_source_extractions.csv', 'new_admission_decisions.csv',
         'new_descriptive_source_findings.csv', 'all_40_result_inventory.csv',
         'paired_opioid_pain_audit.csv', 'moderators_before24_descriptive.csv',
         'dose_protocol_effect_directions.csv', 'completion_bias_links.csv',
         'provisional_new_rob2_domains.csv', 'provisional_grade.csv',
         'provisional_expanded_dose_grade.csv', 'double_zero_arm_risks.csv',
         'stata/model_results.csv', 'stata/model_results.dta', 'stata/inputs.dta',
         'stata/double_zero_arm_risks.csv', 'stata/run.log', 'stata/COMPLETED.txt']
zpath = OUT/'figures'/'registered_outcomes_40_report_stata_figures.zip'
with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(book, book.name)
    for name in files:
        src = P/name
        assert src.is_file(), src
        z.write(src, name)
    for row in rows:
        for ext in ['pdf','svg','png','gph']:
            name = 'stata/figures/'+row['file']+'.'+ext
            z.write(P/name, name)
    z.writestr('README.txt',
        'Registered-outcome completion within fixed 40-report working membership.\n'
        'These additions supplement the original opioid analysis and figure book.\n'
        'See COMPLETION_REPORT.md for results and unresolved source/eligibility issues.\n'
        'From the original review workspace root, Stata 19.5 can rerun run_stata.do;\n'
        'refresh_figures.do refreshes plots from the saved verified inputs/results.\n'
        'Scripts use the original review workspace paths and canonical files.\n'
        'Saved inputs.dta, model_results.dta and forest files are included for inspection.\n'
        'Source PDFs and canonical upstream archives are not redistributed in this ZIP.\n'
        'The estimates can be reproduced from model_inputs.csv without source PDFs.\n'
        'No independent human adjudication or public registration amendment was made.\n')
print(json.dumps({'pdf':str(book), 'pages':len(rows)+1,'zip':str(zpath),
                  'zip_bytes':zpath.stat().st_size},indent=2))
