from pathlib import Path
import csv
P=Path(__file__).resolve().parent
OLD=P.parent/'reviewer_rerun_2026_10_09'
text=(OLD/'stata_figures.do').read_text()
program=text[text.index('capture program drop niceaxis'):text.index('forest "opioid24_TEAS_sham"')]
program=program.replace('Risk ratio for additional opioid receipt','Risk ratio')
program=program.replace("local raw=(`hi'-`lo')/5", "local raw=(`hi'-`lo')/3")
program=program.replace("xlabel(`r(labels)')", "xlabel(`r(labels)',labsize(small))")
(P/'forest_program.do').write_text(program)
read=lambda name:list(csv.DictReader((P/name).open()))
results={r['model_id']:r for r in read('model_results_python.csv')}
inputs=read('model_inputs.csv')
seen=set();captions=[];calls=[]
for s in read('model_specs.csv'):
    mid=s['model_id'];r=results[mid]
    if r['k']=='0' or s['role']=='DIAGNOSTIC':continue
    signature=tuple(sorted((x['result_id'],x['n_i'],x['n_c'],x['yi'],x['vi'],s['measure']) for x in inputs if x['model_id']==mid))
    if signature in seen:continue
    seen.add(signature)
    i=len(captions)+1;name=f'{i:02d}_{mid}'
    title=s['label'].replace('_',' ')
    if len(title)>92:title=mid.replace('_',' ')
    subtitle='Fixed 40-report dataset; '+('held descriptive values; eligibility unresolved' if s['role']=='HELD' else ('additional registered outcome' if s['role']=='ADDITIONAL' else 'separate sensitivity/descriptive result'))
    if 'DIAGNOSTIC' in mid.upper():
        subtitle='Fixed 40-report dataset; pre-treatment measurement; descriptive diagnostic only'
    axis=('Risk ratio' if s['measure']=='RR' else ('Hedges g' if s['measure']=='SMD' else 'Mean difference ('+s['unit'].replace('µ','micro').replace('–','-')+')'))
    def clean(s):return s.replace('"',"'").replace('\n',' ').replace('–','-').replace('≥','>=')
    calls.append(f'forest "{mid}" "{name}" "{clean(title)}" "{subtitle}" "{clean(axis)}"')
    captions.append(dict(figure=i,file=name,model_id=mid,title=title,k=r['k'],N=r['N'],role=s['role'],unit=s['unit'],caption=s['note'],sources=r['reports']))
(P/'forest_calls.do').write_text('\n'.join(calls)+'\n')
with (P/'figure_captions.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,list(captions[0]));w.writeheader();w.writerows(captions)
print(f'{len(captions)} distinct Stata forest plots scheduled; diagnostics explicitly labelled; all model estimates available in tables.')
