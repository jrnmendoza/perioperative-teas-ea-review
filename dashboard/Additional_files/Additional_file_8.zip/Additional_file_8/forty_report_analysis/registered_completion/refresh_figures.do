* Display-only refresh: uses previously verified Stata model results and inputs.
version 19.5
clear all
set more off
global RR "`c(pwd)'/opioid_only_review/forty_report_analysis/registered_completion_2026_10_09"
global ST "$RR/stata"
log using "$ST/figure_refresh.log", text replace
set scheme stcolor
graph set svg fontface "Helvetica"
graph set window fontface "Helvetica"
do "$RR/forest_program.do"
do "$RR/forest_calls.do"
log close
