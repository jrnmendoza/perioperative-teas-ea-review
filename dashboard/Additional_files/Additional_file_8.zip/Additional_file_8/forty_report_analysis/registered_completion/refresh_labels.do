* Display-only refresh: uses previously verified Stata model results and inputs.
version 19.5
clear all
set more off
global RR "`c(pwd)'/opioid_only_review/forty_report_analysis/registered_completion_2026_10_09"
global ST "$RR/stata"
log using "$ST/figure_label_refresh.log", text replace
set scheme stcolor
graph set svg fontface "Helvetica"
graph set window fontface "Helvetica"
do "$RR/forest_program.do"
forest "pain24_Lee_low_arm_only" "10_pain24_Lee_low_arm_only" "pain24 Lee low arm only" "Fixed 40-report dataset; held descriptive values; eligibility unresolved" "Mean difference (0-10 points)"
forest "intraop_remifentanil_Wu2025_preintervention_diagnostic" "23_intraop_remifentanil_Wu2025_preintervention_diagnostic" "intraop remifentanil Wu2025 preintervention diagnostic" "Fixed 40-report dataset; pre-treatment measurement; descriptive diagnostic only" "Mean difference (microg remifentanil)"
forest "INTRAOP_ALFENTANIL_SIM_POST_DIAGNOSTIC" "50_INTRAOP_ALFENTANIL_SIM_POST_DIAGNOSTIC" "Sim 2002: intraoperative alfentanil rate postoperative EA diagnostic" "Fixed 40-report dataset; pre-treatment measurement; descriptive diagnostic only" "Mean difference (micrograms/kg/min)"
forest "INTRAOP_SUF_WU_PREINTERVENTION_DIAGNOSTIC" "68_INTRAOP_SUF_WU_PREINTERVENTION_DIAGNOSTIC" "Wu 2025: intraoperative sufentanil before PACU intervention" "Fixed 40-report dataset; pre-treatment measurement; descriptive diagnostic only" "Mean difference (micrograms sufentanil)"
log close
