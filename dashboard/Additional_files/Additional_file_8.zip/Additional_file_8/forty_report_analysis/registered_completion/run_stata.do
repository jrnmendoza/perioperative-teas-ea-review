* Registered outcome completion within the fixed 40-report working dataset.
version 19.5
clear all
set more off
set varabbrev off
set type double
set linesize 140
global RR "`c(pwd)'/opioid_only_review/forty_report_analysis/registered_completion_2026_10_09"
global ST "$RR/stata"
capture mkdir "$ST"
capture mkdir "$ST/figures"
capture erase "$ST/COMPLETED.txt"
log using "$ST/run.log", text replace
set scheme stcolor
graph set svg fontface "Helvetica"
graph set window fontface "Helvetica"
import delimited using "$RR/model_inputs.csv", clear varnames(1) bindquote(strict) stringcols(_all)
foreach v in n_i n_c mean_i mean_c sd_i sd_c events_i events_c yi vi {
    destring `v', replace
}
gen str100 studylabel=study
gen double s_yi=mean_i-mean_c if effect_measure=="MD"
gen double s_vi=sd_i^2/n_i+sd_c^2/n_c if effect_measure=="MD"
gen double cc=cond(min(events_i,n_i-events_i,events_c,n_c-events_c)==0,.5,0) if effect_measure=="RR"
replace s_yi=ln(((events_i+cc)/(n_i+2*cc))/((events_c+cc)/(n_c+2*cc))) if effect_measure=="RR"
replace s_vi=1/(events_i+cc)-1/(n_i+2*cc)+1/(events_c+cc)-1/(n_c+2*cc) if effect_measure=="RR"
gen double df=n_i+n_c-2 if effect_measure=="SMD"
gen double sp=sqrt(((n_i-1)*sd_i^2+(n_c-1)*sd_c^2)/df) if effect_measure=="SMD"
gen double j=exp(lngamma(df/2)-.5*ln(df/2)-lngamma((df-1)/2)) if effect_measure=="SMD"
replace s_yi=j*(mean_i-mean_c)/sp if effect_measure=="SMD"
replace s_vi=(n_i+n_c)/(n_i*n_c)+s_yi^2/(2*(n_i+n_c)) if effect_measure=="SMD"
assert abs(s_yi-yi)<1e-8
assert abs(s_vi-vi)<1e-8
gen double s_se=sqrt(s_vi)
save "$ST/inputs.dta",replace
import delimited using "$RR/model_specs.csv",clear varnames(1) bindquote(strict) stringcols(_all)
local nm=_N
forvalues i=1/`nm' {
    local id`i'=model_id[`i']
    local measure`i'=measure[`i']
}
tempname reg
postfile `reg' str100 model_id str3 measure int k long N double(theta se ci_lb ci_ub tau2 I2 pi_lb pi_ub effect ci_low ci_high) using "$ST/model_results.dta",replace
forvalues i=1/`nm' {
    use "$ST/inputs.dta",clear
    keep if model_id=="`id`i''"
    local k=_N
    if `k'==0 {
        post `reg' ("`id`i''") ("`measure`i''") (0) (0) (.) (.) (.) (.) (.) (.) (.) (.) (.) (.) (.)
        continue
    }
    quietly summarize n_i
    local N=r(sum)
    quietly summarize n_c
    local N=`N'+r(sum)
    local theta=s_yi[1]
    local se=s_se[1]
    local lb=`theta'-invnormal(.975)*`se'
    local ub=`theta'+invnormal(.975)*`se'
    local tau=0
    local i2=.
    local pl=.
    local pu=.
    if `k'>1 {
        meta set s_yi s_se,studylabel(studylabel) random(reml)
        quietly meta summarize,se(khartung,truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
        assert r(converged)==1
        local theta=r(theta)
        local se=r(se)
        local lb=r(ci_lb)
        local ub=r(ci_ub)
        local tau=r(tau2)
        quietly gen double w0=1/s_vi
        quietly gen double w02=w0^2
        quietly summarize w0
        local sw=r(sum)
        quietly summarize w02
        local C=`sw'-r(sum)/`sw'
        local i2=100*`tau'/(`tau'+(`k'-1)/`C')
        if `k'>=5 {
            local pl=`theta'-invttail(`k'-1,.025)*sqrt(`tau'+`se'^2)
            local pu=`theta'+invttail(`k'-1,.025)*sqrt(`tau'+`se'^2)
        }
    }
    local effect=`theta'
    local lo=`lb'
    local hi=`ub'
    if "`measure`i''"=="RR" {
        local effect=exp(`theta')
        local lo=exp(`lb')
        local hi=exp(`ub')
    }
    post `reg' ("`id`i''") ("`measure`i''") (`k') (`N') (`theta') (`se') (`lb') (`ub') (`tau') (`i2') (`pl') (`pu') (`effect') (`lo') (`hi')
    capture meta clear
}
postclose `reg'
use "$ST/model_results.dta",clear
format theta-ci_high %21.16g
export delimited using "$ST/model_results.csv",replace datafmt

* Exact binomial confidence intervals for observed double-zero arms. These are
* not informative comparative RRs, and are not inserted into RR pooling.
import delimited using "$RR/double_zero_arm_risks.csv",clear varnames(1) bindquote(strict) stringcols(_all)
destring events n,replace
gen double stata_ci_low=.
gen double stata_ci_high=.
forvalues i=1/`=_N' {
    quietly cii proportions `=n[`i']' `=events[`i']',exact
    quietly replace stata_ci_low=r(lb) in `i'
    quietly replace stata_ci_high=r(ub) in `i'
}
export delimited using "$ST/double_zero_arm_risks.csv",replace

* Graphic definitions reuse the already validated Stata forest renderer.
do "$RR/forest_program.do"
do "$RR/forest_calls.do"
tempname marker
file open `marker' using "$ST/COMPLETED.txt",write replace text
file write `marker' "Stata 19.5 models and graphics completed successfully." _n
file close `marker'
log close
