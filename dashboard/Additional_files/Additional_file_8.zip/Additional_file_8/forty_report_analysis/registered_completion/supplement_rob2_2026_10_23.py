"""Result-specific RoB 2 assessments for the sensitivity results that had no exact assessment (23 October 2026).

Scope: every result linked as UNLINKED in completion_bias_links.csv whose model role is SENSITIVITY (62 distinct
results, 63 links). The 16 HELD links are recorded as not assessed, because held results enter no synthesis.
Trial-level domains reuse the second-reviewed judgements for the same trial where they exist; outcome-specific
domains (missing data, measurement) are judged from the source text for each outcome.

Consistency rule for measurement (D4) of self-reported outcomes: Low when participants were masked; Some concerns
when participants knew their allocation but the trial was otherwise masked; High when participants and the staff
collecting the outcome were both unmasked.

The SP-confirmed files (provisional_new_rob2_domains.csv, completion_bias_links.csv) are read, not written.
Outputs: supplement_rob2_domains_2026-10-23.csv, supplement_bias_links_2026-10-23.csv.
"""
from pathlib import Path
import csv, collections

P = Path(__file__).resolve().parent
ROOT = P.parents[2]
D = ROOT / '10_FINAL_ADJUDICATION'
def read(p): return list(csv.DictReader(p.open(encoding='utf-8-sig', newline='')))
def write(name, rows):
    with (P / name).open('w', newline='') as f:
        w = csv.DictWriter(f, list(dict.fromkeys(k for r in rows for k in r))); w.writeheader(); w.writerows(rows)

specs = {s['model_id']: s for s in read(P / 'model_specs.csv')}
links = read(P / 'completion_bias_links.csv')
src = {}
for path in [P / 'all_40_result_inventory.csv', P / 'model_inputs.csv', D / '03_CANONICAL/results.csv', P / 'new_source_extractions.csv']:
    if path.exists():
        for r in read(path): src.setdefault(r['result_id'], r)
audit = {r['report']: r for r in read(ROOT / 'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv')}

STATUS = 'AI domain assessment (delegated); second review SP, 2026-10-23 (confirmed)'
SC, L, H = 'Some concerns', 'Low', 'High'
D5_STD = 'Prospective analysis plan for this exact result not verified; no direct evidence of selection among multiple results.'
new = []
def assess(study, ids, ratings, reasons, location, note=''):
    assert len(ratings) == 5 == len(reasons)
    for rid in ids:
        r = src.get(rid, {})
        overall = H if H in ratings else (SC if SC in ratings else L)
        z = dict(assessment_id='SUPPL-ROB-' + rid, result_id=rid, study=study, outcome=r.get('outcome', ''), window=r.get('window', ''),
                 comparison=r.get('comparator_class', ''), overall=overall, decision_status=STATUS,
                 source_pdf=r.get('source_pdf') or audit.get(study, {}).get('source_pdf', ''),
                 source_sha256=r.get('source_sha256') or audit.get(study, {}).get('source_sha256', ''),
                 source_location=location, note=note)
        for i, (v, why) in enumerate(zip(ratings, reasons), 1): z[f'd{i}'] = v; z[f'd{i}_rationale'] = why
        new.append(z)

# ---- assessments --------------------------------------------------------------------------------------------
assess('Chen 2020', ['V33-OD-0015'], [SC, SC, L, SC, SC], [
    'Computer-based randomisation at enrolment; allocation concealment not described.',
    'Described as double-blind, but who was masked is not specified; 4 mA sham before and after surgery versus active stimulation. No documented departures.',
    'Complete datasets reported for all 80 randomised patients (p3, Fig 1).',
    'Patient-reported VAS; the 4 mA sham is perceptible, but masking success is not reported, so influence on pain reporting cannot be excluded.',
    'Registered (ChiCTR1800016067) with VAS at 6, 24 and 48 h as primary endpoint (p2-3); registration timing relative to enrolment not verified.'],
    'Chen 2020 PDF p1-3 design, randomisation, endpoints and complete data')
assess('El-Rakshy 2009', ['V33-OD-0253'], [SC, SC, H, L, SC], [
    'Computer sequence; concealment insufficiently documented (as in the second-reviewed 24-h assessment).',
    'Usual-care comparator and inconsistent group descriptions leave co-intervention concerns.',
    '107 randomised versus 95 analysed with conflicting arm labels and exclusions; the same missing data affect the 4-h morphine total.',
    'Recorded IV morphine exposure.', D5_STD],
    'El-Rakshy 2009: trial-level domains from second-reviewed assessment V33-OD-0252; 4-h total from the same morphine table')
assess('Gu 2019', ['V33-OD-0221'], [SC, L, L, SC, SC], [
    'Computer random-number table; allocation concealment insufficiently established.',
    'Same perioperative care; no documented departure affecting pain.',
    '117/120 analysed without an established pain-related missingness pattern.',
    'Patient-reported VAS after perceptible active stimulation versus sham; interviewer masking does not establish patient masking.', D5_STD],
    'Gu 2019 PDF p3-5; consistent with second-reviewed 4- and 8-h pain assessments')
assess('Gu 2019', ['AUDIT-0156'], [SC, L, L, SC, SC], [
    'Computer random-number table; allocation concealment insufficiently established.',
    'Same perioperative care; no documented departure.',
    '117/120 analysed.',
    'PONV includes patient-reported nausea after perceptible stimulation versus sham; recording window not stated.',
    'Window not stated; prospective analysis plan for this result not verified.'],
    'Gu 2019 PDF Results; window unspecified')
assess('Gu 2019', ['AUDIT-0157', 'AUDIT-0158', 'AUDIT-0159', 'AUDIT-0160'], [SC, L, L, SC, SC], [
    'Computer random-number table; allocation concealment insufficiently established.',
    'Same perioperative care; no documented departure.',
    '117/120 analysed.',
    'Self-reported satisfaction at 36 h after perceptible active stimulation versus sham; patient masking not demonstrated.',
    'Four-category satisfaction reported in full; prospective analysis plan not verified.'],
    'Gu 2019 PDF Results, satisfaction at 36 h')
assess('He 2026 (hepatectomy/JIS)', ['ALLCAUSE-HE-DEATH'], [L, L, L, L, L], [
    'Secure web randomisation with stratification and blocks.',
    'Patients and clinical/outcome staff masked.',
    '159 of 161 in the modified ITT population: one cancelled surgery (TEAS) and one consent withdrawal (control) excluded (p5).',
    'All-cause death is an objective outcome.',
    'Mortality at 6 months is a named outcome with an available protocol/SAP (p4-5).'],
    'He 2026 PDF p4-5 outcomes and mortality statement; Table 2', note='All-cause finding; not attributed to stimulation.')
assess('Jiang 2026', ['AUDIT-0180'], [L, L, SC, L, SC], [
    'Independent randomisation with opaque envelopes.',
    'Deception sham with patient and assessor masking; common care.',
    '614 allocated, 587 analysed; withdrawal arithmetic does not fully reconcile.',
    'Masked postoperative symptom assessment.', D5_STD],
    'Jiang 2026 PDF p2-5; trial-level domains from second-reviewed assessments')
assess('Jiang 2026', ['AUDIT-0186', 'AUDIT-0187'], [L, L, SC, SC, SC], [
    'Independent randomisation with opaque envelopes.',
    'Common management; no important departure established.',
    'Safety table uses 294/293 against 308/306 randomised; all-treated safety not established.',
    'Local reactions elicited by interview; ascertainment incomplete and table formatting malformed.',
    'Harms described in Methods; no verified prospective category-level analysis plan.'],
    'Jiang 2026 PDF p5 Table 5; consistent with second-reviewed harms assessment AUDIT-0183')
assess('Liu 2026 (ESD)', ['V33-OD-0158', 'V33-OD-0157'], [L, L, H, L, SC], [
    'Computer block randomisation and opaque envelopes.',
    'Patients, surgeons and follow-up physicians masked; shared analgesic rule.',
    '129 randomised, 120 analysed; exclusions for laparotomy conversion, bleeding and withdrawal plausibly relate to postoperative pain.',
    'Pain recorded by masked follow-up physicians from masked patients.',
    'Published protocol followed recruitment onset; exact pain analysis not verified.'],
    'Liu 2026 ESD PDF flow and pain table; trial-level domains from second-reviewed rescue assessment')
assess('Liu 2026 (ESD)', ['V33-OD-0160'], [L, L, H, L, SC], [
    'Computer block randomisation and opaque envelopes.',
    'Patients, surgeons and follow-up physicians masked.',
    '9 of 129 excluded after randomisation for surgical complications and withdrawal, which plausibly relate to PONV.',
    'Masked follow-up assessment.', 'Window not stated; prospective analysis plan not verified.'],
    'Liu 2026 ESD PDF Results')
assess('Liu 2026 (ESD)', ['ALLCAUSE-ESD-BLEED'], [L, L, L, L, SC], [
    'Computer block randomisation and opaque envelopes.',
    'Masked postoperative care.',
    'Bleeding events are counted among all randomised participants; the events themselves caused the withdrawals.',
    'Postoperative bleeding requiring withdrawal is an objective clinical event.', D5_STD],
    'Liu 2026 ESD PDF flow diagram', note='All-cause finding; not attributed to stimulation.')
assess('Ng 2013', ['V33-OD-0118', 'NEW-NG-PAIN-POD2-sham', 'NEW-NG-PAIN-POD3-sham'], [SC, L, L, L, SC], [
    'Random allocation using non-opaque envelopes: concealment concern.',
    'EA and sham participants masked.',
    'All participants retained.',
    'Masked assessment and masked sham participants.', D5_STD],
    'Ng 2013 PDF p2-4; trial-level domains from second-reviewed assessments')
assess('Ng 2013', ['NEW-NG-PAIN-POD1-usual_care', 'NEW-NG-PAIN-POD2-usual_care', 'NEW-NG-PAIN-POD3-usual_care'], [SC, SC, L, SC, SC], [
    'Random allocation using non-opaque envelopes: concealment concern.',
    'No-acupuncture participants unmasked; possible differential care.',
    'All participants retained.',
    'Self-reported pain from participants aware of receiving no acupuncture, collected by a masked assessor.', D5_STD],
    'Ng 2013 PDF p2-4')
OZ = ['Computer web-based block allocation; concealment not established.',
      'Patients and data collector unmasked; one assigned patient excluded for non-protocol drug use.',
      'One exclusion for non-protocol medication, which may also affect pain scores.']
assess('Oztas 2019', ['V33-OD-0311', 'V33-OD-0313', 'V33-OD-0315', 'V33-OD-0317', 'V33-OD-0319'], [SC, SC, SC, H, SC], OZ + [
    'Self-reported pain from patients who knew they received no stimulation, collected by an unmasked data collector.', D5_STD],
    'Oztas 2019 PDF p3-4, p6-9; trial-level domains from second-reviewed assessments')
assess('Oztas 2019', ['V33-OD-0312', 'V33-OD-0314', 'V33-OD-0316', 'V33-OD-0318', 'V33-OD-0320'], [SC, SC, SC, SC, SC], OZ + [
    'Both arms received perceptible electrical stimulation at different sites; patients and collector unmasked, but awareness of which stimulation was expected to work is uncertain.', D5_STD],
    'Oztas 2019 PDF p3-4, p6-9')
assess('Sim 2002', ['AUDIT-0260'], [SC, L, L, L, SC], [
    'Table of random numbers; allocation concealment not described.',
    'Groups I and II blinded to acupuncture type; standard anaesthesia and PCA protocol.',
    '30/30 per group in Table 1 and Table 2.',
    'Pain assessed by an independent observer blinded to group; patients blinded, and 55-65% could not guess their group (p6).',
    'Mean of 6-hourly VAS over 24 h reported; prospective analysis plan not verified.'],
    'Sim 2002 PDF p2-6')
assess('Sim 2002', ['AUDIT-0261'], [SC, SC, L, SC, SC], [
    'Table of random numbers; allocation concealment not described.',
    'Group III received EA awake in recovery and was not blinded, unlike the placebo group.',
    '30/30 per group.',
    'Self-reported pain from unblinded postoperative-EA patients, collected by a blinded observer.',
    'Mean of 6-hourly VAS over 24 h reported; prospective analysis plan not verified.'],
    'Sim 2002 PDF p2-6')
assess('Sim 2002', ['AUDIT-0319'], [SC, L, L, L, SC], [
    'Table of random numbers; allocation concealment not described.',
    'Intraoperative dose given before the postoperative intervention; no post-assignment departures can affect it.',
    '30/30 per group.', 'Recorded alfentanil dose.',
    'Diagnostic comparison; prospective analysis plan not verified.'],
    'Sim 2002 PDF p4', note='Pre-intervention diagnostic; not a treatment effect.')
assess('Szmit 2021', ['V33-OD-0354'], [L, L, L, L, SC], [
    'Independent statistician generated block sequence; independent allocation.',
    'Participants blinded to treatment type; no evidence of differential care.',
    '71/71 across three arms retained.',
    'Self-reported VAS at discharge from blinded participants.',
    'Discharge clock time not reported; prospective analysis plan not verified.'],
    'Szmit 2021 PDF p3, p8; trial-level domains from second-reviewed assessments')
assess('Szmit 2021', ['V33-OD-0355', 'V33-OD-0353'], [L, SC, L, SC, SC], [
    'Independent statistician generated block sequence; independent allocation.',
    'No-stimulation participants unmasked; possible differential care.',
    '71/71 retained.',
    'Self-reported pain or nausea from participants aware of receiving no stimulation; collector masking not reported.',
    'Observation window not exact; prospective analysis plan not verified.'],
    'Szmit 2021 PDF p3, p7-8')
assess('Tu 2024', ['V33-OD-0094', 'V33-OD-0095', 'AUDIT-0199'], [L, L, H, L, SC], [
    'Computer sequence with sealed opaque sequential envelopes.',
    'Participant, clinical and observer masking reported.',
    '120 randomised, 115 analysed; one sham patient was excluded for intracranial-hypertension vomiting, which directly relates to this outcome.',
    'Vomiting observed by masked staff.',
    'Protocol names PONV endpoints; exact interval analysis not verified.'],
    'Tu 2024 PDF flow and Table 4; trial-level domains from second-reviewed rescue assessment')
assess('Wong 2006', ['V33-OD-0247', 'V33-OD-0248', 'V33-OD-0249'], [SC, L, H, L, SC], [
    'Sequence and concealment insufficiently detailed.',
    'Blunt sham and opaque shielding; patients and surgeons masked.',
    '2/27 excluded for postoperative complications that could change morphine requirements in this small trial.',
    'Recorded PCA morphine with masked participants.', D5_STD],
    'Wong 2006: trial-level domains from second-reviewed 3-day assessment V33-OD-0250')
assess('Wu 2016', ['V33-OD-0269'], [L, SC, H, SC, SC], [
    'Computer-generated list with coded sealed envelopes.',
    'Active electrical comparator; participant masking between active arms not established.',
    'Nine of 90 excluded, including three serious postoperative complications that plausibly relate to PONV.',
    'Patient-reported nausea within the composite; masking of participants and collectors not established.',
    'Window not reported; prospective analysis plan not verified.'],
    'Wu 2016 PDF p2-3, p5; trial-level domains from second-reviewed assessments')
assess('Wu 2016', ['V33-OD-0270'], [L, SC, H, SC, SC], [
    'Computer-generated list with coded sealed envelopes.',
    'No-treatment control unmasked.',
    'Nine of 90 excluded, including three serious postoperative complications that plausibly relate to PONV.',
    'Patient-reported nausea from participants aware of receiving no treatment.',
    'Window not reported; prospective analysis plan not verified.'],
    'Wu 2016 PDF p2-3, p5')
assess('Wu 2025', ['V33-OD-0076'], [SC, L, SC, SC, SC], [
    'Independent computer sequence at PACU arrival; concealment mechanism insufficiently explicit.',
    'Same anaesthesia and rescue policy; no documented departures.',
    'Reported for all 100 randomised (6/50 versus 37/50); handling of three early-discharge patients without later contact is not explained.',
    'Self-reported pain after PACU stimulation; authors acknowledge sensory differences as patients awaken.', D5_STD],
    'Wu 2025 PDF p1, p3-4; trial-level domains from second-reviewed QoR assessment')
assess('Xiong 2021', ['V33-OD-0057'], [SC, SC, L, SC, SC], [
    'Computer sequence in sealed envelopes; opacity safeguards not fully documented.',
    'Anaesthetists aware; co-intervention concern despite a masked postoperative resident.',
    'All 62 randomised analysed.',
    'No-current sham with possible postoperative tingling; incomplete masking for a nausea-containing outcome.', D5_STD],
    'Xiong 2021: consistent with second-reviewed 48-h PONV assessment V33-OD-0056')
assess('Yu 2020', ['V33-OD-0368'], [SC, L, L, L, SC], [
    'Computer table and nurse allocation; concealment safeguards insufficiently detailed.',
    'Participants and clinical staff masked.',
    '60/60 retained.',
    'Blinded collector administered questionnaires.',
    'Table and abstract SDs differ; both transcriptions analysed. Prospective analysis plan not verified.'],
    'Yu 2020; consistent with second-reviewed 24-h pain assessment V33-OD-0367')
assess('Yu 2020', ['AUDIT-0361', 'AUDIT-0362'], [SC, L, L, L, SC], [
    'Computer table and nurse allocation; concealment safeguards insufficiently detailed.',
    'Participants and clinical staff masked.',
    '60/60 retained.',
    'MMSE administered by a blinded collector.', D5_STD],
    'Yu 2020 PDF Results, MMSE')
assess('Zhang 2023', ['NEW-ZHANG23-VOMIT'], [L, L, SC, L, SC], [
    'Block randomisation, sequential opaque envelopes and masked outcome assessors.',
    'Masked postoperative care; common management.',
    '110 of 1948 randomised withdrew; completer denominators used.',
    'Vomiting recorded by masked assessors.',
    'Window not stated; prospective analysis plan not verified.'],
    'Zhang 2023 PDF p7 Table 4; consistent with second-reviewed Zhang 2023 assessments')
assess('Zhang 2025', ['V33-OD-0041', 'NEW-ZHANG25-LOS', 'NEW-ZHANG25-DRAIN', 'NEW-ZHANG25-LIQUID', 'NEW-ZHANG25-SOLID', 'NEW-ZHANG25-PONV'],
       [L, SC, H, SC, SC], [
    'Stata-generated sequence and consecutive opaque envelopes.',
    'Anaesthesiologists both deliver the intervention and are described as masked; implementation unclear.',
    '15 of 108 excluded after randomisation, including surgical protocol modifications and withdrawals that plausibly affect these outcomes.',
    'Masking for patient-reported and decision-dependent outcomes not established; several printed CIs and P values conflict with arm data.',
    'Outcomes named, but reporting discrepancies remain unresolved.'],
    'Zhang 2025 PDF p2-4, p9 Table 5; consistent with second-reviewed Zhang 2025 assessments')
assess('Zhou 2021', ['V33-OD-0031'], [SC, SC, H, H, SC], [
    'SPSS random-number table, assigned by a named investigator in order of consent; concealment not established.',
    'Unblinded trial against usual care.',
    'Patients with Clavien-Dindo grade >2 complications were withdrawn and not analysed; complications plausibly affect pain (p3, p8).',
    'Self-reported pain in an unblinded trial with unmasked staff.',
    'Average of POD1-5 scores reported; prospective analysis plan not verified.'],
    'Zhou 2021 PDF p1-4, p8')
assess('Zhou 2025', ['NEW-ZHOU-PONV48', 'NEW-ZHOU-PONV72'], [L, L, L, L, SC], [
    'Computer sequence and sequential opaque sealed envelopes.',
    'Patient and assessor masking with scripted practitioner interaction.',
    '97/100 analysed; no documented outcome-related attrition.',
    'Masked PONV collection.', D5_STD],
    'Zhou 2025; consistent with second-reviewed POD1 PONV assessment V33-OD-0027')
assess('Zhou 2025', ['QOR-ZHOU2025-POD3-AS-PRINTED'], [L, L, L, SC, SC], [
    'Computer sequence and sequential opaque sealed envelopes.',
    'Scripted neutral interaction; common care.',
    '97/100 analysed.',
    'Self-reported QoR after active versus no current; masking success uncertain.',
    'Printed POD3 P value conflicts with near-identical means; as-printed analysis only.'],
    'Zhou 2025; consistent with second-reviewed QoR assessments V33-OD-0025 and V33-OD-0025-LATER')

# ---- checks and links ---------------------------------------------------------------------------------------
by_id = {z['result_id']: z for z in new}
assert len(by_id) == len(new), 'duplicate result assessed twice'
unl = [b for b in links if b['overall'].startswith('UNLINKED')]
sens = [b for b in unl if specs[b['model_id']]['role'] == 'SENSITIVITY']
held = [b for b in unl if specs[b['model_id']]['role'] == 'HELD']
assert len(sens) + len(held) == len(unl) == 79
missing = sorted({b['result_id'] for b in sens} - set(by_id))
extra = sorted(set(by_id) - {b['result_id'] for b in sens})
assert not missing and not extra, (missing, extra)
for z in new:
    assert z['source_pdf'], z['result_id']
out_links = []
for b in unl:
    z = by_id.get(b['result_id'])
    out_links.append(dict(model_id=b['model_id'], role=specs[b['model_id']]['role'], result_id=b['result_id'], study=b['study'],
                          overall=z['overall'] if z else 'NOT ASSESSED: held from synthesis',
                          assessment_id=z['assessment_id'] if z else '',
                          basis=STATUS if z else 'Held results enter no synthesis; no result-specific assessment required.'))
write('supplement_rob2_domains_2026-10-23.csv', new)
write('supplement_bias_links_2026-10-23.csv', out_links)
print(len(new), 'assessments for', len(sens), 'sensitivity links;', len(held), 'held links not assessed')
print(collections.Counter(z['overall'] for z in new))
print(collections.Counter((z['study'], z['overall']) for z in new))
