args <- commandArgs(trailingOnly=TRUE)
base <- if(length(args)) args[1] else "opioid_only_review/forty_report_analysis/registered_completion_2026_10_09"
d <- read.csv(file.path(base,"model_inputs.csv"),stringsAsFactors=FALSE)
specs <- read.csv(file.path(base,"model_specs.csv"),stringsAsFactors=FALSE)
out <- list()
for(id in specs$model_id) {
  x <- d[d$model_id==id,];k<-nrow(x);measure<-specs$measure[specs$model_id==id]
  if(!k){out[[length(out)+1]]<-data.frame(model_id=id,k=0,N=0,effect=NA,ci_low=NA,ci_high=NA,tau2=NA,I2=NA,input_y_difference=NA,input_v_difference=NA);next}
  ni<-x$n_i;nc<-x$n_c
  if(measure=="RR") {
    cc<-ifelse(pmin(x$events_i,ni-x$events_i,x$events_c,nc-x$events_c)==0,.5,0)
    y<-log(((x$events_i+cc)/(ni+2*cc))/((x$events_c+cc)/(nc+2*cc)))
    v<-1/(x$events_i+cc)-1/(ni+2*cc)+1/(x$events_c+cc)-1/(nc+2*cc)
  } else if(measure=="SMD") {
    df<-ni+nc-2;sp<-sqrt(((ni-1)*x$sd_i^2+(nc-1)*x$sd_c^2)/df)
    j<-exp(lgamma(df/2)-.5*log(df/2)-lgamma((df-1)/2))
    y<-j*(x$mean_i-x$mean_c)/sp;v<-(ni+nc)/(ni*nc)+y^2/(2*(ni+nc))
  } else {y<-x$mean_i-x$mean_c;v<-x$sd_i^2/ni+x$sd_c^2/nc}
  dy<-max(abs(y-x$yi));dv<-max(abs(v-x$vi));stopifnot(dy<1e-8,dv<1e-8)
  tau<-0;I2<-NA
  if(k>1) {
    obj<-function(tau){w<-1/(v+tau);mu<-sum(w*y)/sum(w);.5*(sum(log(v+tau))+log(sum(w))+sum(w*(y-mu)^2))}
    opt<-optimize(obj,c(0,max(1,var(y)*(k-1)/k*10,max(v)*10)),tol=1e-12)
    if(opt$objective<obj(0)-1e-12)tau<-opt$minimum
    w<-1/(v+tau);mu<-sum(w*y)/sum(w);hk<-max(1,sum(w*(y-mu)^2)/(k-1));se<-sqrt(hk/sum(w));crit<-qt(.975,k-1)
    w0<-1/v;C<-sum(w0)-sum(w0^2)/sum(w0);I2<-100*tau/(tau+(k-1)/C)
  } else {mu<-y;se<-sqrt(v);crit<-qnorm(.975)}
  tr<-if(measure=="RR") exp else identity
  out[[length(out)+1]]<-data.frame(model_id=id,k=k,N=sum(ni+nc),effect=tr(mu),ci_low=tr(mu-crit*se),ci_high=tr(mu+crit*se),tau2=tau,I2=I2,input_y_difference=dy,input_v_difference=dv)
}
write.csv(do.call(rbind,out),file.path(base,"independent_R_results.csv"),row.names=FALSE)
cat(length(out),"models independently rederived and fitted in base R.\n")
