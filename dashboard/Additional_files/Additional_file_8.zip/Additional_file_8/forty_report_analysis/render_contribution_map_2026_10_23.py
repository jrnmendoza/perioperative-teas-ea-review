"""Render contribution_map_2026-10-23.csv as a manuscript figure (PDF + PNG). Bundled Python with reportlab:
  ~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 render_contribution_map_2026_10_23.py
"""
import csv, subprocess, shutil
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth

HERE = Path(__file__).resolve().parent
rows = list(csv.DictReader((HERE / 'contribution_map_2026-10-23.csv').open(newline='')))
DOM = ['Primary 24-h opioid', 'Broader first-day dose', 'Rescue opioid receipt', 'Other opioid / analgesic', 'Pain',
       'Nausea and vomiting', 'Quality of recovery', 'GI recovery', 'Mobility, stay, satisfaction', 'Harms']
HEAD = [['Primary', '24-h', 'opioid'], ['Broader', 'first-day', 'dose'], ['Rescue', 'opioid', 'receipt'], ['Other', 'opioid or', 'analgesic'],
        ['', '', 'Pain'], ['', 'Nausea and', 'vomiting'], ['', 'Quality of', 'recovery'], ['', 'GI', 'recovery'], ['Mobility,', 'stay,', 'satisfaction'], ['', '', 'Harms']]
FILL = {'P': '#1f3a5f', '1': '#5b7fa6', 'I': '#b9cbe0', 'S': '#e6e6e6', 'H': '#ffffff', 'Q': '#ffffff', '': '#ffffff'}
TXT = {'P': '#ffffff', '1': '#ffffff', 'I': '#1f2933', 'S': '#52606d', 'H': '#1f2933', 'Q': '#1f2933', '': '#c0c6cc'}
LABEL = {'P': 'P', '1': '1', 'I': 'I', 'S': 'S', 'H': 'H', 'Q': 'Q', '': '–'}
F, B, FS = 'Helvetica', 'Helvetica-Bold', 7.6
NAMEW, MODW, CW, RH, TOP = 132, 38, 52, 12.6, 54
W = NAMEW + MODW + CW * len(DOM) + 24
groups = [('TEAS', [r for r in rows if r['modality'] == 'TEAS']), ('EA', [r for r in rows if r['modality'] == 'EA']),
          ('Unclear', [r for r in rows if r['modality'] == 'UNCLEAR'])]
n_lines = sum(len(g) for _, g in groups) + len(groups)
H = TOP + n_lines * RH + RH + 64
out = HERE / 'contribution_map_2026-10-23.pdf'
cv = canvas.Canvas(str(out), pagesize=(W, H)); Y = lambda y: H - y
x0 = 12
cv.setFillColor(HexColor('#1f2933'))
for i, lines in enumerate(HEAD):
    cx = x0 + NAMEW + MODW + CW * i + CW / 2
    cv.setFont(B, FS)
    for j, s in enumerate(lines):
        assert stringWidth(s, B, FS) < CW - 3, s
        cv.drawCentredString(cx, Y(TOP - 30 + 10 * j), s)
cv.setFont(B, FS); cv.drawString(x0, Y(TOP - 10), 'Report'); cv.drawString(x0 + NAMEW, Y(TOP - 10), 'Control')
y = TOP
for gname, g in groups:
    cv.setFillColor(HexColor('#e4e9ef')); cv.rect(x0, Y(y + RH), W - 24, RH, stroke=0, fill=1)
    cv.setFillColor(HexColor('#1f2933')); cv.setFont(B, FS); cv.drawString(x0 + 3, Y(y + RH - 3.6), f'{gname} ({len(g)} report{"" if len(g) == 1 else "s"})')
    y += RH
    for r in g:
        cv.setFillColor(HexColor('#1f2933')); cv.setFont(F, FS)
        name = r['report']
        while stringWidth(name, F, FS) > NAMEW - 6: name = name[:-2] + '…'
        cv.drawString(x0 + 3, Y(y + RH - 3.6), name)
        cv.drawString(x0 + NAMEW, Y(y + RH - 3.6), r['comparator'].replace('Usual care', 'Usual'))
        for i, d in enumerate(DOM):
            c = r[d]; cx = x0 + NAMEW + MODW + CW * i
            cv.setFillColor(HexColor(FILL[c])); cv.setStrokeColor(HexColor('#ffffff')); cv.setLineWidth(1)
            cv.rect(cx + 1, Y(y + RH - 0.6), CW - 2, RH - 1.2, stroke=1, fill=1)
            cv.setFillColor(HexColor(TXT[c])); cv.setFont(B if c in 'P1' and c else F, FS)
            cv.drawCentredString(cx + CW / 2, Y(y + RH - 3.6), LABEL[c])
        y += RH
# totals row
cv.setStrokeColor(HexColor('#52606d')); cv.setLineWidth(0.6); cv.line(x0, Y(y + 1), W - 12, Y(y + 1))
cv.setFillColor(HexColor('#1f2933')); cv.setFont(B, FS); cv.drawString(x0 + 3, Y(y + RH - 2.6), 'Reports in a main analysis')
for i, d in enumerate(DOM):
    n = sum(r[d] in ('P', '1') for r in rows)
    cv.drawCentredString(x0 + NAMEW + MODW + CW * i + CW / 2, Y(y + RH - 2.6), str(n))
y += RH + 14
# key
keys = [('P', 'Pooled main analysis'), ('1', 'Single-trial main estimate'), ('I', 'Individual estimate, original units'),
        ('S', 'Sensitivity analysis only'), ('H', 'Held from synthesis'), ('Q', 'Qualitative only')]
kx = x0
for c, t in keys:
    cv.setFillColor(HexColor(FILL[c])); cv.setStrokeColor(HexColor('#9aa5b1')); cv.setLineWidth(0.5)
    cv.rect(kx, Y(y + 9), 14, 9, stroke=1, fill=1)
    cv.setFillColor(HexColor(TXT[c])); cv.setFont(B, 6.6); cv.drawCentredString(kx + 7, Y(y + 7), LABEL[c])
    cv.setFillColor(HexColor('#1f2933')); cv.setFont(F, 6.8); cv.drawString(kx + 18, Y(y + 7.2), t)
    kx += 18 + stringWidth(t, F, 6.8) + 14
    if kx > W - 140: kx = x0; y += 13
cv.showPage(); cv.save()
png = HERE / 'contribution_map_2026-10-23.png'
if shutil.which('qlmanage'):
    tmp = HERE / '_ql'; tmp.mkdir(exist_ok=True)
    subprocess.run(['qlmanage', '-t', '-s', '2400', '-o', str(tmp), str(out)], check=True, capture_output=True)
    (tmp / (out.name + '.png')).replace(png); tmp.rmdir()
print(out.name, png.name, f'{W:.0f}x{H:.0f} pt')
