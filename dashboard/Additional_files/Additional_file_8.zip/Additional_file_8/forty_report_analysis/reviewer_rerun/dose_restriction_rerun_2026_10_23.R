# Rerun of the post-hoc risk-of-bias restrictions for the broader first-day dose analyses (23 October 2026).
# Base R only. Step 1 reproduces the existing restriction results (model_results.csv, read-only) from the old
# linkage; step 2 refits after adding the three new dose assessments. Writes dose_restriction_rerun_2026-10-23.csv.
# Model: REML tau^2 (bounded optimisation as in rerun.py), Hartung-Knapp scale truncated at 1, t(k-1) interval;
# a single trial uses its normal interval.
args <- commandArgs(trailingOnly = FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)])))
root <- normalizePath(file.path(here, "..", "..", ".."))
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^\ufeff", "", names(x)); x }

e2 <- rd(file.path(here, "e2", "e2_model_inputs.csv"))
models <- c("E2_opioid24_TEAS_sham", "E2_opioid24_TEAS_usual", "E2_opioid24_EA_sham", "E2_opioid24_EA_usual")
link <- rd(file.path(root, "FINAL_RESULT_ROB2_LINKAGE.csv"))
old_rating <- setNames(link$overall, link$result_id)
new_rob <- rd(file.path(here, "dose_rob2_supplement_2026-10-23.csv"))
baseline <- rd(file.path(here, "model_results.csv"))

overall_of <- function(ids, ratings) {
  r <- sapply(strsplit(ids, "+", fixed = TRUE)[[1]], function(i) if (!is.na(ratings[i])) ratings[i] else "UNLINKED")
  if (any(r == "High")) "High" else if (any(!r %in% c("Low", "Some concerns"))) "NOT ESTABLISHED"
  else if (any(r == "Some concerns")) "Some concerns" else "Low"
}
fit <- function(d) {
  k <- nrow(d)
  if (k == 0) return(list(k = 0, N = 0, effect = NA, lo = NA, hi = NA, tau2 = NA, reports = ""))
  y <- as.numeric(d$yi); v <- as.numeric(d$vi)
  N <- sum(as.integer(as.numeric(d$n_i)) + as.integer(as.numeric(d$n_c)))
  if (k == 1) { mu <- y; se <- sqrt(v); crit <- qnorm(.975); tau <- 0 }
  else {
    nll <- function(t) { w <- 1/(v + t); mu <- sum(w*y)/sum(w); .5*(sum(log(v + t)) + log(sum(w)) + sum(w*(y - mu)^2)) }
    up <- max(1, mean((y - mean(y))^2)*10, max(v)*10)
    o <- optimize(nll, c(0, up), tol = 1e-12)
    tau <- if (o$objective < nll(0)) o$minimum else 0
    w <- 1/(v + tau); mu <- sum(w*y)/sum(w)
    q <- sum(w*(y - mu)^2)/(k - 1); se <- sqrt(max(1, q)/sum(w)); crit <- qt(.975, k - 1)
  }
  list(k = k, N = N, effect = mu, lo = mu - crit*se, hi = mu + crit*se, tau2 = tau, reports = paste(d$study, collapse = ";"))
}

new_rating <- old_rating
new_rating[new_rob$result_id] <- new_rob$overall
out <- list(); maxdiff <- 0
for (m in models) {
  d <- e2[e2$model_id == m, ]
  for (spec in list(c("NOT_HIGH_WITH_LINKAGE", "Low|Some concerns"), c("LOW_ONLY", "Low"))) {
    keep <- strsplit(spec[2], "|", fixed = TRUE)[[1]]
    mid <- paste0(m, "_", spec[1])
    ro <- sapply(d$result_id, overall_of, ratings = old_rating)
    rn <- sapply(d$result_id, overall_of, ratings = new_rating)
    f0 <- fit(d[ro %in% keep, , drop = FALSE]); f1 <- fit(d[rn %in% keep, , drop = FALSE])
    b <- baseline[baseline$model_id == mid, ]
    stopifnot(nrow(b) == 1, as.integer(b$k) == f0$k)
    if (f0$k > 0) {
      dd <- max(abs(c(f0$effect - as.numeric(b$effect), f0$lo - as.numeric(b$ci_low), f0$hi - as.numeric(b$ci_high))))
      maxdiff <- max(maxdiff, dd); stopifnot(dd < 1e-6, b$reports == f0$reports)
    }
    out[[mid]] <- data.frame(model_id = mid, restriction = spec[1],
      k_before = f0$k, N_before = f0$N, effect_before = f0$effect, ci_low_before = f0$lo, ci_high_before = f0$hi, reports_before = f0$reports,
      k_after = f1$k, N_after = f1$N, effect_after = f1$effect, ci_low_after = f1$lo, ci_high_after = f1$hi, tau2_after = f1$tau2,
      reports_after = f1$reports, changed = !identical(f0$reports, f1$reports),
      stringsAsFactors = FALSE)
  }
}
res <- do.call(rbind, out)
write.csv(res, file.path(here, "dose_restriction_rerun_2026-10-23.csv"), row.names = FALSE)
cat(sprintf("Baseline reproduced; maximum difference %.2e\n", maxdiff))
print(res[, c("model_id", "k_before", "k_after", "effect_after", "ci_low_after", "ci_high_after", "changed")], row.names = FALSE)
