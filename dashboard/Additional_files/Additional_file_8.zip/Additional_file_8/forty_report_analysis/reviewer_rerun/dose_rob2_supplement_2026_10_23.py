"""Result-specific RoB 2 assessments for the three broader first-day dose results that had none (23 October 2026).

dose_bias_linkage.csv recorded these as UNLINKED, so the post-hoc 'not high risk' dose restriction excluded them as
unassessed. Trial-level domains reuse second-reviewed judgements for the same trial. Read-only inputs; writes
dose_rob2_supplement_2026-10-23.csv only.
"""
from pathlib import Path
import csv, hashlib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
def read(p): return list(csv.DictReader(p.open(encoding='utf-8-sig', newline='')))
audit = {r['report']: r for r in read(ROOT / 'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv')}
STATUS = 'AI domain assessment (delegated); second review SP, 2026-10-23 (confirmed)'
SC, L, H = 'Some concerns', 'Low', 'High'
rows = []
def assess(study, result_ids, model_id, outcome, ratings, reasons, location):
    pdf = audit[study]['source_pdf']
    assert hashlib.sha256((ROOT / pdf).read_bytes()).hexdigest() == audit[study]['source_sha256'], study
    overall = H if H in ratings else (SC if SC in ratings else L)
    for rid in result_ids:
        z = dict(assessment_id='DOSE-SUPPL-ROB-' + rid, result_id=rid, model_id=model_id, study=study, outcome=outcome,
                 overall=overall, decision_status=STATUS, source_pdf=pdf, source_sha256=audit[study]['source_sha256'],
                 source_location=location)
        for i, (v, why) in enumerate(zip(ratings, reasons), 1): z[f'd{i}'] = v; z[f'd{i}_rationale'] = why
        rows.append(z)

assess('Gu 2019', ['E2.1-GU2019-FIG4-T4'], 'E2_opioid24_TEAS_sham', 'First-day opioid dose read from Figure 4', [SC, L, L, L, SC], [
    'Computer random-number table; allocation concealment insufficiently established.',
    'Patients, data collectors and statistician masked; same perioperative care.',
    '117/120 analysed (58/59), without evidence of important differential loss.',
    'Delivered PCA opioid is a recorded quantity; patient demand is part of the assignment effect, not measurement bias.',
    'Values available only as a figure, digitised against the axis gridlines; prospective analysis plan not verified.'],
    'Gu 2019 PDF Figure 4; trial-level domains from second-reviewed assessments')
assess('Zhang 2025', ['E2.1-ZHANG2025-POD1'], 'E2_opioid24_TEAS_sham', 'Opioid dose on postoperative day 1', [L, SC, H, L, SC], [
    'Stata-generated sequence and consecutive opaque envelopes.',
    'Anaesthesiologists both deliver the intervention and are described as masked; implementation unclear.',
    '15 of 108 excluded after randomisation (93 analysed, 45/48), including surgical protocol modifications and withdrawals that plausibly affect opioid need.',
    'Delivered PCA opioid is a recorded quantity.',
    'Printed CIs and P values conflict with arm data elsewhere in the report; prospective analysis plan not verified.'],
    'Zhang 2025 PDF p2-4 flow; consistent with second-reviewed Zhang 2025 assessments')
assess('Lin 2002', ['V33-OD-0004', 'V33-OD-0005'], 'E2_opioid24_EA_usual', 'Cumulative IV PCA morphine, first 24 h', [SC, SC, L, H, SC], [
    'Computer-generated randomisation sequence; allocation concealment not described (p2).',
    'Control patients received no needle insertion and so knew they were untreated; masking applied only to the needled groups (p2).',
    'All enrolled patients completed the study with no withdrawals (p3).',
    'The first-hour dose was given when the patient complained, and PCA demand is self-initiated; untreated controls knew their allocation, and staff masking is not reported (p2-3). Consistent with the high rating for Lin 2002 versus sham.',
    'Morphine at 24 h is a named efficacy measure; prospective analysis plan not verified.'],
    'Lin 2002 PDF p1-3 (Pain 2002;99:509-14)')

out = HERE / 'dose_rob2_supplement_2026-10-23.csv'
with out.open('w', newline='') as f:
    w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)
print(len(rows), 'rows;', {r['result_id']: r['overall'] for r in rows})
