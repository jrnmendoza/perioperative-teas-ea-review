# Lee 2011 held from all pooled analyses (author decision, 23 October 2026): its population included participants aged
# 14-59 years, and its pain and mobility results were already held from the adult-only synthesis for that reason.
# Step 1 reproduces every existing broader-dose model that contains Lee (e2/e2_model_outputs.csv, read-only).
# Step 2 refits each without Lee, plus the high-risk exclusion using dose_rob2_supplement_2026-10-23.csv.
# Writes lee_hold_rerun_2026-10-23.csv. Base R; same estimator as rerun.py (REML, HK truncated at 1, t(k-1)).
args <- commandArgs(trailingOnly = FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)])))
root <- normalizePath(file.path(here, "..", "..", ".."))
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^﻿", "", names(x)); x }
inp <- rd(file.path(here, "e2", "e2_model_inputs.csv"))
out0 <- rd(file.path(here, "e2", "e2_model_outputs.csv"))
fit <- function(d) {
  k <- nrow(d); y <- as.numeric(d$yi); v <- as.numeric(d$vi)
  N <- sum(as.integer(as.numeric(d$n_i)) + as.integer(as.numeric(d$n_c)))
  if (k == 1) return(list(k = 1, N = N, effect = y, lo = y - qnorm(.975)*sqrt(v), hi = y + qnorm(.975)*sqrt(v), I2 = NA, pil = NA, pih = NA))
  nll <- function(t) { w <- 1/(v + t); mu <- sum(w*y)/sum(w); .5*(sum(log(v + t)) + log(sum(w)) + sum(w*(y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2)*10, max(v)*10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1/(v + tau); mu <- sum(w*y)/sum(w); q <- sum(w*(y - mu)^2)/(k - 1)
  se <- sqrt(max(1, q)/sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1/v; C <- sum(w0) - sum(w0^2)/sum(w0); i2 <- 100*tau/(tau + (k - 1)/C)
  pil <- pih <- NA
  if (k >= 5) { h <- qt(.975, k - 1)*sqrt(tau + se^2); pil <- mu - h; pih <- mu + h }
  list(k = k, N = N, effect = mu, lo = mu - cr*se, hi = mu + cr*se, I2 = i2, pil = pil, pih = pih)
}
models <- sort(unique(inp$model_id[inp$study == "Lee 2011"]))
res <- list(); maxd <- 0
for (m in models) {
  d <- inp[inp$model_id == m, ]; b <- out0[out0$model_id == m, ]
  f0 <- fit(d); stopifnot(nrow(b) == 1, f0$k == as.integer(b$k))
  dd <- max(abs(c(f0$effect - as.numeric(b$effect), f0$lo - as.numeric(b$ci_low), f0$hi - as.numeric(b$ci_high)))); maxd <- max(maxd, dd); stopifnot(dd < 1e-6)
  f1 <- fit(d[d$study != "Lee 2011", ])
  res[[m]] <- data.frame(model_id = m, k_with_lee = f0$k, effect_with_lee = f0$effect, k = f1$k, N = f1$N, effect = f1$effect,
                         ci_low = f1$lo, ci_high = f1$hi, I2 = f1$I2, pi_low = f1$pil, pi_high = f1$pih,
                         reports = paste(d$study[d$study != "Lee 2011"], collapse = ";"), stringsAsFactors = FALSE)
}
# check: the new main model equals the existing leave-out-Lee model
lo <- out0[out0$model_id == "E2_TEAS_sham_leaveout_Lee2011", ]
stopifnot(abs(res[["E2_opioid24_TEAS_sham"]]$effect - as.numeric(lo$effect)) < 1e-6)
# high-risk exclusion without Lee, using the second-reviewed dose assessments
link <- rd(file.path(root, "FINAL_RESULT_ROB2_LINKAGE.csv")); rating <- setNames(link$overall, link$result_id)
sup <- rd(file.path(here, "dose_rob2_supplement_2026-10-23.csv")); rating[sup$result_id] <- sup$overall
main <- inp[inp$model_id == "E2_opioid24_TEAS_sham" & inp$study != "Lee 2011", ]
ov <- sapply(main$result_id, function(ids) { r <- rating[strsplit(ids, "+", fixed = TRUE)[[1]]]; if (any(r == "High")) "High" else "OK" })
f2 <- fit(main[ov != "High", ])
res[["NOT_HIGH"]] <- data.frame(model_id = "E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE", k_with_lee = 6, effect_with_lee = -7.10774052025678,
  k = f2$k, N = f2$N, effect = f2$effect, ci_low = f2$lo, ci_high = f2$hi, I2 = f2$I2, pi_low = f2$pil, pi_high = f2$pih,
  reports = paste(main$study[ov != "High"], collapse = ";"), stringsAsFactors = FALSE)
out <- do.call(rbind, res)
write.csv(out, file.path(here, "lee_hold_rerun_2026-10-23.csv"), row.names = FALSE)
cat(sprintf("Reproduced %d models with Lee; maximum difference %.1e\n", length(models), maxd))
print(transform(out[, c("model_id", "k", "N", "effect", "ci_low", "ci_high", "I2", "pi_low", "pi_high")],
                effect = round(effect, 2), ci_low = round(ci_low, 2), ci_high = round(ci_high, 2), I2 = round(I2, 1),
                pi_low = round(pi_low, 2), pi_high = round(pi_high, 2)), row.names = FALSE)
