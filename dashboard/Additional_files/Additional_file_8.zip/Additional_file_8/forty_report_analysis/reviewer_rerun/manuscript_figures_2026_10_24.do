* Manuscript Figures 3 and 4 (24 October 2026).
* Fig 3: broader first-day opioid dose by modality and comparator, Lee 2011 held from all pooled analyses
*        (author decision, 23 October 2026). Fig 4: receipt of additional rescue opioid, TEAS versus sham.
* Same estimator as stata_figures.do and lee_hold_rerun_2026_10_23.R: REML, Hartung-Knapp truncated at 1, normal
* intervals for single trials. Every estimate is checked against the verified outputs before the figures are drawn.
* Figures carry no titles; captions are in the manuscript legends.
* Run from the repository root: stata-se -b do opioid_only_review/forty_report_analysis/reviewer_rerun_2026_10_09/manuscript_figures_2026_10_24.do
version 19.5
clear all
set more off
set varabbrev off
global RR "`c(pwd)'/opioid_only_review/forty_report_analysis/reviewer_rerun_2026_10_09"
global OUT "$RR/stata/manuscript_2026_10_24"
capture mkdir "$RR/stata"
capture mkdir "$OUT"
capture erase "$OUT/COMPLETED.txt"
log using "$OUT/run.log", text replace
set scheme stcolor
graph set svg fontface "Helvetica"
graph set window fontface "Helvetica"

* ---- expected estimates (verified outputs) -------------------------------------------------------------------
import delimited using "$RR/lee_hold_rerun_2026-10-23.csv", clear varnames(1) bindquote(strict) stringcols(_all)
keep if model_id == "E2_opioid24_TEAS_sham"
assert _N == 1
global X_E2_opioid24_TEAS_sham = effect[1] + " " + ci_low[1] + " " + ci_high[1]
global PI_TEAS_sham = pi_low[1] + " " + pi_high[1]
import delimited using "$RR/model_results.csv", clear varnames(1) bindquote(strict) stringcols(_all)
foreach m in E2_opioid24_TEAS_usual E2_opioid24_EA_sham E2_opioid24_EA_usual RESCUE_TEAS_SHAM_ANY_FOLLOWUP {
    preserve
    keep if model_id == "`m'"
    assert _N == 1
    global X_`m' = effect[1] + " " + ci_low[1] + " " + ci_high[1]
    global PI_`m' = pi_low[1] + " " + pi_high[1]
    restore
}

* ---- inputs ----------------------------------------------------------------------------------------------------
import delimited using "$RR/model_inputs.csv", clear varnames(1) bindquote(strict) stringcols(_all)
keep if inlist(model_id, "E2_opioid24_TEAS_sham", "E2_opioid24_TEAS_usual", "E2_opioid24_EA_sham", ///
    "E2_opioid24_EA_usual", "RESCUE_TEAS_SHAM_ANY_FOLLOWUP")
foreach v in n_i n_c mean_i mean_c sd_i sd_c events_i events_c yi vi {
    destring `v', replace
}
gen str100 studylabel = report
replace studylabel = study if studylabel == ""
count if studylabel == "Lee 2011"
assert r(N) == 1
drop if studylabel == "Lee 2011"
replace studylabel = "He 2026" if studylabel == "He 2026 (hepatectomy/JIS)"
gen double s_yi = mean_i - mean_c if effect_measure == "MD"
gen double s_vi = sd_i^2/n_i + sd_c^2/n_c if effect_measure == "MD"
replace s_yi = ln((events_i/n_i)/(events_c/n_c)) if effect_measure == "RR"
replace s_vi = 1/events_i - 1/n_i + 1/events_c - 1/n_c if effect_measure == "RR"
assert abs(s_yi - yi) < 1e-8 & abs(s_vi - vi) < 1e-8
gen double s_se = sqrt(s_vi)
gen byte grp = 1 if model_id == "E2_opioid24_TEAS_sham"
replace grp = 2 if model_id == "E2_opioid24_TEAS_usual"
replace grp = 3 if model_id == "E2_opioid24_EA_sham"
replace grp = 4 if model_id == "E2_opioid24_EA_usual"
replace grp = 5 if model_id == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP"
label define grp 1 "TEAS versus sham" 2 "TEAS versus usual care" 3 "EA versus sham" 4 "EA versus usual care" ///
    5 "TEAS versus sham"
label values grp grp
save "$OUT/inputs.dta", replace

* ---- check every estimate against the verified outputs ---------------------------------------------------------
foreach m in E2_opioid24_TEAS_sham E2_opioid24_TEAS_usual E2_opioid24_EA_sham E2_opioid24_EA_usual RESCUE_TEAS_SHAM_ANY_FOLLOWUP {
    use "$OUT/inputs.dta", clear
    keep if model_id == "`m'"
    local k = _N
    if `k' == 1 {
        local th = s_yi[1]
        local lb = s_yi[1] - invnormal(.975)*s_se[1]
        local ub = s_yi[1] + invnormal(.975)*s_se[1]
    }
    else {
        meta set s_yi s_se, studylabel(studylabel) random(reml)
        quietly meta summarize, se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
        assert r(converged) == 1
        local th = r(theta)
        local lb = r(ci_lb)
        local ub = r(ci_ub)
        meta clear
    }
    if "`m'" == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP" {
        local th = exp(`th')
        local lb = exp(`lb')
        local ub = exp(`ub')
    }
    tokenize "${X_`m'}"
    di as txt "`m': k=`k' effect " %9.4f `th' " (" %9.4f `lb' ", " %9.4f `ub' ")  expected `1' (`2', `3')"
    assert abs(`th' - `1') < 1e-6 & abs(`lb' - `2') < 1e-6 & abs(`ub' - `3') < 1e-6
}

capture program drop exportfigure
program define exportfigure
    args name
    graph save "$OUT/`name'.gph", replace
    graph export "$OUT/`name'.pdf", as(pdf) replace
    graph export "$OUT/`name'.svg", as(svg) replace
    graph export "$OUT/`name'.png", as(png) replace width(2600)
end

* ---- Figure 3: broader first-day opioid dose by comparison (custom forest plot) ------------------------------------
* Drawn with twoway so that nothing is pooled or tested across comparisons, weights are within each comparison, and
* single trials carry no summary diamond.
use "$OUT/inputs.dta", clear
keep if grp <= 4
gen int ord = _n
gen double lb = s_yi - invnormal(.975)*s_se
gen double ub = s_yi + invnormal(.975)*s_se
tempname P
postfile `P' byte grp int k double(theta plb pub tau2 i2 pil piu) using "$OUT/fig3_pooled.dta", replace
forvalues g = 1/4 {
    preserve
    quietly keep if grp == `g'
    local k = _N
    if `k' == 1 {
        post `P' (`g') (1) (.) (.) (.) (0) (.) (.) (.)
    }
    else {
        meta set s_yi s_se, studylabel(studylabel) random(reml)
        quietly meta summarize, se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
        assert r(converged) == 1
        local th = r(theta)
        local se = r(se)
        local plb = r(ci_lb)
        local pub = r(ci_ub)
        local tau = r(tau2)
        quietly gen double w0 = 1/s_vi
        quietly gen double w02 = w0^2
        quietly summarize w0
        local sw = r(sum)
        quietly summarize w02
        local C = `sw' - r(sum)/`sw'
        local i2 = 100*`tau'/(`tau' + (`k'-1)/`C')
        local pil = .
        local piu = .
        if `k' >= 5 {
            local pil = `th' - invttail(`k'-1, .025)*sqrt(`tau' + `se'^2)
            local piu = `th' + invttail(`k'-1, .025)*sqrt(`tau' + `se'^2)
        }
        post `P' (`g') (`k') (`th') (`plb') (`pub') (`tau') (`i2') (`pil') (`piu')
        meta clear
    }
    restore
}
postclose `P'
use "$OUT/fig3_pooled.dta", clear
tokenize "$PI_TEAS_sham"
assert abs(pil[1] - `1') < 1e-6 & abs(piu[1] - `2') < 1e-6
forvalues g = 1/4 {
    foreach v in k theta plb pub tau2 i2 pil piu {
        local `v'_`g' = `v'[`g']
    }
}
use "$OUT/inputs.dta", clear
keep if grp <= 4
gen int ord = _n
gen double lb = s_yi - invnormal(.975)*s_se
gen double ub = s_yi + invnormal(.975)*s_se
gen double tau2 = .
forvalues g = 1/4 {
    replace tau2 = `tau2_`g'' if grp == `g'
}
gen double wraw = 1/(s_vi + tau2)
bysort grp: egen double wsum = total(wraw)
gen double wpct = 100*wraw/wsum
sort grp ord
local n = _N
forvalues i = 1/`n' {
    local g_`i' = grp[`i']
    local lab_`i' = studylabel[`i']
    local est_`i' = s_yi[`i']
    local lb_`i' = lb[`i']
    local ub_`i' = ub[`i']
    local w_`i' = wpct[`i']
}
capture program drop f2
program define f2, rclass
    args x
    return local s = strtrim(string(`x', "%9.2f"))
end
local h = .3
tempname R
postfile `R' double(y est lo hi pil piu dx dy1 dy2) byte(kind did) str100 lab str60 txt str12 wtxt ///
    using "$OUT/fig3_rows.dta", replace
local y = 0
local names `" "TEAS versus sham" "TEAS versus usual care" "EA versus sham" "EA versus usual care" "'
local d = 0
forvalues g = 1/4 {
    local y = `y' - 1
    local nm : word `g' of `names'
    post `R' (`y') (.) (.) (.) (.) (.) (.) (.) (.) (1) (.) ("{bf:`nm'}") ("") ("")
    forvalues i = 1/`n' {
        if `g_`i'' == `g' {
            local y = `y' - 1
            f2 `est_`i''
            local a = r(s)
            f2 `lb_`i''
            local b = r(s)
            f2 `ub_`i''
            local c = r(s)
            local wt = strtrim(string(`w_`i'', "%5.1f"))
            post `R' (`y') (`est_`i'') (`lb_`i'') (`ub_`i'') (.) (.) (.) (.) (.) (2) (.) ("`lab_`i''") ///
                ("`a' (`b' to `c')") ("`wt'")
        }
    }
    if `k_`g'' > 1 {
        local y = `y' - 1
        local ++d
        f2 `theta_`g''
        local a = r(s)
        f2 `plb_`g''
        local b = r(s)
        f2 `pub_`g''
        local c = r(s)
        local i2t = strtrim(string(`i2_`g'', "%5.1f"))
        local tt = strtrim(string(`tau2_`g'', "%6.2f"))
        post `R' (`y') (`theta_`g'') (`plb_`g'') (`pub_`g'') (`pil_`g'') (`piu_`g'') (.) (.) (.) (3) (`d') ///
            ("Pooled (I{superscript:2} = `i2t'%, {&tau}{superscript:2} = `tt')") ("{bf:`a' (`b' to `c')}") ("100.0")
        post `R' (.) (.) (.) (.) (.) (.) (`plb_`g'') (`y') (`y') (4) (`d') ("") ("") ("")
        post `R' (.) (.) (.) (.) (.) (.) (`theta_`g'') (`y' - `h') (`y' + `h') (4) (`d') ("") ("") ("")
        post `R' (.) (.) (.) (.) (.) (.) (`pub_`g'') (`y') (`y') (4) (`d') ("") ("") ("")
    }
    local y = `y' - .5
}
postclose `R'
use "$OUT/fig3_rows.dta", clear
quietly summarize y
local ybot = r(min) - .9
local labs ""
forvalues i = 1/`=_N' {
    if inlist(kind[`i'], 1, 2, 3) {
        local labs `"`labs' `=y[`i']' `"`=lab[`i']'"'"'
    }
}
local XT = 24
local XW = 68
gen double xt = `XT'
gen double xw = `XW'
local ticks ""
local ticklabs ""
forvalues t = -40(10)20 {
    local ticks `"`ticks' (pci `ybot' `t' `=`ybot' - .18' `t', lcolor(black) lwidth(thin))"'
    local ticklabs `"`ticklabs' `=`ybot' - .6' `t' "`t'""'
}
twoway (rspike pil piu y if kind == 3 & pil < ., horizontal lcolor(cranberry) lwidth(medthin)) ///
    (rarea dy1 dy2 dx if did == 1 & kind == 4, sort color(cranberry) lwidth(none)) ///
    (rarea dy1 dy2 dx if did == 2 & kind == 4, sort color(cranberry) lwidth(none)) ///
    (rspike lo hi y if kind == 2, horizontal lcolor(navy) lwidth(medthin)) ///
    (scatter y est if kind == 2, msymbol(S) msize(medsmall) mcolor(navy)) ///
    (scatter y xt if inlist(kind, 2, 3), msymbol(none) mlabel(txt) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatter y xw if inlist(kind, 2, 3), msymbol(none) mlabel(wtxt) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)) ///
    (pci -.45 0 `ybot' 0, lcolor(gs9) lpattern(dash)) ///
    (pci `ybot' -40 `ybot' 20, lcolor(black) lwidth(thin)) `ticks' ///
    (scatteri `ticklabs', msymbol(none) mlabpos(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatteri `=`ybot' - 1.35' -10 "Mean difference, mg IV morphine equivalents", msymbol(none) mlabpos(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatteri `=`ybot' - 1.95' -10 "{&larr} Favours TEAS or EA     Favours control {&rarr}", msymbol(none) mlabpos(0) mlabsize(10pt) mlabcolor(gs6)) ///
    (scatteri 0 `XT' "{bf:Mean difference (95% CI)}" 0 `XW' "{bf:Weight, %}", msymbol(none) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)), ///
    ylabel(0 "{bf:Comparison and trial}" `labs', angle(0) noticks labsize(12pt) nogrid) ytitle("") ///
    yscale(noline range(`=`ybot' - 2.2' .3)) xscale(off range(-40 80)) xlabel(, nogrid) legend(off) ///
    graphregion(color(white) margin(l+3 r+2)) plotregion(color(white) margin(zero)) ///
    note("Pooled: random effects (REML) with Hartung–Knapp 95% CI; weights are within each comparison. Single trials: normal 95% CI." ///
         "Line through the TEAS-versus-sham diamond: 95% prediction interval (t, k−1 df). Lee 2011 is held from all pooled analyses.", ///
         size(10pt) span) ///
    xsize(12) ysize(7.8) name(g, replace)
exportfigure "Figure3_broader_first_day_opioid"

* ---- Figure 4: receipt of additional rescue opioid (same custom style as Figure 3, log scale) -----------------------
use "$OUT/inputs.dta", clear
keep if grp == 5
gen int ord = _n
local k = _N
meta set s_yi s_se, studylabel(studylabel) random(reml)
quietly meta summarize, se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
assert r(converged) == 1
local th = r(theta)
local se = r(se)
local plb = r(ci_lb)
local pub = r(ci_ub)
local tau = r(tau2)
meta clear
gen double w0 = 1/s_vi
quietly summarize w0
local sw = r(sum)
gen double w02 = w0^2
quietly summarize w02
local C = `sw' - r(sum)/`sw'
local i2 = 100*`tau'/(`tau' + (`k'-1)/`C')
local pil = `th' - invttail(`k'-1, .025)*sqrt(`tau' + `se'^2)
local piu = `th' + invttail(`k'-1, .025)*sqrt(`tau' + `se'^2)
tokenize "$PI_RESCUE_TEAS_SHAM_ANY_FOLLOWUP"
assert abs(exp(`pil') - `1') < 1e-6 & abs(exp(`piu') - `2') < 1e-6
gen double wpct = 100*(1/(s_vi + `tau'))
quietly summarize wpct
replace wpct = 100*wpct/r(sum)
gen double lb = s_yi - invnormal(.975)*s_se
gen double ub = s_yi + invnormal(.975)*s_se
sort ord
forvalues i = 1/`k' {
    local lab_`i' = studylabel[`i']
    local est_`i' = s_yi[`i']
    local lb_`i' = lb[`i']
    local ub_`i' = ub[`i']
    local w_`i' = wpct[`i']
}
local h = .3
tempname R
postfile `R' double(y est lo hi pil piu dx dy1 dy2) byte(kind did) str100 lab str60 txt str12 wtxt ///
    using "$OUT/fig4_rows.dta", replace
local y = -1
post `R' (`y') (.) (.) (.) (.) (.) (.) (.) (.) (1) (.) ("{bf:TEAS versus sham}") ("") ("")
forvalues i = 1/`k' {
    local y = `y' - 1
    local a = strtrim(string(exp(`est_`i''), "%9.2f"))
    local b = strtrim(string(exp(`lb_`i''), "%9.2f"))
    local c = strtrim(string(exp(`ub_`i''), "%9.2f"))
    local wt = strtrim(string(`w_`i'', "%5.1f"))
    post `R' (`y') (`est_`i'') (`lb_`i'') (`ub_`i'') (.) (.) (.) (.) (.) (2) (.) ("`lab_`i''") ("`a' (`b' to `c')") ("`wt'")
}
local y = `y' - 1
local a = strtrim(string(exp(`th'), "%9.2f"))
local b = strtrim(string(exp(`plb'), "%9.2f"))
local c = strtrim(string(exp(`pub'), "%9.2f"))
local i2t = strtrim(string(`i2', "%5.1f"))
local tt = strtrim(string(`tau', "%6.2f"))
post `R' (`y') (`th') (`plb') (`pub') (`pil') (`piu') (.) (.) (.) (3) (1) ///
    ("Pooled (I{superscript:2} = `i2t'%, {&tau}{superscript:2} = `tt')") ("{bf:`a' (`b' to `c')}") ("100.0")
post `R' (.) (.) (.) (.) (.) (.) (`plb') (`y') (`y') (4) (1) ("") ("") ("")
post `R' (.) (.) (.) (.) (.) (.) (`th') (`y' - `h') (`y' + `h') (4) (1) ("") ("") ("")
post `R' (.) (.) (.) (.) (.) (.) (`pub') (`y') (`y') (4) (1) ("") ("") ("")
postclose `R'
use "$OUT/fig4_rows.dta", clear
local ybot = `y' - .9
local labs ""
forvalues i = 1/`=_N' {
    if inlist(kind[`i'], 1, 2, 3) {
        local labs `"`labs' `=y[`i']' `"`=lab[`i']'"'"'
    }
}
local x0 = ln(.1)
local x1 = ln(2)
local XT = `x1' + .2
local XW = `x1' + 1.75
gen double xt = `XT'
gen double xw = `XW'
local ticks ""
local ticklabs ""
foreach v in .1 .25 .5 1 2 {
    local lv = ln(`v')
    local s = cond(`v' < 1, "0" + string(`v'), string(`v'))
    local ticks `"`ticks' (pci `ybot' `lv' `=`ybot' - .18' `lv', lcolor(black) lwidth(thin))"'
    local ticklabs `"`ticklabs' `=`ybot' - .6' `lv' "`s'""'
}
local xmid = (`x0' + `x1')/2
twoway (rspike pil piu y if kind == 3 & pil < ., horizontal lcolor(cranberry) lwidth(medthin)) ///
    (rarea dy1 dy2 dx if did == 1 & kind == 4, sort color(cranberry) lwidth(none)) ///
    (rspike lo hi y if kind == 2, horizontal lcolor(navy) lwidth(medthin)) ///
    (scatter y est if kind == 2, msymbol(S) msize(medsmall) mcolor(navy)) ///
    (scatter y xt if inlist(kind, 2, 3), msymbol(none) mlabel(txt) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatter y xw if inlist(kind, 2, 3), msymbol(none) mlabel(wtxt) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)) ///
    (pci -.45 0 `ybot' 0, lcolor(gs9) lpattern(dash)) ///
    (pci `ybot' `x0' `ybot' `x1', lcolor(black) lwidth(thin)) `ticks' ///
    (scatteri `ticklabs', msymbol(none) mlabpos(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatteri `=`ybot' - 1.35' `xmid' "Risk ratio (log scale)", msymbol(none) mlabpos(0) mlabsize(12pt) mlabcolor(black)) ///
    (scatteri `=`ybot' - 1.95' `xmid' "{&larr} Favours TEAS     Favours sham {&rarr}", msymbol(none) mlabpos(0) mlabsize(10pt) mlabcolor(gs6)) ///
    (scatteri 0 `XT' "{bf:Risk ratio (95% CI)}" 0 `XW' "{bf:Weight, %}", msymbol(none) mlabpos(3) mlabgap(0) mlabsize(12pt) mlabcolor(black)), ///
    ylabel(0 "{bf:Comparison and trial}" `labs', angle(0) noticks labsize(12pt) nogrid) ytitle("") ///
    yscale(noline range(`=`ybot' - 2.2' .3)) xscale(off range(`x0' `=`XW' + .45')) xlabel(, nogrid) legend(off) ///
    graphregion(color(white) margin(l+3 r+2)) plotregion(color(white) margin(zero)) ///
    note("Pooled: random effects (REML) with Hartung–Knapp 95% CI. Line through the diamond: 95% prediction interval (t, k−1 df)." ///
         "Follow-up ranged from 6–24 hours to 3 days, so the estimate is not a 0–24-hour effect.", size(10pt) span) ///
    xsize(12) ysize(5.2) name(g, replace)
exportfigure "Figure4_rescue_opioid"

file open done using "$OUT/COMPLETED.txt", write replace text
file write done "Figures 3 and 4 completed in Stata `c(stata_version)' on `c(current_date)'; all estimates matched the verified outputs." _n
file close done
log close
