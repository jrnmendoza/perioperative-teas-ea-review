"""Stata figure selections and captions only; no statistical estimates authored here."""
import collections,csv,json
from pathlib import Path
H=Path(__file__).resolve().parent
ROOT=H.parents[2]
def read(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
    with (H/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
models=read(H/'model_results.csv')
rows=[];specs=[];captions=[]
def summary(fid,title,null,note,selection):
    specs.append(dict(figure_id=fid,title=title,null=null,note=note))
    rows.extend(dict(figure_id=fid,order=i+1,model_id=mid,label=label) for i,(mid,label) in enumerate(selection))
    captions.append(dict(figure_id=fid,title=title,caption=note,kind='Stata-refitted model summary'))
teas_names=['Szmit 2021','Chen 1998','Chen 2020','He 2026','Lee 2011','Zhang 2025','Gu 2019']
teas_loo=[r for r in models if r['model_id'].startswith('E2_TEAS_sham_LOO_')]
summary('07_dose_TEAS_leave_one_out','First-day TEAS dose: leave-one-out checks',0,
    'TEAS versus sham. Broader first-day definition. All seven intervals include no difference.',
    [(r['model_id'],'Without '+name) for r,name in zip(teas_loo,teas_names)])
ea_loo=[r for r in models if r['model_id'].startswith('E2_EA_usual_LOO_')]
summary('08_dose_EA_leave_one_out','First-day EA dose: leave-one-out checks',0,
    'EA versus usual care. Four-trial broader first-day body; sparse-study intervals retained.',
    [(r['model_id'],'Without '+name) for r,name in zip(ea_loo,['El-Rakshy 2009','Seevaunnamtum 2016','Yang 2024','Lin 2002'])])
summary('09_rescue_leave_one_out','Rescue opioids: leave-one-out checks',1,
    'TEAS versus sham. Mixed follow-up. Single-trial removal does not address biases shared by several trials.',
    [(r['model_id'],'Without '+r['removed_report']) for r in models if r['model_id'].startswith('RESCUE_LOO_')])
summary('10_rescue_bias_restrictions','Rescue opioids: outcome-specific bias checks',1,
    'The low-risk-only restriction has no eligible trials. Removing both high-risk trials leaves benefit uncertain.',
    [('RESCUE_TEAS_SHAM_ANY_FOLLOWUP','All five rescue trials'),
     ('RESCUE_LOO_Liu_2026_(ESD)','Exclude Liu ESD only'),('RESCUE_NOT_HIGH','Exclude both high-risk trials')])
summary('11_rescue_timing_restrictions','Rescue opioids: follow-up restrictions',1,
    'No common complete 0-24-hour pool is available. The wide two-trial interval is retained, not truncated.',
    [('RESCUE_TEAS_SHAM_ANY_FOLLOWUP','Mixed follow-up (5 trials)'),
     ('RESCUE_TEAS_SHAM_KNOWN_PERIODS','Exclude unspecified-window Yu (4 trials)'),
     ('RESCUE_TEAS_SHAM_FIRST_DAY_APPROX','Approximate first day (2 trials)'),
     ('RESCUE_TEAS_SHAM_EARLY_PLUS_UNCLEAR','Approximate first day plus Yu (3 trials)')])
summary('12_rescue_missing_outcomes','Rescue opioids: hypothetical missing outcomes',1,
    'All 497 randomized participants. Hypothetical assignments, not recovered data or verified intention-to-treat analyses.',
    [('RESCUE_TEAS_SHAM_ANY_FOLLOWUP','Observed outcomes only'),
     ('RESCUE_MISSING_NONE','No missing patients receive rescue'),('RESCUE_MISSING_ALL','All missing patients receive rescue'),
     ('RESCUE_MISSING_UNFAVOURABLE_TO_TEAS','Missing outcomes unfavourable to TEAS'),
     ('RESCUE_MISSING_FAVOURABLE_TO_TEAS','Missing outcomes favourable to TEAS')])
summary('13_broader_dose_comparisons','Broader first-day opioid dose: comparisons',0,
    'Separate modalities and comparators. EA/sham is one high-risk trial. Not a combined effect from all 40 reports.',
    [(mid,label) for mid,label in [('E2_opioid24_TEAS_sham','TEAS versus sham (7 trials)'),
        ('E2_opioid24_TEAS_usual','TEAS versus usual care (1 trial)'),
        ('E2_opioid24_EA_sham','EA versus sham (1 trial)'),('E2_opioid24_EA_usual','EA versus usual care (4 trials)')]])
write('stata_summary_specs.csv',specs)
write('stata_figure_rows.csv',rows)

existing=read(ROOT/'10_FINAL_ADJUDICATION/04_MODELS/model_outputs.csv')
additional=[]
counter=14
additional_diagnostics={'opioid_partial_EA_sham','opioid_partial_EA_usual','opioid_partial_TEAS_sham',
    'opioid24_EA_sham_weight_normalized','opioid24_EA_sham_fentanyl_per_kg',
    'opioid72_EA_usual_PCA','opioid48_TEAS_sham_uncertain_suf0.5'}
for r in existing:
    if not r['model_id'].startswith(('opioid','pethidine')) or int(r['k'])==0:continue
    if r['role']=='SENSITIVITY' and r['model_id'] not in additional_diagnostics:continue
    if r['model_id'] in ['opioid24_TEAS_sham','opioid24_TEAS_usual']:continue
    # Uncertain conversion variants remain numerical sensitivity tables, not many duplicate figures.
    if 'uncertain_suf' in r['model_id'] and r['model_id'] not in additional_diagnostics:continue
    mid=r['model_id']
    fid=f'{counter:02}_additional_'+mid
    title=r['construct'].replace('_',' ')
    note=f"{r['modality']} versus {r['comparator']}. Original {r['role'].lower()} outcome; source limitations retained."
    axis='Mean difference ('+r['unit']+')'
    if mid=='opioid24_EA_usual':note+=' Complete 24-hour systemic dose, distinct from expanded four-trial body.'
    if 'partial' in mid:note+=' Early postoperative opioid capture is incomplete.'
    if 'uncertain_suf' in mid:note+=' Sufentanil conversion 0.5 mg/ug; source-equivalence uncertainty.'
    additional.append('forest '+ ' '.join('"'+x.replace('"',"'")+'"' for x in [mid,fid,title,note,axis]))
    captions.append(dict(figure_id=fid,title=title,caption=note,kind='Stata forest plot'))
    counter+=1
(H/'stata_additional_forests.do').write_text('\n'.join(additional)+'\n')

individual=read(H/'reextraction/individual_estimates.csv')
groups=collections.defaultdict(list)
for r in individual:
    if r['effect_measure']=='MD':groups[(r['outcome'],r['unit'],r['opioid'])].append(r)
    elif r['report']=='Xie 2014':groups[('EA rescue receipt','Risk ratio','Dezocine')].append(r)
    elif 'Routine' in r['outcome'] or 'PCIA' in r['outcome']:
        groups[('Routine opioid pump receipt','Risk ratio','Various opioids')].append(r)
    elif r['report']=='Zhou 2021':groups[('Any opioid receipt','Risk ratio',r['opioid'])].append(r)
native=[]
for (outcome,unit,drug),items in groups.items():
    fid=f'{counter:02}_native_outcomes'
    counter+=1
    note='Unpooled individual estimates. '+drug+'.'
    if unit=='mL':note+=' Solution volumes are not opioid mass; concentrations/eligibility may remain unresolved.'
    if any('Yeh' in r['report'] for r in items):note+=' Potential cohort overlap; route discrepancies unresolved; held from pooling.'
    if any('Grech' in r['report'] for r in items):note+=' Approximate graph extraction and denominator uncertainty.'
    if any('Xie' in r['report'] for r in items):note+=' Shared active arm; unspecified rescue window; very-low-certainty evidence.'
    if 'pump receipt' in outcome:note+=' Routine provision is different from extra rescue; follow-up periods differ.'
    if any('HELD' in r['status'] for r in items):note+=' Source issues preclude pooled interpretation.'
    native.append(dict(figure_id=fid,unit=('Mean difference ('+unit+')') if items[0]['effect_measure']=='MD' else unit,
        title=outcome+' ('+drug+')',note=note,
        outcome_ids=' '.join('"'+r['outcome_id']+'"' for r in items)))
    captions.append(dict(figure_id=fid,title=outcome+' ('+drug+')',caption=note,kind='Unpooled Stata forest plot'))
write('stata_native_specs.csv',native)
captions=[dict(figure_id=f'{i:02}_{name}',title=title,caption=caption,kind='Stata forest plot') for i,name,title,caption in [
    (1,'registered_24h_TEAS_sham','Registered complete 24-hour opioid dose','One 48-participant trial. 10-mg threshold shown; paired pain criterion not established.'),
    (2,'broader_first_day_TEAS_sham','Broader first-day TEAS versus sham','Seven trials. Post-hoc definition; highly heterogeneous dose results.'),
    (3,'broader_first_day_TEAS_usual','Broader first-day TEAS versus usual care','One trial; shared active arm with sham comparison.'),
    (4,'broader_first_day_EA_sham','Broader first-day EA versus sham','One high-risk trial; incomplete early opioid capture.'),
    (5,'broader_first_day_EA_usual','Broader first-day EA versus usual care','Four trials; source and incomplete-capture limitations retained.'),
    (6,'rescue_TEAS_sham','Additional rescue opioid receipt','Five trials with different postoperative periods. Exploratory low-certainty evidence.')]]+captions
captions.sort(key=lambda r:r['figure_id'])
write('figure_captions.csv',captions)
print('Prepared',len(captions),'Stata figures:',6,'main forests,',len(specs),'robustness/comparison figures,',len(additional),'additional dose forests,',len(native),'native-outcome figures.')
