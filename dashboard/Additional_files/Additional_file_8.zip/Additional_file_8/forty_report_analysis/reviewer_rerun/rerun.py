"""Dated reviewer-informed rerun of the fixed 40-report scenario.

Existing builders are executed with output-directory overrides only. Baseline
files remain unchanged. New checks are post hoc, not registered analyses.
Run with /tmp/teas-broad-opioid-plot/bin/python.
"""
import collections, contextlib, csv, hashlib, io, json, math
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm, t

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[1]
DATE = '2026-10-09'
D = ROOT / '10_FINAL_ADJUDICATION'

def read(path):
    with path.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def write(name, rows):
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with (HERE / name).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

protected = [BASE/'build_analysis.py', BASE/'additional_source_extraction.csv',
    BASE/'processed_outcomes.csv', BASE/'individual_estimates.csv',
    BASE/'rescue_model_inputs.csv', BASE/'rescue_model_results.csv',
    BASE/'forty_report_final_contributions.csv',
    BASE/'certainty_and_manuscript/rob2_rescue_assessments.csv',
    BASE/'certainty_and_manuscript/grade_rescue_evidence_profile.csv',
    D/'03_CANONICAL/results.csv', D/'03_CANONICAL/grade.csv',
    D/'04_MODELS/model_inputs.csv', D/'04_MODELS/model_outputs.csv',
    D/'09_E2_ANALYSIS/e2_model_inputs.csv', D/'09_E2_ANALYSIS/e2_model_outputs.csv',
    ROOT/'opioid_only_review/prisma/prisma_counts.json']
before = {str(p.relative_to(ROOT)): sha(p) for p in protected}
audit = read(ROOT/'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv')
cohort = {r['report']: r for r in audit if r['source_confirmed_named_opioid_or_author_MME']=='YES'}
families = {r['trial_id'] for r in cohort.values()}
assert len(cohort)==40 and len(families)==39
for r in cohort.values():
    assert sha(ROOT/r['source_pdf']) == r['source_sha256']

# Rerun the original extraction/calculation builder without writing its baseline.
reextract = HERE/'reextraction'
reextract.mkdir(exist_ok=True)
p = BASE/'build_analysis.py'
code = p.read_text()
old = 'OUT = Path(__file__).resolve().parent'
assert code.count(old)==1
with contextlib.redirect_stdout(io.StringIO()) as log:
    exec(compile(code.replace(old, f'OUT = Path({str(reextract)!r})'), str(p), 'exec'),
         {'__file__': str(p), '__name__': '__main__'})
(HERE/'reextraction_run.txt').write_text(log.getvalue())
for name in ['additional_source_extraction.csv','processed_outcomes.csv',
             'individual_estimates.csv','rescue_model_inputs.csv','rescue_model_results.csv',
             'forty_report_final_contributions.csv','analysis_counts.json']:
    assert (BASE/name).read_bytes()==(reextract/name).read_bytes(), name

# Rebuild all E2 arms from the canonical raw results, including shared-arm combination.
e2dir = HERE/'e2'
e2dir.mkdir(exist_ok=True)
p = D/'09_E2_ANALYSIS/run_e2.py'
code = p.read_text()
old = "OUT=D/'09_E2_ANALYSIS'"
assert code.count(old)==1
with contextlib.redirect_stdout(io.StringIO()) as log:
    exec(compile(code.replace(old, f'OUT=pathlib.Path({str(e2dir)!r})'), str(p), 'exec'),
         {'__file__': str(p), '__name__': '__main__'})
(HERE/'e2_run.txt').write_text(log.getvalue())

def fit(rows, mid, measure='MD', family='', analysis='', removed=''):
    k = len(rows)
    result = dict(model_id=mid, outcome_family=family, analysis=analysis,
        effect_measure=measure, k=k, N=sum(int(float(r['n_i']))+int(float(r['n_c'])) for r in rows),
        reports=';'.join(r.get('report', r.get('study','')) for r in rows),
        removed_report=removed, post_hoc='YES' if analysis!='Registered/canonical rerun' else 'See original model role')
    if not k:
        return dict(result, status='NO ELIGIBLE QUANTITATIVE DATA')
    y = np.array([float(r['yi']) for r in rows])
    v = np.array([float(r['vi']) for r in rows])
    assert np.all(v>0)
    tau=0.; q=None
    if k>1:
        def nll(tau):
            w=1/(v+tau); mu=np.sum(w*y)/sum(w)
            return .5*(sum(np.log(v+tau))+math.log(sum(w))+sum(w*(y-mu)**2))
        opt=minimize_scalar(nll, bounds=(0,max(1,np.var(y)*10,max(v)*10)),
                            method='bounded', options={'xatol':1e-12})
        tau=float(opt.x if opt.fun<nll(0) else 0)
        w=1/(v+tau); mu=float(sum(w*y)/sum(w))
        q=float(sum(w*(y-mu)**2)/(k-1)); se=math.sqrt(max(1,q)/sum(w)); crit=t.ppf(.975,k-1)
        w0=1/v; C=sum(w0)-sum(w0*w0)/sum(w0)
        i2=100*tau/(tau+(k-1)/C)
    else:
        mu=float(y[0]); se=math.sqrt(v[0]); crit=norm.ppf(.975); i2=None
    lo,hi=mu-crit*se,mu+crit*se
    transform = math.exp if measure=='RR' else float
    result.update(effect=transform(mu),ci_low=transform(lo),ci_high=transform(hi),
        estimate_scale=mu,se=se,tau2=tau,I2=i2,hk_scale=q,
        status='REML + safeguarded Hartung-Knapp' if k>1 else 'SINGLE TRIAL; NOT POOLED',
        confidence_includes_no_difference=lo<=0<=hi)
    if k>=5:
        half=t.ppf(.975,k-1)*math.sqrt(tau+se*se)
        result.update(pi_low=transform(mu-half),pi_high=transform(mu+half))
    return result

inputs=[]; results=[]; numerical_checks=[]
def add(rows, mid, measure, family, analysis, removed=''):
    assert len({r.get('trial_id') or r.get('report') or r.get('study') for r in rows})==len(rows), mid
    results.append(fit(rows,mid,measure,family,analysis,removed))
    inputs.extend(dict(r,model_id=mid,effect_measure=measure) for r in rows)

def dose_rows(path):
    groups=collections.defaultdict(list)
    for r in read(path):
        if not r['model_id'].startswith(('opioid','pethidine','tramadol','E2_')):
            continue
        # Input arms are already converted to the analysis scale; do not convert twice.
        yi=float(r['mean_i'])-float(r['mean_c'])
        vi=float(r['sd_i'])**2/float(r['n_i'])+float(r['sd_c'])**2/float(r['n_c'])
        assert abs(yi-float(r['yi']))<1e-8 and abs(vi-float(r['vi']))<1e-8
        r.update(yi=yi,vi=vi)
        groups[r['model_id']].append(r)
    return groups

canonical=dose_rows(D/'04_MODELS/model_inputs.csv')
expected=read(D/'04_MODELS/model_outputs.csv')
for r in expected:
    mid=r['model_id']
    if not (mid.startswith('opioid') or mid.startswith('pethidine') or mid.startswith('tramadol')):
        continue
    rows=canonical[mid]
    assert all(x['trial_id'] in families for x in rows), mid
    add(rows,mid,'MD','Postoperative opioid quantity: '+r['construct'],'Registered/canonical rerun')
    results[-1]['original_role']=r['role']
    if rows:
        delta=max(abs(results[-1][k]-float(r[k])) for k in ['effect','ci_low','ci_high'])
        assert delta<1e-6,(mid,delta)
        numerical_checks.append(dict(model_id=mid,baseline_max_abs_difference=delta,status='REPRODUCED'))

e2=dose_rows(e2dir/'e2_model_inputs.csv')
e2_expected={r['model_id']:r for r in read(D/'09_E2_ANALYSIS/e2_model_outputs.csv')}
for r in read(e2dir/'e2_model_outputs.csv'):
    add(e2[r['model_id']],r['model_id'],'MD','Broader first-day opioid dose: '+r['body'],r['role'])
    delta=max(abs(results[-1][k]-float(e2_expected[r['model_id']][k])) for k in ['effect','ci_low','ci_high'])
    assert delta<1e-6,(r['model_id'],delta)
    numerical_checks.append(dict(model_id=r['model_id'],baseline_max_abs_difference=delta,status='REPRODUCED'))

# Use exact result-linked RoB records, never a report-level rating from studies.json.
links={r['result_id']:r for r in read(ROOT/'FINAL_RESULT_ROB2_LINKAGE.csv')}
dose_bias=[]
for mid in ['E2_opioid24_TEAS_sham','E2_opioid24_TEAS_usual','E2_opioid24_EA_sham','E2_opioid24_EA_usual']:
    graded=[]
    for r in e2[mid]:
        ratings=[links.get(rid,{}).get('overall','UNLINKED') for rid in r['result_id'].split('+')]
        overall='High' if 'High' in ratings else ('NOT ESTABLISHED' if any(x not in ['Low','Some concerns'] for x in ratings) else ('Some concerns' if 'Some concerns' in ratings else 'Low'))
        row=dict(r,report=r['study'],result_specific_rob=overall)
        dose_bias.append(dict(model_id=mid,report=r['study'],result_ids=r['result_id'],
            outcome_specific_rob=overall,component_ratings=';'.join(ratings),
            basis='FINAL_RESULT_ROB2_LINKAGE.csv; no study-level substitution'))
        graded.append(row)
    for suffix, keep, description in [
        ('NOT_HIGH_WITH_LINKAGE',{'Low','Some concerns'},'Exclude high risk and unassessed dose results'),
        ('LOW_ONLY',{'Low'},'Reviewer-requested low-risk-only dose restriction')]:
        add([r for r in graded if r['result_specific_rob'] in keep],mid+'_'+suffix,
            'MD','Broader first-day opioid dose',description)

rescue=[]
for r in read(reextract/'rescue_model_inputs.csv'):
    if r['model_id']!='RESCUE_TEAS_SHAM_ANY_FOLLOWUP':continue
    a,c,ni,nc=[int(r[k]) for k in ['events_i','events_c','n_i','n_c']]
    r.update(yi=math.log((a/ni)/(c/nc)),vi=1/a-1/ni+1/c-1/nc,trial_id=cohort[r['report']]['trial_id'])
    rescue.append(r)
rob={r['report']:r['overall'] for r in read(BASE/'certainty_and_manuscript/rob2_rescue_assessments.csv') if r['comparison']=='Sham'}
for r in read(reextract/'rescue_model_results.csv'):
    selected=[x for x in rescue if x['report'] in r['reports'].split(';')]
    add(selected,r['model_id'],'RR','Additional rescue opioid receipt',r['description'])
    delta=max(abs(results[-1][k]-float(r[k])) for k in ['effect','ci_low','ci_high'])
    assert delta<1e-8
    numerical_checks.append(dict(model_id=r['model_id'],baseline_max_abs_difference=delta,status='REPRODUCED'))
for dropped in rescue:
    add([r for r in rescue if r['report']!=dropped['report']],
        'RESCUE_LOO_'+dropped['report'].replace(' ','_'),'RR','Additional rescue opioid receipt',
        'Complete leave-one-out check',dropped['report'])
for suffix,keep in [('NOT_HIGH',{'Low','Some concerns'}),('LOW_ONLY',{'Low'})]:
    add([r for r in rescue if rob[r['report']] in keep], 'RESCUE_'+suffix,
        'RR','Additional rescue opioid receipt','Outcome-specific bias restriction: '+suffix)

# Explicitly hypothetical binary missing-outcome bounds; not recovered outcome data.
randomized={'Tu 2024':(60,60),'Liu 2026 (burn)':(44,44),'Yu 2020':(30,30),
    'Liu 2026 (ESD)':(64,65),'Zhou 2025':(50,50)}
missing_rows=[]
for active_event,control_event,label in [(0,0,'NONE'),(1,1,'ALL'),(1,0,'UNFAVOURABLE_TO_TEAS'),(0,1,'FAVOURABLE_TO_TEAS')]:
    selected=[]
    for r in rescue:
        ni,nc=randomized[r['report']]; ai,ac=int(r['n_i']),int(r['n_c'])
        ei=int(r['events_i'])+(ni-ai)*active_event
        ec=int(r['events_c'])+(nc-ac)*control_event
        selected.append(dict(r,n_i=ni,n_c=nc,events_i=ei,events_c=ec,
            yi=math.log((ei/ni)/(ec/nc)),vi=1/ei-1/ni+1/ec-1/nc))
        missing_rows.append(dict(scenario=label,report=r['report'],observed_n_i=ai,observed_n_c=ac,
            randomized_n_i=ni,randomized_n_c=nc,missing_i=ni-ai,missing_c=nc-ac,
            imputed_events_i=(ni-ai)*active_event,imputed_events_c=(nc-ac)*control_event,
            assumption='Hypothetical sensitivity only; missing outcomes were not measured'))
    add(selected,'RESCUE_MISSING_'+label,'RR','Additional rescue opioid receipt',
        'Hypothetical complete randomized-denominator missing-outcome scenario')

write('model_results.csv',results)
write('model_inputs.csv',inputs)
write('baseline_reproduction.csv',numerical_checks)
write('dose_bias_linkage.csv',dose_bias)
write('missing_outcome_assumptions.csv',missing_rows)

# Display all 40 reports' reported background regimens, without assuming co-intervention balance.
chars={r['report_id']:r for r in read(D/'14_CHARACTERISTICS/report_characteristics_wide.csv')}
characteristics=[]
for name,c in cohort.items():
    r=chars[name]
    characteristics.append(dict(report=name,trial_family=c['trial_id'],country=r['country'],
        anaesthesia=r['anaesthesia'],procedure=r['procedure'],modality=r['modality'],
        comparator=r['comparator'],postoperative_analgesia=r['postoperative_analgesia'],
        pca_regimen=r['pca_regimen'],rescue_analgesia=r['rescue_analgesia'],
        care_level='Not independently adjudicated in this rerun',
        multimodal_analgesia_in_both_groups='Requires source-based adjudication; regimen text alone is not a yes/no judgment',
        source_pdf=c['source_pdf'],source_sha256=c['source_sha256'],
        source='Existing report_characteristics_wide.csv; no fresh full-cohort extraction claimed'))
write('forty_report_characteristics.csv',characteristics)

lookup={r['model_id']:r for r in results}
headline_ids=['opioid24_TEAS_sham','E2_opioid24_TEAS_sham','E2_opioid24_TEAS_usual',
    'E2_opioid24_EA_sham','E2_opioid24_EA_usual','RESCUE_TEAS_SHAM_ANY_FOLLOWUP',
    'RESCUE_NOT_HIGH','RESCUE_LOW_ONLY','RESCUE_TEAS_SHAM_FIRST_DAY_APPROX']
write('headline_results.csv',[lookup[k] for k in headline_ids])
loo=[r for r in results if r['model_id'].startswith('RESCUE_LOO_')]
assert len(loo)==5 and all(r['k']==4 for r in loo)

# Final figures are generated by stata_figures.do, not by Python.

after={str(p.relative_to(ROOT)):sha(p) for p in protected}
assert before==after,'Baseline changed'
manifest=dict(date=DATE,reports=40,provisional_families=39,numerical_reports=38,
    qualitative_only=['Ntritsou 2014','Wu 2016'],source_PDF_hashes_checked=40,
    extraction_outputs_byte_identical=7,baseline_models_reproduced=len(numerical_checks),
    total_models=len(results),fitted_models=sum(r['k']>0 for r in results),
    rescue_leave_one_out_models=5,baseline_hashes=before,baseline_unchanged=True,
    assessment_scope='Existing outcome-specific RoB/GRADE retained; no new independent human review',
    statistical_verification='Independent R check pending',
    new_checks='Post-hoc bias restrictions, complete rescue LOO and hypothetical missing outcomes',
    analysis_status='Fixed 40-report working scenario; remaining eligibility/completeness uncertainties persist',
    countries=dict(collections.Counter(r['country'] for r in characteristics)))
(HERE/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='baseline_hashes'},indent=2))
for mid in headline_ids+[r['model_id'] for r in loo]+['RESCUE_MISSING_UNFAVOURABLE_TO_TEAS']:
    r=lookup[mid]
    print(mid,r['k'],r['N'],*[round(r[k],6) for k in ['effect','ci_low','ci_high'] if k in r])
