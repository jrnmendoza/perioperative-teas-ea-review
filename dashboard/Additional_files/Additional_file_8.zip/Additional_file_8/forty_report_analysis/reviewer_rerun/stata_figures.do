* Reviewer-informed 40-report results. Official Stata models and graphics.
* Run from the repository root: stata-se -b do <this file>.
version 19.5
clear all
set more off
set varabbrev off
set linesize 140
global RR "`c(pwd)'/opioid_only_review/forty_report_analysis/reviewer_rerun_2026_10_09"
global ST "$RR/stata"
capture mkdir "$ST"
capture mkdir "$ST/figures"
capture erase "$ST/COMPLETED.txt"
log using "$ST/run.log", text replace
set scheme stcolor
graph set svg fontface "Helvetica"
graph set window fontface "Helvetica"
tempname info
file open `info' using "$ST/software.csv", write replace text
file write `info' "stata_version,edition,born_date,os,machine" _n
file write `info' "`c(stata_version)',`c(edition_real)',`c(born_date)',`c(os)',`c(machine_type)'" _n
file close `info'

import delimited using "$RR/model_inputs.csv", clear varnames(1) bindquote(strict) stringcols(_all)
foreach v in n_i n_c mean_i mean_c sd_i sd_c events_i events_c yi vi {
    destring `v', replace
}
gen str100 studylabel = report
replace studylabel = study if studylabel == ""
gen double s_yi = mean_i - mean_c if effect_measure == "MD"
gen double s_vi = sd_i^2/n_i + sd_c^2/n_c if effect_measure == "MD"
replace s_yi = ln((events_i/n_i)/(events_c/n_c)) if effect_measure == "RR"
replace s_vi = 1/events_i - 1/n_i + 1/events_c - 1/n_c if effect_measure == "RR"
assert abs(s_yi-yi) < 1e-8
assert abs(s_vi-vi) < 1e-8
gen double s_se = sqrt(s_vi)
save "$ST/inputs.dta", replace

import delimited using "$RR/model_results.csv", clear varnames(1) bindquote(strict) stringcols(_all)
local nm = _N
forvalues i=1/`nm' {
    local id`i' = model_id[`i']
    local measure`i' = effect_measure[`i']
}
tempname reg
postfile `reg' str100 model_id str3 measure int k long N double(theta se ci_lb ci_ub tau2 I2 pi_lb pi_ub effect ci_low ci_high) ///
    using "$ST/model_results.dta", replace
forvalues i=1/`nm' {
    use "$ST/inputs.dta", clear
    keep if model_id == "`id`i''"
    local k = _N
    if `k' == 0 {
        post `reg' ("`id`i''") ("`measure`i''") (0) (0) (.) (.) (.) (.) (.) (.) (.) (.) (.) (.) (.)
        continue
    }
    quietly summarize n_i
    local N = r(sum)
    quietly summarize n_c
    local N = `N' + r(sum)
    local theta = s_yi[1]
    local se = s_se[1]
    local lb = `theta' - invnormal(.975)*`se'
    local ub = `theta' + invnormal(.975)*`se'
    local tau = 0
    local i2 = .
    local pl = .
    local pu = .
    if `k' > 1 {
        meta set s_yi s_se, studylabel(studylabel) random(reml)
        quietly meta summarize, se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
        assert r(converged) == 1
        local theta = r(theta)
        local se = r(se)
        local lb = r(ci_lb)
        local ub = r(ci_ub)
        local tau = r(tau2)
        * Use the same tau-based I2 convention as the declared analysis.
        quietly gen double w0 = 1/s_vi
        quietly gen double w02 = w0^2
        quietly summarize w0
        local sw = r(sum)
        quietly summarize w02
        local C = `sw' - r(sum)/`sw'
        local i2 = 100*`tau'/(`tau'+(`k'-1)/`C')
        if `k' >= 5 {
            local pl = `theta' - invttail(`k'-1,.025)*sqrt(`tau'+`se'^2)
            local pu = `theta' + invttail(`k'-1,.025)*sqrt(`tau'+`se'^2)
        }
    }
    local effect = `theta'
    local lo = `lb'
    local hi = `ub'
    if "`measure`i''" == "RR" {
        local effect = exp(`theta')
        local lo = exp(`lb')
        local hi = exp(`ub')
    }
    post `reg' ("`id`i''") ("`measure`i''") (`k') (`N') (`theta') (`se') (`lb') (`ub') ///
        (`tau') (`i2') (`pl') (`pu') (`effect') (`lo') (`hi')
    capture meta clear
}
postclose `reg'
use "$ST/model_results.dta", clear
format theta-ci_high %21.16g
export delimited using "$ST/model_results.csv", replace datafmt

capture program drop niceaxis
program define niceaxis, rclass
    args lo hi ef
    local pad = (`hi'-`lo')*.05
    local lo = `lo'-`pad'
    local hi = `hi'+`pad'
    if "`ef'" == "1" {
        foreach set in ".25 .5 .75 1 1.5 2 3" ".1 .2 .5 1 2 5 10" ".01 .1 1 10 100" ".001 .01 .1 1 10 100 1000" {
            local labs ""
            local n=0
            local cmin=.
            local cmax=0
            foreach c of local set {
                if ln(`c') >= `lo' & ln(`c') <= `hi' {
                    local s = strtrim(string(`c',"%9.0g"))
                    if substr("`s'",1,1)=="." local s "0`s'"
                    local labs `"`labs' `c' "`s'""'
                    local ++n
                    local cmin=min(`cmin',`c')
                    local cmax=max(`cmax',`c')
                }
            }
            if `n'<=8 & `n'>=2 & ln(`cmax')-ln(`cmin')>=.5*(`hi'-`lo') continue,break
        }
        return local range = "`=exp(`lo')' `=exp(`hi')'"
        return local labels `"`labs'"'
    }
    else {
        local raw=(`hi'-`lo')/5
        local p=10^floor(log10(`raw'))
        local step ""
        foreach m in 1 2 2.5 5 10 {
            if "`step'"=="" & `m'*`p'>=`raw' local step=`m'*`p'
        }
        local a=floor(`lo'/`step')*`step'
        local b=ceil(`hi'/`step')*`step'
        return local range "`a' `b'"
        return local labels "`a'(`step')`b'"
    }
end

capture program drop exportfigure
program define exportfigure
    args name
    graph save "$ST/figures/`name'.gph", replace
    graph export "$ST/figures/`name'.pdf", as(pdf) replace
    graph export "$ST/figures/`name'.svg", as(svg) replace
    graph export "$ST/figures/`name'.png", as(png) replace width(2600)
end

capture program drop forest
program define forest
    args mid name title subtitle customaxis
    use "$ST/inputs.dta", clear
    keep if model_id == "`mid'"
    local k = _N
    assert `k' > 0
    quietly summarize n_i
    local N = r(sum)
    quietly summarize n_c
    local N = `N' + r(sum)
    local ef ""
    local axis "Mean difference (mg IV morphine equivalents)"
    local null = 0
    if effect_measure[1] == "RR" {
        local ef "eform"
        local axis "Risk ratio for additional opioid receipt"
        local null = 1
    }
    if "`customaxis'" != "" local axis "`customaxis'"
    meta set s_yi s_se, studylabel(studylabel) random(reml)
    local opt se(khartung, truncated) tolerance(1e-14) nrtolerance(1e-14) iterate(1000)
    local summ noosigtest
    local cols _id _plot _esci _weight
    local notes "`k' trial(s), `N' analyzed participants. REML; safeguarded Knapp-Hartung 95% confidence intervals."
    local hstats ""
    quietly gen double individual_lb = s_yi-invnormal(.975)*s_se
    quietly gen double individual_ub = s_yi+invnormal(.975)*s_se
    quietly summarize individual_lb
    local xlo=min(r(min),0)
    quietly summarize individual_ub
    local xhi=max(r(max),0)
    if `k' == 1 {
        local summ nooverall noohetstats noohomtest noosigtest
        local cols _id _plot _esci
        local notes "One trial, `N' participants. Within-trial normal 95% confidence interval; not pooled."
    }
    else {
        preserve
        use "$ST/model_results.dta", clear
        keep if model_id == "`mid'"
        local xlo=min(`xlo',ci_lb[1])
        local xhi=max(`xhi',ci_ub[1])
        local i2text = strtrim(string(I2[1],"%4.1f"))
        local tau = strtrim(string(tau2[1],"%7.3f"))
        local summ ohetstatstext("Heterogeneity: I{superscript:2} = `i2text'%, {&tau}{superscript:2} = `tau'") noohomtest noosigtest
        if `k' >= 5 {
            local xlo=min(`xlo',pi_lb[1])
            local xhi=max(`xhi',pi_ub[1])
            local lo = pi_lb[1]
            local hi = pi_ub[1]
            if "`ef'" != "" {
                local lo = exp(`lo')
                local hi = exp(`hi')
            }
            local lo = strtrim(string(`lo',"%7.2f"))
            local hi = strtrim(string(`hi',"%7.2f"))
            local hstats "Approximate prediction interval: `lo' to `hi' (t, k-1 df). Sparse-study estimate."
        }
        restore
    }
    local xline ""
    if "`mid'" == "opioid24_TEAS_sham" local xline xline(-10,lpattern(shortdash) lcolor(orange))
    if "`mid'" == "opioid24_TEAS_sham" local xlo=min(`xlo',-10)
    niceaxis `xlo' `xhi' `=cond("`ef'"=="",0,1)'
    local axisopts `"xscale(range(`r(range)')) xlabel(`r(labels)')"'
    local ys = max(3.6,2.6+.35*`k')
    meta forestplot `cols', `opt' `ef' `summ' nullrefline `xline' `axisopts' ///
        columnopts(_esci, supertitle("Effect")) ///
        title("`title'",size(medium)) subtitle("`subtitle'",size(small)) ///
        xtitle("`axis'") note("`notes'" "`hstats'",size(vsmall)) ///
        xsize(10) ysize(`ys') name(g,replace)
    exportfigure "`name'"
    meta clear
end

forest "opioid24_TEAS_sham" "01_registered_24h_TEAS_sham" "Registered complete 24-hour opioid dose" "TEAS versus sham. Orange line: registered 10-mg threshold; paired pain criterion not established."
forest "E2_opioid24_TEAS_sham" "02_broader_first_day_TEAS_sham" "Broader first-day opioid dose" "TEAS versus sham. Post-hoc definition; source and conversion uncertainties retained."
forest "E2_opioid24_TEAS_usual" "03_broader_first_day_TEAS_usual" "Broader first-day opioid dose" "TEAS versus usual care. Single trial; shares the active arm with the registered sham comparison."
forest "E2_opioid24_EA_sham" "04_broader_first_day_EA_sham" "Broader first-day opioid dose" "EA versus sham. Single high-risk trial; incomplete early opioid capture."
forest "E2_opioid24_EA_usual" "05_broader_first_day_EA_usual" "Broader first-day opioid dose" "EA versus usual care. Source and incomplete-capture limitations retained."
forest "RESCUE_TEAS_SHAM_ANY_FOLLOWUP" "06_rescue_TEAS_sham" "Receipt of additional rescue opioids" "TEAS versus sham. Mixed follow-up periods; exploratory low-certainty evidence."
do "$RR/stata_additional_forests.do"

* Summary figures use estimates REFITTED ABOVE IN STATA, not imported Python effects.
import delimited using "$RR/stata_figure_rows.csv", clear varnames(1) bindquote(strict) stringcols(_all)
destring order, replace
save "$ST/figure_rows.dta",replace
import delimited using "$RR/stata_summary_specs.csv", clear varnames(1) bindquote(strict) stringcols(_all)
local nf = _N
forvalues i=1/`nf' {
    local fig`i' = figure_id[`i']
    local title`i' = title[`i']
    local note`i' = note[`i']
    local null`i' = null[`i']
}
forvalues j=1/`nf' {
    use "$ST/figure_rows.dta",clear
    keep if figure_id == "`fig`j''"
    merge m:1 model_id using "$ST/model_results.dta", keep(match) nogen
    assert k > 0
    sort order
    gen double y = _N - _n + 1
    gen str100 values = strtrim(string(effect,"%7.2f")) + " (" + strtrim(string(ci_low,cond(ci_low>0 & ci_low<.01,"%7.3f","%7.2f"))) + ", " + strtrim(string(ci_high,"%7.2f")) + ")"
    local labels ""
    forvalues i=1/`=_N' {
        local lab = label[`i']
        local labels `"`labels' `=y[`i']' "`lab'""'
    }
    local axis "Mean difference (mg IV morphine equivalents)"
    local xopt ""
    if "`null`j''" == "1" {
        local axis "Risk ratio (log scale)"
        local xopt xscale(log)
    }
    quietly summarize ci_high
    local hi = r(max)
    quietly summarize ci_low
    local lo = r(min)
    local tickopts ""
    if "`null`j''" == "1" & `lo'<.01 local tickopts xlabel(.001 "0.001" .01 "0.01" .1 "0.1" 1 "1" 10 "10" 100 "100" 1000 "1000",labsize(small))
    local pos = `hi' + (`hi'-`lo')*.1
    if "`null`j''" == "1" local pos = `hi'*1.5
    local xmax = `pos' + (`hi'-`lo')*.55
    local xmin = min(`lo',`null`j'') - (`hi'-`lo')*.05
    local xopt xscale(range(`xmin' `xmax'))
    if "`null`j''" == "1" {
        local xmax = `hi'*10
        local xmin = min(`lo',1)*.8
        local xopt xscale(log range(`xmin' `xmax'))
    }
    gen double textx = `pos'
    twoway (rcap ci_low ci_high y, horizontal lcolor(navy)) ///
        (scatter y effect, mcolor(navy) msymbol(D) msize(small)) ///
        (scatter y textx, msymbol(none) mlabel(values) mlabposition(3) mlabsize(small) mlabcolor(black)), ///
        `xopt' `tickopts' xline(`null`j'',lcolor(gs8) lpattern(dash)) ///
        ylabel(`labels',angle(0) labsize(small) noticks) ytitle("") ///
        xtitle("`axis'") legend(off) title("`title`j''",size(medium)) ///
        note("`note`j''" "Rows share studies. Trial and participant counts must not be added across rows.",size(vsmall)) ///
        xsize(12) ysize(5.4) name(g,replace)
    exportfigure "`fig`j''"
}

* Individual native outcomes: no pooled summary across incompatible periods or units.
import delimited using "$RR/reextraction/individual_estimates.csv",clear varnames(1) bindquote(strict) stringcols(_all)
foreach v in n_i n_c events_i events_c y variance {
    destring `v',replace
}
gen double s_yi = y
gen double s_se = sqrt(variance)
gen str40 short_period = window
replace short_period = "period unclear" if strpos(lower(window),"unspecified") | strpos(lower(window),"not restated")
replace short_period = "postoperative" if strpos(lower(window),"postoperative") & strlen(window)>30
replace short_period = "postoperative stay" if strpos(lower(window),"postoperative stay")
replace short_period = "PACU" if strpos(lower(window),"pacu")
replace short_period = subinstr(short_period,uchar(8211),"-",.)
gen str160 native_label = report + ": " + short_period + "; " + comparator
save "$ST/individual_inputs.dta",replace
import delimited using "$RR/stata_native_specs.csv",clear varnames(1) bindquote(strict) stringcols(_all)
local nn = _N
forvalues i=1/`nn' {
    foreach var in figure_id unit title note outcome_ids {
        local `var'`i' = `var'[`i']
    }
}
forvalues i=1/`nn' {
    use "$ST/individual_inputs.dta",clear
    gen byte selected = 0
    foreach oid of local outcome_ids`i' {
        replace selected = 1 if outcome_id == "`oid'"
    }
    keep if selected
    assert _N > 0
    local k = _N
    local ef ""
    if effect_measure[1] == "RR" local ef "eform"
    meta set s_yi s_se,studylabel(native_label) random(reml)
    quietly gen double lower = s_yi-invnormal(.975)*s_se
    quietly gen double upper = s_yi+invnormal(.975)*s_se
    quietly summarize lower
    local xlo=min(r(min),0)
    quietly summarize upper
    local xhi=max(r(max),0)
    niceaxis `xlo' `xhi' `=cond("`ef'"=="",0,1)'
    local axisopts `"xscale(range(`r(range)')) xlabel(`r(labels)')"'
    local ys = max(3.6,2.6+.36*`k')
    meta forestplot _id _plot _esci, nooverall noohetstats noohomtest noosigtest nullrefline `ef' `axisopts' ///
        columnopts(_esci,supertitle("Effect")) ///
        title("`title`i''",size(medium)) xtitle("`unit`i''") ///
        note("`note`i''" "Individual estimates only. Repeated observations and shared groups are not independent trials.",size(vsmall)) ///
        xsize(11) ysize(`ys') name(g,replace)
    exportfigure "`figure_id`i''"
    meta clear
}
file open `info' using "$ST/COMPLETED.txt",write replace text
file write `info' "Models and all figures completed in Stata `c(stata_version)' on `c(current_date)'." _n
file close `info'
log close
