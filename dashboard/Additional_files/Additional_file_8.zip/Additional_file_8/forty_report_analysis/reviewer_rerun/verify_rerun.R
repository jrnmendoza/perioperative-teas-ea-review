# Separate base-R implementation. Rebuild contrasts from arms/event counts.
args <- commandArgs(trailingOnly=TRUE)
folder <- if(length(args)) args[1] else 'opioid_only_review/forty_report_analysis/reviewer_rerun_2026_10_09'
input <- read.csv(file.path(folder,'model_inputs.csv'),check.names=FALSE)
expected <- read.csv(file.path(folder,'model_results.csv'),check.names=FALSE)
checks <- list()
for(i in seq_len(nrow(expected))) {
  target <- expected[i,]
  d <- input[input$model_id==target$model_id,]
  k <- nrow(d)
  stopifnot(k==target$k)
  if(k==0) {
    stopifnot(target$N==0)
    checks[[i]] <- data.frame(model_id=target$model_id,k=0,N=0,effect_R=NA,
      ci_low_R=NA,ci_high_R=NA,max_absolute_difference=0,check='NO ELIGIBLE DATA CONFIRMED')
    next
  }
  if(target$effect_measure=='RR') {
    yi <- log((d$events_i/d$n_i)/(d$events_c/d$n_c))
    vi <- 1/d$events_i-1/d$n_i+1/d$events_c-1/d$n_c
  } else {
    yi <- d$mean_i-d$mean_c
    vi <- d$sd_i^2/d$n_i+d$sd_c^2/d$n_c
  }
  stopifnot(max(abs(yi-d$yi))<1e-8,max(abs(vi-d$vi))<1e-8)
  tau <- 0
  if(k>1) {
    nll <- function(tau) {
      w <- 1/(vi+tau)
      mu <- weighted.mean(yi,w)
      .5*(sum(log(vi+tau))+log(sum(w))+sum(w*(yi-mu)^2))
    }
    upper <- max(1,mean((yi-mean(yi))^2)*10,max(vi)*10)
    opt <- optimize(nll,c(0,upper),tol=1e-12)
    tau <- if(opt$objective<nll(0)) opt$minimum else 0
    weights <- 1/(vi+tau)
    mu <- weighted.mean(yi,weights)
    q <- sum(weights*(yi-mu)^2)/(k-1)
    se <- sqrt(max(1,q)/sum(weights))
    crit <- qt(.975,k-1)
  } else {
    mu <- yi[1];se <- sqrt(vi[1]);crit <- qnorm(.975)
  }
  effect <- c(mu,mu-crit*se,mu+crit*se)
  if(target$effect_measure=='RR') effect <- exp(effect)
  delta <- max(abs(effect-c(target$effect,target$ci_low,target$ci_high)))
  # Independent optimizers can differ in the final digits; tolerance is far below reporting precision.
  stopifnot(delta<1e-5,sum(d$n_i+d$n_c)==target$N)
  if(k>=5) {
    pi <- mu+c(-1,1)*qt(.975,k-1)*sqrt(tau+se^2)
    if(target$effect_measure=='RR') pi <- exp(pi)
    stopifnot(max(abs(pi-c(target$pi_low,target$pi_high)))<1e-5)
  }
  checks[[i]] <- data.frame(model_id=target$model_id,k=k,N=target$N,
    effect_R=effect[1],ci_low_R=effect[2],ci_high_R=effect[3],
    max_absolute_difference=delta,check='AGREES')
}
write.csv(do.call(rbind,checks),file.path(folder,'independent_R_verification.csv'),row.names=FALSE)

# Recalculate all new native-scale individual effects as well as pooled models.
processed <- read.csv(file.path(folder,'reextraction/processed_outcomes.csv'),check.names=FALSE)
individual <- read.csv(file.path(folder,'reextraction/individual_estimates.csv'),check.names=FALSE)
individual_checks <- list()
for(i in seq_len(nrow(individual))) {
  r <- individual[i,]
  if(r$effect_measure=='RR') {
    y <- log((r$events_i/r$n_i)/(r$events_c/r$n_c))
    v <- 1/r$events_i-1/r$n_i+1/r$events_c-1/r$n_c
    effect <- exp(c(y,y-qnorm(.975)*sqrt(v),y+qnorm(.975)*sqrt(v)))
  } else {
    p <- processed[processed$outcome_id==r$outcome_id,]
    stopifnot(nrow(p)==1)
    y <- p$mean_i-p$mean_c
    v <- p$sd_i^2/p$n_i+p$sd_c^2/p$n_c
    effect <- c(y,y-qnorm(.975)*sqrt(v),y+qnorm(.975)*sqrt(v))
  }
  delta <- max(abs(effect-c(r$effect,r$ci_low,r$ci_high)))
  stopifnot(delta<1e-8)
  individual_checks[[i]] <- data.frame(outcome_id=r$outcome_id,report=r$report,
    max_absolute_difference=delta,check='AGREES')
}
write.csv(do.call(rbind,individual_checks),file.path(folder,'individual_R_verification.csv'),row.names=FALSE)
cat(nrow(expected),'model rows checked;',sum(expected$k>0),'fitted models;',
    sum(expected$k==0),'empty evidence cells;',nrow(individual),'individual estimates agree.\n')
