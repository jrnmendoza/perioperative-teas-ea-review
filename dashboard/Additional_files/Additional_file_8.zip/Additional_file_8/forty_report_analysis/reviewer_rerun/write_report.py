"""Finalize verified outputs and manuscript wording for the dated rerun."""
import csv, hashlib, json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def read(name):
    with (HERE/name).open(newline='') as f:return list(csv.DictReader(f))
models={r['model_id']:r for r in read('model_results.csv')}
checks=read('independent_R_verification.csv')
individual_checks=read('individual_R_verification.csv')
assert len(checks)==75 and len(individual_checks)==38
assert all(r['check'] in ['AGREES','NO ELIGIBLE DATA CONFIRMED'] for r in checks)
manifest=json.loads((HERE/'run_manifest.json').read_text())
for path,expected in manifest['baseline_hashes'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
manifest.update(statistical_verification='PASS: separate base-R recalculation from analyzed arms/event counts',
    independently_verified_model_rows=len(checks),independently_verified_individual_estimates=len(individual_checks),
    max_model_R_difference=max(float(r['max_absolute_difference']) for r in checks),
    max_individual_R_difference=max(float(r['max_absolute_difference']) for r in individual_checks),
    figure_visual_review='Stata exports await final visual review',
    final_report_status='Completed rerun; submission prerequisites explicitly unresolved')
(HERE/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

def effect(mid,decimals=2):
    r=models[mid]
    if int(r['k'])==0:return 'No eligible data'
    return f"{float(r['effect']):.{decimals}f} ({float(r['ci_low']):.{decimals}f} to {float(r['ci_high']):.{decimals}f})"

def table(ids,labels):
    lines=['| Analysis | Trials | Participants | Effect (95% confidence interval) |',
           '|---|---:|---:|---|']
    for mid,label in zip(ids,labels):
        r=models[mid]
        lines.append(f"| {label} | {r['k']} | {r['N']} | {effect(mid)} |")
    return '\n'.join(lines)

main_dose=['opioid24_TEAS_sham','E2_opioid24_TEAS_sham','E2_opioid24_TEAS_usual','E2_opioid24_EA_sham','E2_opioid24_EA_usual']
rescue_ids=['RESCUE_TEAS_SHAM_ANY_FOLLOWUP','RESCUE_NOT_HIGH','RESCUE_LOW_ONLY']
loo=[r for r in models.values() if r['model_id'].startswith('RESCUE_LOO_')]
dose_loo=[r for r in models.values() if r['model_id'].startswith('E2_TEAS_sham_LOO_')]
assert len(loo)==5 and len(dose_loo)==7
assert all(float(r['ci_high'])<1 for r in loo)
assert all(float(r['ci_low'])<=0<=float(r['ci_high']) for r in dose_loo)
dose=models['E2_opioid24_TEAS_sham']

report=f'''# Results after the peer-review checks

9 October 2026. **The signal for fewer extra opioid treatments persists when any single rescue trial is removed. It becomes uncertain when both high-risk trials are removed. Total-dose reduction remains uncertain.**

This rerun uses the same 40-report working set: 39 provisional trial families, 38 reports with numerical opioid findings and two qualitative reports. It does not establish final eligibility for every retained report or completeness of the historical screening. Forty reports are an evidence inventory, not forty trials supporting one pooled effect. No verified total number of unique participants across all 40 is claimed.

## Opioid dose

Negative mean differences mean less opioid in the intervention group. Units are mg IV morphine equivalents, conditional on each existing conversion and source decision.

{table(main_dose,['Registered complete 24-hour TEAS vs sham','Broader first-day TEAS vs sham','Broader first-day TEAS vs usual care','Broader first-day EA vs sham','Broader first-day EA vs usual care'])}

The registered TEAS/sham result remains a single 48-participant trial with the existing low-certainty rating. Its point estimate does not reach the registered 10-mg threshold. Its confidence interval spans that threshold, so clinically meaningful sparing is not established or ruled out. Removing pain from the review also prevents testing the registered joint opioid/pain criterion.

The broader TEAS/sham analysis has I²={float(dose['I2']):.1f}%. Its prediction interval is **{float(dose['pi_low']):.2f} to {float(dose['pi_high']):.2f} mg**, indicating substantial variability under the model assumptions. With only seven trials this interval is approximate; it is not a prediction for an individual patient. Every one of its seven leave-one-out analyses still includes no dose difference. Their point estimates range from {min(float(r['effect']) for r in dose_loo):.2f} to {max(float(r['effect']) for r in dose_loo):.2f} mg. The EA/sham result is one high-risk trial with incomplete early opioid capture, not replicated strong evidence.

All 25 existing E2 dose models, including conversion, incomplete-capture and source-contradiction sensitivities, were rebuilt from canonical source arms. Results reproduce the baseline. Their previous limitations remain. These broader dose bodies have **not** received a new complete formal GRADE assessment in this rerun.

## Additional rescue opioid receipt

A risk ratio below 1 indicates fewer patients receiving an extra opioid. This measures whether an extra opioid was administered, not how much total opioid was used.

{table(rescue_ids,['All five TEAS/sham rescue trials, mixed follow-up','Exclude both high-risk rescue trials','Keep only trials rated low risk for this rescue outcome'])}

The broad five-trial result is approximately a 49% relative reduction, with the existing **provisional low-certainty** assessment retained. All five trials were conducted in China. Periods are 6–24 hours, through postoperative day 1, unspecified postoperative follow-up, 48 hours and three days. It is a supportive exploratory mixed-follow-up analysis, not a common complete 24-hour endpoint.

{table([r['model_id'] for r in loo],['Without '+r['removed_report'] for r in loo])}

All five leave-one-out intervals favour TEAS. This addresses Reviewer 3's requested single-study robustness check, but does not remove bias affecting several trials. Removing both high-risk trials leaves RR {effect('RESCUE_NOT_HIGH')}, which includes no effect and possible increased receipt. The stricter requested low-risk-only analysis is empty; trials with “some concerns” are not equivalent to low risk. No trial was removed from the 40-report inventory merely because it was omitted from a sensitivity analysis.

The approximate first-day subset remains two trials/201 patients, RR {effect('RESCUE_TEAS_SHAM_FIRST_DAY_APPROX',3)}. Its very wide safeguarded Hartung–Knapp interval reflects limited information and one degree of freedom. It is not replaced with a narrower interval to make the result appear more convincing. Neither report provides the same complete elapsed 0–24-hour period, so an exact time-matched rescue pool is unavailable.

## Missing outcomes

Four explicitly hypothetical scenarios use all 497 randomized participants across the five rescue trials and assign the 19 unobserved outcomes as none receiving rescue, all receiving rescue, outcomes maximally unfavourable to TEAS, or outcomes maximally favourable to TEAS.

{table(['RESCUE_MISSING_NONE','RESCUE_MISSING_ALL','RESCUE_MISSING_UNFAVOURABLE_TO_TEAS','RESCUE_MISSING_FAVOURABLE_TO_TEAS'],['No missing patient receives rescue','Every missing patient receives rescue','All missing TEAS patients receive rescue, no missing controls do','No missing TEAS patients receive rescue, all missing controls do'])}

The unfavourable scenario attenuates the RR to {effect('RESCUE_MISSING_UNFAVOURABLE_TO_TEAS')}. This shows how the recorded missing outcomes affect the summary under extreme binary assumptions. These are not recovered data, a verified intention-to-treat analysis or corrections for concealment, selective reporting, rescue decisions or other biases. They do not replace the high-risk exclusion check or justify upgrading certainty. The original source-informed missing-outcome judgments were not changed solely because these pooled sensitivity intervals exclude 1.

## Bias restrictions for opioid dose

The rerun links each dose result to its exact existing outcome-specific assessment. It does not substitute the study-level rating in the report inventory.

{table(['E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE','E2_opioid24_TEAS_usual_NOT_HIGH_WITH_LINKAGE','E2_opioid24_EA_sham_NOT_HIGH_WITH_LINKAGE','E2_opioid24_EA_usual_NOT_HIGH_WITH_LINKAGE'],['TEAS/sham: linked low/some-concerns results only','TEAS/usual care: linked low/some-concerns results only','EA/sham: linked low/some-concerns results only','EA/usual care: linked low/some-concerns results only'])}

These are joint restrictions removing known high-risk results **and** results without an established exact assessment. They cannot isolate the effect of bias alone. Zhang 2025 and Gu 2019 lack exact dose-result linkage here; the Lin 2002 usual-care dose results are also unlinked. Unassessed does not mean high risk. All four low-risk-only broader dose restrictions are empty under the available exact links. Neither “some concerns” nor “unlinked” was relabelled as low risk to populate an analysis.

## What the rejection comments change

| Actual comment | Response in this rerun | Remaining implication |
|---|---|---|
| Reviewer 3: leave-one-out analyses | All five rescue trials checked; all 7 TEAS/sham and 4 EA/usual-care E2 leave-one-out analyses reproduced | Single-study stability does not establish freedom from bias |
| Reviewer 3: exclude moderate/high-risk evidence | Rescue high-risk exclusion and low-risk-only restriction; exact-linked dose restrictions | No low-risk-only rescue or broader dose body available |
| Editor: outcome-specific RoB 2 and correct GRADE | Use exact dose linkage and existing rescue-specific assessments; retain low/very-low ratings | New rescue judgments remain AI assessments; independent human adjudication is pending; expanded dose/new native outcomes are not all formally graded |
| Reviewer 2: multimodal analgesia and hospital level | Export all 40 reports' background, pump and rescue regimen fields | Both-group multimodal status and care level require source adjudication; no blanket tertiary-hospital or common ERAS claim |
| Reviewer 2: patient-reported outcomes and clinical meaning | Restrict conclusions to the opioid outcomes actually analyzed | Better pain, recovery, satisfaction, safety or persistent opioid use cannot be inferred from this opioid-only synthesis; wider-project PROM data are not absent |
| Reviewer 1: dependence across repeated measurements | Periods kept separate; shared arms combined or comparisons kept separate | Do not add trial counts across nested analyses or pool repeated observations as independent patients |
| Reviewer 3: consider meta-regression | Document non-feasibility in homogeneous outcome/comparison bodies | Largest relevant main dose pool has 7 trials, rescue 5; the inventory of 40 does not supply 40 independent moderator observations |
| Editor/Reviewer 2: inaccurate references and opioid thresholds | Use source-linked calculations and documented registered threshold, without importing old citation claims | Final bibliography and claim-level verification remain required; a pain-threshold paper is not evidence for an opioid threshold |
| Editor/Reviewer 3: registration, searches, language and exclusions | Preserve registered primary result and disclose post-hoc focus; link dated PRISMA/exclusion ledger | This rerun is not a search update, new prospective registration or independent full rescreen; English full-text restriction remains a limitation |

The 40-report characteristics list contains 25 reports with country recorded as China, with Taiwan and Hong Kong retained under the source table's separate labels. All five trials in the headline rescue body are from China, limiting evidence for transfer to other care settings. Differences in surgery, baseline analgesia, drugs, rescue rules and observation periods remain despite estimated rescue I²=0%. Zero detected statistical heterogeneity does not prove clinical equivalence.

## Likely interpretation at BMC Anesthesiology

This is an inference about likely reviewer questions, not a prediction of acceptance. The journal [encourages PRISMA reporting, datasets supporting conclusions and prospective registration, and excludes non-commissioned pooled analyses of selected published research](https://link.springer.com/journal/12871/submission-guidelines/systematic-review). Therefore, transparent systematic selection of the 40 reports and disclosure of the results-known scope change matter more than the number 40 itself. A favourable mixed-period rescue pool must not be promoted into the registered main result.

[Cochrane Chapter 10](https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-10) advises against meta-regression with fewer than ten studies and explains limitations of heterogeneity estimates and prediction intervals with sparse studies. We do not fit moderator models by pooling incompatible outcomes to reach a larger count.

A reviewer could reasonably see a potentially useful but exploratory rescue-use signal, uncertain total-dose benefit, and an important reporting gap for the strict primary outcome. They could still question the mixed rescue periods, low-risk evidence gap, clinical usefulness without pain/PROM results, generalizability, novelty and selection completeness. These are not solved by rerunning arithmetic.

**Suggested conclusion:** “Perioperative TEAS may reduce receipt of additional postoperative opioids, but this finding is based on low-certainty evidence with heterogeneous follow-up and becomes inconclusive after exclusion of high-risk trials. Broader first-day opioid-dose estimates do not establish a consistent reduction. Evidence for EA is sparse and uncertain. The opioid-focused synthesis does not establish preserved pain control or improved recovery.”

## Verification and files

The original extraction builder reproduced seven data/count outputs byte for byte. Fifty-five populated baseline model results were reproduced. A separate base-R implementation recalculated 68 fitted models, checked seven empty evidence cells, and verified all 38 new individual estimate rows. These are analysis rows and overlapping checks, not additional trials. Maximum Python/R model difference was {manifest['max_model_R_difference']:.2g}, below reporting precision. All 40 source PDF hashes match their recorded versions. The protected baseline analysis, certainty, canonical and PRISMA files remain unchanged. Final figures are generated by Stata. The separate Stata verification and figure manifest document their numerical and visual checks.

- [Stata rescue forest plot](stata/figures/06_rescue_TEAS_sham.png)
- [Stata robustness figures and captions](figure_captions.csv)
- [Full model results](model_results.csv) and [analyzed inputs](model_inputs.csv)
- [40-report characteristics](forty_report_characteristics.csv)
- [Exact dose bias linkage](dose_bias_linkage.csv)
- [Independent R model checks](independent_R_verification.csv) and [individual checks](individual_R_verification.csv)
- [Run manifest](run_manifest.json)
- [Updated manuscript results](MANUSCRIPT_RESULTS_DRAFT.md)
- [40-report PRISMA accounting](../../prisma/PRISMA_ACCOUNTING.md)
- [Existing rescue certainty assessment](../certainty_and_manuscript/CERTAINTY.md)

The rerun is complete for the specified fixed scenario. Submission still requires final eligibility/source reconciliation, independent human validation, outcome-specific certainty completion, search/reporting documentation and a verified bibliography. This pass sends no author queries and makes no registration or submission changes.
'''
(HERE/'RESULTS_AND_REVIEWER_INTERPRETATION.md').write_text(report)

manuscript=f'''# Updated opioid-focused manuscript results

9 October 2026. Based on the fixed 40-report exploratory scenario. Numerical verification is complete; independent human adjudication of new rescue assessments and final review eligibility are not established by this rerun.

## Study selection and evidence available

The opioid-focused working set comprised 40 reports representing 39 provisional trial families. Thirty-eight reports provided numerical opioid findings; Ntritsou 2014 and Wu 2016 contributed qualitative findings only. Potential cohort overlap between Yeh 2010 and Yeh 2011 remained unresolved and their dose findings were not pooled. Each outcome used its own eligible subset. No overall unique participant total was calculated. The focused selection was made after results were known and did not replace the registered primary definition.

## Postoperative opioid quantity

The registered complete 24-hour TEAS-versus-sham outcome was supported by one trial (48 participants; MD {effect('opioid24_TEAS_sham')} mg IV morphine equivalents), with the existing low-certainty assessment retained. The point estimate did not meet the registered 10-mg threshold, and the joint clinical criterion could not be established without paired pain evidence.

The broader first-day TEAS-versus-sham analysis included seven trials and 581 participants (MD {effect('E2_opioid24_TEAS_sham')} mg IV morphine equivalents; I² {float(dose['I2']):.1f}%; approximate prediction interval {float(dose['pi_low']):.2f} to {float(dose['pi_high']):.2f} mg). All seven leave-one-out intervals included no difference. Conversion and source-restriction sensitivities reproduced the existing E2 findings. The five-trial restriction to results with established low/some-concerns outcome-specific assessments yielded MD {effect('E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE')} mg (371 participants). This excluded unassessed results as well as high-risk results and was not a pure bias restriction. No low-risk-only body was available under the established exact links.

Other broader first-day results were TEAS versus usual care, one trial/47 participants, MD {effect('E2_opioid24_TEAS_usual')} mg; EA versus sham, one trial/75 participants, MD {effect('E2_opioid24_EA_sham')} mg; and EA versus usual care, four trials/414 participants, MD {effect('E2_opioid24_EA_usual')} mg. These four comparison rows represented 11 unique trials and were not combined across modality or comparator. The EA/sham result had high risk of bias and incomplete early opioid capture. New formal GRADE assessments were not completed for all expanded dose bodies.

## Receipt of additional rescue opioids

Five TEAS-versus-sham trials (478 analyzed participants, 135 events) contributed to a supportive exploratory mixed-follow-up synthesis: RR {effect('RESCUE_TEAS_SHAM_ANY_FOLLOWUP')}, estimated I²=0%, with provisional low-certainty evidence. All five were conducted in China. Follow-up comprised 6–24 hours, through postoperative day 1, an unspecified postoperative period, 48 hours and three days. Consequently, this synthesis did not estimate a common complete 0–24-hour effect.

Complete leave-one-out analyses retained point estimates between {min(float(r['effect']) for r in loo):.2f} and {max(float(r['effect']) for r in loo):.2f}; all five intervals excluded RR=1. Exclusion of both trials at high risk of bias yielded RR {effect('RESCUE_NOT_HIGH')} (three trials, 243 participants), whose interval included no effect. No trial remained in the low-risk-only restriction. The approximate first-day subset comprised two trials and 201 participants, RR {effect('RESCUE_TEAS_SHAM_FIRST_DAY_APPROX',3)}, with very-low-certainty evidence; neither report established an identical complete 0–24-hour period.

Hypothetical missing-outcome scenarios included all 497 randomized participants. Assigning rescue to every missing TEAS patient and to no missing control patient yielded RR {effect('RESCUE_MISSING_UNFAVOURABLE_TO_TEAS')}. Other complete-denominator scenarios yielded point estimates from {min(float(models[k]['effect']) for k in models if k.startswith('RESCUE_MISSING_')):.2f} to {max(float(models[k]['effect']) for k in models if k.startswith('RESCUE_MISSING_')):.2f}. These post-hoc assumptions did not recover missing outcomes or address other bias mechanisms and were not treated as verified intention-to-treat results.

## Other opioid outcomes

Native solution volumes, weight-normalized quantities, medians/IQRs, injection or tablet counts, and rescue delays remained separate from the MME and binary rescue pools. The rerun reproduced all 38 individual estimate rows. Routine opioid pump receipt was distinguished from additional rescue and showed no clear difference in the three previously reported individual comparisons. EA rescue evidence remained a single Xie 2014 trial with shared-arm sham/usual-care comparisons and very-low-certainty evidence. The existing source-specific native/qualitative results are supplied in the additional results table rather than counted by statistical significance.

Unresolved dose concentration, anesthesia, modality, cohort linkage and reporting discrepancies continued to restrict pooling, including Jin 2023, Long 2025 and the Yeh reports. Exact dose-result bias assessments were not established for every expanded result. New rescue assessments were outcome-specific provisional AI judgments; no independent human adjudication was performed in this rerun.

## Methods amendment and interpretation

All new restrictions, complete rescue leave-one-out checks and missing-outcome scenarios were post hoc. Models retained modality, comparator and outcome-period distinctions. Repeated periods and shared control arms were not pooled as independent trials. REML with safeguarded Hartung–Knapp intervals was retained for pools; single-trial estimates used within-study intervals. Meta-regression was not undertaken because the relevant main bodies contained at most seven trials. The original dose calculations, native-scale results and event-count models were reproduced and verified against a separate base-R implementation.

The opioid-focused analysis cannot establish maintained pain control, improved quality of recovery, satisfaction, safety or reduced persistent opioid use. It supports cautious interpretation of a rescue-use signal alongside uncertain total-dose benefit.

Detailed numerical outputs and methodological limits: [rerun report](RESULTS_AND_REVIEWER_INTERPRETATION.md). Native outcomes: [additional results](../ADDITIONAL_RESULTS.md). Rescue certainty: [existing provisional assessment](../certainty_and_manuscript/CERTAINTY.md). Selection: [PRISMA accounting](../../prisma/PRISMA_ACCOUNTING.md).
'''
(HERE/'MANUSCRIPT_RESULTS_DRAFT.md').write_text(manuscript)
print('Completed verified report and manuscript results draft.')
