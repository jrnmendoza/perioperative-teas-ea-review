# Scenario check for SP: E2 TEAS-vs-sham excluding high risk of bias, if Chen 2020's opioid result were rated High.
# Same estimator as lee_hold_rerun_2026_10_23.R (REML, HK truncated at 1, t(k-1)); reproduces the existing NOT_HIGH model first.
here <- commandArgs(trailingOnly = TRUE)[1]
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^﻿", "", names(x)); x }
inp <- rd(file.path(here, "e2", "e2_model_inputs.csv"))
prev <- rd(file.path(here, "lee_hold_rerun_2026-10-23.csv"))
fit <- function(d) {
  k <- nrow(d); y <- as.numeric(d$yi); v <- as.numeric(d$vi)
  N <- sum(as.integer(as.numeric(d$n_i)) + as.integer(as.numeric(d$n_c)))
  nll <- function(t) { w <- 1/(v + t); mu <- sum(w*y)/sum(w); .5*(sum(log(v + t)) + log(sum(w)) + sum(w*(y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2)*10, max(v)*10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1/(v + tau); mu <- sum(w*y)/sum(w); q <- sum(w*(y - mu)^2)/(k - 1)
  se <- sqrt(max(1, q)/sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1/v; C <- sum(w0) - sum(w0^2)/sum(w0); i2 <- 100*tau/(tau + (k - 1)/C)
  pil <- pih <- NA
  if (k >= 5) { h <- qt(.975, k - 1)*sqrt(tau + se^2); pil <- mu - h; pih <- mu + h }
  c(k = k, N = N, effect = mu, lo = mu - cr*se, hi = mu + cr*se, I2 = i2, pil = pil, pih = pih)
}
main <- inp[inp$model_id == "E2_opioid24_TEAS_sham" & inp$study != "Lee 2011", ]
cur <- main[!(main$study %in% c("Zhang 2025")), ]
f_cur <- fit(cur); p <- prev[prev$model_id == "E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE", ]
stopifnot(abs(f_cur["effect"] - p$effect) < 1e-6, abs(f_cur["lo"] - p$ci_low) < 1e-6, abs(f_cur["hi"] - p$ci_high) < 1e-6)
alt <- cur[cur$study != "Chen 2020", ]
f_alt <- fit(alt)
print(rbind(current_not_high = round(f_cur, 2), if_chen2020_high = round(f_alt, 2)))
cat("Studies (alt):", paste(alt$study, collapse = "; "), "\n")
