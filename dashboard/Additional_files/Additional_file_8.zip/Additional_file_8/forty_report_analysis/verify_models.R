# Independent base-R recalculation from the saved event counts.
args <- commandArgs(trailingOnly=TRUE)
folder <- if(length(args)) args[1] else "opioid_only_review/forty_report_analysis"
prefix <- if(length(args)>1) args[2] else "rescue_model"
inputs <- read.csv(file.path(folder,paste0(prefix,"_inputs.csv")),check.names=FALSE)
expected <- read.csv(file.path(folder,paste0(prefix,"_results.csv")),check.names=FALSE)
checks <- list()
for(id in expected$model_id) {
  d <- inputs[inputs$model_id==id,]
  yi <- log((d$events_i/d$n_i)/(d$events_c/d$n_c))
  vi <- 1/d$events_i-1/d$n_i+1/d$events_c-1/d$n_c
  k <- length(yi)
  nll <- function(tau) {
    weights <- 1/(vi+tau)
    estimate <- weighted.mean(yi,weights)
    0.5*(sum(log(vi+tau))+log(sum(weights))+sum(weights*(yi-estimate)^2))
  }
  upper <- max(1,mean((yi-mean(yi))^2)*10,max(vi)*10)
  optimized <- optimize(nll,c(0,upper),tol=1e-12)
  tau <- if(optimized$objective<nll(0)) optimized$minimum else 0
  weights <- 1/(vi+tau)
  estimate <- weighted.mean(yi,weights)
  q <- sum(weights*(yi-estimate)^2)/(k-1)
  se <- sqrt(max(1,q)/sum(weights))
  ci <- exp(estimate+c(-1,1)*qt(.975,k-1)*se)
  e <- expected[expected$model_id==id,]
  delta <- max(abs(c(exp(estimate),ci)-c(e$effect,e$ci_low,e$ci_high)))
  stopifnot(delta<1e-8,k==e$k,sum(d$n_i+d$n_c)==e$N)
  checks[[id]] <- data.frame(model_id=id,k=k,N=sum(d$n_i+d$n_c),
    effect_R=exp(estimate),ci_low_R=ci[1],ci_high_R=ci[2],
    max_absolute_difference=delta,check="AGREES")
}
write.csv(do.call(rbind,checks),file.path(folder,"independent_R_verification.csv"),row.names=FALSE)
cat(nrow(expected),"model effects, intervals, participant counts and trial counts agree with independent base R.\n")
