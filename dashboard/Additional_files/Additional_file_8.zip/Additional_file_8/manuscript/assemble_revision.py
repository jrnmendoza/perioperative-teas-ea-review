"""Assemble the revised manuscript (after the Astra audit, 2 November 2026) from sources/*_REVISED.*.

The sources hold the final prose, with figures and additional files already in manuscript numbering and citations as
[@key]. This script only: numbers citations in order of first mention (ranges for three or more consecutive numbers);
checks that figures and additional files are first cited in order; checks the abstract (<= 350 words, no citations);
removes thousands separators inside tables; and writes manuscript_spec.json for build_docx.js. It reads the
October spec only for the title page. Writes nothing outside this folder.
"""
import csv, json, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / 'sources'
OCT = json.loads((HERE.parent / 'BMC_2026-10-25' / 'manuscript_spec.json').read_text(encoding='utf-8'))
read = lambda n: (SRC / n).read_text(encoding='utf-8')


def blocks(md):
    out = []
    for chunk in re.split(r'\n\s*\n', md.strip()):
        chunk = ' '.join(l.strip() for l in chunk.splitlines())
        if chunk.startswith('## '):
            out.append(('h2', chunk[3:].strip()))
        elif chunk:
            out.append(('p', chunk))
    return out


background = [t for k, t in blocks(read('background_REVISED.md'))]
methods = blocks(read('methods_REVISED.md'))
results = blocks(read('results_REVISED.md'))
discussion = blocks(read('discussion_REVISED.md'))
conclusions = ' '.join(read('conclusions_REVISED.md').split())

ab = read('abstract_REVISED.md')
abstract = [(h, ' '.join(t.split())) for h, t in re.findall(r'\*\*(Background|Methods|Results|Conclusions):\*\* (.*?)\n\n', ab, re.S)]
registration = re.search(r'\*\*Registration:\*\* (.*)', ab).group(1).strip()
keywords = re.search(r'\*\*Keywords:\*\* (.*)', ab).group(1).strip()
_m = re.search(r'\*\*Note:\*\* (.*)', ab); abstract_note = _m.group(1).strip() if _m else ''   # owner comments, 8 Nov 2026
abstract_words = sum(len(t.split()) for _, t in abstract)
assert [h for h, _ in abstract] == ['Background', 'Methods', 'Results', 'Conclusions'] and abstract_words <= 350, abstract_words
assert '[@' not in ' '.join(t for _, t in abstract)
assert 3 <= len(keywords.split(';')) <= 10

t2 = read('table2_REVISED.md')
t2_title = re.search(r'\*\*Title:\*\* (.*)', t2).group(1).strip()
t2_rows = [[c.strip() for c in l.strip().strip('|').split('|')] for l in t2.splitlines() if l.startswith('|')]
t2_legend = re.search(r'\*\*Legend:\*\* (.*)', t2).group(1).strip()
t1_rows = list(csv.reader(open(SRC / 'table1_REVISED.csv', encoding='utf-8')))
t1l = read('table1_legend_REVISED.md')
t1_title = re.search(r'\*\*Title:\*\* (.*)', t1l).group(1).strip()
t1_legend = re.search(r'\*\*Legend:\*\* (.*)', t1l).group(1).strip()
figs = []
for n, ttl, leg in re.findall(r'## Figure (\d)\n\n\*\*Title:\*\* (.*?)\n\n\*\*Legend:\*\* (.*?)(?=\n\n## Figure|\s*$)', read('figures_REVISED.md'), re.S):
    figs.append(dict(n=int(n), title=ttl.strip(), legend=' '.join(leg.split())))
assert [f['n'] for f in figs] == [1, 2, 3, 4, 5]
afs = list(csv.DictReader(open(SRC / 'additional_files_REVISED.csv', encoding='utf-8')))

# ---------------------------------------------------------------- figure and additional-file order (BMC: cited in sequence)
body_text = ' '.join(background + [t for _, t in methods + results + discussion]) + ' ' + conclusions
seen_af, seen_fig = [], []
for m in re.finditer(r'Additional files? (\d+)(?: and (\d+))?|Fig\. (\d)', body_text):
    for g in (m.group(1), m.group(2)):
        if g and int(g) not in seen_af: seen_af.append(int(g))
    if m.group(3) and int(m.group(3)) not in seen_fig: seen_fig.append(int(m.group(3)))
assert seen_af == [k for k in range(1, 13) if k != 2], seen_af   # owner, 8 Nov 2026: file 2 not supplied; renumber_spec.py renumbers
assert seen_fig == [1, 2, 3, 4, 5], seen_fig
assert 'Table 1' in body_text and 'Table 2' in body_text and body_text.index('Table 1') < body_text.index('Table 2')

# ---------------------------------------------------------------- citations, numbered by first mention
refs = {r['key']: r for r in csv.DictReader(open(HERE / 'references' / 'references_revision.csv', encoding='utf-8'))}
order = []
cite_re = re.compile(r'\[(@[^\]]+)\]')
scan = (background + [t for _, t in methods] + [t for _, t in results] + [t2_legend] + [t for _, t in discussion] +
        [conclusions] + [f['legend'] for f in figs] + [r[0] for r in t1_rows[1:]] + [t1_legend])
for t in scan:
    for m in cite_re.finditer(t):
        for k in re.findall(r'@([A-Za-z0-9_:-]+)', m.group(1)):
            assert k in refs, k
            if k not in order: order.append(k)
NUM = {k: i + 1 for i, k in enumerate(order)}


def cite(t):
    def fmt(m):
        nums = sorted({NUM[k] for k in re.findall(r'@([A-Za-z0-9_:-]+)', m.group(1))})
        out, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1: j += 1
            out.append(f'{nums[i]}–{nums[j]}' if j - i >= 2 else ', '.join(str(n) for n in nums[i:j + 1]))
            i = j + 1
        return '[' + ', '.join(out) + ']'
    return cite_re.sub(fmt, t)


nocomma = lambda s: re.sub(r'(?<=\d),(?=\d{3}\b)', '', s)
sec = lambda bl: [dict(kind=k, text=cite(t)) for k, t in bl]
spec = dict(
    # author confirmations, 3 Nov 2026 (confirm/apply_confirm_static.py): SKP at Region Skane, as in PROSPERO
    # owner comments, 8 Nov 2026 (owner_comments_2026-11-08/apply_owner_static.py): JRNM also at Region Skane; no programme name
    title=OCT['title'], authors=[[a, {'Siv Katrin Peters': '2', 'John Ryan Nual Mendoza': '1,2*'}.get(a, s)] for a, s in OCT['authors']],
    affiliations=['1 Department of Health Sciences, Faculty of Medicine, Lund University, Lund, Sweden', '2 Region Skåne, Sweden'],
    corresponding=OCT['corresponding'],
    title_note='[PROVISIONAL: not for submission until the screening records (Covidence exports and each reviewer\'s account) and SKP\'s check of the analysis inputs (D9) are complete; see AUTHOR_ACTIONS.md.]',
    abstract=abstract, abstract_note=abstract_note, registration=registration, keywords=keywords, abstract_words=abstract_words,
    background=[cite(p) for p in background], methods=sec(methods), results=sec(results), discussion=sec(discussion),
    conclusions=cite(conclusions),
    table2=dict(title=t2_title, rows=[[nocomma(c) for c in r] for r in t2_rows], legend=cite(t2_legend)),
    table1=dict(title=t1_title, rows=[[nocomma(cite(c)) for c in r] for r in t1_rows], legend=cite(t1_legend)),
    figures=[dict(f, legend=cite(f['legend'])) for f in figs],
    references=[refs[k]['text'] for k in order],
    additional_files=[dict(n=int(a['n']), fmt=a['fmt'], title=a['title'], desc=a['desc']) for a in afs],
)
dump = json.dumps(spec, ensure_ascii=False)
assert '[@' not in dump and '§A' not in dump
for f in spec['figures']:
    assert len(f['title'].split()) <= 15 and len(f['legend'].split()) <= 300, f['n']
(HERE / 'manuscript_spec.json').write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding='utf-8')
unused = [k for k in refs if k not in NUM]
print('abstract words', abstract_words, '| references cited', len(order), '| not cited:', unused)
