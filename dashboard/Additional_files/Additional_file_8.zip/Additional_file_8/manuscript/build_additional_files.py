"""Additional files 1-12, revision after the Astra audit (2 November 2026; first built 25 October 2026).

Numbering follows the manuscript (order of first mention; see README.md). Every table is read from the project's
records; nothing is re-estimated here. Items the authors must confirm are highlighted yellow ("[CONFIRM ...]").
Run with the bundled Python (pandas, python-docx, openpyxl):
  ~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 build_additional_files.py
Writes additional_files/Additional_file_N.{docx,xlsx,zip}.
"""
import csv, json, math, re, zipfile, hashlib, collections
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_COLOR_INDEX
from docx.enum.section import WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'additional_files'
FA = ROOT / 'opioid_only_review/forty_report_analysis'
C = FA / 'registered_completion_2026_10_09'
R = FA / 'reviewer_rerun_2026_10_09'
CM = FA / 'certainty_and_manuscript'
V38 = ROOT / '10_FINAL_ADJUDICATION/02_DECISIONS/v38'
QOR = ROOT / '10_FINAL_ADJUDICATION/08_QOR_ANALYSIS'
PR = ROOT / 'opioid_only_review/prisma'
SRCH = ROOT / '01_search_strategy'
SPEC = json.loads((HERE / 'manuscript_spec.json').read_text())
TITLE, REG = SPEC['title'], 'PROSPERO CRD420261452908'
REV = HERE  # revision folder: C01 triage, references and reproduction script
import csv as _csv   # owner, 8 Nov 2026: the spec lists the submitted (renumbered) files; the internal build uses the full list
AF = {int(a['n']): dict(a, n=int(a['n'])) for a in _csv.DictReader(open(HERE / 'sources/additional_files_REVISED.csv', encoding='utf-8'))}
assert [a['n'] for a in AF.values()] == list(range(1, 13))


def rd(p):
    return pd.read_csv(p, dtype=str, keep_default_na=False, encoding='utf-8-sig')


def recs(p):
    return list(csv.DictReader(Path(p).open(encoding='utf-8-sig', newline='')))


def num(v, dp=3):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return v if v not in (None, 'nan') else ''
    if f != f:
        return ''
    return round(f, dp) if dp is not None else f


def tidy(s):
    """Restore spaces lost between words and numbers in the conversion register (e.g. 'factor100'), outside URLs."""
    parts = re.split(r'(https?://\S+)', s)
    for i in range(0, len(parts), 2):
        t = re.sub(r'(?<=[A-Za-z])(?=\d)', ' ', parts[i])
        parts[i] = re.sub(r'(?<=\d)(?=(mg|µg)\b)', ' ', t)
    return ''.join(parts).replace('IVMME', 'IV MME')


# ================================================================ Word helpers
CONF = re.compile(r'(\[CONFIRM[^\]]*\])')


def runs(p, text, bold=False, italic=False, size=None, mono=False):
    for part in CONF.split(str(text)):
        if not part:
            continue
        for j, seg in enumerate(part.split('**')):
            if not seg:
                continue
            r = p.add_run(seg)
            r.bold = bold or j % 2 == 1
            r.italic = italic
            if size:
                r.font.size = Pt(size)
            if mono:
                r.font.name = 'Courier New'
                r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Courier New')
            if part.startswith('[CONFIRM'):
                r.font.highlight_color = WD_COLOR_INDEX.YELLOW
    return p


def page_field(par):
    r = par.add_run()
    for tag, txt in (('begin', None), (None, 'PAGE'), ('end', None)):
        if tag:
            e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), tag)
        else:
            e = OxmlElement('w:instrText'); e.set(qn('xml:space'), 'preserve'); e.text = txt
        r._element.append(e)


def new_doc(n):
    d = Document()
    s = d.sections[0]
    s.page_width, s.page_height = Cm(21.0), Cm(29.7)
    s.left_margin = s.right_margin = s.top_margin = s.bottom_margin = Cm(2.0)
    st = d.styles['Normal']
    st.font.name, st.font.size = 'Times New Roman', Pt(11)
    st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    st.paragraph_format.space_after = Pt(6)
    for name, size in (('Heading 1', 13), ('Heading 2', 11.5), ('Heading 3', 11)):
        h = d.styles[name]
        h.font.name, h.font.size, h.font.bold = 'Times New Roman', Pt(size), True
        h.font.color.rgb = RGBColor(0, 0, 0)
        h.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
        h.paragraph_format.space_before, h.paragraph_format.space_after = Pt(12), Pt(4)
    page_field(s.footer.paragraphs[0])
    runs(d.add_paragraph(), f'Additional file {n}', bold=True, size=14)
    runs(d.add_paragraph(), AF[n]['title'], bold=True, size=13)
    runs(d.add_paragraph(), f'Supplement to: {TITLE}. {REG}.', italic=True, size=10)
    return d


def para(d, text, **kw):
    return runs(d.add_paragraph(), text, **kw)


def bullet(d, text):
    return runs(d.add_paragraph(style='List Bullet'), text)


def head(d, text, level=1):
    return d.add_heading(text, level=level)


def table(d, rows, widths, size=9, mono_cols=()):
    t = d.add_table(rows=len(rows), cols=len(rows[0]))
    t.autofit = False
    tp = t._tbl.tblPr
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tp.append(lay)
    b = OxmlElement('w:tblBorders')
    for edge in ('top', 'bottom', 'insideH', 'left', 'right', 'insideV'):
        e = OxmlElement(f'w:{edge}')
        if edge in ('top', 'bottom', 'insideH'):
            e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '4'); e.set(qn('w:color'), '808080')
        else:
            e.set(qn('w:val'), 'nil')
        b.append(e)
    tp.append(b)
    tw = OxmlElement('w:tblW'); tw.set(qn('w:w'), str(int(sum(widths) * 567))); tw.set(qn('w:type'), 'dxa')
    for old in tp.findall(qn('w:tblW')):
        tp.remove(old)
    tp.append(tw)
    for j, w in enumerate(widths):  # the grid, which Pages and LibreOffice use
        t.columns[j].width = Cm(w)
    for i, row in enumerate(rows):
        tr = t.rows[i]
        if i == 0:
            h = OxmlElement('w:tblHeader'); h.set(qn('w:val'), 'true'); tr._tr.get_or_add_trPr().append(h)
        for j, v in enumerate(row):
            cell = tr.cells[j]
            cell.width = Cm(widths[j])
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            runs(p, '' if v is None else v, bold=(i == 0), size=size, mono=(j in mono_cols and i > 0))
    d.add_paragraph()
    return t


def code_block(d, lines, size=7.5):
    for ln in lines:
        p = d.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        runs(p, ln if ln else ' ', size=size, mono=True)
    d.add_paragraph()


# ================================================================ Excel helpers
BOLD, WRAP = Font(bold=True), Alignment(wrap_text=True, vertical='top')
RULE = Border(bottom=Side(style='thin', color='000000'))
YELLOW = PatternFill('solid', fgColor='FFFF00')


def new_wb(n, about, sheets, notes=()):
    wb = Workbook()
    ws = wb.active
    ws.title = 'README'
    ws.column_dimensions['A'].width, ws.column_dimensions['B'].width = 30, 125
    rows = [(f'Additional file {n}', ''), (AF[n]['title'], ''), (f'Supplement to: {TITLE}. {REG}.', ''), ('', '')]
    rows += [('About this file', a) for a in ([about] if isinstance(about, str) else about)]
    rows += [('', ''), ('Sheet', 'Contents')] + list(sheets)
    if notes:
        rows += [('', ''), ('Notes', '')] + [('', x) for x in notes]
    for r in rows:
        ws.append(list(r))
    for row in ws.iter_rows():
        for c in row:
            c.alignment = WRAP
            if c.value and '[CONFIRM' in str(c.value):
                c.fill = YELLOW
    for r in (1, 2):
        ws.cell(r, 1).font = Font(bold=True, size=13 if r == 1 else 12)
    hdr = 5 + len([about] if isinstance(about, str) else about) + 1
    ws.cell(hdr, 1).font = ws.cell(hdr, 2).font = BOLD
    return wb


def sheet(wb, name, rows, cols):
    """rows: list of dicts; cols: list of (key, header, width)."""
    ws = wb.create_sheet(name[:31])
    ws.append([h for _, h, _ in cols])
    for j, (_, _, w) in enumerate(cols, 1):
        ws.column_dimensions[ws.cell(1, j).column_letter].width = w
        c = ws.cell(1, j); c.font, c.alignment, c.border = BOLD, WRAP, RULE
    for r in rows:
        ws.append([r.get(k, '') for k, _, _ in cols])
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = WRAP
            if isinstance(c.value, str) and '[CONFIRM' in c.value:
                c.fill = YELLOW
    ws.freeze_panes = 'B2' if len(cols) > 6 else 'A2'
    ws.auto_filter.ref = ws.dimensions
    return ws


def save(obj, n, ext):
    OUT.mkdir(exist_ok=True)
    p = OUT / f'Additional_file_{n}{ext}'
    obj.save(p)
    return p


# ================================================================ shared facts
pc = json.loads((REV / 'd3/prisma_counts_current.json').read_text())  # D1 and D3 (2 Nov 2026): four outcome exclusions included
INCL = rd(C / 'protocol_characteristics.csv')
REPORTS = sorted(INCL.report_id)
assert len(REPORTS) == 40 and pc['included_reports'] == 44  # the 40 project reports + Wang 1997 (wang1997/) + three D3 reports (d3/)
# Decision D1 (2 Nov 2026): the review owner judged Wang 1997 to be TEAS, with its results known. Its extraction, refit,
# RoB 2 and GRADE assessments are in wang1997/; SKP confirmed them on 2 Nov 2026.
W97 = REV / 'wang1997'
W97_RES = {r['result_id']: r for r in recs(W97 / 'wang1997_results.csv')}
W97_CHAR = {r['field']: r for r in recs(W97 / 'wang1997_characteristics.csv')}
W97_IN = recs(W97 / 'wang1997_analysis_inputs.csv')
W97_MOD = {r['model_id']: r for r in recs(W97 / 'models_with_wang.csv')}
W97_PDF = '10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/1879897512.pdf'
W97_SHA = '68b137a7876f976afd74bf0620c80d4cda08c8f7de73ae1740309d8b5d3b0d2f'
W97_NOTE = 'Wang 1997, included 2 Nov 2026 (decision D1)'
W97_INV = recs(W97 / 'wang1997_outcome_inventory.csv')   # every reported Wang result and its disposition (re-check, M05)
# Decision D3 (2 Nov 2026): Colak 2010 and Fu 2024 included; Chen 2016 included and held from pooling (ages 16-80); Tu 2018,
# Zhou 2025 [1879896127] and Li 2017 relabelled. Records in d3/; SKP confirmed the extraction and the RoB 2 and GRADE assessments on 3 Nov 2026.
D3 = REV / 'd3'
D3_DEC = {r['covidence_id']: r for r in recs(D3 / 'd3_decisions.csv')}
D3_RES = {r['result_id']: r for r in recs(D3 / 'd3_results.csv')}
D3_INV = recs(D3 / 'd3_outcome_inventory.csv')   # every result the D3 reports give, with its disposition (Astra's D3 audit, 3 Nov 2026)
D3_CHAR = recs(D3 / 'd3_characteristics.csv')
D3_PDF = {'Colak 2010': '1879897298', 'Fu 2024': '1879896270', 'Chen 2016': '1879896981'}
D3_NOTE = 'included 2 Nov 2026 (decision D3)'
# Decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected reason; all remain excluded.
D4_DEC = {r['covidence_id']: r for r in recs(REV / 'd4/d4_decisions.csv')}
# Decision D5 (JRNM and SKP, 3 Nov 2026): the 53 outcome exclusions the triage could not assess, sought and read with AI assistance.
D5_DEC = {r['covidence_id']: r for r in recs(REV / 'd5/d5_decisions.csv')}
D5_LOG = recs(REV / 'd5/d5_retrieval_log.csv')
D5_LOGD = {x['covidence_id']: x for x in D5_LOG}
# Decision D8 (JRNM and SKP, 3 Nov 2026): the three report leads of the September 2026 discovery audit, screened and excluded.
D8_DEC = {r['record_id']: r for r in recs(REV / 'd8/d8_decisions.csv')}
D3_MOD = {m for m, x in W97_MOD.items() if 'Fu 2024' in x['description'] or 'Colak 2010' in x['description']}


# ================================================================ Additional file 1: PRISMA 2020 checklist
def af1():
    d = new_doc(1)
    para(d, 'Location of each PRISMA 2020 item in the manuscript. Item wording is abbreviated; the full checklist is '
            'Page MJ, McKenzie JE, Bossuyt PM, et al. The PRISMA 2020 statement: an updated guideline for reporting '
            'systematic reviews. BMJ. 2021;372:n71 (CC BY 4.0). Locations are given by section heading, because page '
            'numbers change during production.', size=10)
    rows = [['Section and topic', 'Item', 'Checklist item (abbreviated)', 'Location where reported']]
    items = [
        ('TITLE', '', '', ''),
        ('Title', '1', 'Identify the report as a systematic review.', 'Title'),
        ('ABSTRACT', '', '', ''),
        ('Abstract', '2', 'Structured abstract (see the PRISMA 2020 for Abstracts checklist below).', 'Abstract'),
        ('INTRODUCTION', '', '', ''),
        ('Rationale', '3', 'Rationale for the review in the context of existing knowledge.', 'Background'),
        ('Objectives', '4', 'Explicit statement of the objectives or questions the review addresses.', 'Background, final paragraph'),
        ('METHODS', '', '', ''),
        ('Eligibility criteria', '5', 'Inclusion and exclusion criteria, and how studies were grouped for the syntheses.',
         'Methods: Eligibility criteria; Statistical analysis (grouping by modality and comparator)'),
        ('Information sources', '6', 'All databases, registers, websites, organisations, reference lists and other sources searched or consulted, with the date each was last searched.',
         'Methods: Search and selection; Additional file 3. Trial registers were not searched within the review.'),
        ('Search strategy', '7', 'Full search strategies for all databases, registers and websites, including any filters and limits.', 'Additional file 3'),
        ('Selection process', '8', 'Methods used to decide eligibility, including how many reviewers screened each record and report, whether they worked independently, and any automation tools.',
         'Methods: Search and selection. Titles and abstracts, and then full texts, were screened independently by JRNM and SKP; disagreements were resolved by consensus, with an AI agent (Codex) supporting some conflict resolution. Before screening, Covidence\'s randomised-controlled-trial classifier excluded 508 records without a human check.'),
        ('Data collection process', '9', 'Methods used to collect data, including how many reviewers collected data, whether independently, processes for obtaining or confirming data from investigators, and automation tools.',
         'Methods: Data extraction; Use of AI tools'),
        ('Data items', '10a', 'Outcomes for which data were sought, whether all compatible results were sought, and methods used to decide which results to collect.',
         'Methods: Outcomes; Additional file 6'),
        ('', '10b', 'Other variables for which data were sought, and assumptions made about missing or unclear information.',
         'Methods: Data extraction; Additional files 5 and 8'),
        ('Study risk of bias assessment', '11', 'Methods used to assess risk of bias, including the tool, how many reviewers assessed each study, whether independently, and any automation tools.',
         'Methods: Risk of bias and certainty of evidence; Use of AI tools; Additional file 10'),
        ('Effect measures', '12', 'Effect measures used for each outcome in the synthesis or presentation of results.', 'Methods: Outcomes; Statistical analysis'),
        ('Synthesis methods', '13a', 'Processes used to decide which studies were eligible for each synthesis.', 'Methods: Outcomes; Statistical analysis; Additional file 6'),
        ('', '13b', 'Methods required to prepare the data for synthesis, such as handling missing summary statistics or data conversions.',
         'Methods: Outcomes (conversion to IV morphine equivalents); Statistical analysis; Additional file 7'),
        ('', '13c', 'Methods used to tabulate or visually display results of individual studies and syntheses.', 'Methods: Statistical analysis; Results: Tables 1 and 2, Figs. 2–5'),
        ('', '13d', 'Methods used to synthesise results, with rationale; for meta-analysis, the model, methods for heterogeneity and software.', 'Methods: Statistical analysis'),
        ('', '13e', 'Methods used to explore possible causes of heterogeneity (subgroup analysis, meta-regression).',
         'Methods: Statistical analysis (registered meta-regression not performed; protocol characteristics described)'),
        ('', '13f', 'Sensitivity analyses conducted to assess the robustness of the synthesised results.', 'Methods: Statistical analysis'),
        ('Reporting bias assessment', '14', 'Methods used to assess risk of bias due to missing results in a synthesis.',
         'Methods: Statistical analysis (within-trial selective reporting through RoB 2 domain 5 only; non-reporting across trials not assessed; small-study tests required at least 10 trials)'),
        ('Certainty assessment', '15', 'Methods used to assess certainty in the body of evidence for an outcome.', 'Methods: Risk of bias and certainty of evidence; Additional file 11'),
        ('RESULTS', '', '', ''),
        ('Study selection', '16a', 'Results of the search and selection process, ideally with a flow diagram.', 'Results: Study selection; Fig. 1'),
        ('', '16b', 'Studies that might appear to meet the inclusion criteria but were excluded, and why.', 'Results: Study selection; Additional file 4'),
        ('Study characteristics', '17', 'Cite each included study and present its characteristics.', 'Results: Study characteristics; Table 1; Additional file 8'),
        ('Risk of bias in studies', '18', 'Risk of bias assessments for each included study.', 'Results: Risk of bias; Fig. 3; Additional file 10'),
        ('Results of individual studies', '19', 'For all outcomes, summary statistics for each group and an effect estimate with its precision for each study.',
         'Figs. 4 and 5; Additional file 12'),
        ('Results of syntheses', '20a', 'For each synthesis, the characteristics and risk of bias of contributing studies.', 'Results; Figs. 2 and 3'),
        ('', '20b', 'Results of all statistical syntheses: summary estimate and its precision, and measures of heterogeneity.', 'Results; Table 2; Figs. 4 and 5; Additional file 12'),
        ('', '20c', 'Results of all investigations of possible causes of heterogeneity.', 'Results: Protocol characteristics; Additional file 8'),
        ('', '20d', 'Results of all sensitivity analyses.', 'Results; Additional file 12'),
        ('Reporting biases', '21', 'Assessments of risk of bias due to missing results for each synthesis assessed.',
         'Not assessed across trials (Methods: Statistical analysis); selection of the reported result within trials: Results: Risk of bias. The selection check of historical exclusions is reported separately (Results: Study selection; Additional file 4).'),
        ('Certainty of evidence', '22', 'Assessments of certainty in the body of evidence for each outcome assessed.', 'Results; Table 2; Additional file 11'),
        ('DISCUSSION', '', '', ''),
        ('Discussion', '23a', 'General interpretation of the results in the context of other evidence.', 'Discussion: Principal findings; Comparison with previous reviews'),
        ('', '23b', 'Limitations of the evidence included in the review.', 'Discussion: Why the evidence is uncertain; Where the evidence comes from'),
        ('', '23c', 'Limitations of the review processes used.', 'Discussion: Strengths and limitations'),
        ('', '23d', 'Implications of the results for practice, policy and future research.', 'Discussion: Implications for practice and research'),
        ('OTHER INFORMATION', '', '', ''),
        ('Registration and protocol', '24a', 'Registration information, including register name and registration number, or a statement that the review was not registered.',
         'Abstract (registration line); Methods: Protocol and registration'),
        ('', '24b', 'Where the review protocol can be accessed, or a statement that a protocol was not prepared.',
         'Stated here: the full protocol was not made publicly available; the PROSPERO record (CRD420261452908) describes it as a team draft not yet released.'),
        ('', '24c', 'Describe and explain any amendments to information provided at registration or in the protocol.', 'Methods: Protocol and registration (opioid-result requirement); Eligibility criteria (outcome requirements narrower than registered); Search and selection (registers not searched, searches not updated); Statistical analysis (post hoc analyses; meta-regression not feasible)'),
        ('Support', '25', 'Sources of financial or non-financial support, and the role of funders or sponsors.', 'Declarations: Funding'),
        ('Competing interests', '26', 'Competing interests of review authors.', 'Declarations: Competing interests'),
        ('Availability of data, code and other materials', '27', 'Which of the following are publicly available and where: data collection forms, extracted data, data used for analyses, analytic code, other materials.',
         'Declarations: Availability of data and materials; Additional files 4–12 (extracted data and analysis inputs); Additional file 9 (code)'),
    ]
    for sec, it, txt, loc in items:
        rows.append([f'**{sec}**' if not it else sec, it, txt, loc])
    table(d, rows, [3.6, 1.1, 6.8, 5.5], size=8.5)

    head(d, 'PRISMA 2020 for Abstracts', 1)
    para(d, 'Items of the PRISMA 2020 for Abstracts checklist and where each is reported in the abstract.')
    rows = [['Section and topic', 'Item', 'Checklist item (abbreviated)', 'Reported']]
    for r in [
        ('Title', '1', 'Identify the report as a systematic review.', 'Yes (title)'),
        ('Objectives', '2', 'The main objective(s) or question(s) the review addresses.', 'Yes (Background: whether TEAS and EA reduce postoperative opioid consumption by a clinically important amount)'),
        ('Eligibility criteria', '3', 'Inclusion and exclusion criteria.', 'Yes (Methods)'),
        ('Information sources', '4', 'Information sources and the date each was last searched.', 'Yes (Methods: four databases, 21–23 July 2026)'),
        ('Risk of bias', '5', 'Methods used to assess risk of bias in the included studies.', 'Yes (Methods: result-specific RoB 2; GRADE)'),
        ('Synthesis of results', '6', 'Methods used to present and synthesise results.', 'Yes (Methods: random-effects models, REML, Hartung–Knapp)'),
        ('Included studies', '7', 'Number of included studies and participants and relevant characteristics.', 'Yes (Results: 44 reports of 43 trials, 7,703 participants) [PROVISIONAL: six historical outcome exclusions not retrieved]'),
        ('Synthesis of results', '8', 'Results for main outcomes, with number of studies and participants, summary estimate and confidence interval.', 'Yes (Results)'),
        ('Limitations of evidence', '9', 'Brief summary of the limitations of the evidence.', 'Yes (Results: risk of bias; Conclusions: certainty)'),
        ('Interpretation', '10', 'General interpretation of the results and important implications.', 'Yes (Conclusions)'),
        ('Funding', '11', 'Primary source of funding for the review.', 'Not in the abstract (BMC abstract structure); Declarations: Funding'),
        ('Registration', '12', 'Register name and registration number.', 'Yes (registration line after the abstract)'),
    ]:
        rows.append(list(r))
    table(d, rows, [3.6, 1.1, 6.8, 5.5], size=8.5)
    return save(d, 1, '.docx')


# ================================================================ Additional file 2: eligibility, deviations, decision log
def af2():
    d = new_doc(2)
    para(d, 'This file gives the eligibility criteria as registered and as applied, every deviation from the registered '
            'protocol, a dated log of the decisions that shaped the analysis, the author queries and the record of '
            'second review. Text under "Registered" is quoted verbatim from the PROSPERO record (CRD420261452908, '
            'version 1.0, first submitted 19 August 2026 and published 20 August 2026; review start date 14 August 2026). '
            'All decisions after registration were made with the results of the contributing trials known.')

    head(d, '1. Population')
    para(d, '**Registered.** Included:')
    for t in ['Adults aged 18 years or older undergoing an operative surgical procedure under general anaesthesia.',
              'General anaesthesia alone or general anaesthesia combined with regional or neuraxial anaesthesia or analgesia.',
              'Any surgical specialty and elective or urgent surgery, provided postoperative opioid consumption or another eligible outcome is reported.',
              'Mixed-age studies when adult data can be extracted separately or when at least 90% of participants are aged 18 years or older.']:
        bullet(d, t)
    para(d, 'Excluded:')
    for t in ['Studies involving only children or adolescents.',
              'Procedures conducted exclusively under local, regional, or neuraxial anaesthesia without general anaesthesia.',
              'Non-surgical procedures, dental procedures without general anaesthesia, chronic pain populations without an acute perioperative context, and interventions delivered only after recovery from the acute postoperative period.']:
        bullet(d, t)
    para(d, '**Applied.** General anaesthesia was verified from the methods of each report, not from a label, an '
            'analgesic regimen or an indexing term. Where the report did not establish it, the report was retained but '
            'not pooled (Jin 2023). Lee 2011 enrolled participants aged 14–59 years (whole-trial mean 42.0 years; ages '
            'by arm not reported), so neither condition of the mixed-age rule could be shown. Its pain and mobility '
            'results were held from the start; on 23 October 2026 its broader first-day opioid result, which had been '
            'pooled, was also held, so that Lee 2011 enters no pooled analysis.')

    head(d, '2. Interventions')
    para(d, '**Registered.** Included:')
    for t in ['Transcutaneous electrical acupoint stimulation (TEAS): non-invasive electrical stimulation delivered through surface electrodes positioned over recognised or explicitly defined body acupuncture points, without needle penetration.',
              'Electroacupuncture (EA): electrical stimulation delivered through one or more pairs of acupuncture needles inserted at recognised or explicitly defined body acupuncture points.']:
        bullet(d, t)
    para(d, 'Eligible terminology may include transcutaneous electrical acupoint stimulation, transcutaneous electric '
            'acupoint stimulation, transcutaneous acupoint electrical stimulation, electrical acupoint stimulation, '
            'electroacupoint stimulation, acupuncture-like TENS delivered at acupuncture points, electroacupuncture, '
            'electric acupuncture, or electrically stimulated acupuncture when the intervention clearly meets the '
            'definitions above. At least one eligible stimulation session must occur before the end of the first 24 '
            'postoperative hours. Interventions may be preoperative, intraoperative, postoperative, or delivered across '
            'more than one perioperative phase. TEAS or EA may be used alone or as an adjunct to balanced usual '
            'multimodal perioperative care.')
    para(d, 'Excluded:')
    for t in ['Manual acupuncture without electrical stimulation.',
              'Dry needling, trigger-point needling, acupuncture-point injection, laser acupuncture, moxibustion, cupping, massage, or herbal interventions.',
              'Ordinary TENS or percutaneous electrical nerve stimulation delivered only at non-acupuncture locations.',
              'Auricular acupuncture, battlefield acupuncture, auricular acupressure, electroauriculotherapy, press-tack or intradermal needle interventions, wrist-ankle acupuncture, and buccal acupuncture.',
              'Electrical stimulation used only for neuromuscular monitoring, nerve localisation, or physiological measurement.',
              'Mixed interventions in which the independent effect of TEAS or EA cannot be separated.',
              'Studies in which TEAS and EA are combined within the same intervention arm and their individual contribution cannot be separated.']:
        bullet(d, t)
    para(d, '**Applied.** Modality was assigned from the physical method described, not from the trial\'s own label. '
            'Long 2025 described its intervention as delivered by "needle or patch", which does not establish needle '
            'penetration; it was classified as modality-unclear and retained but not pooled.')

    head(d, '3. Comparators')
    para(d, '**Registered.** The principal analyses will use sham-controlled comparisons: (1) TEAS versus inactive or '
            'credible sham TEAS, including identical electrode placement with no current, sub-sensory or minimally '
            'active current, or non-acupoint sham electrical stimulation; (2) EA versus sham EA, including '
            'non-penetrating sham needles, superficial or non-acupoint needling, needles connected to an inactive '
            'device, or another credible sham procedure designed to preserve participant blinding. Usual perioperative '
            'care, standard multimodal analgesia, no TEAS or EA, waiting-list control, or attention control will be '
            'eligible but analysed separately as supportive comparisons. Active electrical comparators, such as '
            'non-acupoint TENS, may be included and reported separately when the contrast is clinically interpretable. '
            'Anaesthetic techniques, regional or neuraxial analgesia, non-opioid analgesics, antiemetics, and '
            'postoperative care pathways must be balanced between groups or sufficiently described to assess their '
            'potential influence. Excluded: comparators containing an active acupuncture-point intervention that '
            'prevents estimation of the independent effect of TEAS or EA; groups receiving substantially different '
            'perioperative or analgesic co-interventions without adequate adjustment; comparators that are '
            'insufficiently described to classify as sham, usual care, no treatment, or active comparator.')
    para(d, '**Applied.** The registered record lists non-acupoint electrical stimulation both as a form of sham and as a '
            'possible active comparator, so comparator class was assigned for each result from the source text. '
            'Comparator decisions that needed adjudication in the included reports:')
    inv = rd(C / 'all_40_result_inventory.csv')
    adj = sorted({a for a in inv.comparator_adjudication if a})
    rows = [['Report', 'Source basis', 'Class assigned']]
    cls = {'Lin 2002': 'Usual care', 'Xiong 2021': 'Sham', 'Szmit 2021': 'Usual care'}
    for a in adj:
        rep, txt = a.split(':', 1)
        txt = txt.strip()
        txt = txt if txt.startswith('"') else txt[0].upper() + txt[1:]
        c = cls.get(rep, 'Active electrical comparator (reported separately)' if 'TENS' in txt else 'Usual care')
        rows.append([rep, txt.strip(), c])
    table(d, rows, [2.8, 10.2, 4.0])

    head(d, '4. Study designs')
    para(d, '**Registered.** Only randomized study types will be included. Included: individually randomized '
            'parallel-group controlled trials; cluster-randomized trials when appropriate design-adjusted results are '
            'available or can be calculated; crossover trials only when an eligible perioperative treatment period can '
            'be validly separated and carryover is implausible. Excluded: quasi-randomized studies, non-randomized '
            'controlled studies, observational studies, case series, case reports, qualitative studies, reviews, and '
            'protocols without results; conference abstracts without sufficient information for eligibility, '
            'risk-of-bias assessment, and outcome extraction.')

    head(d, '5. Context and language')
    para(d, '**Registered.** Inpatient, day-surgery, ambulatory surgical, and other perioperative hospital settings in '
            'any country or healthcare system will be eligible. [...] Only studies for which the full-text report is '
            'published in English will be eligible for inclusion. No language restriction will be applied at the '
            'database-search stage; reports published in languages other than English that are identified by the '
            'unrestricted searches will be excluded during study selection on the basis of publication language.')
    para(d, '**Applied.** Twelve reports were excluded for publication language at screening; their English abstracts were checked '
            'on 24 October 2026 for a postoperative opioid result (Additional file 4). SKP checked this abstract '
            'check (reported 3 Nov 2026). Seven more, recorded at screening as having no eligible analgesic outcome, were counted '
            'under publication language on 3 November 2026 because their English abstracts report pain at about 24 hours or an '
            'opioid result (decision D5, section 6). The English-language restriction was adopted on 20 August 2026, the day '
            'of registration, and is part of the registered record, so it is not a deviation. The draft protocol of 21 '
            'July 2026 had planned no language restriction.')

    head(d, '6. Outcome requirements at full text')
    para(d, 'Two outcome requirements were applied at full text in addition to the registered criteria.')
    para(d, '**Outcome-focused full-text rule (14 August 2026, before registration).** An otherwise eligible report had '
            'to provide extractable comparative results for at least one of (1) cumulative systemic postoperative opioid '
            'consumption from the end of surgery to approximately 24 hours, with the opioid, route and quantity reported '
            'sufficiently for conversion to IV morphine equivalents, or with the necessary information reasonably '
            'obtainable from the report or authors; or (2) postoperative pain at approximately 24 hours, at rest or on '
            'movement, on an interpretable scale. The rule was adopted to focus screening on the two primary outcomes. It '
            'is narrower than the registered population criterion ("provided postoperative opioid consumption or another '
            'eligible outcome is reported") and is not in the registered record. '
            f'{pc["exclusion_reasons"]["no perioperative analgesia outcome found"]} reports remain excluded under it (113 '
            'before the recheck of 2 November 2026; four were then included and 21 were counted under a corrected reason, decisions '
            'D1, D3, D4 and D5) '
            '("No eligible analgesic outcome" in Fig. 1). These exclusions were made at full-text screening, which JRNM and SKP '
            'did independently (Methods); the label does not establish that every excluded report lacked every '
            'registered outcome.')
    a = pc['additional_exclusion_reasons']
    para(d, '**Confirmed postoperative opioid result (9 October 2026, after registration, with trial results known).** '
            'Reports had to include a postoperative opioid result: a named postoperative opioid, or an author-defined '
            'morphine-equivalent quantity, confirmed in the source report. Reports without such a result could not '
            'inform the primary question. An audit of the outcome reporting of the 70 reports then included (dated '
            f'8 October 2026) identified {pc["additional_focused_exclusions"] - 2 - 8 - 2} without one: '
            f'{a["No postoperative opioid result located in available report"] - 7 - 2} in which no postoperative opioid result '
            f'was located in the available report; {a["Opioid outcome identity, timing or treatment comparison unresolved"] - 2} '
            'in which the opioid identity, timing or treatment comparison could not be resolved; '
            f'{a["Pump requests/presses only; opioid quantity not verified"] - 1} reporting only pump requests or presses; and '
            f'{a["Reported pump deliveries; opioid identity/formulation unconfirmed"]} reporting pump deliveries without a '
            'confirmed opioid identity or formulation. Two further reports were excluded under this criterion on 2 November 2026 '
            '(decision D3, below), eight more were counted under it on 3 November 2026 (decision D4, below) and two more the same day '
            '(decision D5, below). The 40 remaining reports formed the review until Wang 1997, and then Colak 2010, Fu 2024 '
            'and Chen 2016, were added on 2 November 2026 (below). Each excluded report '
            'and its finding is listed in Additional file 4.')
    para(d, '**Later check of the 113 outcome exclusions (2 November 2026).** Filter B was applied only to reports that '
            'had passed the 14 August rule, so a report wrongly excluded under that rule was never assessed under filter B. '
            'An AI-assisted triage of the existing source checks (24 September and 8 October 2026) and of four reports read '
            'for the revision found 9 reports that pass or may pass both outcome requirements (membership candidates, '
            'including Wang 1997, a sham-controlled TEAS trial with 24-hour hydromorphone and pain results, and Colak 2010, '
            'an EA trial with day-1 pain and a 7-day pethidine total); 8 that report pain at about 24 hours but no '
            'postoperative opioid result (they remain excluded and, by decision D4, are counted under the 9 October criterion); 7 '
            'whose exclusion is supported or fails another criterion first (Tzeng 2015: spinal anaesthesia without general '
            'anaesthesia, counted as wrong setting by decision D4); 8 '
            'with a keyword signal never followed by a full read; 36 with no signal; and 45 with no local full text (the 53 in these '
            'two groups were sought and read on 3 November 2026; decision D5, below). '
            'This triage is not an independent human screen and changed no decision itself; SKP checked it (reported 3 Nov 2026). On 2 November 2026, after '
            'reading the report, the review owner judged that the stimulation in Wang 1997 (surface electrodes at LI4 and '
            'beside the incision; the sites are not identical to Szmit 2021, which used bilateral LI4) is TEAS, and the '
            'trial was included, with its results known. Complete capture of systemic opioid is not established: '
            'the report does not establish whether its 24-hour hydromorphone quantities include the intramuscular supplemental opioid given to 19 of its 101 participants (it converted supplemental meperidine to hydromorphone equivalents for its analysis but does not itemise rescue). Under the rules in Additional file 6, which never assume complete capture, it therefore '
            'enters the broader first-day analysis and not the primary analysis (decision D1b, 2 November 2026). It also '
            'enters rescue receipt, pain without stated rest or movement, nausea and vomiting, and single-trial estimates '
            'of length of stay and 48-hour pain; every other result it reports is listed in Additional file 4 (sheet '
            '"Wang 1997 outcomes") with its disposition. SKP checked the Wang 1997 extraction and confirmed its RoB 2 and '
            'GRADE assessments on 2 November 2026.')
    para(d, '**Decision D3: the other eight candidates (2 November 2026).** After reading each report (evidence in '
            'Additional file 4, sheets "Outcome exclusions recheck" and "D3 decisions"), the review owner decided, with trial '
            'results known: Colak 2010 included (EA versus usual care after coronary artery bypass grafting; randomised by '
            'tables of random numbers although the report calls the design case-control; general anaesthesia implied by '
            'extubation at about 8 hours); Fu 2024 included (TEAS versus sham; the second, pulse-generator stage of deep brain '
            'stimulation was done under general anaesthesia, with stimulation through both stages except during microelectrode '
            'recording); Chen 2016 included and '
            'held from pooled analyses, as Lee 2011 is, because its eligibility criteria admitted patients aged 16–80 years; Tu 2018 excluded as '
            'wrong comparator (only the control arm received scheduled oral tramadol); Zhou 2025 (Covidence 1879896127, not '
            'the included Zhou 2025) and Li 2017 excluded under the 9 October criterion (no confirmed postoperative opioid '
            'result); and Zhang 2022 and Poulain 1997 excluded for the recorded reason. Colak 2010 adds the only EA rest-pain '
            'result (day 1, with single-trial estimates for days 2 to 7) and 7-day pethidine and metamizole totals (single-trial '
            'estimates in native units); Fu 2024 enters rescue receipt (follow-up not stated, as in Yu 2020), QoR-15 (days 1, '
            '3 and 7) and intraoperative remifentanil. Every result the three reports give is listed with its disposition in '
            'Additional file 4 (sheet "D3 outcomes"), added on 3 November 2026 after an independent AI audit of the D3 work. '
            'SKP checked the extraction for the three reports and confirmed the 14 RoB 2 and seven GRADE assessments for '
            'Colak 2010 and Fu 2024 on 3 November 2026 (section 12). [PROVISIONAL: '
            'six outcome exclusions published in English could not be retrieved (Huang 2019, Li 2020, Li 2025, Wang 2010, Xu 2012 and Zárate 2001; decision D5, below); see '
            'AUTHOR_ACTIONS.md and Additional file 4.]')

    para(d, '**Decision D4: corrected reasons for nine outcome exclusions (3 November 2026).** JRNM and SKP decided, with '
            'trial results known, to count nine reports from the recheck under a corrected reason (evidence in Additional '
            'file 4, sheets "Outcome exclusions recheck" and "D4 decisions"). All remain excluded and no estimate changed. '
            'Eight give no postoperative opioid result and are now counted under the 9 October criterion: five report pain '
            'at or near 24 hours (Hou 2023, Li 2025, Liu 2024, Tong 2022 and Yue 2023), so their recorded reason was not '
            'supported, and for three it is unclear whether their pain result meets the 14 August rule (Liu 2008, the '
            'number of patients with severe pain only; Qin 2023, pain over 6–24 hours; Zheng 2008, pain over 12–24 hours), '
            'as for Li 2017 under decision D3. Tzeng 2015, done under spinal anaesthesia without general anaesthesia, is now '
            'counted as wrong setting. In Fig. 1, no eligible analgesic outcome went from 106 to 97, no confirmed '
            'postoperative opioid result from 32 to 40 and wrong setting from 8 to 9.')
    para(d, '**Decision D5: the 53 outcome exclusions the triage could not assess (3 November 2026).** The 45 without a local '
            'full text and the 8 keyword signals never read in full were sought and read with AI assistance (Additional file 4, '
            'sheet "D5 re-check"): the 8 from local full texts; the 16 published in English from PubMed Central, publisher pages '
            'and the Lund University library; and the 29 published in Chinese from their English abstracts, since the English '
            'full-text criterion excludes them in any case. Six in English could not be retrieved (Huang 2019, Li 2020, Li 2025, Wang 2010, Xu 2012 and Zárate 2001); of these, only '
            'Huang 2019\'s abstract reports pain at about 24 hours. JRNM and SKP decided, with trial results known, to count nine '
            'under a corrected reason, all still excluded: Chen 2018 (pain on day 1, no postoperative opioid result) and Luo 2024 '
            '(pain over 6–24 hours only; its "postoperative opioid use" row is a baseline risk-score item) under the 9 October '
            'criterion, and seven reports in Chinese whose English abstracts report pain at about 24 hours or an opioid result '
            'under publication language (Ding 2013, Ge 2021, He 2024, Lu 2005, Tian 2026, Yin 2013 and Zhang 2023). Every other '
            'recorded reason was kept; Hou 2024 scores headache, which is not the registered pain outcome, and reports no '
            'postoperative opioid result. In Fig. 1, no eligible analgesic outcome went from 97 to 88, no confirmed postoperative '
            'opioid result from 40 to 42 and publication language from 12 to 19. No estimate changed. [PROVISIONAL: the six '
            'reports not retrieved have not been re-checked.]')

    head(d, '7. Outcomes')
    para(d, '**Registered main outcomes.** (1) Cumulative systemic postoperative opioid consumption from the end of '
            'surgery to 24 hours, converted to IV MME using prespecified conversion rules. Programmed but undelivered '
            'patient-controlled analgesia doses will not be counted as consumed opioid. The principal effect measure '
            'will be mean difference in IV MME. (2) Postoperative pain at approximately 24 hours, assessed separately at '
            'rest and during movement where reported. Pain scores will be converted to a 0-10 scale when valid; '
            'otherwise standardised mean differences will be used in supportive analyses.')
    para(d, '**Registered clinical interpretation.** A pooled opioid-sparing effect will be considered clinically '
            'meaningful when the point estimate indicates a reduction of at least 10 mg IV MME during 0-24 hours and '
            'the corresponding pain evidence does not permit clinically important worsening. Clinically important pain '
            'worsening is prespecified as an increase of 1.0 point or more on a 0-10 scale; the upper 95% confidence '
            'limit will be examined against this margin. Sensitivity interpretations will use an 8 mg IV MME threshold '
            'and, when calculable, a 30% relative opioid reduction.')
    para(d, '**Registered additional outcomes:**')
    for t in ['Cumulative postoperative opioid consumption during 0-48 hours, 0-72 hours, and the longest reported acute postoperative interval.',
              'Intraoperative opioid consumption, converted to an appropriate common opioid-equivalent metric when valid.',
              'Pain at rest and during movement at approximately 6, 24, 48, and 72 hours and at the longest reported acute time point.',
              'Postoperative nausea, vomiting, or composite PONV during 0-24 hours, 0-48 hours, and the longest reported interval.',
              'Need for rescue analgesia and time to first rescue analgesia.',
              'Quality of recovery measured using validated instruments such as QoR-15, QoR-40, or QoR-9.',
              'Patient satisfaction, gastrointestinal recovery, functional recovery, time to mobilisation, and length of hospital stay.',
              'Persistent postoperative opioid use beyond 30 days, when reported.',
              'Serious and non-serious adverse events plausibly related to TEAS or EA, including skin reactions, bleeding, infection, electrical discomfort, needle-related adverse effects, and device-related events.']:
        bullet(d, t)
    para(d, '**Applied.** The clinical-importance criterion was evaluated only where the trial supplying the opioid '
            'estimate also supplied eligible pain evidence at about 24 hours; pain from other trials could not supply '
            'the pairing. Candidate opioid results were classified against the registered construct before synthesis '
            '(Additional file 6), and conversion factors are in Additional file 7. Rescue opioid receipt was analysed '
            'separately from rescue amount, time to first rescue and routine receipt of an opioid pump.')

    head(d, '8. Protocol characteristics and the registered meta-regression')
    para(d, '**Registered.** Protocol characteristics will be extracted according to STRICTA-compatible domains, '
            'including modality, timing, number of sessions, session duration, cumulative stimulation duration before 24 '
            'hours, acupoints, frequency, waveform, pulse width, intensity strategy, current amplitude, laterality, '
            'device, practitioner, and treatment fidelity. Prespecified protocol moderators are intervention timing; '
            'single versus repeated treatment before the 24-hour outcome; cumulative active stimulation duration before '
            '24 hours, analysed per 30-minute increment; electrical frequency; and stimulation intensity. Timing will be '
            'classified as preoperative only, intraoperative-inclusive, postoperative only, or spanning multiple '
            'perioperative phases. Frequency will be grouped as low, intermediate, high, or alternating/mixed. Intensity '
            'will be classified as sub-sensory or fixed low current, sensory-level, motor-twitch threshold, maximum '
            'tolerated, or insufficiently reported. [...] Meta-regression will be conducted separately for TEAS and EA, '
            'without causal claims of superiority. [...] Normally, at least 10 independent estimates per predictor and '
            'four studies per categorical level will be required. Univariable models will be prioritised. Multivariable '
            'models will be considered only with at least 20 studies and 10 studies per predictor. [...] If '
            'meta-regression is unjustified, protocol characteristics will be synthesised descriptively using '
            'structured tables and effect-direction plots.')
    para(d, '**Applied.** No modality–comparator stratum met the minimum requirements, which were not relaxed, and TEAS '
            'and EA were not pooled to reach them. An earlier regression that pooled the two modalities was not carried '
            'forward. The registered fallback was used: protocol characteristics are tabulated, with effect directions, '
            'in Additional file 8. Stimulation after 24 hours was not counted towards the before-24-hour total.')

    head(d, '9. Deviations from the registered protocol')
    para(d, 'Each deviation is listed with the registered wording, what was done instead, and its consequence.')
    rows = [['Item', 'Registered plan', 'What was done', 'Consequence']]
    rows += [
        ['Full-text outcome rule (14 Aug 2026; before registration, not in the registered record)',
         'Any report with postoperative opioid consumption or another eligible outcome', 'Eligibility required a 24-hour opioid or about 24-hour pain outcome (section 6)',
         f'{pc["exclusion_reasons"]["no perioperative analgesia outcome found"]} reports excluded; not re-screened in duplicate'],
        ['Confirmed postoperative opioid result (9 Oct 2026; after registration, results known)', 'Not in the registered record',
         'Reports required a named postoperative opioid or author-defined morphine-equivalent quantity confirmed in the source (section 6)',
         f'{pc["additional_focused_exclusions"]} reports excluded'],
        ['Other methods of identifying studies', '"contacting authors or experts, [...] forward citation searching, reference list checking [...] and searching trial or study registers"',
         'Trial registers were not searched within the review. One report was identified by citation searching; the citing source was not recorded. Authors were contacted with data queries (section 11). Reference lists of the included reports were not systematically checked, and experts were not contacted.',
         'Unpublished and register-only trials may be missing'],
        ['Search update', '"Searches will be updated before manuscript submission when required."', 'The four review databases were not re-searched.',
         'Trials published after July 2026 are not included'],
        ['Selection process', '"Studies will be screened independently by at least two people (or person/machine combination) with a process to resolve differences."',
         'Titles and abstracts (23–28 July 2026) and full texts (9–20 August 2026) were screened independently in Covidence by JRNM (reviewer account shown as "JR Mendoza") and SKP (account shown as "JM"). Disagreements were resolved by consensus between JRNM and SKP, with an AI agent (Codex) supporting the resolution of some conflicts (reported by the review owner, 2 Nov 2026).',
         'Consistent with the registered process: two people at both stages'],
        ['Data extraction', '"Data will be extracted independently by at least two people (or person/machine combination) with a process to resolve differences."',
         'An AI assistant extracted all data with a recorded source location for each value; verbatim quotations were recorded for characteristics, setting and regimens and for 74 of 264 outcome results. Study characteristics, stimulation protocols, setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP) for every report (Colak 2010, Fu 2024 and Chen 2016, decision D3, and the corrections of 2 Nov 2026: 3 Nov 2026). The arm-level opioid inputs were re-checked by the AI assistant against the source reports; they were not double-extracted.',
         'Errors in arm-level outcome data would not be caught by a second extractor.'],
        ['Risk of bias and certainty', '"Data will be assessed independently by at least two people (or person/machine combination) with a process to resolve differences."',
         'Each RoB 2 and GRADE assessment was made by an AI assistant. SKP checked and confirmed them (section 12), including the 12 RoB 2 and 11 GRADE assessments for Wang 1997 (2 Nov 2026), and the 14 RoB 2 and 7 GRADE assessments for Colak 2010 and Fu 2024 and the 2 RoB 2 assessments for Wang 1997\'s pain at 48 h (3 Nov 2026)', 'A check of a first assessment is not an independent duplicate assessment'],
        ['Meta-regression (primary objective)', 'Separate TEAS and EA meta-regressions of five protocol moderators', 'Not performed: no stratum met 10 estimates per predictor',
         'Protocol characteristics described (Additional file 8). The title no longer describes the review as a meta-regression.'],
        ['Subgroup analyses', 'Sham design, surgical category, regional or neuraxial analgesia, background analgesia balance, and risk of bias', 'Not performed',
         'Too few trials in any comparison'],
        ['Sensitivity analyses', 'Sham credibility, high risk of bias, imputed or converted data, opioid-conversion uncertainty, unbalanced co-interventions, non-peer-reviewed reports, influential studies, unresolved cohort overlap; alternative variance estimators and interval methods; 8 mg and 30% thresholds',
         'Performed: exclusion of high risk of bias, sufentanil conversion bounds, leave-one-out, holding the overlapping Yeh reports, the 8 mg threshold. Not performed: sham credibility, imputed data, co-intervention balance, peer-review status, alternative estimators or interval methods. The 30% relative threshold was examined descriptively for the primary trial only (Szmit 2021: 50.7% below the control mean; not a pooled ratio of means).',
         'Robustness to these choices is untested'],
        ['Medians and quantiles', '"converted only when assumptions are reasonable and examined in sensitivity analyses"', 'Not converted; reported descriptively', 'Some trials contribute no pooled estimate'],
    ]
    table(d, rows, [3.4, 4.2, 5.6, 3.8], size=8.5)

    head(d, '10. Decision log')
    para(d, 'Dated decisions that shaped the evidence base and the analyses. "Post hoc" means the decision was made with '
            'the results of the contributing trials known.')
    rows = [['Date (2026)', 'Decision', 'Post hoc']]
    rows += [
        ['21–23 Jul', 'Searches of PubMed and CENTRAL (21 July), Embase (22 July) and CINAHL Ultimate (23 July), with no date, language or outcome limits (Additional file 3).', 'No'],
        ['14 Aug', 'Outcome-focused full-text rule adopted (section 6).', 'No'],
        ['20 Aug', 'English full-text restriction adopted; PROSPERO record published (version 1.0).', 'No'],
        ['20 Aug and 1 Sep', 'Full-text exclusions recorded in Covidence.', 'No'],
        ['11 Sep', 'Reports and studies counted separately: Yeh 2010 and Yeh 2011 judged to be probable reports of one trial, counted once and held from pooling.', 'Yes'],
        ['12 Sep', 'Standardised mean difference adopted as the headline measure for time to first flatus (reversed on 20 September).', 'Yes'],
        ['20 Sep', 'Risk of bias assessed per result (outcome, window, comparison and population). Participant awareness alone does not make the deviations domain high risk; the mode of ascertainment governs the measurement domain.', 'Yes'],
        ['20 Sep', 'GRADE rules: downgrades by explicit domain reasoning, not by I² or P-value thresholds; no automatic downgrade of a single-trial body for inconsistency; pain imprecision judged against the registered 1-point margin.', 'Yes'],
        ['20 Sep', 'Sufentanil converted at 0.5 mg IV morphine per µg, with 0.25 and 1.0 as sensitivity bounds; author-reported morphine equivalents of unknown route used only in sensitivity analyses.', 'Yes'],
        ['20 Sep', 'Only delivered systemic opioid from the end of surgery to 24 hours, including quantified rescue, meets the primary construct; permitted rescue is never assumed to be zero (Additional file 6).', 'Yes'],
        ['20 Sep', 'Comparator class assigned per result from source text (section 3); a matched active non-acupoint electrical control is kept separate from inert sham.', 'Yes'],
        ['20 Sep', 'Gastrointestinal recovery reported as mean difference in hours, as registered; the standardised mean difference is a sensitivity analysis (reverses 12 September).', 'Yes'],
        ['20 Sep', 'Statistical rules: REML with Hartung–Knapp intervals truncated at 1 for two or more trials; single trials not pooled; prediction intervals for five or more trials; compatible active arms combined with a shared control counted once.', 'Yes'],
        ['20 Sep', 'Wu 2025 intraoperative opioid excluded from efficacy analyses: randomisation and treatment began in the recovery unit, after the intraoperative dose.', 'Yes'],
        ['20 Sep', 'Holds: Yeh 2010/2011 (overlap; route conflict), Jin 2023 (general anaesthesia not established), Long 2025 (modality unclear) (Additional file 5).', 'Yes'],
        ['20 Sep', 'One report (Wu 2016) confirmed as identified by citation searching. Covidence dispositions reconciled against the exported records; 12 references merged by Covidence at import counted with the duplicates.', 'No'],
        ['22 Sep', 'Author queries sent (section 11).', 'No'],
        ['23 Sep', 'Broader first-day opioid analysis defined in writing before being applied: totals that capture PCA only, or with unquantified rescue, are admitted; units, conversions and holds unchanged (Additional file 6). A later amendment (E2.1), made knowing it admitted exactly two reports, took postoperative-day-1 totals as the first 24 hours and allowed arm-level values printed only in a figure to be digitised. The broader analysis was briefly adopted as primary and run; the registered outcome was then kept as primary, with these results known, and the broader analysis is reported as a sensitivity analysis.', 'Yes'],
        ['8 Oct', 'Audit of postoperative opioid reporting in the 70 then-included reports. Rescue receipt pooled across TEAS-versus-sham trials over each trial\'s own follow-up (exploratory).', 'Yes'],
        ['9 Oct', 'Confirmed postoperative opioid result required (section 6): 40 reports retained. Registered outcomes completed for the 40 reports.', 'Yes'],
        ['20–23 Oct', 'Second reviews of the risk-of-bias and GRADE assessments (section 12). 62 further RoB 2 assessments added for sensitivity results and 3 for broader-dose results; restriction analyses refitted.', 'Yes'],
        ['23 Oct', 'Lee 2011 held from all pooled analyses (age criterion; section 1); broader-dose analyses refitted without it.', 'Yes'],
        ['24 Oct', 'Hospital setting and multimodal analgesia extracted for all 40 reports. Multimodal analgesia defined as a non-opioid analgesic or regional or local technique given routinely to all groups; rescue-only drugs not counted.', 'Yes'],
        ['24 Oct', 'Zhou 2021 analgesic regimen corrected (epidural-assisted general anaesthesia for all patients; incision infiltration was an exclusion criterion).', 'Yes'],
        ['24 Oct', 'External check of three trials: Chen 2020 randomised 86, not 80 (Fig. 1 of the report); Chen 2020 schedule corrected; RoB 2 missing-data domain for two Chen 2020 results changed from Low to Some concerns (overall unchanged). El-Rakshy 2009 sex-by-arm contradiction recorded. No effect estimate changed.', 'Yes'],
        ['24 Oct', 'Broader first-day GRADE profile updated for the Lee 2011 hold (6 trials, 547 participants; certainty unchanged). English abstracts of the 12 language exclusions checked (second review by SKP, 3 Nov).', 'Yes'],
        ['2 Nov', 'Pre-submission audit (Codex Astra) and revision: AI-assisted triage of the 113 outcome exclusions (nine membership candidates; awaiting adjudication); Table 1 corrections (An 2014 female 53%, Coura 2011 3/15 Hz, Oztas 2019 2–100 Hz, comparator labels for Wu 2016, Grech 2016, Xie 2014, Lee 2011 and Yeh 2011); Szmit 2021 reclassified as routine multimodal analgesia (intraoperative metamizole to all) under the stated definition. Triage and corrections checked by SKP on 3 Nov.', 'Yes'],
    ]
    def after(prefix, row):
        i = max(j for j, r in enumerate(rows) if r[0].startswith(prefix))
        rows.insert(i + 1, row)
    after('21–23 Jul', ['23–28 Jul', 'Title and abstract screening in Covidence by JRNM and SKP, independently; disagreements resolved by consensus, with AI support for some conflicts (section 9).', 'No'])
    after('14 Aug', ['9–20 Aug', 'Full-text screening in Covidence by JRNM and SKP, independently; disagreements resolved by consensus, with AI support for some conflicts (section 9).', 'No'])
    rows.append(['2 Nov', 'Wang 1997 included as TEAS by the review owner after reading the report, with its results known '
                 '(decision D1). It enters the broader first-day analysis (capture of supplemental doses not established; '
                 'kept out of the primary analysis by decision D1b), rescue receipt, pain without stated rest or '
                 'movement, and nausea and vomiting. Every affected analysis was refitted in R; the three pooled models shown '
                 'in Figs. 4 and 5 were also reproduced in Stata. RoB 2 and GRADE assessed by the AI assistant and confirmed by '
                 'SKP on 2 Nov.', 'Yes'])
    rows.append(['2 Nov', 'Decision D1b: Wang 1997 kept in the broader first-day analysis only, because its report does not '
                 'establish that its 24-hour opioid total includes every supplemental dose (the basis on which Chen 1998 is in '
                 'that analysis).', 'Yes'])
    rows.append(['2 Nov', 'Independent AI re-check (Codex Astra) of the revision. Corrected: Wang 1997 dose-capture wording; '
                 'the statement that Wang 1997 was the only broader-dose trial with paired pain (Chen 2020 and Gu 2019 also '
                 'report unclassified 24-hour pain). Completed: six legacy expanded-dose sensitivity models refitted with '
                 'Wang 1997; nausea and vomiting diagnostics; inventory of every Wang 1997 result (length of stay and 48-hour '
                 'pain added as single-trial estimates). RoB 2 and GRADE assessments revised, then confirmed by SKP on 2 Nov.', 'Yes'])
    rows.append(['2 Nov', 'Decision D3 (review owner, results known): Colak 2010 and Fu 2024 included; Chen 2016 included and '
                 'held from pooled analyses (eligible ages 16–80 years); Tu 2018 relabelled wrong comparator; Zhou 2025 (1879896127) and '
                 'Li 2017 relabelled to the 9 October criterion; Zhang 2022 and Poulain 1997 excluded for the recorded reason '
                 '(section 6). Rescue receipt, QoR-15 at about 24 hours, EA-versus-usual-care rest pain and intraoperative '
                 'remifentanil refitted in R; the rescue model (Fig. 5) reproduced in Stata. RoB 2 and GRADE drafted by the AI '
                 'assistant; confirmed by SKP on 3 Nov.', 'Yes'])
    rows.append(['3 Nov', 'Independent AI audit (Codex Astra) of the D3 work and a re-audit of its repairs. Added: results at the other '
                 'reported time points (Colak 2010 rest pain on days 2 to 7 and 7-day metamizole; Fu 2024 QoR-15 on day 7), an inventory '
                 'of every result the three reports give, and RoB 2 drafts for Wang 1997\'s pain at 48 hours (earlier listed as not '
                 'assessed on a mistaken precedent). Revised: Fu 2024 randomisation and QoR-15 measurement drafts (Low to Some concerns, '
                 'as for confirmed assessments of similar reports); stimulation-timing, eligibility-age and pain wording. Fu 2024\'s '
                 'source problems recorded (Additional file 5). Every refit affected by D3 recomputed independently. All confirmed by SKP '
                 'on 3 Nov (section 12).', 'Yes'])
    rows.append(['3 Nov', 'Decision D4 (JRNM and SKP, results known): nine outcome exclusions counted under a corrected reason '
                 '(section 6). Eight with no postoperative opioid result moved to the 9 October criterion; Tzeng 2015 (spinal '
                 'anaesthesia without general anaesthesia) moved to wrong setting. All remain excluded; no estimate changed.', 'Yes'])
    rows.append(['3 Nov', 'Decision D5 (JRNM and SKP, results known): the 53 outcome exclusions the triage could not assess were '
                 'sought and read with AI assistance (section 6). Chen 2018 and Luo 2024 moved to the 9 October criterion; seven '
                 'reports in Chinese moved to publication language; six in English could not be retrieved. All remain excluded; no '
                 'estimate changed.', 'Yes'])
    rows.append(['3 Nov', 'Decision D6 (JRNM and SKP, all authors agreeing; results known): certainty that rest pain is not '
                 'worse (Yu 2020) lowered from moderate to low for imprecision; no downgrade for selection. Post-hoc what-ifs '
                 'refitted rest pain and PONV with the trials removed by the opioid-result requirement (Additional file 11).', 'Yes'])
    rows.append(['3 Nov', 'Decision D7 (JRNM; split checked by SKP): multimodal analgesia keeps the definition "a routine non-opioid '
                 'at any perioperative time" (14 reports); the Results and Additional file 8 now show that it continued after '
                 'surgery in 6 and was given only before or at the end of surgery in 8, including Szmit 2021.', 'Yes'])
    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions: four reports flagged as having a postoperative opioid result (Colak 2010, Tzeng 2015, Wang 1997, Zhang 2025 spinal fixation); no decision changed.', 'Yes'])
    table(d, rows, [2.4, 13.0, 1.6], size=8.5)

    head(d, '11. Author queries')
    para(d, 'All drafted queries were sent. They asked for aggregate arm-level data or clarification only. No reply had '
            'been received by 25 October 2026, and no analysis depends on a reply. Queries about reports outside this '
            'review are not listed.')
    rows = [['Report', 'Question', 'Status']]
    rows += [
        ['Jin 2023', 'Anaesthetic technique; drug concentration of the PCA solution', 'Sent 22 Sep 2026'],
        ['Xie 2014', 'Outcome window, inclusion of basal infusion, nature of the third arm', 'Sent 22 Sep 2026'],
        ['Yeh 2010 / Yeh 2011', 'Whether the two reports describe one cohort; opioid route', 'Sent 22 Sep 2026'],
        ['Ntritsou 2014', 'Separation of postoperative from perioperative tramadol', 'Sent 22 Sep 2026'],
        ['Chen 1998', 'Supplemental analgesics recorded as a count, not a dose', 'Sent 22 Sep 2026'],
        ['Lee 2011', 'Whether the 24-hour total includes recovery-room doses', 'Sent 22 Sep 2026'],
        ['Lin 2002', 'Pethidine given outside PCA, not quantified', 'Sent 22 Sep 2026'],
        ['Sim 2002', 'Morphine reported per kilogram', 'Sent 22 Sep 2026'],
        ['Coura 2011', 'Fentanyl reported per kilogram', 'Sent 22 Sep 2026; did not reach the recipient'],
        ['Chen 2020', 'Printed 48-hour sufentanil totals below the stated basal infusion', 'Sent; date not recorded'],
        ['He 2026 (hepatectomy)', 'Route basis of the author-reported morphine equivalents', 'Sent; date not recorded'],
        ['El-Rakshy 2009', 'Arm labels and denominators', 'Sent; date not recorded'],
        ['Long 2025', 'Needle or surface electrodes', 'Sent; date not recorded'],
    ]
    table(d, rows, [3.6, 9.4, 4.0], size=8.5)
    para(d, 'Delivery: the Coura 2011 message did not reach its recipient. A project record also notes that three of the '
            'messages sent on 22 September 2026 bounced, without naming the other two.', size=10)

    head(d, '12. Record of second review')
    para(d, 'Assessments and extractions made by the AI assistant were checked by a second reviewer (SKP), including '
            'those for Wang 1997 (2 November 2026) and those added under decision D3 (3 November 2026); every item is listed '
            'below. Each check '
            'is recorded on the date the review owner reported it. No judgement was changed at review unless stated.')
    rows = [['Date (2026)', 'Items checked', 'Outcome']]
    rows += [
        ['28 and 30 Sep', 'Result-specific RoB 2 assessments, GRADE profiles and study and regimen characteristics of the main review record', 'Confirmed'],
        ['20 Oct', '32 RoB 2 assessments and 63 GRADE profiles added for the 40-report analyses', 'Confirmed'],
        ['23 Oct', '7 RoB 2 assessments for rescue receipt (154 signalling responses); 6 rescue GRADE profiles; 4 broader-dose GRADE profiles; 6 earlier assessments used in the 40-report models; 62 RoB 2 assessments for sensitivity results; 3 for broader-dose results', 'Confirmed'],
        ['24 Oct', 'Hospital setting and multimodal analgesia for 40 reports', 'Confirmed'],
        ['24 Oct', 'Chen 2020 missing-data domain (2 results); broader-dose TEAS-versus-sham GRADE profile after the Lee 2011 hold', 'Revisions confirmed'],
        ['25 Oct', 'Five earlier RoB 2 assessments used in the broader first-day dose analysis: Chen 1998, Chen 2020, He 2026 (hepatectomy), Lin 2002 (versus sham) and Yang 2024', 'Confirmed'],
        ['2 Nov', 'Wang 1997 extraction (characteristics, Table 1 row and outcome values); 12 RoB 2 assessments and 11 GRADE profiles for Wang 1997, as revised after the independent re-check', 'Confirmed'],
        ['3 Nov', 'Decision D3 extraction (Colak 2010, Fu 2024, Chen 2016: characteristics, Table 1 rows and outcome values); 14 RoB 2 assessments and 7 GRADE profiles for Colak 2010 and Fu 2024 (9 and 2 of them added on 3 Nov after an independent AI audit; the Fu 2024 randomisation and QoR-15 measurement drafts revised the same day after an AI re-audit). Points put to the reviewer: Fu 2024 rescue measurement (kept Low); one imprecision level for the small single-trial bodies (kept); Fu 2024 source problems (arm summaries kept as printed, ratings unchanged; Additional file 5); Chen 2016 pethidine (text values kept)', 'Confirmed'],
        ['3 Nov', '2 RoB 2 assessments for Wang 1997 (pain at 48 h against sham and usual care; added 3 Nov after the AI re-audit found them unassessed; missing outcome data kept Low)', 'Confirmed'],
        ['3 Nov', 'Rule for which results are assessed: every result used in an analysis, including sensitivity results; transcription variants of one result share one assessment; results held from synthesis or reported only descriptively are not assessed (JRNM and SKP)', 'Confirmed'],
        ['3 Nov', 'Corrections of 2 November 2026: Table 1 values (An 2014, Coura 2011, Oztas 2019, Chen 1998 ages) and comparator labels (Wu 2016, Grech 2016, Xie 2014, Lee 2011, Yeh 2011); Szmit 2021 multimodal analgesia (No to Yes)', 'Confirmed'],
        ['3 Nov', 'The 2 November 2026 AI-assisted triage of the 113 outcome exclusions (Additional file 4) and the English-abstract check of the 12 language exclusions (24 October 2026)', 'Checked; no change reported'],
        ['3 Nov', 'Timing of the routine non-opioid in the 14 multimodal reports (decision D7; Additional file 8)', 'Confirmed'],
    ]
    table(d, rows, [2.6, 11.0, 3.4], size=8.5)

    head(d, '13. Chronology')
    para(d, 'Searches 21–23 July 2026; title and abstract screening 23–28 July; review start date entered in PROSPERO 14 August; '
            'outcome-focused full-text rule 14 August; full-text screening votes 9–20 August; PROSPERO submitted 19 August '
            'and published 20 August; full-text exclusions recorded 20 August and 1 September; adjudication record 20 '
            'September; confirmed-opioid criterion 9 October. The PROSPERO record (version 1.0) marks pilot work as completed '
            'and formal searching as started but leaves screening unmarked, although title and abstract screening had been '
            'completed and full-text screening had begun; this was an error in completing the form (decision D10, JRNM, '
            '3 November 2026). The earlier, broader review by the same team (CRD420251090635) was used only for search '
            'terminology, to identify known reports for testing the search and for reproducibility comparisons (search '
            'decision log, 21 July 2026); its search exports, screening decisions and extracted data were not reused. The full '
            'protocol of this review was not made publicly available; the PROSPERO record describes it as a team draft not '
            'yet released.')
    return save(d, 2, '.docx')


# ================================================================ Additional file 3: search strategies
def af3():
    d = new_doc(3)
    db = pc['databases']
    para(d, 'Four databases were searched without date, language, outcome, age or anaesthesia limits. General '
            'anaesthesia and outcomes were assessed at screening, because a general-anaesthesia search block failed to '
            'retrieve known eligible reports in exploratory testing. All searches used Lund University institutional '
            'access; strategies, line counts, exports and screenshots are kept with SHA-256 hashes.')
    rows = [['Database', 'Platform', 'Date searched', 'Records exported']]
    rows += [['PubMed', 'NCBI E-utilities (ESearch/EFetch)', '21 July 2026', str(db['PubMed'])],
             ['CENTRAL', 'Cochrane Library, Search Manager', '21 July 2026', str(db['CENTRAL'])],
             ['Embase', 'Embase.com (Elsevier)', '22 July 2026', str(db['Embase'])],
             ['CINAHL Ultimate', 'EBSCOhost', '23 July 2026', str(db['CINAHL'])],
             ['Total', '', '', str(pc['references'])]]
    table(d, rows, [3.5, 6.5, 3.5, 3.5])
    para(d, f'Covidence imported the {pc["references"]:,} references as {pc["reported_import_records"]:,} records, merging '
            f'{pc["unmapped_import_difference"]} into existing records; they are counted with the duplicates (Fig. 1). One further report '
            '(Wu 2016) was identified by citation searching; the citing source was not recorded. Trial registers were not '
            'searched within the review, and the four databases were not re-searched before submission.')

    head(d, 'PubMed (21 July 2026; 1009 records)')
    para(d, 'Strategy version 0.2, run through the NCBI E-utilities on 21 July 2026 at 21:08 CEST. The randomised-trial '
            'component is the Cochrane sensitivity-maximising filter. Of 25 known eligible reports indexed in PubMed, '
            '24 were retrieved. The one missed report (PMID 29391879) has no electrical, needle, device or stimulation '
            'term in its PubMed record, and adding generic acupuncture terms to retrieve it would have brought in the '
            'excluded manual, auricular and other acupuncture types; the strategy was therefore not changed to retrieve '
            'it. Version 0.2 differs from version 0.1 only by removing operation*[tiab], which added 161 records '
            'without retrieving any further known report.')
    code_block(d, (SRCH / 'pubmed/pubmed_v0_2_multiline.txt').read_text().rstrip('\n').split('\n'))

    head(d, f'CENTRAL (21 July 2026; {db["CENTRAL"]} records)')
    para(d, 'Cochrane Library Search Manager. Counts are for all Cochrane Library content; line 16 returned 1706 records, '
            f'of which {db["CENTRAL"]} were CENTRAL trials (exported) and 8 were Cochrane Reviews (not exported). MeSH '
            'descriptors were added with the MeSH composer after the interface rejected typed descriptor syntax; the '
            'displayed syntax was unchanged. All five prespecified known reports were retrieved.')
    rows = [['#', 'Search', 'Records']]
    for r in recs(SRCH / 'cochrane/2026-07-21/CENTRAL_line_counts_2026-07-21.csv'):
        rows.append([r['line'], r['search'], r['count_all_cochrane_content']])
    table(d, rows, [1.0, 14.0, 2.0], size=8, mono_cols=(1,))

    head(d, f'Embase (22 July 2026; {db["Embase"]} records)')
    para(d, 'Embase.com Advanced Search with broad mapping off; Emtree headings were checked before use. Line 9 was '
            'rejected by the interface ("Missing bracket") and was entered as two equivalent proximity chains, with the '
            'same fields and distances. The export (line 55) was made in four batches of up to 500 records and merged '
            'after checking record counts; MEDLINE records were not removed.')
    rows = [['#', 'Search', 'Records']]
    for r in recs(SRCH / 'embase/2026-07-22/EMBASE_line_counts_2026-07-22.csv'):
        rows.append([r['line'], r['displayed_query'], r['count']])
    table(d, rows, [1.0, 14.0, 2.0], size=7.5, mono_cols=(1,))

    head(d, f'CINAHL Ultimate (23 July 2026; {db["CINAHL"]} records)')
    para(d, 'EBSCOhost, proximity search mode, no limits. CINAHL Complete was not available through the library, so '
            'CINAHL Ultimate was searched alone. Headings were checked in CINAHL Headings; where a heading could not be '
            'exploded the unexploded form was used, and the randomised-trial filter (Cochrane, May 2023) was run as '
            'published. A first run was discarded because set references resolved against temporary lines in the '
            'search history; the full strategy was rerun in a clean history (S1–S50) and reproduced every concept count.')
    rows = [['#', 'Search', 'Records']]
    for r in recs(SRCH / 'cinahl/2026-07-23/CINAHL_line_counts_2026-07-23.csv'):
        rows.append([r['ebsco_id'], r['exact_query'], r['count']])
    table(d, rows, [1.2, 13.8, 2.0], size=7.5, mono_cols=(1,))
    return save(d, 3, '.docx')


# ================================================================ Additional file 4: report ledger
FIG1 = {'no perioperative analgesia outcome found': 'No eligible analgesic outcome',
        'Publication language': 'Publication language', 'Wrong setting': 'Wrong setting',
        'Wrong intervention': 'Wrong intervention', 'Wrong comparator': 'Wrong comparator',
        'Wrong patient population': 'Wrong population', 'Wrong study design': 'Wrong study design',
        'Abstract only': 'Abstract only'}


def af4():
    led = rd(PR / 'prisma_record_ledger.csv')
    rows = []
    for r in led.to_dict('records'):
        fd, fr = r['focused_disposition'], r['focused_reason']
        note = ''
        b = r['decision_basis']
        if b.startswith('v38 delegated adjudication'):
            note = 'Recorded as excluded in Covidence; reinstated after source-verified adjudication (20 Sep 2026)'
        elif b.startswith('Same DOI'):
            note = f'Same DOI and normalised title as record {r["duplicate_of"].split(".")[0]}'
        elif b.startswith('Related Zhang2018'):
            note = 'Conference abstract related to Zhang 2018 (distinct DOI); not a duplicate publication'
        elif b.startswith('Citation-search'):
            note = 'Identified by citation searching'
        if r['covidence_id'] == '1879897512':   # D1, 2 Nov 2026
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found'
            fd, r = 'INCLUDED', dict(r, registry_report='Wang 1997')
            note = ('Excluded at full-text screening (no eligible analgesic outcome); included on 2 Nov 2026 after the '
                    'outcome-exclusion recheck, when the review owner judged its stimulation to be TEAS (results known)')
        if r['covidence_id'] in D3_DEC:   # D3, 2 Nov 2026 (d3/d3_decisions.csv)
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']
            dec = D3_DEC[r['covidence_id']]
            note = ('Excluded at full-text screening (no eligible analgesic outcome); reread after the outcome-exclusion recheck. '
                    f'Decision D3 (review owner, 2 Nov 2026, results known): {dec["decision"]}. {dec["basis"]}')
            if dec['decision'].startswith('Include'):
                fd, r = 'INCLUDED', dict(r, registry_report=dec['report'])
            elif dec['decision'] == 'Exclude: wrong comparator':
                fr = 'Wrong comparator'
            elif dec['decision'] == 'Exclude: no confirmed postoperative opioid result':
                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', 'Opioid outcome identity, timing or treatment comparison unresolved'
                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-02')
        if r['covidence_id'] in D4_DEC:   # D4, 3 Nov 2026 (d4/d4_decisions.csv)
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']
            dec = D4_DEC[r['covidence_id']]
            note = ('Excluded at full-text screening (no eligible analgesic outcome); reread after the outcome-exclusion recheck. '
                    f'Decision D4 (JRNM and SKP, 3 Nov 2026, results known): {dec["decision"]}. {dec["basis"]}')
            if dec['counted_as'] == 'Wrong setting':
                fr = 'Wrong setting'
            else:
                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', dec['counted_as']
                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-03')
        if r['covidence_id'] in D5_DEC and D5_DEC[r['covidence_id']]['decision'].startswith('Exclude'):   # D5, 3 Nov 2026
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found', r['covidence_id']
            dec = D5_DEC[r['covidence_id']]
            note = ('Excluded at full-text screening (no eligible analgesic outcome); sought and read after the outcome-exclusion '
                    f'recheck. Decision D5 (JRNM and SKP, 3 Nov 2026, results known): {dec["decision"]}. {dec["basis"]}')
            if dec['counted_as'] == 'Publication language':
                fr = 'Publication language'
            else:
                fd, fr = 'EXCLUDED_FROM_FOCUSED_WORKING_SET', dec['counted_as']
                r = dict(r, outcome_finding=dec['basis'], focused_decision_date='2026-11-03')
        if fd == 'INCLUDED':
            disp, fig = 'Included', ''
        elif fd == 'EXCLUDED_FROM_FOCUSED_WORKING_SET':
            disp, fig = 'Excluded', 'No confirmed postoperative opioid result'
        elif fd == 'EXCLUDED':
            disp, fig = 'Excluded', FIG1[fr]
        elif fd == 'DUPLICATE':
            disp, fig = 'Duplicate report', 'Duplicate reports'
        else:
            disp, fig = 'Not retrieved', 'Reports not retrieved'
        if r['covidence_id'] == 'CITATION-WU2016' and not r['title']:   # M06: identity from PubMed PMID 26893636
            wu = next(x for x in json.load(open(REV / 'references/included_reports_pubmed_2026-11-02.json')) if x['pmid'] == '26893636')
            r = dict(r, title='Effects of transcutaneous acupoint electrical stimulation on the imbalance of Th1, Th2, Th17 and '
                              'Treg cells following thoracotomy of patients with lung cancer (PMID 26893636)', doi=wu['doi'])
        rows.append(dict(cid=r['covidence_id'], label=r['covidence_study_id'], report=r['registry_report'] if fd == 'INCLUDED' else '',
                         title=r['title'], doi=r['doi'], route='Citation searching' if r['route'] == 'CITATION SEARCH' else 'Databases',
                         cov=r['covidence_decision'].title(), covr=r['exclusion_reason'], disp=disp, fig=fig,
                         detail=fr if fd == 'EXCLUDED_FROM_FOCUSED_WORKING_SET' else '',
                         finding=r['outcome_finding'] if fd == 'EXCLUDED_FROM_FOCUSED_WORKING_SET' else '',
                         date=r['focused_decision_date'] if fd == 'EXCLUDED_FROM_FOCUSED_WORKING_SET' else '',
                         note=note))
    order = {'Included': 0, 'Excluded': 1, 'Duplicate report': 2, 'Not retrieved': 3}
    rows.sort(key=lambda x: (order[x['disp']], x['fig'], x['label']))
    # reconcile with Fig. 1
    cnt = collections.Counter(x['fig'] for x in rows if x['disp'] == 'Excluded' and x['route'] != 'Discovery audit')
    exp = collections.Counter()
    for k, v in pc['exclusion_reasons'].items():
        exp[FIG1.get(k, 'No confirmed postoperative opioid result')] += v
    assert cnt == exp, (cnt, exp)
    assert sum(x['disp'] == 'Included' for x in rows) == pc['included_reports'] == 44
    assert sum(x['disp'] == 'Duplicate report' for x in rows) == pc['late_duplicates']
    assert sum(x['disp'] == 'Not retrieved' for x in rows) == pc['database_not_retrieved']
    summ = [dict(reason=k, n=v) for k, v in sorted(cnt.items(), key=lambda kv: -kv[1])]
    summ += [dict(reason='Total excluded, database route', n=sum(cnt.values())), dict(reason='Duplicate reports', n=pc['late_duplicates']),
             dict(reason='Reports not retrieved', n=pc['database_not_retrieved']), dict(reason='Included', n=44)]
    summ += [dict(reason='Other methods (citation searching): reports assessed', n=pc['citation_assessed'])]
    summ += [dict(reason='Total excluded, all routes', n=sum(cnt.values()))]   # owner, 8 Nov 2026: no other-methods exclusions
    lang = rd(PR / 'language_exclusions_abstract_check_2026-10-24.csv').to_dict('records')
    assert all(r['second_review'] == 'Pending (SP)' for r in lang), {r['second_review'] for r in lang}   # source record, not edited
    for r in lang:   # SKP's check, reported by the review owner on 3 Nov 2026
        r['second_review'] = 'SKP (reported 3 Nov 2026)'
    wb = new_wb(4, ['Every report sought for full-text assessment (224 from the databases and 1 from citation searching), '
                    'with its disposition and the exclusion reason as counted in Fig. 1.',
                    'Excluded reports with no confirmed postoperative opioid result also carry the finding of the outcome '
                    'audit (8 October 2026). This requirement was added on 9 October 2026, after registration and with '
                    'trial results known (Additional file 2).'],
                [('Reports', 'One row per report sought (228)'), ('Fig. 1 counts', 'Exclusion reasons, reconciled with Fig. 1'),
                 ('Outcome exclusions recheck', 'AI-assisted triage (2 Nov 2026) of the 113 "No eligible analgesic outcome" exclusions under both dated outcome requirements, with the review owner decisions on the nine membership candidates (D1, D3) and the corrected reasons for nine others (D4, JRNM and SKP); the triage itself is not a human screen; SKP checked it (reported 3 Nov 2026); the 53 it could not assess were sought and read on 3 Nov 2026 (sheet "D5 re-check") '
                                               '[PROVISIONAL: six not retrieved]'),
                 ('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language at screening; checked by SKP '
                                         '(reported 3 Nov 2026). Seven more were counted under publication language by decision D5 '
                                         '(sheet "D5 re-check")'),
                 ('Wang 1997 outcomes', 'Every result reported by Wang 1997 (included 2 Nov 2026), with its disposition: existing analysis, single-trial estimate, narrative, hold or excluded by rule'),
                 ('D3 decisions', 'Decision D3 (review owner, 2 Nov 2026) on the other eight membership candidates, with its basis'),
                 ('D3 extracted results', 'Results extracted from the three reports included by decision D3, with source location, quotation and use'),
                 ('D3 outcomes', 'Every result reported by Colak 2010, Fu 2024 and Chen 2016 (decision D3), with its disposition: existing analysis, '
                                 'single-trial estimate, descriptive, narrative, not a registered outcome or held (added 3 Nov 2026)'),
                 ('D4 decisions', 'Decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected '
                                  'reason, with the source basis; all remain excluded'),
                 ('D5 re-check', 'Decision D5 (JRNM and SKP, 3 Nov 2026): how each of the 53 outcome exclusions the triage could '
                                 'not assess was sought and read (AI-assisted, not a human read), what it reports and the decision; '
                                 'nine counted under a corrected reason, six not retrieved')],
                ['"No eligible analgesic outcome" preserves the exclusion decisions made at full-text screening under the 14 '
                 'August 2026 outcome rule, apart from the reports included or relabelled after the 2 November 2026 recheck '
                 '(decisions D1, D3, D4 and D5); JRNM and SKP screened the full texts independently (Methods). The label does not '
                 'show that every excluded report lacked every registered outcome.',
                 'Covidence decision and reason are as exported; six reports recorded there as excluded were reinstated after '
                 'source-verified adjudication.',
                 'Covidence imported the 5,100 exported references as 5,088 records, merging 12 into existing records; they are '
                 'counted with the duplicates in Fig. 1.',
                 'Study labels are as exported from Covidence; for included reports the label used in the manuscript is also given.'])
    sheet(wb, 'Reports', rows, [('cid', 'Covidence ID', 13), ('label', 'Covidence label', 18), ('report', 'Report label in manuscript', 22),
                                ('title', 'Title', 60), ('doi', 'DOI', 26), ('route', 'Identified through', 14),
                                ('cov', 'Covidence decision', 12), ('covr', 'Covidence exclusion reason', 20),
                                ('disp', 'Disposition in this review', 14), ('fig', 'Reason as counted in Fig. 1', 28),
                                ('detail', 'Outcome audit category', 34), ('finding', 'Outcome audit finding', 60),
                                ('date', 'Decision date', 12), ('note', 'Note', 40)])
    sheet(wb, 'Fig. 1 counts', summ, [('reason', 'Reason', 44), ('n', 'Reports', 10)])
    tri = recs(REV / 'C01_selection/C01_historical_outcome_exclusions_triage.csv')
    assert len(tri) == 113
    for t in tri:
        if t['covidence_id'] == '1879897512':
            assert t['category'] == 'MEMBERSHIP'
            t['category'] = 'MEMBERSHIP: included 2 Nov 2026'
            t['proposed_human_action'] += ' Decided 2 Nov 2026 by the review owner: TEAS; included (broader first-day analysis).'
        if t['covidence_id'] in D3_DEC:   # D3, 2 Nov 2026
            assert t['category'] == 'MEMBERSHIP', t['covidence_id']
            dec = D3_DEC[t['covidence_id']]
            t['category'] = 'MEMBERSHIP: ' + ('included' if dec['decision'].startswith('Include') else 'excluded') + ' 2 Nov 2026 (D3)'
            t['proposed_human_action'] += f' Decided 2 Nov 2026 by the review owner (D3): {dec["decision"]}.'
        if t['covidence_id'] in D4_DEC:   # D4, 3 Nov 2026
            assert t['category'] in ('REASON', 'STANDS'), t['covidence_id']
            dec = D4_DEC[t['covidence_id']]
            t['category'] += ': reason corrected 3 Nov 2026 (D4)'
            t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D4): {dec["decision"]}.'
        if t['covidence_id'] in D5_LOGD:   # D5, 3 Nov 2026
            assert t['category'] in ('UNREAD_SIGNAL', 'UNAVAILABLE'), t['covidence_id']
            dec = D5_DEC.get(t['covidence_id'])
            if dec and dec['decision'].startswith('Exclude'):
                t['category'] += ': reason corrected 3 Nov 2026 (D5)'
                t['proposed_human_action'] += f' Decided 3 Nov 2026 by JRNM and SKP (D5): {dec["decision"]}.'
            elif D5_LOGD[t['covidence_id']]['access'] == 'Not retrieved':
                t['category'] += ': not retrieved 3 Nov 2026 (D5)'
            else:
                t['category'] += ': re-checked 3 Nov 2026 (D5); reason kept'
    sheet(wb, 'Outcome exclusions recheck', tri, [('covidence_id', 'Covidence ID', 13), ('covidence_label', 'Covidence label', 16),
          ('title', 'Title', 50), ('doi', 'DOI', 24), ('category', 'Category (2 Nov 2026 triage)', 16), ('filter_A_14Aug', '14 Aug outcome rule', 40),
          ('filter_B_9Oct', '9 Oct opioid-result criterion', 40), ('other_criteria', 'Other criteria', 40),
          ('proposed_human_action', 'Proposed human action', 40), ('evidence_basis', 'Evidence basis', 40),
          ('local_full_text', 'Local full text', 9), ('covidence_date', 'Covidence date', 10)])
    sheet(wb, 'Language exclusions', lang, [('covidence_id', 'Covidence ID', 13), ('study', 'Study', 14), ('pmid', 'PMID', 11), ('doi', 'DOI', 28),
                                           ('citation', 'Citation', 30), ('abstract_postoperative_opioid_category', 'Postoperative opioid result in the English abstract', 34),
                                           ('abstract_quote_verbatim', 'Abstract text (verbatim)', 70), ('note', 'Note', 50),
                                           ('checked_by', 'Checked by', 26), ('second_review', 'Second review', 14)])
    sheet(wb, 'D3 decisions', list(D3_DEC.values()), [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 22),
          ('decision', 'Decision', 30), ('basis', 'Basis', 80), ('decided_by', 'Decided by', 40)])
    sheet(wb, 'D3 extracted results', list(D3_RES.values()), [('result_id', 'Result ID', 16), ('report', 'Report', 12),
          ('outcome', 'Outcome', 34), ('window', 'Window', 18), ('unit', 'Unit', 14), ('comparison', 'Comparison', 16),
          ('n_i', 'N, intervention', 8), ('value_i', 'Value, intervention', 12), ('sd_i', 'SD', 8), ('n_c', 'N, control', 8),
          ('value_c', 'Value, control', 12), ('sd_c', 'SD', 8), ('data_type', 'Data type', 12), ('source_location', 'Source location', 22),
          ('source_text', 'Source text (verbatim)', 60), ('use', 'Use in this review', 40), ('source_sha256', 'Source SHA-256', 20)])
    sheet(wb, 'Wang 1997 outcomes', W97_INV, [('source', 'Source (printed page)', 18), ('result', 'Result', 50),
                                              ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
    sheet(wb, 'D3 outcomes', D3_INV, [('report', 'Report', 12), ('source', 'Source (printed page)', 22), ('result', 'Result', 44),
                                      ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
    sheet(wb, 'D4 decisions', list(D4_DEC.values()), [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 14),
          ('previous_reason', 'Previous reason', 22), ('decision', 'Decision', 30), ('counted_as', 'Counted in Fig. 1 as', 30),
          ('rule_14aug', '14 Aug outcome rule', 22), ('basis', 'Basis (source location)', 80), ('decided_by', 'Decided by', 40)])
    d5 = [dict(x, decision=D5_DEC[x['covidence_id']]['decision'] if x['covidence_id'] in D5_DEC else
               ('Not retrieved' if x['access'] == 'Not retrieved' else 'No change'),
               decided_by=D5_DEC[x['covidence_id']]['decided_by'] if x['covidence_id'] in D5_DEC else '') for x in D5_LOG]
    sheet(wb, 'D5 re-check', d5, [('covidence_id', 'Covidence ID', 13), ('report', 'Report', 16), ('set', 'Triage group', 22),
          ('language', 'Language', 22), ('route', 'Where sought', 40), ('access', 'Result', 18), ('rule_14aug', '14 Aug outcome rule', 40),
          ('criterion_9oct', '9 Oct opioid-result criterion', 40), ('other', 'Other', 36), ('ai_proposal', 'AI proposal', 40),
          ('decision', 'Decision', 30), ('decided_by', 'Decided by', 34), ('read_by', 'Read by', 30)])
    return save(wb, 4, '.xlsx')


# ================================================================ Additional file 5: source contradictions
CONTRA = [
    ('Chen 2020', 'Printed 48-hour sufentanil totals (118.5 and 140.2 µg) are lower than the trial\'s own stated basal infusion (144 µg).',
     'Printed values used unchanged. The 24-hour result enters only the broader first-day analysis, with analyses omitting Chen 2020 and across the three sufentanil factors.'),
    ('Chen 2020', 'Fig. 1 shows 86 randomised (42 and 44) and 80 analysed; the abstract and Table 1 give 80.',
     'Recorded as 86 randomised (24 Oct 2026, after an external check). Missing-data domain changed from Low to Some concerns for both results; overall judgements and all estimates unchanged.'),
    ('He 2026 (hepatectomy)', 'Author-reported morphine equivalents whose intravenous or oral basis is not stated.',
     'Used at factor 1 only in the broader first-day analysis, with an analysis excluding results of unstated route.'),
    ('El-Rakshy 2009', 'Arm labels and denominators conflict between the flow diagram, the baseline table and the abstract.',
     'Table 2 assignment retained in EA versus usual care, at high risk of bias, with an analysis omitting the trial.'),
    ('El-Rakshy 2009', 'Women by arm: Table 1 gives 56/58 (PCA) and 36/44 (PCA + EA); the text says eight of the ten men received PCA alone (50/58 and 42/44).',
     'Text followed. Overall 92 of 102 (90%) women either way. No analysis affected.'),
    ('Yeh 2010 / Yeh 2011', 'Probably the same cohort reported twice; opioid route (epidural or intravenous) and schedule differ between the reports.',
     'Counted once as one trial; both reports held from every analysis.'),
    ('Jin 2023', 'General anaesthesia not established; PCA volume reported without drug concentration; statistics for the 2-Hz and 20/100-Hz arms differ between table and text.',
     'Held from all pooled analyses.'),
    ('Long 2025', '"Needle or patch" does not establish the modality; abstract and Table 7 give different 24-hour pain values; percentages do not reconcile with the analysed denominators.',
     'Held (modality unclear).'),
    ('Lee 2011', 'The sham group\'s interval sums differ from its Table 8 24-hour total; Table 8 excludes recovery-room doses.',
     'Table 8 values used. Lee 2011 has been held from all pooled analyses since 23 Oct 2026 (age criterion).'),
    ('Gu 2019', 'The 24-hour opioid value is printed only in a figure; digitised control-arm bars exceed the control means printed in the text by 1.85–3.90 mL at every time point reported in both.',
     'Admitted to the broader first-day analysis with a flag; an analysis omitting it is reported. The figure was not corrected using the text.'),
    ('Gu 2019', 'A satisfaction composite in the text (67.3% vs 42.4%) does not reconcile with the category counts in Table 4.',
     'Composite not used; table counts retained descriptively.'),
    ('Yu 2020', 'Pain SDs differ between Table 2 and the abstract (24 h: 1.53 vs 1.41; 48 h: 0.98 vs 0.88), and the text and table disagree on the 48-hour P value.',
     'Table 2 values used; analyses with the abstract SDs reported (Additional file 12).'),
    ('Wu 2025', 'Randomisation and treatment began on arrival in the recovery unit, after the intraoperative opioid dose.',
     'Intraoperative opioid excluded from efficacy analyses; reported only as a pre-intervention check.'),
    ('Liu 2026 (ESD)', 'Published risk ratio and P value for nausea and vomiting are inconsistent with the event counts.', 'Raw counts (4/58 vs 14/62) used.'),
    ('Zhang 2025', 'Published risk ratio 0.70 (0.44 to 1.10) conflicts with the raw counts (about 0.52) and the reported P value.', 'Raw counts used.'),
    ('Liu 2026 (burn)', 'Abstract and Results/Fig. 4 give different values for the same outcome.', 'Results/Fig. 4 values recorded; result held (no tabulated mean and SD).'),
    ('Xiong 2021', 'Postoperative interval not stated; route terminology in the Results is inconsistent.', 'Result held.'),
    ('Colak 2010', 'Called a "case-control study", although participants were randomised by tables of random numbers; the exclusion criteria mention an epidural catheter that is not otherwise described.',
     'Treated as a randomised trial (decision D3, 2 Nov 2026); no epidural analgesia assumed. Randomisation domain judged Some concerns.'),
    ('Fu 2024', 'Printed P values do not match the printed summaries. Rescue analgesic 2/30 versus 6/29 is printed with P < 0.001 '
                '(two-sided Fisher P ≈ 0.15). With the printed means, SDs and arm sizes, QoR-15 gives Welch P ≈ 4 × 10⁻⁷, 3 × 10⁻⁶ and '
                '2 × 10⁻⁸ on days 1, 3 and 7 against printed 0.004, 0.008 and 0.020; remifentanil ≈ 0.006 and propofol ≈ 0.016 against '
                'printed < 0.001; baseline QoR-15 ≈ 0.88, age ≈ 0.69, duration of surgery ≈ 0.64 and duration of anaesthesia ≈ 0.78 '
                'against printed 0.761, 0.606, 0.364 and 0.463 (Tables 2-4, pp6-7); agitation 3/30 versus 11/29 '
                'gives Fisher P ≈ 0.015 against printed < 0.001. A pooled-variance t test does not explain the differences, and the '
                'report does not show which values, labels or analyses are wrong.',
     'Arm summaries used as printed; printed P values not used. Flagged for the human source check (D9). At second review '
     '(SKP, 3 Nov 2026) the arm summaries were kept as printed and the Fu 2024 RoB 2 and GRADE assessments confirmed. Without Fu 2024, rescue receipt RR 0.52 (0.37 to 0.74) and QoR-15 at about 24 h '
     'MD 9.64 (−57.20 to 76.47) (Results; Additional file 12). Inclusion '
     '(decision D3) is unchanged.'),
    ('Fu 2024', 'Table 3 (p6) gives day-7 MMSE interquartile ranges of 21.0 to 32.0 (TEAS) and 19.0 to 31.0 (control), although the '
                'MMSE is a 30-point scale (Methods p4); Table 2 (p6) prints 7 of 29 control participants with ASA III as 23.3% (7/30).',
     'MMSE is not an outcome of this review; neither value corrected. Recorded with the P-value discrepancies as evidence on the '
     'reliability of the report.'),
    ('Chen 2016', 'Results (p3) give total supplementary pethidine (Sauteralgyl) of 9.2 ± 2.8 versus 11.5 ± 1.8 mg/kg, but Fig. 2c (p4) '
                  'plots about 3.7 versus 4.6 mg/kg on a 0-6 mg/kg axis; the relative reduction (20%) agrees, the amounts do not.',
     'Text values recorded (kept at second review, 3 Nov 2026); figure not read. Chen 2016 is held from all analyses (decision D3), so no estimate is affected.'),
    ('Fu 2024', 'The dexmedetomidine row of Table 4 (2 [6.7%] versus 6 [20.7%], P < 0.001) repeats the rescue-analgesic row exactly.',
     'Neither row corrected; dexmedetomidine is not an outcome of this review. Flagged for the human source check.'),
]


def af5():
    inv = rd(C / 'all_40_result_inventory.csv')
    held = []
    for r in inv.to_dict('records'):
        if r['decision'] in ('HOLD', 'SENSITIVITY'):
            held.append(dict(result_id=r['result_id'], study=r['study'], family=r['family'], outcome=r['outcome'], window=r['window'],
                             comparison=f'{r["modality"]} vs {r["comparator_class"]}'.strip(), decision=r['decision'].title(),
                             rationale=r['rationale'], qc=r['source_qc'], loc=r['source_location']))
    for w in D3_RES.values():   # D3, 2 Nov 2026: Chen 2016 held (ages 16-80); Fu 2024 pain medians descriptive only
        if w['report'] == 'Chen 2016' or w['use'].startswith('Descriptive'):
            held.append(dict(result_id=w['result_id'], study=w['report'], family=w['outcome'], outcome=w['outcome'], window=w['window'],
                             comparison=w['comparison'], decision='Hold', rationale=w['use'], qc='', loc=w['source_location']))
    held.sort(key=lambda x: (x['study'], x['family'], x['result_id']))
    wb = new_wb(5, ['Contradictions within source reports, and how each affected the analyses. Source values were never '
                    'altered to make a report consistent.',
                    'Dispositions: hold (enters no pooled analysis; printed values kept for labelled checks), sensitivity '
                    'only, or leave-out (retained, with an analysis omitting it).'],
                [('Contradictions', 'Each contradiction or source problem in the included reports, with its disposition'),
                 ('Held or sensitivity-only', 'Every result held or used only in sensitivity analyses, with the reason')],
                ['"V33", "V34" and "AUDIT" in result identifiers refer to versions of the project\'s extraction record.',
                 'Lee 2011 is held from all pooled analyses because of its age range, in addition to the source issue listed here.'])
    sheet(wb, 'Contradictions', [dict(report=a, issue=b, disp=c) for a, b, c in CONTRA],
          [('report', 'Report', 20), ('issue', 'Contradiction or source problem', 70), ('disp', 'Disposition and effect on the analyses', 70)])
    sheet(wb, 'Held or sensitivity-only', held, [('result_id', 'Result ID', 14), ('study', 'Report', 20), ('family', 'Outcome family', 20),
                                                 ('outcome', 'Outcome', 34), ('window', 'Window', 16), ('comparison', 'Comparison', 16),
                                                 ('decision', 'Disposition', 12), ('rationale', 'Reason', 60), ('qc', 'Source note', 60),
                                                 ('loc', 'Source location', 24)])
    return save(wb, 5, '.xlsx')


# ================================================================ Additional file 6: classification of opioid results
OPIOID_FAMILIES = {'Opioid consumption', 'Opioid demand', 'Rescue opioid use', 'Intraoperative opioid', 'PCIA solution volume',
                   'Postoperative opioid consumption', 'Opioid-related adverse effect'}


def af6():
    ta = rd(V38 / 'E2_tierA_reclassification.csv').to_dict('records') + rd(V38 / 'E2_tierA_reclassification_addendum.csv').to_dict('records')
    for r in ta:
        r['report'] = {'He 2026 (hepatectomy)': 'He 2026 (hepatectomy/JIS)'}.get(r['report'], r['report'])
        r['now'] = 'Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years)' if r['report'] == 'Lee 2011' else ''
        assert r['report'] in REPORTS, r['report']
    b1 = [r for r in rd(V38 / 'E2_tierB1_extraction.csv').to_dict('records') if r['report'] in REPORTS]
    b2 = [r for r in rd(V38 / 'E2_tierB2_recheck.csv').to_dict('records') if r['report'] in REPORTS]
    ta.append(dict(body='TEAS vs sham; TEAS vs usual care', report='Wang 1997', result_ids='WANG97-HM24',
                   E1_disposition='NOT ADMITTED (decision D1b, 2 Nov 2026): capture of the intramuscular supplemental opioid given to 19 of 101 participants in the first 24 h is not established (supplemental meperidine was converted to hydromorphone equivalents for the report\'s analysis, but rescue is not itemised)',
                   E2_disposition='ADMIT', E2_basis=W97_RES['WANG97-HM24']['classification'], flags='Capture of rescue not established (as Chen 1998)',
                   mandatory_sensitivity='Excluded from the analysis without unquantified rescue; leave-one-out', addendum_note=W97_NOTE,
                   now='Included 2 Nov 2026'))
    ta.append(dict(body='EA vs usual care', report='Colak 2010', result_ids='COLAK10-PETH-7D',
                   E1_disposition='EXCLUDE: pethidine total over postoperative days 0-7; no 0-24-h quantity', E2_disposition='NOT ADMITTED',
                   E2_basis='Window: a 7-day total does not give the first 24 hours', flags='Single-trial estimate in native units (Additional file 12)',
                   mandatory_sensitivity='', addendum_note='Colak 2010, ' + D3_NOTE, now='Included 2 Nov 2026'))
    ta.append(dict(body='EA vs sham', report='Chen 2016', result_ids='CHEN16-PETH-72',
                   E1_disposition='HOLD: participants aged 16-80 years (as Lee 2011); also a 72-h weight-normalised total', E2_disposition='NOT ADMITTED',
                   E2_basis='Window (0-72 h) and a weight-normalised dose (mg/kg), which cannot be converted to an absolute dose (Additional file 7)',
                   flags='Held from all pooled analyses', mandatory_sensitivity='', addendum_note='Chen 2016, ' + D3_NOTE + '; held',
                   now='Included 2 Nov 2026; held'))
    inv = rd(C / 'all_40_result_inventory.csv')
    allop = [dict(result_id=r['result_id'], study=r['study'], family=r['family'], outcome=r['outcome'], window=r['window'], unit=r['unit'],
                  comparison=f'{r["modality"]} vs {r["comparator_class"]}', decision=r['decision'].title(), rationale=r['rationale'],
                  models=r['completion_models'] or r['models'], loc=r['source_location'], quote=r['source_quote'])
             for r in inv.to_dict('records') if r['family'] in OPIOID_FAMILIES]
    for rid, fam, mods in (('WANG97-HM24', 'Postoperative opioid consumption', 'E2_opioid24_TEAS_sham (and sensitivity analyses); E2_opioid24_TEAS_usual'),
                           ('WANG97-RESCUE24', 'Rescue opioid use', 'RESCUE_TEAS_SHAM_* ; RESCUE_TEAS_USUAL')):
        w = W97_RES[rid]
        allop.append(dict(result_id=rid, study='Wang 1997', family=fam, outcome=w['outcome'], window=w['window'], unit=w['unit'],
                          comparison='TEAS vs sham; TEAS vs usual care', decision='Include' if rid.endswith('RESCUE24') else 'Admit (broader only)',
                          rationale=w['classification'], models=mods, loc=w['source_location'], quote=w['source_text']))
    for rid, fam, dec, mods in (('COLAK10-PETH-7D', 'Postoperative opioid consumption', 'Individual estimate', 'opioid7d_pethidine_EA_usual_COLAK (single trial, native units)'),
                                ('FU24-RESCUE', 'Rescue opioid use', 'Include', 'RESCUE_TEAS_SHAM_* (not the known-period or first-day subsets: follow-up not stated)'),
                                ('FU24-REMI', 'Intraoperative opioid', 'Include', 'intraop_remifentanil_TEAS_sham (single trial)'),
                                ('CHEN16-PETH-72', 'Postoperative opioid consumption', 'Hold', 'None (held: participants aged 16-80 years)')):   # D3
        w = D3_RES[rid]
        allop.append(dict(result_id=rid, study=w['report'], family=fam, outcome=w['outcome'], window=w['window'], unit=w['unit'],
                          comparison=w['comparison'], decision=dec, rationale=w['use'] + '; ' + D3_NOTE, models=mods,
                          loc=w['source_location'], quote=w['source_text']))
    rules = [
        ('Primary construct (registered)', 'All delivered systemic opioid from the end of surgery to 24 hours, in mg IV morphine equivalents. A result qualifies only where the source establishes that it captures all delivered systemic opioid, including any quantified rescue. Programmed but undelivered PCA doses are not counted. Permitted but unquantified rescue is never treated as zero.'),
        ('Broader first-day construct (post hoc, defined 23 Sep 2026)', 'Cumulative postoperative opioid reported as consumed or delivered in the first 24 postoperative hours, in mg IV morphine equivalents. Totals capturing PCA only, and totals where additional rescue was given but not quantified, are admitted. Unquantified components are never imputed or added.'),
        ('Consumed, not requested', 'Demands, button presses and programmed doses are excluded.'),
        ('Window', 'A stated 24-hour window from the end of surgery, or from recovery-unit arrival or PCA connection within the first postoperative hour. Unstated, "perioperative", calendar-day and longer windows do not qualify. Amendment E2.1: postoperative-day-1 totals are taken as the first 24 hours.'),
        ('Convertible drug', 'The total must be in a drug with a registered factor (Additional file 7), or be the authors\' own morphine equivalents (admitted as reported, with an analysis excluding them). A result whose only quantified opioid lacks a factor is excluded. An unfactored drug given only as unquantified rescue alongside a convertible total does not exclude the result.'),
        ('Absolute dose with dispersion', 'Arm-level mean and SD of an absolute dose are required. Amendment E2.1: values printed only in a figure may be digitised against the axis gridlines and validated against printed text.'),
        ('Unchanged', 'Prohibited conversions, separation of modality and comparator, holds for unresolved source questions, the joint clinical-importance criterion and the statistical methods.'),
        ('Timing', 'The broader construct was defined after the primary results were known and fixed in writing before it was applied. Amendment E2.1 was made after it had been applied to the reports without an extracted result, knowing that it admitted exactly two (Zhang 2025 and Gu 2019). The broader analysis was briefly adopted as primary and run; the registered outcome was then retained as primary, with these results known.'),
    ]
    wb = new_wb(6, 'Classification of every candidate opioid result in the 44 reports against the registered primary '
                   'construct and the broader first-day construct, with the basis for each decision.',
                [('Rules', 'Definitions and admission rules'),
                 ('Analysis inputs', 'Every value entering an analysis reported in the main text: values as reported, factor, values as modelled, and source'),
                 ('Extracted results', 'Results with an extracted opioid quantity: primary and broader classification'),
                 ('Reports without a result', 'Reports whose text suggested an opioid quantity not yet extracted, classified under the broader rules'),
                 ('All opioid results', 'Every opioid-related result in the 44 reports, with its disposition in the analyses')],
                ['Primary = registered construct (also called E1 in the project record); Broader = broader first-day construct (E2).',
                 'Dispositions: INCLUDE, primary analysis; SENSITIVITY, sensitivity analyses only; HOLD, no pooled analysis; EXCLUDE, outside the construct; ADMIT / NOT ADMITTED, broader construct.'])
    sheet(wb, 'Rules', [dict(a=a, b=b) for a, b in rules], [('a', 'Rule', 34), ('b', 'Definition', 120)])
    sheet(wb, 'Extracted results', ta, [('body', 'Comparison', 22), ('report', 'Report', 20), ('result_ids', 'Result ID(s)', 24),
                                        ('E1_disposition', 'Primary construct', 22), ('E2_disposition', 'Broader construct', 16),
                                        ('E2_basis', 'Basis', 70), ('flags', 'Flags', 50), ('mandatory_sensitivity', 'Required sensitivity analyses', 40),
                                        ('addendum_note', 'Addendum', 40), ('now', 'Current status', 30)])
    sheet(wb, 'Reports without a result', [dict(r, tier='B1') for r in b1] + [dict(r, tier='B2') for r in b2],
          [('report', 'Report', 18), ('modality', 'Modality', 10), ('comparator', 'Comparator', 30),
           ('opioid_reported', 'Opioid reported', 50), ('what_is_reported', 'What is reported', 60), ('literal_values', 'Values as printed', 50),
           ('window_as_reported', 'Window as reported', 24), ('E2_rule_failed', 'Rule not met', 40), ('E2_disposition', 'Broader construct', 16),
           ('E1_disposition', 'Primary construct', 16), ('notes', 'Notes', 50), ('flag', 'Flag', 30)])
    sheet(wb, 'Analysis inputs', analysis_inputs(), [('analysis', 'Analysis', 30), ('report', 'Report', 20), ('result_id', 'Result ID(s)', 22),
          ('outcome', 'Outcome', 30), ('window', 'Window', 14), ('raw_unit', 'Unit as reported', 16),
          ('raw_values', 'Values as reported (intervention; control)', 40), ('factor', 'Factor', 8), ('model_values', 'Values entering the model', 40),
          ('yi', 'Effect (model scale)', 10), ('vi', 'Variance', 10), ('source_location', 'Source location', 26),
          ('source_quote', 'Verbatim source text', 50), ('source_sha256', 'Source SHA-256', 20)])
    sheet(wb, 'All opioid results', allop, [('result_id', 'Result ID', 14), ('study', 'Report', 20), ('family', 'Outcome family', 22),
                                            ('outcome', 'Outcome', 40), ('window', 'Window', 16), ('unit', 'Unit', 14), ('comparison', 'Comparison', 16),
                                            ('decision', 'Disposition', 12), ('rationale', 'Reason', 60), ('models', 'Analyses', 40),
                                            ('loc', 'Source location', 22), ('quote', 'Source text', 70)])
    return save(wb, 6, '.xlsx')


# ================================================================ Additional file 7: conversion register
MAIN_MODELS = ['opioid24_TEAS_sham', 'opioid24_TEAS_usual', 'opioid24_EA_usual', 'E2_opioid24_TEAS_sham', 'E2_opioid24_TEAS_usual',
               'E2_opioid24_EA_sham', 'E2_opioid24_EA_usual', 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'ponv24_TEAS_sham', 'vomiting24_TEAS_sham',
               'pain24_rest_TEAS_sham', 'pain24_unclassified_TEAS_sham', 'QoR40_SHAM_24H', 'QoR15_SHAM_24H', 'flatus_TEAS_sham',
               'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY', 'nausea24_TEAS_sham', 'RESCUE_TEAS_USUAL', 'pain24_rest_EA_usual']
W97_MAIN = {('E2_opioid24_TEAS_sham', 'sham'): 'WANG97-HM24', ('E2_opioid24_TEAS_usual', 'usual care'): 'WANG97-HM24',
            ('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'sham'): 'WANG97-RESCUE24', ('RESCUE_TEAS_USUAL', 'usual care'): 'WANG97-RESCUE24',
            ('pain24_unclassified_TEAS_sham', 'sham'): 'WANG97-VAS24', ('nausea24_TEAS_sham', 'sham'): 'WANG97-NAUSEA24',
            ('vomiting24_TEAS_sham', 'sham'): 'WANG97-VOMIT24'}


# Source locators for the two amendment-E2.1 results, which are not in the 40-report result inventory (re-check, M09).
# Sources: opioid_only_review/source_audit/postoperative_opioid_source_audit.csv and
# 10_FINAL_ADJUDICATION/02_DECISIONS/v38/E2_digitisation_gu2019.md.
E21_SRC = {
    'E2.1-GU2019-FIG4-T4': dict(loc='Fig. 4, PDF pp3-4 (24-h point, T4): values not printed; digitised against the axis gridlines (E2_digitisation_gu2019.md). PCIA 100 µg sufentanil in 100 mL, Methods p2',
                                raw='L-TEAS 55.71 (7.93) mL, n 58 vs C-TEAS 58.84 (7.41) mL, n 59 (digitised; 1 mL = 1 µg sufentanil)',
                                quote='Not printed (figure only). Digitisation record: 24-h control value probably overstated relative to the text; leave-out analysis mandatory',
                                sha='b6fb0c0901f5f6716bd6cc6facc06f0844dca5c5e9d357527f55936d5de0aa33'),
    'E2.1-ZHANG2025-POD1': dict(loc='Results table, PDF p9 (postoperative day 1; taken as the first 24 h under amendment E2.1)',
                                raw='50.53 (4.46) µg sufentanil, n 45 vs 53.79 (5.14) µg, n 48',
                                quote='Total sufentanil consumption (μg) 50.53±4.46 53.79±5.14 MD:-3.26(−5.25 to −1.27)',
                                sha='691899a10069da68a1525a13662118fca1d4f9ed245d4304b120c426d27bb053'),
}


def analysis_inputs():
    """Inputs to every analysis reported in the main text, with values as reported (inventory) and as modelled."""
    inv = {r['result_id']: r for r in recs(C / 'all_40_result_inventory.csv')}
    src = recs(R / 'model_inputs.csv') + recs(R / 'e2/e2_model_inputs.csv') + recs(C / 'model_inputs.csv')
    out, seen = [], set()
    for r in src:
        m = r.get('model_id', '')
        if m not in MAIN_MODELS or r['study'] == 'Lee 2011' or (m, r['result_id']) in seen or m == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':
            continue
        seen.add((m, r['result_id']))
        ids = r['result_id'].split('+')
        raw = []
        for i in ids:
            v = inv.get(i)
            if not v:
                continue
            if v['events_i']:
                raw.append(f"{v['events_i']}/{v['n_i']} vs {v['events_c']}/{v['n_c']}")
            else:
                raw.append(f"{v['mean_i']} ({v['sd_i']}), n {v['n_i']} vs {v['mean_c']} ({v['sd_c']}), n {v['n_c']}")
        v0 = inv.get(ids[0], {})
        ev = r.get('events_i', '')
        mv = (f"{ev}/{r.get('n_i', '')} vs {r.get('events_c', '')}/{r.get('n_c', '')}" if ev else
              f"{r.get('mean_i', '')} ({r.get('sd_i', '')}), n {r.get('n_i', '')} vs {r.get('mean_c', '')} ({r.get('sd_c', '')}), n {r.get('n_c', '')}")
        quote = v0.get('source_quote', '') or r.get('source_quote', '') or r.get('source_excerpt', '')
        e21 = E21_SRC.get(r['result_id'], {})
        loc = v0.get('source_location', '') or r.get('source_location', '') or e21.get('loc', '')
        sha = v0.get('source_sha256', '') or r.get('source_sha256', '') or r.get('source_pdf_sha256', '') or e21.get('sha', '')
        out.append(dict(analysis=m, report=r['study'], result_id=r['result_id'], outcome=v0.get('outcome', r.get('outcome', '')),
                        window=v0.get('window', r.get('window', '')), raw_unit=v0.get('unit', ''),
                        raw_values=' | '.join(raw) if raw else (e21.get('raw') or 'see result inventory'),
                        factor=r.get('factor', ''), model_values=mv, yi=num(r.get('yi', ''), 4), vi=num(r.get('vi', ''), 5),
                        source_location=loc,
                        source_quote=quote or e21.get('quote') or ('Not recorded (location only)' if loc else 'NOT RECORDED: no location or quotation'),
                        source_sha256=sha[:16]))
    for r in recs(FA / 'rescue_model_inputs.csv'):   # D9, 3 Nov 2026: the rescue model's own inputs (five trials; Wang 1997 and Fu 2024 below)
        if r['model_id'] != 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':
            continue
        ev = f"{r['events_i']}/{r['n_i']} vs {r['events_c']}/{r['n_c']}"
        out.append(dict(analysis=r['model_id'], report=r['report'], result_id=r['outcome_id'], outcome=f"{r['outcome']} ({r['opioid']})",
                        window=r['window'], raw_unit='patients', raw_values=ev, factor='', model_values=ev, yi=num(r['y'], 4),
                        vi=num(r['variance'], 5), source_location=r['source_location'], source_quote='Not recorded (location only)',
                        source_sha256=r['source_sha256'][:16]))
    arm = {'sham': 'sham', 'usual care': 'PCA only'}
    for (m, comp), rid in W97_MAIN.items():   # D1, 2 Nov 2026: values as reported (Wang 1997 Tables 3, 5, 6) and as modelled
        w, x = W97_RES[rid], next(i for i in W97_IN if i['result_id'] == rid and i['comparator'] == comp)
        ctrl = w['arm_II_sham'] if comp == 'sham' else w['arm_I_pca_only']
        mv = (f"{x['events_i']}/{x['n_i']} vs {x['events_c']}/{x['n_c']}" if x['events_i'] not in ('', 'NA') else
              f"{num(x['mean_i'], 2)} ({num(x['sd_i'], 2)}), n {x['n_i']} vs {num(x['mean_c'], 2)} ({num(x['sd_c'], 2)}), n {x['n_c']}")
        out.append(dict(analysis=m, report='Wang 1997', result_id=rid, outcome=w['outcome'], window=w['window'], raw_unit=w['unit'],
                        raw_values=f"low {w['arm_III_low']}; high {w['arm_IV_high']} (combined) vs {arm[comp]} {ctrl}",
                        factor=x['factor'] if x['factor'] not in ('', 'NA') else '', model_values=mv, yi=num(x['yi'], 4), vi=num(x['vi'], 5),
                        source_location=w['source_location'], source_quote=w['source_text'], source_sha256=W97_SHA[:16]))
    for m, rid, scale in (('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'FU24-RESCUE', 1), ('QoR15_SHAM_24H', 'FU24-QOR-T1', 1),
                          ('pain24_rest_EA_usual', 'COLAK10-VAS-D1', 10)):   # D3, 2 Nov 2026: values as reported and as modelled
        w = D3_RES[rid]
        ni, nc = int(w['n_i']), int(w['n_c'])
        if w['data_type'] == 'events':
            ei, ec = int(w['value_i']), int(w['value_c'])
            yi, vi = math.log((ei / ni) / (ec / nc)), 1 / ei - 1 / ni + 1 / ec - 1 / nc
            raw = mv = f'{ei}/{ni} vs {ec}/{nc}'
        else:
            mi, si, mc, sc = (float(w[k]) / scale for k in ('value_i', 'sd_i', 'value_c', 'sd_c'))
            yi, vi = mi - mc, si ** 2 / ni + sc ** 2 / nc
            raw = f"{w['value_i']} ({w['sd_i']}), n {ni} vs {w['value_c']} ({w['sd_c']}), n {nc}"
            mv = f'{num(mi, 3)} ({num(si, 3)}), n {ni} vs {num(mc, 3)} ({num(sc, 3)}), n {nc}'
        if m == 'pain24_rest_EA_usual':   # single trial: the modelled effect is this difference
            assert abs(yi - float(W97_MOD[m]['effect'])) < 1e-9
        out.append(dict(analysis=m, report=w['report'], result_id=rid, outcome=w['outcome'], window=w['window'], raw_unit=w['unit'],
                        raw_values=raw, factor='0.1 (0-100 to 0-10)' if scale == 10 else '', model_values=mv, yi=num(yi, 4), vi=num(vi, 5),
                        source_location=w['source_location'], source_quote=w['source_text'], source_sha256=w['source_sha256'][:16]))
    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(), sorted(set(MAIN_MODELS) - {o['analysis'] for o in out})
    return sorted(out, key=lambda o: (MAIN_MODELS.index(o['analysis']), o['report']))


def af7():
    fac = []
    for r in recs(ROOT / 'FINAL_MME_CONVERSIONS.csv'):
        fac.append({k: tidy(v) for k, v in r.items()})
        fac[-1]['factor_mg_IV_morphine'] = num(r['factor_mg_IV_morphine'], None) if r['factor_mg_IV_morphine'] else 'None adopted'
    proh = [('Multiplying a group mean weight', 'To reconcile a weight-normalised dose (mg/kg) with an absolute dose: the within-group weight distribution is not recoverable.'),
            ('Multiplying an infusion duration', 'To turn a dose rate into a cumulative dose: the rate is not constant and the duration is rarely reported per participant.'),
            ('Converting pump volume to mass without a verified concentration', 'A volume of a mixed PCA solution does not determine the delivered opioid mass.'),
            ('Treating programmed doses or button presses as delivered dose', 'The registered outcome excludes programmed but undelivered doses.'),
            ('Summing separately reported rescue components into a total SD', 'The covariance between components is not published.')]
    inv = {r['result_id']: r for r in recs(C / 'all_40_result_inventory.csv')}
    app = collections.OrderedDict()
    for r in recs(R / 'e2/e2_model_inputs.csv') + recs(R / 'model_inputs.csv'):
        if not r.get('factor'):
            continue
        key = (r['study'], r['result_id'], r['factor'])
        e = app.setdefault(key, dict(study=r['study'], result_id=r['result_id'], factor=num(r['factor'], None),
                                     unit=inv.get(r['result_id'].split('+')[0], {}).get('unit', r.get('unit', '')), models=[]))
        e['models'].append(r['model_id'])
    app[('Wang 1997', 'WANG97-HM24', '5')] = dict(study='Wang 1997', result_id='WANG97-HM24', factor=5, unit='mg hydromorphone',
                                                 models=['E2_opioid24_TEAS_sham and its sensitivity analyses', 'E2_opioid24_TEAS_usual'])
    applied = [dict(e, models='; '.join(sorted(set(e['models'])))) for e in app.values()]
    for e in applied:
        u = e['unit'].lower()
        if e['study'] == 'Gu 2019':
            e['meaning'] = ('PCIA solution in mL digitised from Fig. 4; 1 mL contains 1 µg sufentanil (100 µg in 100 mL), so mL = µg '
                            'sufentanil; then the sufentanil factor (0.5, with 0.25 and 1.0 as bounds)')
        elif e['factor'] == 1 and 'morphine' in u:
            e['meaning'] = 'Identity: already mg IV morphine (or author morphine equivalents, sensitivity only)'
        elif e['factor'] == 1:
            e['meaning'] = 'Native units: not converted (analysed in the drug\'s own unit)'
        else:
            e['meaning'] = 'Converted to mg IV morphine with the register factor'
    applied.sort(key=lambda x: (x['study'], x['result_id'], str(x['factor'])))
    wb = new_wb(7, ['Opioid conversion factors, with their sources, and the factor applied to each result entering an opioid analysis.',
                    'The target unit is mg intravenous morphine, not oral morphine equivalents. Each factor multiplies both the mean '
                    'and the SD. Route and original unit were checked for every result. These are research standardisations, not '
                    'dosing instructions.',
                    'Timing: the factors were fixed on 20 September 2026, with trial results known; the registration anticipated '
                    'conversion rules but did not give the values.',
                    'Sufentanil: 0.5 mg IV morphine per µg is the central factor, with 0.25 and 1.0 as sensitivity bounds. It is a '
                    'research assumption: the '
                    'geometric midpoint of a published parenteral equivalence range for chronic dosing (10 mg parenteral morphine '
                    'to 10–40 µg sufentanil), chosen symmetrically on the ratio scale before the final fits; it is not a validated '
                    'constant for postoperative PCA. No result in the primary analysis needed it.',
                    'Opioids without a sourced factor (tramadol, pethidine, alfentanil, remifentanil, butorphanol, dezocine, '
                    'oxycodone, bucinnazine) were analysed in native units where routes, units and windows matched.'],
                [('Factors', 'Conversion register: every opioid encountered, including those with no factor adopted'),
                 ('Prohibited conversions', 'Conversions not made because they need quantities that were not reported'),
                 ('Applied to results', 'Factor applied to each result entering an opioid analysis, with the analyses it enters')],
                ['Source of the parenteral factors: British Columbia Ministry of Health, Palliative care equianalgesic table '
                 '(https://www2.gov.bc.ca/assets/gov/health/practitioner-pro/bc-guidelines/palliative2_-_pain_equianalgesic.pdf).',
                 'Analysis names: opioid24 = 0–24 h; E2 = broader first-day analysis; suf0.25/suf1 = sufentanil sensitivity factor.'])
    sheet(wb, 'Factors', fac, [('opioid', 'Opioid', 22), ('route', 'Route', 10), ('source_unit', 'Source unit', 12),
                               ('factor_mg_IV_morphine', 'Factor (mg IV morphine per source unit)', 16), ('source', 'Source', 40),
                               ('context', 'Context', 34), ('certainty', 'Certainty', 24), ('role', 'Role', 18), ('notes', 'Notes', 44)])
    sheet(wb, 'Prohibited conversions', [dict(a=a, b=b) for a, b in proh], [('a', 'Conversion not made', 44), ('b', 'Reason', 90)])
    sheet(wb, 'Applied to results', applied, [('study', 'Report', 22), ('result_id', 'Result ID(s)', 26), ('unit', 'Source unit', 16),
                                              ('factor', 'Factor applied', 12), ('meaning', 'What the factor does', 50), ('models', 'Analyses', 80)])
    return save(wb, 7, '.xlsx')


# ================================================================ Additional file 8: characteristics
T1COMP = {re.sub(r'\s*\[@[^\]]+\]', '', r[0]): r[8].replace('§', '') for r in list(csv.reader(open(REV / 'sources/table1_REVISED.csv', encoding='utf-8')))[1:]}


def af8():
    pcs = {r['report_id']: r for r in recs(C / 'protocol_characteristics.csv')}
    mod = {r['report_id']: r for r in recs(C / 'moderators_before24_descriptive.csv')}
    st = {r['report']: r for r in recs(FA / 'setting_mma_2026-10-24.csv')}
    frc = {r['report']: r for r in recs(R / 'forty_report_characteristics.csv')}
    assert set(pcs) == set(mod) == set(st) == set(frc) == set(REPORTS)
    rows = []
    for k in REPORTS:
        r = dict(pcs[k])
        r.update({f'm_{x}': mod[k][x] for x in ('timing_before24_category', 'planned_active_minutes_before24', 'before24_coding_note')})
        r.update({f's_{x}': v for x, v in st[k].items()})
        r['sha'] = frc[k]['source_sha256']
        if k == 'Szmit 2021':   # M11: stated definition has no time boundary; report §2.5.1, PDF p3
            assert r['s_mma_all_groups'] == 'No'
            r['s_mma_all_groups'] = 'Yes (corrected 2 Nov 2026)'
            r['s_non_opioid_components'] = 'Metamizole 1 g to every patient before the end of surgery; further metamizole 1 g if needed before PCA'
            r['s_mma_quote'] = 'For basic pain control, 1 g of metamizole was given to every patient before completion of the surgery.'
            r['s_mma_page'] = '3'
        r['comp_desc'] = T1COMP[k]
        rows.append(r)
    wc = {k: v['value'] for k, v in W97_CHAR.items()}
    rows.append(dict(report_id='Wang 1997', year='1997', trial_family='Wang 1997', country='USA', s_setting='Named hospital, level not stated',
                     s_setting_quote='101 ASA physical status I-II gynecological patients scheduled to undergo elective lower abdominal surgery were studied at Cedars-Sinai Medical Center in Los Angeles, CA.',
                     s_setting_page='407', modality='TEAS', comparator='Sham TAES (no current); PCA only', comparator_class='Sham; usual care',
                     comp_desc=T1COMP['Wang 1997'], randomized_n='101', analysed_n='101 (PCA only 26, sham 25, low 25, high 25)',
                     anaesthesia=wc['anaesthesia'], surgical_category='Gynecologic & Breast', procedure='Elective lower abdominal gynaecological surgery',
                     age='Mean 44, 44, 45, 43 y (PCA only, sham, low, high)', female='100%', bmi='Not extracted', asa='I–II',
                     intervention_arms='Low-intensity TAES 4–5 mA (25); high-intensity TAES 9–12 mA (25)',
                     control_arms='Sham TAES, no current (25); PCA only (26)', acupoints=wc['intervention'],
                     frequency='2/100 Hz, alternating every 3 s; hand and incision alternated every 6 s', intensity='4–5 mA or 9–12 mA',
                     timing=wc['timing'], sessions='30 min every 2 h while awake', session_duration='30 min',
                     cumulative_duration='Until patients could control pain with oral analgesics (p408); mean TAES use 35, 36 and 29 h in arms II–IV (Table 4, p410)',
                     m_timing_before24_category='Postoperative only', m_planned_active_minutes_before24='Not determinable from current source schedule',
                     m_before24_coding_note='Sessions while awake; planned schedule, not measured adherence.',
                     postoperative_analgesia=wc['postoperative_analgesia'],
                     pca_regimen='Hydromorphone 0.2 mg (>55 y) or 0.4 mg bolus on demand, lockout 10 min',
                     rescue_analgesia='IM hydromorphone 0.5–1 mg or meperidine 25–50 mg if PCA relief inadequate',
                     s_mma_all_groups='No', s_non_opioid_components='None routine during PCA (oral analgesics on demand only after PCA)',
                     s_mma_quote='After discontinuation of PCA, oral pain medications were administered on demand.', s_mma_page='406',
                     s_note=W97_NOTE + '; AI extraction, checked by SKP (reported 2 Nov 2026)', s_source_pdf=W97_PDF, sha=W97_SHA))
    for c in D3_CHAR:   # D3, 2 Nov 2026: AI extraction from the source PDFs; checked by SKP (reported 3 Nov 2026)
        sha = next(x['source_sha256'] for x in D3_RES.values() if x['report'] == c['report'])
        rows.append(dict(report_id=c['report'], year=c['report'][-4:], trial_family=c['report'], country=c['country'],
                         s_setting={'University': 'University or university-affiliated hospital'}.get(c['setting'], c['setting']),
                         s_setting_quote=c['setting_basis'], modality=c['modality'], comparator=c['comparator'],
                         comparator_class=c['comparator'], comp_desc=T1COMP[c['report']], randomized_n=c['n'].split(' ')[0],
                         analysed_n=c['analysed'], anaesthesia=c['anaesthesia'], surgical_category=c['surgery'], procedure=c['procedure'],
                         age='Mean ' + c['age'] + ' y (intervention/control)', female=c['female'] + '%', acupoints=c['acupoints'],
                         frequency=c['frequency'], timing=c['timing'], s_mma_all_groups=c['mma'], s_non_opioid_components=c['mma_basis'],
                         s_setting_page=c['setting_page'], bmi=c['bmi'], asa=c['asa'], intervention_arms=c['intervention_arms'],
                         control_arms=c['control_arms'], intensity=c['intensity'], sessions=c['sessions'], session_duration=c['session_duration'],
                         cumulative_duration=c['cumulative_duration'], m_timing_before24_category=c['timing_category'],
                         m_planned_active_minutes_before24=c['planned_minutes_24'], m_before24_coding_note=c['coding_note'],
                         postoperative_analgesia=c['postop_analgesia'], pca_regimen=c['pca'], rescue_analgesia=c['rescue'],
                         s_mma_quote=c['mma_quote'], s_mma_page=c['mma_page'],
                         s_note=f"{c['report']}, {D3_NOTE}; {c['design_note']}; AI extraction, checked by SKP (reported 3 Nov 2026)",
                         s_source_pdf=f"10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/{D3_PDF[c['report']]}.pdf", sha=sha))
    D7T = {r['report']: r for r in recs(REV / 'd7/d7_mma_timing.csv')}   # decision D7, 3 Nov 2026
    for r in rows:
        t = D7T.get(r['report_id'])
        assert bool(t) == str(r['s_mma_all_groups']).startswith('Yes'), r['report_id']
        r['s_mma_timing'] = f"{t['timing']}: {t['basis']}" if t else 'Not applicable (no routine multimodal analgesia in all groups)'
    assert [sum(r['s_mma_timing'].startswith(k) for r in rows) for k in ('Continues after surgery', 'Before or at the end of surgery only')] == [6, 8]
    eff = recs(C / 'dose_protocol_effect_directions.csv')
    for e in eff:
        if e['study'] == 'Lee 2011':   # m04: historical row; Lee 2011 held from all pooled analyses since 23 Oct 2026
            e['limitation'] = 'Historical: Lee 2011 is held from all pooled analyses (23 Oct 2026); shown for completeness. ' + e['limitation']
    for m, comp in (('E2_opioid24_TEAS_sham', 'sham'), ('E2_opioid24_TEAS_usual', 'usual care')):
        x = next(i for i in W97_IN if i['result_id'] == 'WANG97-HM24' and i['comparator'] == comp)
        y, se = float(x['yi']), float(x['vi']) ** 0.5
        eff.append(dict(model_id=m, study='Wang 1997', modality='TEAS', timing='Postoperative only',
                        minutes_before24='Not determinable from current source schedule', frequency='2/100 Hz, alternating every 3 s',
                        intensity='4–5 mA or 9–12 mA (arms combined)', effect=y, ci_low=y - 1.959964 * se, ci_high=y + 1.959964 * se,
                        descriptive_direction='Lower point estimate',
                        limitation='Added 2 Nov 2026 (decision D1). Completeness of the 24-h quantity is uncertain (supplemental doses not itemised). Descriptive association only; shared-arm comparisons must not be counted independently.'))
    for e in eff:
        for x in ('effect', 'ci_low', 'ci_high'):
            e[x] = num(e[x], 2)
    wb = new_wb(8, ['Study, participant, analgesic-regimen and stimulation-protocol characteristics of the 44 included reports, '
                    'with hospital setting and multimodal analgesia, and the descriptive protocol table that replaces the '
                    'registered meta-regression.',
                    'Values were extracted from the source PDFs with a page and verbatim quotation (setting and multimodal analgesia '
                    'quotations are given here). Study characteristics, stimulation protocols, setting and analgesic regimens were '
                    'checked by a second reviewer (SKP), including those of Wang 1997 (added and checked 2 Nov 2026) and those of Colak 2010, '
                    'Fu 2024 and Chen 2016 (added 2 Nov 2026, decision D3; checked 3 Nov 2026); the corrections of 2 Nov 2026 (Table 1 '
                    'values and comparator labels; Szmit 2021 multimodal analgesia) were checked on 3 Nov 2026.'],
                [('Characteristics', 'One row per report'),
                 ('Effect directions', 'Broader first-day opioid results by protocol characteristic (registered fallback for the meta-regression)')],
                ['Multimodal analgesia: a non-opioid analgesic or regional or local technique given routinely to all groups; drugs given only as rescue are not counted.',
                 'Decision D7 (JRNM, 3 Nov 2026; the timing split checked by SKP): the definition counts a routine non-opioid given at any '
                 'perioperative time. The timing column shows that it continued after surgery in 6 of the 14 multimodal reports and was '
                 'given only before or at the end of surgery in 8, including Szmit 2021.',
                 'Setting is as stated in the report.',
                 'Cumulative stimulation before 24 hours counts planned active stimulation only; stimulation after 24 hours is not counted.',
                 'Chen 2020 randomised 86 participants (Fig. 1 of the report), not the 80 given in its abstract and Table 1 (corrected 24 Oct 2026).',
                 'Zhou 2021 analgesia corrected on 24 Oct 2026: all included patients had epidural-assisted general anaesthesia.',
                 'Wang 1997 was added on 2 Nov 2026 (decision D1); its characteristics were extracted by the AI assistant and checked by SKP (reported 2 Nov 2026).',
                 'Szmit 2021 multimodal analgesia corrected on 2 Nov 2026 (No to Yes; checked by SKP, reported 3 Nov 2026): every patient received 1 g metamizole before the end of surgery. The stated definition counts routine non-opioid analgesia at any perioperative time; a keyword check of the other 39 reports found no similar omission.',
                 'Comparator arms (as in Table 1) gives the arms actually compared; for Wu 2016 the "sham" is identical current at non-acupoints (an active comparator), and Grech 2016 describes no sham procedure.',
                 'Lee 2011 (age 14–59 years), Chen 2016 (eligible ages 16–80 years), Jin 2023 (general anaesthesia not established) and Long 2025 (modality unclear) are retained but not pooled.',
                 'Colak 2010, Fu 2024 and Chen 2016 were added on 2 Nov 2026 (decision D3). Their rows give the fields extracted for the '
                 'decision (setting source, anaesthesia, regimen and stimulation protocol), completed on 3 Nov 2026 from the sources (arms, '
                 'intensity, sessions, analgesic and rescue regimens); "Not reported" means the report gives nothing. SKP checked them (reported 3 Nov 2026).'])
    sheet(wb, 'Characteristics', rows, [
        ('report_id', 'Report', 20), ('year', 'Year', 6), ('trial_family', 'Trial', 14), ('country', 'Country', 12),
        ('s_setting', 'Setting', 26), ('s_setting_quote', 'Setting: source text', 40), ('s_setting_page', 'Page', 6),
        ('modality', 'Modality', 9), ('comparator', 'Comparator (as extracted)', 30), ('comparator_class', 'Comparator class (extraction)', 12),
        ('comp_desc', 'Comparator arms (as in Table 1)', 22),
        ('randomized_n', 'N randomised', 10), ('analysed_n', 'N analysed', 14), ('anaesthesia', 'Anaesthesia', 24),
        ('surgical_category', 'Surgical category', 18), ('procedure', 'Procedure', 40), ('age', 'Age', 30), ('female', 'Female', 24),
        ('bmi', 'BMI', 20), ('asa', 'ASA', 24), ('intervention_arms', 'Intervention arm(s)', 26), ('control_arms', 'Control arm(s)', 22),
        ('acupoints', 'Acupoints', 30), ('frequency', 'Frequency', 24), ('intensity', 'Intensity', 30), ('timing', 'Timing', 34),
        ('sessions', 'Sessions', 18), ('session_duration', 'Session duration', 18), ('cumulative_duration', 'Cumulative duration', 30),
        ('m_timing_before24_category', 'Timing category (registered)', 20), ('m_planned_active_minutes_before24', 'Planned active minutes before 24 h', 12),
        ('m_before24_coding_note', 'Coding note', 40), ('postoperative_analgesia', 'Postoperative analgesia', 50), ('pca_regimen', 'PCA regimen', 40),
        ('rescue_analgesia', 'Rescue analgesia', 40), ('s_mma_all_groups', 'Multimodal analgesia in all groups', 12),
        ('s_non_opioid_components', 'Non-opioid components', 30),
        ('s_mma_timing', 'Timing of the routine non-opioid (decision D7)', 40), ('s_mma_quote', 'Multimodal analgesia: source text', 50), ('s_mma_page', 'Page', 6),
        ('s_note', 'Note', 40), ('s_source_pdf', 'Source file', 30), ('sha', 'Source SHA-256', 30)])
    sheet(wb, 'Effect directions', eff, [('model_id', 'Analysis', 24), ('study', 'Report', 20), ('modality', 'Modality', 9), ('timing', 'Timing', 24),
                                         ('minutes_before24', 'Minutes before 24 h', 10), ('frequency', 'Frequency', 20), ('intensity', 'Intensity', 24),
                                         ('effect', 'MD (mg IV MME)', 10), ('ci_low', '95% CI low', 10), ('ci_high', '95% CI high', 10),
                                         ('descriptive_direction', 'Direction', 20), ('limitation', 'Limitation', 50)])
    return save(wb, 8, '.xlsx')


# ================================================================ Additional file 10: RoB 2
def rob_units():
    link = {r['result_id']: r for r in recs(ROOT / 'FINAL_RESULT_ROB2_LINKAGE.csv')}
    exist = {r['assessment_id']: r for r in recs(ROOT / '10_FINAL_ADJUDICATION/02_DECISIONS/existing_rob2_assessments.csv')}
    dom = {}
    for f in (QOR / 'qor_rob2.csv', QOR / 'qor_rob2_later.csv', C / 'provisional_new_rob2_domains.csv'):
        for r in recs(f):
            dom[r['result_id']] = (f.name, r)
    six = {'CORRECTED-V34-020', 'AF26-GAO22-POSTLOCK-C', 'AF26-F-intra-005', 'AF26-SZMIT21-POSTLOCK', 'AF26-F-exposure-007', 'AF26-F-mixed/undefined-002'}
    reg25 = recs(C / 'second_review_2026-10-25.csv')
    five = set(re.findall(r'(?:CORRECTED-V34-\d+|AF26-[\w/-]+)', reg25[0]['scope']))
    assert len(five) == 5 and reg25[0]['outcome'] == 'all confirmed', five

    def linked_status(aid, signoff):
        if aid in six:
            return 'Second review SP, 2026-10-23 (confirmed)'
        return 'Second review SP, 2026-10-25 (confirmed)' if aid in five else signoff
    units = {}

    def add(key, study, rec, analysis, outcome, window, comparison, aid, status, rat):
        d = [rec[f'd{i}'] for i in range(1, 6)]
        assert all(x in ('Low', 'Some concerns', 'High') for x in d) and rec['overall'] in ('Low', 'Some concerns', 'High'), key
        u = units.setdefault(key, dict(key=key, study=study, d=d, overall=rec['overall'], analyses=set(), outcome=outcome, window=window,
                                       comparison=comparison, aid=aid, status=norm(status), rat=rat))
        u['analyses'].add(analysis)

    def rationale(r):
        out = {f'r{i}': r.get(f'd{i}_rationale', '') for i in range(1, 6)} | {'ro': r.get('overall_rationale', '')}
        if not any(out.values()):  # earlier assessments recorded judgements with a summary rationale only
            out['ro'] = r.get('provenance', '')
        return out

    def norm(s):
        s = s.replace('2026-09-28 (second review by SP: confirmed)', 'Second review SP, 2026-09-28 (confirmed)')
        s = re.sub(r'^SP, (\d{4}-\d\d-\d\d): confirmed$', r'Second review SP, \1 (confirmed)', s)
        if s.startswith('NOT INDEPENDENTLY DOCUMENTED'):
            s = '[CONFIRM: second review not documented in the project record]' + s[len('NOT INDEPENDENTLY DOCUMENTED'):]
        return s

    for b in recs(C / 'completion_bias_links.csv'):
        if b['overall'].startswith('UNLINKED'):
            continue
        if b['result_id'] in dom:
            src, r = dom[b['result_id']]
            st = r.get('decision_status') or r.get('reviewer', '')
            add(b['result_id'], b['study'], r, b['model_id'], r['outcome'], r['window'], r['comparison'], r['assessment_id'], st, rationale(r))
        else:
            lk = link[b['result_id']]
            ex = exist[lk['rob2_assessment_id']]
            assert [ex[f'd{i}'] for i in range(1, 6)] == [lk[f'd{i}'] for i in range(1, 6)], lk['rob2_assessment_id']
            st = linked_status(lk['rob2_assessment_id'], lk['human_final_signoff'])
            add(b['result_id'], b['study'], lk, b['model_id'], lk['outcome'], lk['timepoint'], lk['contrast'], lk['rob2_assessment_id'], st, rationale(ex))
    sup_models = collections.defaultdict(set)
    for s in recs(C / 'supplement_bias_links_2026-10-23.csv'):
        sup_models[s['result_id']].add(s['model_id'])
    for s in recs(C / 'supplement_rob2_domains_2026-10-23.csv'):
        for m in sorted(sup_models[s['result_id']]) or ['sensitivity']:
            add(s['result_id'], s['study'], s, m, s['outcome'], s['window'], s['comparison'], s['assessment_id'], s['decision_status'], rationale(s))
    for s in recs(CM / 'rob2_rescue_assessments.csv'):
        add(s['assessment_id'], s['report'], s, 'Rescue opioid receipt', s['outcome'], s['window'], s['comparison'], s['assessment_id'],
            s['human_signoff'], rationale(s))
    dose_sup = {s['result_id']: s for s in recs(R / 'dose_rob2_supplement_2026-10-23.csv')}
    for d in recs(R / 'dose_bias_linkage.csv'):
        if d['report'] == 'Lee 2011':
            continue
        first = d['result_ids'].split('+')[0]
        if first in dose_sup:
            s = dose_sup[first]
            add(d['result_ids'], d['report'], s, d['model_id'], s['outcome'], '', '', s['assessment_id'], s['decision_status'], rationale(s))
        else:
            lk = link[first]
            ex = exist[lk['rob2_assessment_id']]
            st = linked_status(lk['rob2_assessment_id'], lk['human_final_signoff'])
            add(d['result_ids'], d['report'], lk, d['model_id'], lk['outcome'], lk['timepoint'], lk['contrast'], lk['rob2_assessment_id'], st, rationale(ex))
    assert len(units) == 152, len(units)
    for s in recs(W97 / 'wang1997_rob2_DRAFT.csv'):   # D1, 2 Nov 2026: AI assessments; confirmed by SKP 2 Nov 2026
        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],
            s['decision_status'], rationale(s))
    assert len(units) == 164, len(units)
    for s in recs(REV / 'd3/d3_rob2_DRAFT.csv'):   # D3, 2 Nov 2026: AI assessments; confirmed by SKP 3 Nov 2026
        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],
            s['decision_status'], rationale(s))
    assert len(units) == 178, len(units)   # 169 + 9 D3 drafts added 3 Nov 2026
    for s in recs(REV / 'reaudit_d3/wang48_rob2_DRAFT.csv'):   # Wang 1997 pain at 48 h, 3 Nov 2026 (re-audit R05): AI assessments; confirmed by SKP 3 Nov 2026
        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],
            s['decision_status'], rationale(s))
    assert len(units) == 180, len(units)
    for rv in recs(C / 'rob2_revisions_2026-10-24.csv'):
        u = units[rv['result_id']]
        assert u['d'][2] in (rv['d3_previous'], rv['d3'])
        u['d'] = [rv[f'd{i}'] for i in range(1, 6)]
        u['rat']['r3'] = rv['d3_rationale']
        if 'D3 revised' in u['status']:  # updated in place in its home record
            u['status'] = u['status'].replace(' (see rob2_revisions_2026-10-24.csv)', '')
        else:
            u['status'] += f'; D3 revised 2026-10-24 ({rv["d3_previous"]} to {rv["d3"]}) after an external check of Fig 1; second review SP, 2026-10-24 (confirmed)'
        assert u['overall'] == rv['overall']
    return units


def af10():
    units = rob_units()
    LABEL = {'ALLCAUSE-HE-DEATH': 'All-cause death (harms)', 'ALLCAUSE-ESD-BLEED': 'Bleeding, all-cause (harms)',
             'HARMS-BURN-SKIN': 'Skin injury at electrode sites (harms)', 'SAT-YAO2015-GE8': 'Satisfaction score of 8 or more',
             'HARMS-ZHANG-ITCH': 'Itching at electrode sites (harms)', 'HARMS-ZHANG-RED': 'Redness at electrode sites (harms)',
             'QOR-ZHOU2025-POD3-AS-PRINTED': 'QoR-15 on postoperative day 3, as printed'}
    for u in units.values():
        if not u['outcome']:
            u['outcome'] = LABEL[u['key']] + ' [label added 2 Nov 2026]'
    rows = []
    for u in sorted(units.values(), key=lambda x: (x['study'], x['outcome'], x['key'])):
        rows.append(dict(key=u['key'], study=u['study'], outcome=u['outcome'], window=u['window'], comparison=u['comparison'],
                         analyses='; '.join(sorted(u['analyses'])), d1=u['d'][0], d2=u['d'][1], d3=u['d'][2], d4=u['d'][3], d5=u['d'][4],
                         overall=u['overall'], **u['rat'], aid=u['aid'], status=u['status']))
    levels = ('Low', 'Some concerns', 'High')
    summ = []
    for i, name in enumerate(['D1 Randomisation process', 'D2 Deviations from intended interventions', 'D3 Missing outcome data',
                              'D4 Measurement of the outcome', 'D5 Selection of the reported result', 'Overall']):
        c = collections.Counter(u['d'][i] if i < 5 else u['overall'] for u in units.values())
        summ.append(dict(domain=name, **{l: c[l] for l in levels}))
    fig = {r['domain']: r for r in recs(REV / 'd3/rob_domain_summary_d3.csv')}   # Fig. 3 rebuilt with Wang 1997 and the D3 assessments
    for s in summ:
        assert all(int(fig[s['domain']][l]) == s[l] for l in levels), s
    aids = {u['aid'] for u in units.values()}
    sig = []
    for r in recs(V38 / 'rob2_signalling_questions.csv'):
        if r['assessment_id'] in aids:
            sig.append(dict(aid=r['assessment_id'], study=r['study'], q=r['question_id'], sq=r['short_question'], a=r['answer'], j=r['justification']))
    for f in (QOR / 'qor_rob2_signals.csv', QOR / 'qor_rob2_signals_later.csv'):
        for r in recs(f):
            if r['assessment_id'] in aids:
                sig.append(dict(aid=r['assessment_id'], study=r['study'], q=r['question_id'], sq=r['short_question'], a=r['answer'], j=r['justification']))
    for r in recs(CM / 'rob2_rescue_signalling_questions.csv'):
        sig.append(dict(aid=r['assessment_id'], study=r['report'], q=r['question_id'], sq=r['short_question'], a=r['answer'], j=r['justification']))
    with_sig = {s['aid'] for s in sig}
    n_with = sum(u['aid'] in with_sig for u in units.values())
    for r in rows:
        r['sigrec'] = 'Recorded' if r['aid'] in with_sig else 'Not recorded (domain rationale only)'
    held = [dict(model=s['model_id'], result=s['result_id'], study=s['study'], reason=s['basis'])
            for s in recs(C / 'supplement_bias_links_2026-10-23.csv') if s['overall'].startswith('NOT ASSESSED')]
    held.append(dict(model='E2_opioid24_TEAS_sham', result='V33-OD-0184+V33-OD-0185', study='Lee 2011',
                     reason='Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years); not counted among the 180.'))
    held.append(dict(model='All analyses', result='CHEN16-*', study='Chen 2016',
                     reason='Included 2 Nov 2026 (decision D3) and held from all pooled analyses (eligible ages 16–80 years, as Lee 2011); its results were not assessed.'))
    held.append(dict(model='Descriptive only', result='FU24-VAS-T1, FU24-VAS-T2, FU24-VAS-T3', study='Fu 2024',
                     reason='Pain on postoperative days 1, 3 and 7 reported as medians (rest or movement not stated); not converted or pooled, so not assessed.'))
    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 180 results used in the analyses, with the rationale for each '
                     'domain, the signalling responses where they were recorded, and the second-review status.',
                     'Each combination of outcome, time window, comparison and analysis population was assessed separately. '
                     'Assessments were made by an AI assistant under the review team\'s delegation. A second reviewer (SKP) '
                     'checked and confirmed every assessment (below); a check is not '
                     'an independent duplicate assessment. The 12 '
                     'assessments for Wang 1997 (included 2 Nov 2026) were revised after an independent AI '
                     're-check (sham rescue receipt: measurement domain Low to Some concerns; two length-of-stay results added) and '
                     'confirmed by SKP on 2 Nov 2026. The 14 assessments for Colak 2010 and Fu 2024 (included 2 Nov 2026, decision D3; '
                     'nine added on 3 Nov 2026 after an independent AI audit, for their results at later time points and Colak\'s '
                     '7-day analgesic totals) were made by the AI assistant. After an independent AI re-audit (3 Nov 2026), the '
                     'Fu 2024 randomisation judgements (all five results) and QoR-15 measurement judgements (three) were revised from Low to Some '
                     'concerns, for consistency with confirmed assessments of similar reports (Xiong 2021; Gu 2019 and Yao 2015), and two '
                     'assessments were added for Wang 1997\'s pain at 48 hours, a sensitivity result earlier listed as not assessed; Yu 2020\'s '
                     '48-hour pain had been assessed (V33-OD-0368). SKP confirmed all 16 on 3 Nov 2026. Every result used in an analysis is '
                     'assessed, including sensitivity results; transcription variants of one result (Yu 2020\'s two SDs) share one '
                     'assessment; results held from synthesis or reported only descriptively are not (rule confirmed by JRNM and SKP, '
                     '3 Nov 2026). The four trials added only in the post-hoc D6 refits (Liu 2021, Xing 2022, Zheng 2025, Lu 2021) were not '
                     're-assessed: their assessments from the 70-report review (second review SP, 28 Sep 2026) are in sheet '
                     '"D6 what-if trials" and are not among the 180.'],
                 [('Judgements', 'One row per assessed result (180), with domain judgements and rationales'),
                  ('Domain summary', 'Counts by domain (Fig. 3, panel B)'),
                  ('Signalling questions', f'Signalling responses recorded for {n_with} of the 180 results'),
                  ('Not assessed', 'Results held from synthesis or reported only descriptively, which were not assessed'),
                  ('D6 what-if trials', 'Earlier assessments (70-report review, second review SP 28 Sep 2026) of the five results that the post-hoc D6 refits added')],
                 ['D1, randomisation process; D2, deviations from intended interventions; D3, missing outcome data; D4, measurement '
                  'of the outcome; D5, selection of the reported result.',
                  'Signalling responses were recorded separately only for some assessments; for the others the domain rationale '
                  'gives the basis. Eleven earlier assessments recorded domain judgements with a summary rationale only, given '
                  'in the Overall rationale column.',
                  'Five earlier assessments used in the broader first-day dose analysis (Chen 1998, Chen 2020, He 2026 '
                  '(hepatectomy), Lin 2002 versus sham, Yang 2024) were second-reviewed on 25 Oct 2026.',
                  'Where one result row combines arms (for example Lin 2002, "A+B"), the arms were combined in the analysis and '
                  'assessed as one result.',
                  'Two Chen 2020 results had the missing-data domain revised on 24 Oct 2026 after an external check of the trial\'s '
                  'Fig. 1 (86 randomised, 80 analysed).'])
    sheet(wb, 'Judgements', rows, [('key', 'Result ID', 16), ('study', 'Report', 20), ('outcome', 'Outcome', 34), ('window', 'Window', 14),
                                   ('comparison', 'Comparison', 22), ('analyses', 'Analyses', 34), ('d1', 'D1', 12), ('d2', 'D2', 12),
                                   ('d3', 'D3', 12), ('d4', 'D4', 12), ('d5', 'D5', 12), ('overall', 'Overall', 12),
                                   ('r1', 'D1 rationale', 50), ('r2', 'D2 rationale', 50), ('r3', 'D3 rationale', 50), ('r4', 'D4 rationale', 50),
                                   ('r5', 'D5 rationale', 50), ('ro', 'Overall rationale', 50), ('aid', 'Assessment ID', 24),
                                   ('sigrec', 'Signalling responses', 18),
                                   ('status', 'Assessor and second review', 40)])
    sheet(wb, 'Domain summary', summ, [('domain', 'Domain', 40), ('Low', 'Low', 10), ('Some concerns', 'Some concerns', 14), ('High', 'High', 10)])
    sheet(wb, 'Signalling questions', sig, [('aid', 'Assessment ID', 24), ('study', 'Report', 20), ('q', 'Question', 8),
                                            ('sq', 'Signalling question', 50), ('a', 'Answer', 10), ('j', 'Justification', 90)])
    sheet(wb, 'Not assessed', held, [('model', 'Analysis', 30), ('result', 'Result ID', 24), ('study', 'Report', 18), ('reason', 'Reason', 80)])
    v38 = {r['result_id']: r for r in recs(ROOT / '10_FINAL_ADJUDICATION/02_DECISIONS/v38/rob2_assessments.csv')}   # Astra, 4 Nov 2026
    d6l = [dict(v38[rid], used='D6 what-if: ' + x['model_id']) for x in recs(REV / 'd6/d6_inputs.csv')
           if x['origin'] != 'review model inputs' for rid in x['result_id'].split('+')]
    assert len(d6l) == 5 and all(r['reviewer'].endswith('second review SP, 2026-09-28 (confirmed)') for r in d6l), [r['result_id'] for r in d6l]
    sheet(wb, 'D6 what-if trials', d6l, [('result_id', 'Result ID', 16), ('study', 'Report', 14), ('outcome', 'Outcome', 24),
          ('used', 'Used in', 30), ('assessment_id', 'Assessment ID', 20), ('d1', 'D1', 13), ('d2', 'D2', 13), ('d3', 'D3', 13),
          ('d4', 'D4', 13), ('d5', 'D5', 13), ('overall', 'Overall', 13), ('overall_rationale', 'Overall rationale', 60),
          ('reviewer', 'Assessor and second review', 40)])
    return save(wb, 10, '.xlsx'), len(sig)


# ================================================================ Additional file 11: GRADE
def af11():
    grade = {r['model_id']: r for r in recs(ROOT / '10_FINAL_ADJUDICATION/03_CANONICAL/grade.csv')}
    mr = {r['model_id']: r for r in recs(R / 'model_results.csv')}
    prim = []
    for m, lab in (('opioid24_TEAS_sham', 'TEAS vs sham'), ('opioid24_EA_sham', 'EA vs sham'),
                   ('opioid24_TEAS_usual', 'TEAS vs usual care'), ('opioid24_EA_usual', 'EA vs usual care')):
        g, e = grade[m], mr[m]
        prim.append(dict(model=m, comp=lab, k=e['k'], n=e['N'], eff=num(e['effect'], 2), lo=num(e['ci_low'], 2), hi=num(e['ci_high'], 2),
                         cert=g['certainty'], rob=g['risk_of_bias'], inc=g['inconsistency'], ind=g['indirectness'], imp=g['imprecision'],
                         pub=g['publication_bias'], rd=g['risk_of_bias_downgrades'], idn=g['inconsistency_downgrades'],
                         nd=g['indirectness_downgrades'], md=g['imprecision_downgrades'], pd=g['publication_bias_downgrades'], status=g['reviewer']))
    exp = []
    for g in recs(C / 'provisional_expanded_dose_grade.csv'):
        exp.append(dict(model=g['model_id'], k=g['k'], n=g['N'], eff=num(g['effect'], 2), lo=num(g['ci_low'], 2), hi=num(g['ci_high'], 2),
                        cert=g['certainty'], rd=g['risk_of_bias_downgrades'], idn=g['inconsistency_downgrades'], nd=g['indirectness_downgrades'],
                        md=g['imprecision_downgrades'], pd=g['publication_bias_downgrades'], reason=g['reason'], status=g['status']))
    resc = []
    for g in recs(CM / 'grade_rescue_evidence_profile.csv'):
        lo = float(g['ci_low'])
        resc.append(dict(g, effect=num(g['effect'], 2), ci_low=float(f'{lo:.3g}') if lo < 0.01 else num(lo, 2), ci_high=num(g['ci_high'], 2)))
    oth = []
    for g in recs(C / 'provisional_grade.csv'):
        oth.append(dict(model=g['model_id'], label=g['label'], k=g['k'], n=num(g['N'], 0), eff=num(g['effect'], 2), lo=num(g['ci_low'], 2),
                        hi=num(g['ci_high'], 2), cert=g['certainty'], rd=g['risk_of_bias_downgrades'], idn=g['inconsistency_downgrades'],
                        nd=g['indirectness_downgrades'], md=g['imprecision_downgrades'], pd=g['publication_bias_downgrades'],
                        pub=g['publication_bias'], reason=g['reason'], status=g['status']))
    d3g = recs(REV / 'd3/d3_grade_DRAFT.csv')   # D3, 2 Nov 2026: AI assessments, confirmed by SKP 3 Nov 2026
    D3_GRADE = {g['model_id'] for g in d3g}
    wdr = []
    for g in recs(W97 / 'wang1997_grade_DRAFT.csv'):
        # the confirmed rescue profile rated the six-trial body; with Fu 2024 that body is RESCUE_LOO_Fu_2024
        x = W97_MOD['RESCUE_LOO_Fu_2024' if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP' else g['model_id']]
        ab = ''
        if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':   # control risk = pooled sham events / sham participants (96/267)
            cr = 96 / 267
            ab = (f'Control {1000 * cr:.0f} per 1,000; with TEAS {1000 * cr * float(x["effect"]):.0f} '
                  f'({1000 * cr * float(x["ci_low"]):.0f} to {1000 * cr * float(x["ci_high"]):.0f}) per 1,000')
        wdr.append(dict(model=g['model_id'], target=g['target'], k=x['k'], n=x['N'], eff=num(x['effect'], 2), lo=num(x['ci_low'], 2),
                        hi=num(x['ci_high'], 2), cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'],
                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'],
                        version='Superseded by decision D3 (Fu 2024 added): current profile in sheet "With Colak and Fu"' if g['model_id'] in D3_GRADE else 'Current'))
    ddr = []
    for g in d3g:
        x = W97_MOD[g['model_id']]
        ab = ''
        if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':   # control risk = pooled sham events / sham participants (102/296)
            cr = 102 / 296
            ab = (f'Control {1000 * cr:.0f} per 1,000; with TEAS {1000 * cr * float(x["effect"]):.0f} '
                  f'({1000 * cr * float(x["ci_low"]):.0f} to {1000 * cr * float(x["ci_high"]):.0f}) per 1,000')
        ddr.append(dict(model=g['model_id'], target=g['target'], k=x['k'], n=x['N'], eff=num(x['effect'], 2), lo=num(x['ci_low'], 2),
                        hi=num(x['ci_high'], 2), cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'],
                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'], version='Current'))
    SUPER = {d['model'] for d in wdr}
    SUP_TXT = 'Superseded: profile for the membership before Wang 1997. Current profile: sheet "With Wang 1997"'
    RESC_SUP = {'TEAS/sham: each trial postoperative follow-up': 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'TEAS/sham: approximate first day': 'RESCUE_TEAS_SHAM_FIRST_DAY_APPROX'}
    for rows_, key in ((prim, 'model'), (exp, 'model'), (oth, 'model')):
        for r in rows_:
            r['version'] = SUP_TXT if r[key] in SUPER else 'Current'
    for r in resc:
        r['version'] = SUP_TXT if RESC_SUP.get(r['outcome_comparison']) in SUPER else 'Current'
    for rows_ in (prim, exp, oth):   # D3: earlier profiles of the bodies that Colak 2010 or Fu 2024 enter
        for r in rows_:
            if r['model'] in D3_GRADE and r['version'] == 'Current':
                r['version'] = 'Superseded: profile before decision D3 (2 Nov 2026). Current profile: sheet "With Colak and Fu"'
    for r in oth:   # decision D6, 3 Nov 2026 (JRNM and SKP, all authors agreeing)
        if r['model'] == 'pain24_rest_TEAS_sham':
            assert r['cert'] == 'Moderate' and str(r['md']) == '0', (r['cert'], r['md'])
            r.update(cert='Low', md='1', reason=r['reason'] + ' Decision D6 (3 Nov 2026): one level for imprecision (one trial of '
                     '60 participants, below the about 70 needed to detect a 1-point difference with SD 1.5). With the two rest-pain '
                     'trials removed by the opioid-result requirement, MD -0.21 (-0.75 to 0.33) in a post-hoc what-if; not '
                     'downgraded for selection.', status=r['status'] + '; revised 3 Nov 2026 by decision D6 (JRNM and SKP, all '
                     'authors agreeing): Moderate to Low')
        if r['model'] == 'ponv24_TEAS_sham':
            r['reason'] += (' Decision D6 (3 Nov 2026): with the two trials removed by the opioid-result requirement, RR 0.63 '
                            '(0.51 to 0.77) in a post-hoc what-if; not downgraded for selection.')
    d6w = recs(REV / 'd6/d6_scenarios.csv')
    wb = new_wb(11, ['GRADE evidence profiles for each outcome and comparison, with the reasons for downgrading.',
                     'Randomised evidence started at high certainty and was downgraded for risk of bias, inconsistency, '
                     'indirectness, imprecision or publication bias; no body was upgraded. Downgrades rest on explicit domain '
                     'reasoning, not on I² or P-value thresholds. A single-trial body was not downgraded for inconsistency. '
                     'Imprecision was judged against the 10 mg opioid threshold and the 1-point pain margin. Sensitivity analyses '
                     'other than the broader first-day analysis were not graded.',
                     'Assessments were made by an AI assistant under the review team\'s delegation and checked and confirmed by '
                     'a second reviewer (SKP); the profiles in sheet "With Wang 1997" were confirmed on 2 Nov 2026 and those in sheet '
                     '"With Colak and Fu" on 3 Nov 2026. Where one '
                     'exists, the corresponding pre-Wang row in the other sheets is marked "Superseded" in its Version column.'],
                 [('Primary outcome', 'All delivered systemic opioid, 0–24 h (registered construct)'),
                  ('Broader first-day dose', 'Broader first-day opioid consumption (post-hoc sensitivity analysis)'),
                  ('Rescue opioid receipt', 'Receipt of additional rescue opioid, with absolute effects'),
                  ('Other outcomes', 'Pain, nausea and vomiting, recovery, gastrointestinal and other outcomes, including empty comparisons'),
                  ('With Wang 1997', 'Current profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026): revised after an independent AI re-check and confirmed by SKP on 2 Nov 2026'),
                  ('With Colak and Fu', 'Current profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): revised after independent AI audits and confirmed by SKP on 3 Nov 2026'),
                  ('Selection what-ifs (D6)', 'Post-hoc what-ifs for decision D6 (3 Nov 2026): rest pain and PONV, TEAS vs sham, with the trials the '
                                             'opioid-result requirement removed; not results of the review and not graded')],
                 ['Downgrade columns give the number of levels (0, 1 or 2) for each domain.',
                  'MD, mean difference (mg IV morphine equivalents for opioid outcomes); RR, risk ratio.',
                  'The broader first-day TEAS-versus-sham profile was updated on 24 Oct 2026 for the Lee 2011 hold (6 trials, 547 participants); certainty unchanged.',
                  'The rescue profile in sheet "With Wang 1997" rated the six-trial body that SKP confirmed before Fu 2024 was added; its numbers are that body (RESCUE_LOO_Fu_2024). The seven-trial profile is in sheet "With Colak and Fu".'])
    dn = [('rd', 'Risk of bias (levels)', 10), ('idn', 'Inconsistency (levels)', 10), ('nd', 'Indirectness (levels)', 10),
          ('md', 'Imprecision (levels)', 10), ('pd', 'Publication bias (levels)', 10)]
    sheet(wb, 'Primary outcome', prim, [('model', 'Analysis', 22), ('comp', 'Comparison', 18), ('k', 'Trials', 7), ('n', 'Participants', 10),
                                         ('eff', 'MD', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9), ('cert', 'Certainty', 16)] + dn +
          [('rob', 'Risk of bias', 45), ('inc', 'Inconsistency', 40), ('ind', 'Indirectness', 40), ('imp', 'Imprecision', 45),
           ('pub', 'Publication bias', 45), ('status', 'Assessor and second review', 30), ('version', 'Version', 40)])
    sheet(wb, 'Broader first-day dose', exp, [('model', 'Analysis', 24), ('k', 'Trials', 7), ('n', 'Participants', 10), ('eff', 'MD', 8),
                                              ('lo', '95% CI low', 9), ('hi', '95% CI high', 9), ('cert', 'Certainty', 12)] + dn +
          [('reason', 'Reasons', 60), ('status', 'Assessor and second review', 50), ('version', 'Version', 40)])
    sheet(wb, 'Rescue opioid receipt', resc, [('outcome_comparison', 'Analysis', 34), ('reports', 'Reports', 40), ('trials', 'Trials', 7),
                                              ('analyzed_N', 'Participants', 10), ('events_i', 'Events, intervention (TEAS or EA)', 9), ('n_i', 'N, intervention', 8),
                                              ('events_c', 'Events, control', 9), ('n_c', 'N, control', 8), ('effect_measure', 'Measure', 8),
                                              ('effect', 'Effect', 8), ('ci_low', '95% CI low', 9), ('ci_high', '95% CI high', 9),
                                              ('risk_of_bias_deduction', 'Risk of bias (levels)', 10), ('risk_of_bias_reason', 'Risk of bias', 45),
                                              ('inconsistency_deduction', 'Inconsistency (levels)', 10), ('inconsistency_reason', 'Inconsistency', 40),
                                              ('indirectness_deduction', 'Indirectness (levels)', 10), ('indirectness_reason', 'Indirectness', 40),
                                              ('imprecision_deduction', 'Imprecision (levels)', 10), ('imprecision_reason', 'Imprecision', 40),
                                              ('publication_bias_deduction', 'Publication bias (levels)', 10), ('publication_bias_reason', 'Publication bias', 40),
                                              ('final_certainty', 'Certainty', 12), ('illustrative_control_per_1000', 'Control risk per 1000', 10),
                                              ('corresponding_intervention_per_1000', 'Intervention risk per 1000', 10), ('corresponding_low_per_1000', 'Low', 8),
                                              ('corresponding_high_per_1000', 'High', 8), ('absolute_risk_note', 'Absolute risk note', 40),
                                              ('assessor', 'Assessor and second review', 40), ('version', 'Version', 40)])
    sheet(wb, 'Other outcomes', oth, [('model', 'Analysis', 30), ('label', 'Label', 30), ('k', 'Trials', 7), ('n', 'Participants', 10),
                                      ('eff', 'Effect', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9), ('cert', 'Certainty', 16)] + dn +
          [('reason', 'Reasons', 60), ('pub', 'Publication bias', 40), ('status', 'Assessor and second review', 40), ('version', 'Version', 40)])
    sheet(wb, 'With Wang 1997', wdr, [('model', 'Analysis', 30), ('target', 'Target of the rating', 40), ('k', 'Trials', 7),
                                              ('n', 'Participants', 10), ('eff', 'Effect', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9),
                                              ('cert', 'Certainty', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('ab', 'Absolute effect (illustrative)', 36),
           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])
    sheet(wb, 'With Colak and Fu', ddr, [('model', 'Analysis', 30), ('target', 'Target of the rating', 40), ('k', 'Trials', 7),
                                 ('n', 'Participants', 10), ('eff', 'Effect', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9),
                                 ('cert', 'Certainty', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('ab', 'Absolute effect (illustrative)', 36),
           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])
    sheet(wb, 'Selection what-ifs (D6)', d6w, [('scenario', 'Scenario', 9), ('assumption', 'Assumption', 60), ('k', 'Trials', 7),
          ('N', 'Participants', 10), ('measure', 'Measure', 10), ('effect', 'Effect', 8), ('ci_low', '95% CI low', 9),
          ('ci_high', '95% CI high', 9), ('I2', 'I² (%)', 7), ('reports', 'Reports', 60)])
    return save(wb, 11, '.xlsx')


# ================================================================ Additional file 12: additional and sensitivity results
def st_empty(st):
    return st.startswith(('NO ELIGIBLE', 'Empty'))


def af12():
    lee = {r['model_id']: r for r in recs(R / 'lee_hold_rerun_2026-10-23.csv')}
    rep = {r['model_id']: r for r in recs(REV / 'reproduce/reproduced_final_estimates.csv') if r['set'] == 'lee_hold_refit'}
    assert set(rep) == set(lee)
    for m in lee:
        lee[m]['tau2'] = rep[m]['tau2']   # tau2 from reproduce_final.R (same estimator); not stored by the refit
    dose = {r['model_id']: r for r in recs(R / 'dose_restriction_rerun_2026-10-23.csv')}
    superseded = {'E2_TEAS_sham_leaveout_Lee2011', 'E2_TEAS_sham_LOO_Lee_2011'}
    op = []
    for r in recs(R / 'model_results.csv'):
        m = r['model_id']
        row = dict(model=m, family=r['outcome_family'], analysis=r['analysis'], measure=r['effect_measure'], k=r['k'], n=r['N'],
                   eff=r['effect'], lo=r['ci_low'], hi=r['ci_high'], pil=r['pi_low'], pih=r['pi_high'], tau2=r['tau2'], i2=r['I2'],
                   reports=r['reports'], status=r['status'], post_hoc=r['post_hoc'], role=r['original_role'], note='')
        if m in lee:
            x = lee[m]
            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'],
                       i2=x['I2'], reports=x['reports'], note='Refitted without Lee 2011, which is held from all pooled analyses (23 Oct 2026)')
        elif m in superseded:
            row['note'] = 'Superseded: identical to the main broader first-day analysis after the Lee 2011 hold, before Wang 1997 was added (2 Nov 2026)'
        elif m == 'opioid_partial_TEAS_sham':
            row['note'] = 'Lee 2011 only; shown as a single-trial estimate, not pooled (Lee 2011 held: participants aged 14–59 years)'
        elif m in dose:
            x = dose[m]
            row.update(k=x['k_after'], n=x['N_after'], eff=x['effect_after'], lo=x['ci_low_after'], hi=x['ci_high_after'],
                       tau2=x['tau2_after'], reports=x['reports_after'])
            if x['changed'].strip().lower() in ('true', 'yes', '1'):
                row['note'] = 'Refitted 23 Oct 2026 after the remaining dose results were assessed for risk of bias'
        if m in W97_MOD:   # D1, 2 Nov 2026: refitted with Wang 1997 (wang1997/refit_with_wang.R)
            x = W97_MOD[m]
            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'],
                       tau2=x['tau2'], i2=x['I2'], reports=x['reports'],
                       note=(row['note'] + '; ' if row['note'] else '') + ('Refitted with Wang 1997 (included 2 Nov 2026)' if 'Wang 1997' in x['reports']
                                                                          else 'Unchanged: Wang 1997 excluded by this analysis\'s rule'))
            if 'Fu 2024' in x['reports']:   # D3, 2 Nov 2026
                row['note'] += '; refitted with Fu 2024 (decision D3, 2 Nov 2026)'
            elif 'Fu 2024 not eligible' in x['description']:
                row['note'] += '; Fu 2024 (decision D3) not eligible: follow-up not stated'
            if m.startswith('opioid24_TEAS_sham_expanded'):   # re-check M03
                row['note'] += ('. Legacy construct (device or uncertain-capture 0-24-h quantity, before amendment E2.1), kept as a '
                                'sensitivity analysis; with Wang 1997 the central-factor model equals E2_TEAS_sham_excl_E2.1, and the '
                                'three models without Chen 2020 are identical because no sufentanil result remains')
            for c in ('eff', 'lo', 'hi'):
                row[c] = '' if row[c] == 'NA' else row[c]
            for c in ('pil', 'pih', 'tau2', 'i2'):
                row[c] = '' if row[c] == 'NA' else row[c]
        if 'Lee 2011' in row['reports'] and not row['note']:
            raise AssertionError(m)
        for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
            row[c] = num(row[c], dp)
        op.append(row)
    for m in ('E2_TEAS_sham_LOO_Wang_1997', 'E2_WANG_1997_SHAM_SINGLE', 'RESCUE_LOO_Wang_1997', 'RESCUE_TEAS_USUAL'):
        x = W97_MOD[m]
        row = dict(model=m, family='Broader first-day opioid' if m.startswith('E2') else 'Rescue opioid receipt', analysis=x['description'],
                   measure='MD' if m.startswith('E2') else 'RR', k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'],
                   pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'], reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)',
                   post_hoc='Yes', role='Added 2 Nov 2026', note='Added with Wang 1997 (decision D1)' + ('; includes Fu 2024 (decision D3)' if 'Fu 2024' in x['reports'] else ''))
        for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
            row[c] = '' if row[c] == 'NA' else num(row[c], dp)
        op.append(row)
    have = {r['model'] for r in op}
    for m, x in W97_MOD.items():   # re-check: every remaining Wang-era opioid model not already shown
        if m in have or m in D3_MOD or not m.startswith(('E2', 'RESCUE', 'opioid')):
            continue
        row = dict(model=m, family='Broader first-day opioid' if m.startswith('E2') else 'Rescue opioid receipt', analysis=x['description'],
                   measure='MD' if m.startswith('E2') else 'RR', k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'],
                   pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'], reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)',
                   post_hoc='Yes', role='Added 2 Nov 2026', note='Added after the re-check of the Wang 1997 inclusion')
        for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
            row[c] = '' if row[c] == 'NA' else num(row[c], dp)
        op.append(row)
    x = W97_MOD['RESCUE_LOO_Fu_2024']   # D3, 2 Nov 2026
    row = dict(model='RESCUE_LOO_Fu_2024', family='Rescue opioid receipt', analysis=x['description'], measure='RR', k=x['k'], n=x['N'],
               eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'],
               reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)', post_hoc='Yes', role='Added 2 Nov 2026',
               note='Added with Fu 2024 (decision D3): the earlier six-trial estimate with Wang 1997')
    for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
        row[c] = '' if row[c] == 'NA' else num(row[c], dp)
    op.append(row)
    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']
    assert (main['k'], main['n'], main['eff'], main['lo'], main['hi']) == ('7', '622', -7.221, -14.126, -0.316), main
    oth = []
    for r in recs(C / 'model_results_python.csv'):
        r = dict(r)
        if r['model_id'] in W97_MOD:   # D1, 2 Nov 2026
            x = W97_MOD[r['model_id']]
            r.update(k=x['k'], N=x['N'], effect=x['effect'].replace('NA', ''), ci_low=x['ci_low'].replace('NA', ''), ci_high=x['ci_high'].replace('NA', ''), pi_low=x['pi_low'].replace('NA', ''),
                     pi_high=x['pi_high'].replace('NA', ''), tau2=x['tau2'].replace('NA', ''), I2=x['I2'].replace('NA', ''),
                     reports=x['reports'].replace('; ', ';'), note=(r['note'] + ' ' if r['note'] else '') + ('Refitted with Fu 2024 (decision D3, 2 Nov 2026).' if r['model_id'] in D3_MOD else 'Refitted with Wang 1997 (included 2 Nov 2026).'))
        oth.append(dict(model=r['model_id'], label=r['label'], role=r['role'].title(), family=r['family'], measure=r['measure'], unit=r['unit'],
                        k=r['k'], n=r['N'], eff=num(r['effect']), lo=num(r['ci_low']), hi=num(r['ci_high']), pil=num(r['pi_low']),
                        pih=num(r['pi_high']), tau2=num(r['tau2'], 4), i2=num(r['I2'], 1), status=r['status'], reports=r['reports'],
                        parent=r['parent_model_id'], basis=r['basis'], note=r['note']))
    for m, lab, fam, meas, unit in (('pain24_unclassified_TEAS_usual', 'Pain at 24 h, rest or movement not stated, TEAS vs usual care', 'pain', 'MD', 'points (0-10)'),
                                    ('nausea24_TEAS_usual', 'Nausea 0-24 h, TEAS vs usual care', 'nausea', 'RR', 'risk ratio'),
                                    ('pain24_WANG_1997_SHAM_SINGLE', 'Wang 1997 pain at 24 h vs sham (paired with its broader dose result)', 'pain', 'MD', 'points (0-10)')):
        x = W97_MOD[m]
        oth.append(dict(model=m, label=lab, role='Sensitivity' if 'pain' in m else 'Additional', family=fam, measure=meas, unit=unit, k=x['k'],
                        n=x['N'], eff=num(x['effect']), lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='', i2='',
                        status='Single trial, normal interval', reports=x['reports'], parent='', basis='Wang 1997 (included 2 Nov 2026)',
                        note='Added with Wang 1997 (decision D1)'))
    have = {r['model'] for r in oth} | {r['model'] for r in op}
    for m, x in W97_MOD.items():   # re-check (M04, M05): nausea and vomiting diagnostics, low-risk-only cells, single-trial results
        if m in have or m in D3_MOD:
            continue
        rr = m.startswith(('nausea', 'vomiting'))
        role = 'Diagnostic' if ('_LOO_' in m or m.endswith(('NOT_HIGH_LINKED', 'LOW_ONLY'))) else ('Sensitivity' if 'PAIN48' in m else 'Additional')
        oth.append(dict(model=m, label=x['description'], role=role, family='nausea' if m.startswith('nausea') else 'vomiting' if m.startswith('vomiting')
                        else 'length_of_stay' if 'LOS' in m else 'pain', measure='RR' if rr else 'MD',
                        unit='risk ratio' if rr else 'days' if 'LOS' in m else 'points (0-10)', k=x['k'], n=x['N'],
                        eff='' if x['effect'] == 'NA' else num(x['effect']),
                        lo='' if x['ci_low'] == 'NA' else num(x['ci_low']), hi='' if x['ci_high'] == 'NA' else num(x['ci_high']),
                        pil='', pih='', tau2='' if x['tau2'] == 'NA' else num(x['tau2'], 4), i2='' if x['I2'] == 'NA' else num(x['I2'], 1),
                        status='Empty: no low-risk result' if x['k'] == '0' else ('Single trial, normal interval' if x['k'] == '1' else 'REML + Hartung-Knapp (floored at 1)'),
                        reports=x['reports'], parent='', basis='Wang 1997 re-check (2 Nov 2026)', note=x['description']))
    have = {r['model'] for r in oth} | {r['model'] for r in op}
    D3_OTH = {'pain24_rest_EA_usual': ('Pain at rest at about 24 h, EA vs usual care', 'Additional', 'pain_rest_approximately24h', '0–10 points', ''),
              'QoR15_SHAM_24H_LOO_Fu_2024': ('QoR-15: TEAS vs sham 24H; omit Fu 2024', 'Diagnostic', 'quality_of_recovery', 'QoR-15 points', 'QoR15_SHAM_24H')}
    for m, (lab, role, fam, unit, parent) in D3_OTH.items():   # D3, 2 Nov 2026
        x = W97_MOD[m]
        oth.append(dict(model=m, label=lab, role=role, family=fam, measure='MD', unit=unit, k=x['k'], n=x['N'], eff=num(x['effect']),
                        lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='' if x['tau2'] == 'NA' else num(x['tau2'], 4),
                        i2='' if x['I2'] == 'NA' else num(x['I2'], 1),
                        status='Single trial, normal interval' if x['k'] == '1' else 'REML + Hartung-Knapp (floored at 1)',
                        reports=x['reports'], parent=parent, basis='Decision D3 (2 Nov 2026)', note=x['description']))
    D3_AUD = {'COLAK_PAIN_DAY2_EA_USUAL': ('Colak 2010: pain at rest on day 2 (about 48 h), EA vs usual care', 'pain_rest_day2', '0–10 points'),
              'COLAK_PAIN_DAY3_EA_USUAL': ('Colak 2010: pain at rest on day 3 (about 72 h), EA vs usual care', 'pain_rest_day3', '0–10 points'),
              'COLAK_PAIN_DAY4_EA_USUAL': ('Colak 2010: pain at rest on day 4, EA vs usual care', 'pain_rest_day4', '0–10 points'),
              'COLAK_PAIN_DAY5_EA_USUAL': ('Colak 2010: pain at rest on day 5, EA vs usual care', 'pain_rest_day5', '0–10 points'),
              'COLAK_PAIN_DAY6_EA_USUAL': ('Colak 2010: pain at rest on day 6, EA vs usual care', 'pain_rest_day6', '0–10 points'),
              'COLAK_PAIN_DAY7_EA_USUAL': ('Colak 2010: pain at rest on day 7 (longest reported), EA vs usual care', 'pain_rest_day7', '0–10 points'),
              'RESCUE_METAMIZOLE_7D_EA_USUAL': ('Colak 2010: metamizole on request, days 0–7, EA vs usual care', 'rescue_analgesia', 'g metamizole'),
              'QoR15_SHAM_POD7': ('QoR-15: TEAS vs sham POD7', 'quality_of_recovery', 'QoR-15 points')}
    for m, (lab, fam, unit) in D3_AUD.items():   # Astra's D3 audit (finding 4), 3 Nov 2026: the other reported time points
        x = W97_MOD[m]
        assert x['k'] == '1', m
        oth.append(dict(model=m, label=lab, role='Additional', family=fam, measure='MD', unit=unit, k=x['k'], n=x['N'], eff=num(x['effect']),
                        lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='', i2='', status='Single trial, normal interval',
                        reports=x['reports'], parent='', basis='Decision D3; added 3 Nov 2026 after an independent AI audit', note=x['description']))
    left = D3_MOD - {r['model'] for r in oth} - {r['model'] for r in op} - {'opioid7d_pethidine_EA_usual_COLAK'}
    assert not left, left
    ind = []
    for r in recs(FA / 'individual_estimates.csv'):
        ind.append(dict(r, effect=num(r['effect']), ci_low=num(r['ci_low']), ci_high=num(r['ci_high'])))
    x, w = W97_MOD['opioid7d_pethidine_EA_usual_COLAK'], D3_RES['COLAK10-PETH-7D']   # D3, 2 Nov 2026
    ind.append(dict(report='Colak 2010', outcome='Pethidine, total', window='Postoperative days 0–7', opioid='Pethidine', unit='mg',
                    modality='EA', comparator='Usual care', effect_measure='MD', effect=num(x['effect']), ci_low=num(x['ci_low']),
                    ci_high=num(x['ci_high']), n_i=w['n_i'], n_c=w['n_c'], status='NATIVE_SINGLE_TRIAL',
                    note='Added 2 Nov 2026 (decision D3); longest reported acute interval (0–7 days), outside every 0–24-h analysis; RoB 2 assessment added and confirmed 3 Nov 2026',
                    derivation=f"Means (SD) as printed: {w['value_i']} ({w['sd_i']}) vs {w['value_c']} ({w['sd_c']}) mg", source_location=w['source_location']))
    miss = recs(R / 'missing_outcome_assumptions.csv')
    for sc in ('NONE', 'ALL', 'UNFAVOURABLE_TO_TEAS', 'FAVOURABLE_TO_TEAS'):   # Wang 1997: all randomised analysed, nothing to assign
        miss.append(dict(scenario=sc, report='Wang 1997', observed_n_i='50', observed_n_c='25', randomized_n_i='50', randomized_n_c='25',
                         missing_i='0', missing_c='0', imputed_events_i='0', imputed_events_c='0',
                         assumption='No missing outcomes; observed values used in every scenario (added 2 Nov 2026)'))
    for sc, ev in (('NONE', '0'), ('ALL', '1'), ('UNFAVOURABLE_TO_TEAS', '0'), ('FAVOURABLE_TO_TEAS', '1')):   # Fu 2024 (D3)
        miss.append(dict(scenario=sc, report='Fu 2024', observed_n_i='30', observed_n_c='29', randomized_n_i='30', randomized_n_c='30',
                         missing_i='0', missing_c='1', imputed_events_i='0', imputed_events_c=ev,
                         assumption='One sham participant withdrew (Fig. 2 of the report); added 2 Nov 2026 (decision D3)'))
    relabelled = []
    for rows_ in (op, oth):   # Astra's D3 audit (finding 3), 3 Nov 2026: the Method label follows the final fit, not the archived row
        for r in rows_:
            k, st = int(float(r['k'] or 0)), r['status'] or ''
            new = ((st if st.startswith(('NO ELIGIBLE', 'Empty')) else 'NO ELIGIBLE QUANTITATIVE DATA') if k == 0 else
                   (st if 'single' in st.lower() else 'Single trial, normal interval') if k == 1 else
                   (st if 'REML' in st else 'REML + Hartung-Knapp (floored at 1)'))
            if new != st:
                relabelled.append(r['model']); r['status'] = new
            assert (k == 0) == st_empty(r['status']) and (k == 1) == ('single' in r['status'].lower()), (r['model'], k, r['status'])
    assert len(relabelled) == 10, relabelled
    wb = new_wb(12, ['Every opioid analysis, every other outcome analysis (additional outcomes, sensitivity analyses, diagnostics '
                     'and held results), single-trial estimates in native units, and the missing-outcome scenarios for rescue receipt.',
                     'Mean differences are intervention minus comparator; for opioid, pain and time outcomes a negative value favours '
                     'the intervention. Pooled analyses used REML with Hartung–Knapp intervals truncated at 1; single trials are shown '
                     'with their own normal confidence interval and are not pooled. Prediction intervals are given for five or more trials.'],
                 [('Opioid analyses', 'All opioid analyses (registered outcome, broader first-day analysis, later windows, native units, rescue receipt), after the Lee 2011 hold'),
                  ('Other outcomes', 'All other analyses with their role: additional outcome, sensitivity, diagnostic or held'),
                  ('Single-trial estimates', 'Opioid results reported by one trial only, in native units'),
                  ('Rescue missing outcomes', 'Assumptions behind the missing-outcome scenarios for rescue receipt')],
                 ['Analysis names: opioid24/48/72 = window in hours; TEAS or EA; sham, usual (care) or active comparator; E2 = broader '
                  'first-day analysis; suf0.25/suf0.5/suf1 = sufentanil factor; LOO = leave-one-out; NOT_HIGH = excluding results at high '
                  'risk of bias; LOW_ONLY = results at low risk only; E2.1 = results admitted by amendment E2.1.',
                  'Lee 2011 is held from all pooled analyses (23 Oct 2026). Analyses that contained it were refitted without it and are '
                  'labelled in the Note column; two leave-out analyses of Lee 2011 are superseded because they now equal the main analysis.',
                  'Missing-outcome scenarios are hypothetical: missing outcomes were not measured, and the scenarios do not recover them.',
                  'Wang 1997 was included on 2 Nov 2026 (decision D1). Every analysis it enters was refitted (Note column); without it, '
                  'the broader first-day TEAS-versus-sham estimate is the earlier one (E2_TEAS_sham_LOO_Wang_1997).',
                  'Notes such as "membership restricted to the fixed 40 reports" describe the membership when an analysis was built; '
                  'rows refitted or added with Wang 1997 say so. The two Lee 2011 leave-out aliases equal the pre-Wang main analysis, '
                  'not the current one.',
                  'Colak 2010 and Fu 2024 were included on 2 Nov 2026 (decision D3), and Chen 2016 was included and held from pooled '
                  'analyses (eligible ages 16–80 years). Analyses that Fu 2024 or Colak 2010 enter were refitted (Note column); without Fu 2024 '
                  'the rescue estimate is the earlier six-trial one (RESCUE_LOO_Fu_2024).',
                  'Added on 3 Nov 2026 after an independent AI audit of the D3 work: single-trial estimates for Colak 2010 (rest pain on '
                  'days 2 to 7; metamizole over days 0–7) and Fu 2024 (QoR-15 on day 7).',
                  'The Method column follows the number of trials in the final fit: no eligible data (0 trials), single trial (1) or REML '
                  'with Hartung–Knapp (2 or more). Until 3 Nov 2026, ten rows refitted with Wang 1997 or the D3 reports kept their '
                  'earlier label.'])
    num_cols = [('k', 'Trials', 7), ('n', 'Participants', 10), ('eff', 'Effect', 9), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9),
                ('pil', 'PI low', 9), ('pih', 'PI high', 9), ('tau2', 'τ²', 8), ('i2', 'I² (%)', 7)]
    sheet(wb, 'Opioid analyses', op, [('model', 'Analysis', 40), ('family', 'Outcome', 40), ('analysis', 'Type', 30), ('measure', 'Measure', 8)] + num_cols +
          [('reports', 'Reports', 50), ('status', 'Method', 26), ('post_hoc', 'Post hoc', 10), ('role', 'Original role', 12), ('note', 'Note', 50)])
    sheet(wb, 'Other outcomes', oth, [('model', 'Analysis', 36), ('label', 'Label', 36), ('role', 'Role', 12), ('family', 'Outcome family', 20),
                                      ('measure', 'Measure', 8), ('unit', 'Unit', 14)] + num_cols +
          [('status', 'Method', 26), ('reports', 'Reports', 50), ('parent', 'Parent analysis', 26), ('basis', 'Basis', 50), ('note', 'Note', 50)])
    sheet(wb, 'Single-trial estimates', ind, [('report', 'Report', 20), ('outcome', 'Outcome', 30), ('window', 'Window', 16), ('opioid', 'Opioid', 16),
                                              ('unit', 'Unit', 14), ('modality', 'Modality', 9), ('comparator', 'Comparator', 14),
                                              ('effect_measure', 'Measure', 8), ('effect', 'Effect', 9), ('ci_low', '95% CI low', 9),
                                              ('ci_high', '95% CI high', 9), ('n_i', 'N, intervention', 9), ('n_c', 'N, control', 9),
                                              ('events_i', 'Events, intervention', 9), ('events_c', 'Events, control', 9), ('status', 'Status', 30),
                                              ('note', 'Note', 50), ('derivation', 'Derivation', 40), ('source_location', 'Source location', 24)])
    sheet(wb, 'Rescue missing outcomes', miss, [('scenario', 'Scenario', 22), ('report', 'Report', 18), ('observed_n_i', 'Observed N, TEAS', 9),
                                                ('observed_n_c', 'Observed N, sham', 9), ('randomized_n_i', 'Randomised N, TEAS', 9),
                                                ('randomized_n_c', 'Randomised N, sham', 9), ('missing_i', 'Missing, TEAS', 9), ('missing_c', 'Missing, sham', 9),
                                                ('imputed_events_i', 'Events assigned, TEAS', 9), ('imputed_events_c', 'Events assigned, sham', 9),
                                                ('assumption', 'Assumption', 50)])
    return save(wb, 12, '.xlsx')


# ================================================================ Additional file 9: code and verification
CODE = {
    'prisma': [PR / 'build_prisma.py', PR / 'build_prisma_manuscript.py', PR / 'prisma_counts.json'],
    'forty_report_analysis': sorted(FA.glob('*.py')) + [FA / 'verify_models.R'],
    'forty_report_analysis/registered_completion': sorted(C.glob('*.py')) + sorted(C.glob('*.R')) + sorted(C.glob('*.do')),
    'forty_report_analysis/reviewer_rerun': sorted(R.glob('*.py')) + sorted(R.glob('*.R')) + sorted(R.glob('*.do')),
    'forty_report_analysis/certainty_and_manuscript': sorted(CM.glob('*.py')),
    'forty_report_analysis/reviewer_sheet_check': sorted((FA / 'reviewer_sheet_check_2026-10-24').glob('*.R')),
    'manuscript': [HERE / 'make_sources.py', HERE / 'assemble_revision.py', HERE / 'build_docx.js', HERE / 'build_additional_files.py',
                   HERE / 'patch_additional_files.py', HERE / 'references/build_references.py', HERE / 'references/references_revision.csv'],
    'manuscript/sources': sorted((HERE / 'sources').glob('*_REVISED.*')) + [HERE / 'sources/make_table1_revised.py', HERE / 'sources/table1_REVISED_edits.csv'],
    'selection_check': [HERE / 'C01_selection/build_c01_triage.py', HERE / 'C01_selection/C01_historical_outcome_exclusions_triage.csv',
                        HERE / 'C01_selection/c01_scenarios.R', HERE / 'C01_selection/C01_scenarios.csv', HERE / 'C01_selection/C01_FOUR_REPORTS.md'],
    'figures': [HERE / 'figures/manuscript_figures_REVISED_2026-11-02.do', HERE / 'figures/Fig2_source_contribution_map.csv'],
    'wang1997': [W97 / f for f in ('wang1997_results.csv', 'wang1997_characteristics.csv', 'wang1997_analysis_inputs.csv',
                                   'wang1997_rob2_DRAFT.csv', 'wang1997_grade_DRAFT.csv', 'rob_domain_summary_2026-10-23.csv',
                                   'rob_key_analyses_2026-10-23.csv', 'prisma_counts_with_wang1997.json', 'stata_figures_with_wang1997.log',
                                   'apply_wang_text.py', 'patch_af_wang.py', 'wang1997_outcome_inventory.csv')],
    'recheck': [REV / 'recheck' / f for f in ('update_wang_records.py', 'apply_recheck_text.py', 'patch_af_recheck.py')],
    'd3': [REV / 'd3' / f for f in ('build_d3_records.py', 'apply_d3_text.py', 'patch_af_d3.py', 'd3_decisions.csv', 'd3_results.csv',
                                    'd3_characteristics.csv', 'd3_rob2_DRAFT.csv', 'd3_grade_DRAFT.csv', 'prisma_counts_current.json',
                                    'rob_domain_summary_d3.csv', 'rob_key_analyses_d3.csv', 'stata_figures_d3.log', 'd3_outcome_inventory.csv')]
          + [REV / 'recheck/D3_membership_dossier.md'],
    'audit_d3': [REV / 'audit_d3' / f for f in ('apply_audit_text.py', 'patch_af_audit.py', 'update_verify_audit.py')],
    'reaudit_d3': [REV / 'reaudit_d3' / f for f in ('build_wang48_rob2.py', 'wang48_rob2_DRAFT.csv', 'apply_reaudit_text.py',
                                                    'patch_af_reaudit.py', 'update_verify_reaudit.py', 'astra_recompute_2026-11-03.csv')]
          + [REV / 'reaudit_d3/figure_builds/build_rob_figure_reaudit.py'],
    'skp_d3_review': [REV / 'skp_d3_review' / f for f in ('record_skp_review.py', 'apply_skp_text.py', 'patch_af_skp.py',
                                                          'update_verify_skp.py')]
          + [REV / 'skp_d3_review/figure_builds/build_rob_figure_skp.py'],
    'd4': [REV / 'd4' / f for f in ('record_d4.py', 'd4_decisions.csv', 'apply_d4_text.py', 'patch_af_d4.py', 'update_verify_d4.py')]
          + [REV / 'd4/figure_builds/build_prisma_manuscript_d4.py'],
    'd5': [REV / 'd5' / f for f in ('build_d5_log.py', 'd5_retrieval_log.csv', 'record_d5.py', 'd5_decisions.csv', 'apply_d5_text.py',
                                    'patch_af_d5.py', 'update_verify_d5.py')]
          + [REV / 'd5/figure_builds/build_prisma_manuscript_d5.py'],
    'd9': [REV / 'd9' / f for f in ('patch_af_d9.py', 'update_verify_d9.py')],
    'd7': [REV / 'd7' / f for f in ('d7_mma_timing.csv', 'apply_d7_text.py', 'patch_af_d7.py', 'update_verify_d7.py')],
    'd10': [REV / 'd10' / f for f in ('apply_d10_text.py', 'patch_af_d10.py', 'update_verify_d10.py')],
    'confirm': [REV / 'confirm' / f for f in ('apply_confirm_static.py', 'apply_confirm_text.py', 'patch_af_confirm.py', 'update_verify_confirm.py')],
    'astra_2026-11-04': [REV / 'astra_2026-11-04' / f for f in ('ASTRA_FINDINGS_2026-11-04.md', 'apply_astra_text.py', 'patch_af_astra.py',
                                                                'update_verify_astra.py')],
    'd6': [REV / 'd6' / f for f in ('d6_decision.csv', 'build_d6_inputs.py', 'd6_inputs.csv', 'd6_scenarios.R', 'd6_scenarios.csv',
                                    'apply_d6_text.py', 'patch_af_d6.py',
                                    'update_verify_d6.py')],
    'data/inputs': [R / 'model_inputs.csv', R / 'e2/e2_model_inputs.csv', C / 'model_inputs.csv', C / 'model_specs.csv',
                    FA / 'rescue_model_inputs.csv', R / 'missing_outcome_assumptions.csv', R / 'dose_bias_linkage.csv'],
    'data/results': [R / 'model_results.csv', R / 'lee_hold_rerun_2026-10-23.csv', R / 'dose_restriction_rerun_2026-10-23.csv',
                     HERE / 'reproduce/reproduced_final_estimates.csv', W97 / 'models_with_wang.csv',
                     C / 'model_results_python.csv', FA / 'rescue_model_results.csv', FA / 'individual_estimates.csv'],
    'verification': [C / 'numerical_verification.csv', C / 'independent_R_results.csv', FA / 'independent_R_verification.csv',
                     R / 'independent_R_verification.csv', R / 'individual_R_verification.csv', R / 'stata_verification.csv',
                     R / 'baseline_reproduction.csv', R / 'run_manifest.json', C / 'manifest.json'],
}


def af9():
    files = []
    prefix = {R: 'reviewer_rerun_', C: 'registered_completion_', FA: 'forty_report_', R / 'e2': ''}
    clash = {'independent_R_verification.csv', 'model_inputs.csv'}
    for folder, paths in CODE.items():
        for p in paths:
            assert p.exists(), p
            name = prefix[p.parent] + p.name if p.name in clash else p.name
            files.append((f'{folder}/{name}', p))
    names = [n for n, _ in files]
    assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
    ver = rd(C / 'numerical_verification.csv')
    passed = (ver.passed.str.lower() == 'true').sum()
    readme = [f'# Additional file 9. {AF[9]["title"]}', '', f'Supplement to: {TITLE}. {REG}.', '',
              'Scripts that produced the analyses, figures, tables and additional files, with the model inputs and outputs and '
              'the record of independent numerical verification.', '',
              '## Software', '', '- Python 3.12 (standard library, numpy, scipy and pandas for analysis; reportlab, matplotlib and pypdf for figures; python-docx and openpyxl for the additional files)',
              '- Stata 19.5 (StataNow/SE; `meta` suite: REML with truncated Hartung–Knapp standard errors)', '- R 4.5.2 (base R only)',
              '- Node.js with docx 9.x (manuscript file)', '',
              '## Verification', '',
              f'- `verification/numerical_verification.csv`: every estimate and empty analysis of the registered-outcome completion '
              f'compared between Python, Stata and R, field by field ({passed} of {len(ver)} comparisons within tolerance; maximum '
              'difference in effects or confidence limits 1.4 × 10⁻⁶).',
              '- `verification/*_R_verification.csv`, `independent_R_results.csv`: independent base-R recomputation from arm-level data.',
              '- Later refits (the risk-of-bias restriction update and the Lee 2011 hold, 23 October 2026) were run in base R after '
              'first reproducing the existing estimates (maximum differences 6.8 × 10⁻⁸ and 9.5 × 10⁻⁸): '
              '`forty_report_analysis/reviewer_rerun/dose_restriction_rerun_2026_10_23.R` and `lee_hold_rerun_2026_10_23.R`.',
              '- `reaudit_d3/astra_recompute_2026-11-03.csv`: an independent AI re-check (3 Nov 2026) recomputed every refit '
              'affected by decision D3 (35 rows) with its own code: effects and confidence limits within 4.8 × 10⁻⁷, τ² and I² '
              'within 1.5 × 10⁻⁶ (the largest, τ² for QoR15_SHAM_24H_LOO_Zhou_2025, reflects optimiser precision).',
              '- `skp_d3_review/`: records the second review by SKP (reported 3 Nov 2026) of the decision-D3 extraction and '
              'assessments, of Wang 1997\'s 48-hour pain assessments and of the 2 November corrections, triage and '
              'English-abstract check. All were confirmed as made or drafted, so no judgement, value or estimate changed.',
              '- `d4/`: decision D4 (JRNM and SKP, 3 Nov 2026): nine outcome exclusions counted under a corrected reason '
              '(`d4_decisions.csv`), with the Fig. 1 counts, text and builder edits that follow; no estimate changed.',
              '- `d5/`: decision D5 (JRNM and SKP, 3 Nov 2026): the 53 outcome exclusions the triage could not assess, sought '
              'and read with AI assistance (`d5_retrieval_log.csv`); nine counted under a corrected reason (`d5_decisions.csv`), '
              'six not retrieved; no estimate changed.',
              '- `d9/`: Additional file 6, sheet "Analysis inputs", now lists all seven rescue trials (3 Nov 2026); no value changed.',
              '- `d6/`: decision D6 (JRNM and SKP, all authors agreeing, 3 Nov 2026): rest-pain certainty lowered to low; '
              '`d6_scenarios.R` refits rest pain and PONV with the trials the opioid-result requirement removed (post-hoc '
              'what-ifs, not results; reads the review\'s inputs and the 70-report extraction).',
              '- `d7/`: decision D7 (JRNM, 3 Nov 2026; checked by SKP): when the routine non-opioid was given in the 14 '
              'multimodal reports (`d7_mma_timing.csv`); the definition and counts are unchanged.',
              '- `d10/`: decision D10 (JRNM, 3 Nov 2026): registration history stated in the Methods and Additional file 2.',
              '- `confirm/`: the author confirmations of 3 Nov 2026 (title page, Declarations, the 508 automated exclusions, AI '
              'tools, the search questions in Additional file 2); no estimate changed.',
              '- `astra_2026-11-04/`: repairs after an independent AI check (4 Nov 2026). `reproduce_final.R` also reruns the four '
              'D6 what-ifs from `d6/d6_inputs.csv` and compares them with `d6/d6_scenarios.csv`.', '',
              '## Reproducing the final estimates', '',
              'From this folder, with R installed: `Rscript reproduce_final.R`. Base R only; it reads `data/inputs` and '
              '`data/results`, refits every final model (239: registered outcome, rescue receipt and other opioid models; the '
              'broader first-day models without Lee 2011; all other outcomes), writes `reproduced_final_estimates.csv`, and '
              'stops with an error if any effect or confidence limit differs from the archived result by more than 2 × 10⁻⁶. '
              'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026), and Colak 2010 and Fu 2024 '
              '(decision D3, same date), to every analysis they enter '
              '(including the legacy expanded-dose sensitivity models, the nausea and vomiting diagnostics and Wang\'s '
              'single-trial results), and compares the result with `data/results/models_with_wang.csv`. A passing run shows '
              'that the distributed models reproduce; it does not show that every eligible analysis or result is included. '
              'Expected output ends: "Reproduction passed." A passing run shows that the estimates follow from these inputs; it '
              'does not show that the inputs were extracted correctly or that the set of included trials is complete.', '',
              'Units: in `data/inputs/reviewer_rerun_model_inputs.csv` and `e2_model_inputs.csv` the arm means and SDs are '
              'already converted to mg IV morphine (`factor` gives the factor applied); the `unit` column gives the source '
              'unit. For example, Chen 1998 is stored as 32.5 and 53.5 (hydromorphone 6.5 and 10.7 mg × 5). Do not convert '
              'these values again. Values as reported are in Additional file 6, sheet Analysis inputs.', '',
              '## Running the build scripts', '',
              'The scripts expect the project folder layout and the source PDFs, which are pinned by SHA-256 hash but are not '
              'distributed here because they are copyrighted. The model inputs in `data/inputs` carry every arm-level value with '
              'its source location and quotation, so each estimate can be recomputed from them without the PDFs.', '',
              'A passing reproduction shows that the estimates follow from the extracted data by the stated methods. It does not show '
              'that the extraction is free of error or that the evidence base is complete.', '',
              '## Contents', '']
    readme += [f'- `{n}`' for n in names]
    OUT.mkdir(exist_ok=True)
    zp = OUT / 'Additional_file_9.zip'
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('Additional_file_9/README.md', '\n'.join(readme) + '\n')
        z.write(HERE / 'reproduce/reproduce_final.R', 'Additional_file_9/reproduce_final.R')
        z.write(W97 / 'refit_with_wang.R', 'Additional_file_9/refit_with_wang.R')
        for n, p in files:
            z.write(p, f'Additional_file_9/{n}')
    return zp, len(files)


if __name__ == '__main__':
    out = [af1(), af2(), af3(), af4(), af5(), af6(), af7(), af8()]
    zp, nfiles = af9()
    p10, nsig = af10()
    out += [zp, p10, af11(), af12()]
    for p in out:
        print(f'{p.name:28s} {p.stat().st_size:>9,d} bytes  {hashlib.sha256(p.read_bytes()).hexdigest()[:16]}')
    print('zip files:', nfiles, '| signalling responses:', nsig)
