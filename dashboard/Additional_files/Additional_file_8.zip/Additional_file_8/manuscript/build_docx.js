// Build the BMC Anesthesiology submission draft (.docx) from manuscript_spec.json (written by assemble_manuscript.py).
// BMC layout: A4, double line spacing, continuous line numbers, page numbers, no page breaks; figure titles and legends
// in the manuscript (figures uploaded separately); tables as Word tables without colour or shading, titles above and
// legends below; Table 1 (wider than one page) at the end in a landscape section.
// Run: NODE_PATH=<folder containing node_modules/docx> node build_docx.js
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Footer, PageNumber, Table, TableRow, TableCell,
  WidthType, BorderStyle, PageOrientation, LineNumberRestartFormat, SectionType, VerticalAlign, LineRuleType,
} = require('docx');

const S = JSON.parse(fs.readFileSync(path.join(__dirname, 'manuscript_spec.json'), 'utf8'));
const OUT = path.join(__dirname, 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx');
const FONT = 'Times New Roman';
const DOUBLE = { line: 480, lineRule: LineRuleType.AUTO };   // explicit 'auto' so every reader shows double spacing

// inline markup: **bold**, *italic*, [CONFIRM ...] / [TOOLS: ...] / [PROVISIONAL: ...] highlighted
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\[(?:CONFIRM|TOOLS|PROVISIONAL)[^\]]*\])/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), ...base }));
    const t = m[0];
    if (t.startsWith('**')) out.push(new TextRun({ text: t.slice(2, -2), ...base, bold: true }));
    else if (t.startsWith('*')) out.push(new TextRun({ text: t.slice(1, -1), ...base, italics: true }));
    else out.push(new TextRun({ text: t, ...base, highlight: 'yellow' }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), ...base }));
  return out;
}
const P = (text, opts = {}) => new Paragraph({ children: runs(text, opts.run || {}), spacing: { ...DOUBLE, after: 240 },
  alignment: opts.align, indent: opts.indent });
const H1 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text })],
  spacing: { ...DOUBLE, before: 240, after: 0 } });
const H2 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text })],
  spacing: { ...DOUBLE, before: 120, after: 0 } });
const Labelled = (label, text) => new Paragraph({ spacing: { ...DOUBLE, after: 120 },
  children: [new TextRun({ text: label + ': ', bold: true }), ...runs(text)] });

function section(blocks) {
  return blocks.map(b => b.kind === 'h2' ? H2(b.text) : P(b.text));
}

// tables: horizontal rules only (top, under header, bottom); no colour or shading
const RULE = { style: BorderStyle.SINGLE, size: 6, color: '000000' };
const NONE = { style: BorderStyle.NIL, size: 0, color: 'FFFFFF' };
function table(rows, widths, fontHalfPts) {
  const total = widths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    borders: { top: RULE, bottom: RULE, left: NONE, right: NONE, insideHorizontal: NONE, insideVertical: NONE },
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0,
      children: r.map((c, j) => new TableCell({
        width: { size: widths[j], type: WidthType.DXA }, verticalAlign: VerticalAlign.TOP,
        margins: { top: 40, bottom: 40, left: 70, right: 70 },
        borders: { top: i === 0 ? RULE : NONE, bottom: (i === 0 || i === rows.length - 1) ? RULE : NONE, left: NONE, right: NONE },
        children: [new Paragraph({ spacing: { ...DOUBLE, after: 0 },
          children: runs(c, { bold: i === 0, size: fontHalfPts }) })],
      })),
    })),
  });
}
const TableTitle = (n, title) => new Paragraph({ spacing: { ...DOUBLE, before: 240, after: 120 }, keepNext: true,
  children: [new TextRun({ text: `Table ${n} `, bold: true }), new TextRun({ text: title, bold: true })] });
const TableLegend = (text) => new Paragraph({ spacing: { ...DOUBLE, before: 120, after: 240 }, children: runs(text, { size: 20 }) });

// ---------------------------------------------------------------- front matter
const front = [];
front.push(new Paragraph({ spacing: { ...DOUBLE, after: 240 }, children: [new TextRun({ text: S.title, bold: true, size: 28 })] }));
const auth = [];
S.authors.forEach(([name, sup], i) => {
  auth.push(new TextRun({ text: name }));
  auth.push(new TextRun({ text: sup, superScript: true }));
  if (i < S.authors.length - 1) auth.push(new TextRun({ text: ', ' }));
});
front.push(new Paragraph({ spacing: { ...DOUBLE, after: 0 }, children: auth }));
S.affiliations.forEach(a => {
  const [n, ...rest] = a.split(' ');
  front.push(new Paragraph({ spacing: { ...DOUBLE, after: 0 },
    children: [new TextRun({ text: n, superScript: true }), new TextRun({ text: rest.join(' ') })] }));
});
front.push(P(S.corresponding));
front.push(P(S.title_note));

front.push(H1('Abstract'));
S.abstract.forEach(([label, text]) => front.push(Labelled(label, text)));
front.push(Labelled('Systematic review registration', S.registration));
front.push(Labelled('Keywords', S.keywords));
if (S.abstract_note) front.push(P(S.abstract_note));

// ---------------------------------------------------------------- main text
const main = [];
main.push(H1('Background'));
S.background.forEach(p => main.push(P(p)));
main.push(H1('Methods'));
main.push(...section(S.methods));
main.push(H1('Results'));
main.push(...section(S.results));
main.push(TableTitle(2, S.table2.title));
main.push(table(S.table2.rows, [1850, 1400, 1650, 2926, 1200], 20));
main.push(TableLegend(S.table2.legend));
main.push(H1('Discussion'));
main.push(...section(S.discussion));
main.push(H1('Conclusions'));
main.push(P(S.conclusions));

const ABBR = [
  ['AI', 'artificial intelligence'], ['CI', 'confidence interval'], ['EA', 'electroacupuncture'],
  ['ENT', 'ear, nose and throat'], ['ESD', 'endoscopic submucosal dissection'], ['GI', 'gastrointestinal'],
  ['GRADE', 'Grading of Recommendations Assessment, Development and Evaluation'],
  ['IV MME', 'intravenous morphine milligram equivalents'], ['MD', 'mean difference'], ['MMA', 'multimodal analgesia'],
  ['PCA', 'patient-controlled analgesia'], ['PCIA', 'patient-controlled intravenous analgesia'],
  ['PONV', 'postoperative nausea and vomiting'],
  ['PRISMA', 'Preferred Reporting Items for Systematic Reviews and Meta-Analyses'],
  ['PROSPERO', 'International Prospective Register of Systematic Reviews'],
  ['QoR-9, QoR-15, QoR-40', 'Quality of Recovery scores with 9, 15 and 40 items'],
  ['REML', 'restricted maximum likelihood'], ['RoB 2', 'Cochrane risk-of-bias tool for randomised trials, version 2'],
  ['RR', 'risk ratio'], ['StEP', 'Standardised Endpoints in Perioperative Medicine'],
  ['STRICTA', 'Standards for Reporting Interventions in Clinical Trials of Acupuncture'],
  ['TEAS', 'transcutaneous electrical acupoint stimulation'], ['TENS', 'transcutaneous electrical nerve stimulation'],
];
main.push(H1('List of abbreviations'));
ABBR.forEach(([a, d]) => main.push(new Paragraph({ spacing: { ...DOUBLE, after: 0 },
  children: [new TextRun({ text: a, bold: true }), new TextRun({ text: ': ' + d })] })));

main.push(H1('Declarations'));
const DECL = [
  ['Ethics approval and consent to participate', 'Not applicable. This systematic review synthesised data from published reports; no new human participants, human data or human tissue were involved.'],
  ['Consent for publication', 'Not applicable.'],
  ['Availability of data and materials', 'The datasets supporting the conclusions of this article are included within the article and its additional files (Additional files 4 to 12).'],
  ['Competing interests', 'The authors declare that they have no competing interests.'],
  ['Funding', 'This work received no external funding.'],
  ["Authors' contributions", 'JRNM conceived and designed the review, ran the searches, screened titles, abstracts and full texts, directed the AI-assisted data extraction, risk-of-bias and GRADE assessments and the analyses, and drafted the manuscript. SKP screened titles, abstracts and full texts and was the second reviewer for study characteristics, stimulation protocols, hospital setting, analgesic regimens, narrative outcome tables, and all risk-of-bias and GRADE assessments. CS and PJ contributed to the design and critically revised the manuscript. All authors read and approved the final manuscript.'],
  ['Acknowledgements', 'Not applicable.'],
];
DECL.forEach(([h, t]) => { main.push(H2(h)); main.push(P(t)); });

main.push(H1('References'));
S.references.forEach((r, i) => main.push(new Paragraph({ spacing: { ...DOUBLE, after: 0 },
  indent: { left: 567, hanging: 567 }, children: [new TextRun({ text: `${i + 1}.\t` }), ...runs(r)] })));

main.push(H1('Figures'));
S.figures.forEach(f => {
  main.push(new Paragraph({ spacing: { ...DOUBLE, before: 120, after: 0 }, keepNext: true,
    children: [new TextRun({ text: `Fig. ${f.n} `, bold: true }), new TextRun({ text: f.title, bold: true })] }));
  main.push(P(f.legend));
});

main.push(H1('Additional files'));
S.additional_files.forEach(a => main.push(new Paragraph({ spacing: { ...DOUBLE, after: 0 }, children: [
  new TextRun({ text: `Additional file ${a.n} (${a.fmt}). `, bold: true }),
  new TextRun({ text: a.title + '. ', italics: true }), new TextRun({ text: a.desc })] })));

// ---------------------------------------------------------------- Table 1 (landscape, end of document)
const t1 = [TableTitle(1, S.table1.title),
  table(S.table1.rows, [1400, 900, 1000, 1400, 1150, 800, 550, 700, 1000, 1650, 900, 1908, 600], 16),
  TableLegend(S.table1.legend)];

// ---------------------------------------------------------------- document
const footer = new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
  children: [new TextRun({ children: [PageNumber.CURRENT] })] })] });
const margin = { top: 1440, bottom: 1440, left: 1440, right: 1440 };
const lineNumbers = { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS };
const doc = new Document({
  creator: 'John Ryan Nual Mendoza', title: S.title,
  styles: {
    default: { document: { run: { font: FONT, size: 24 } } },
    paragraphStyles: [
      // explicit Normal style: docx 9.6 does not write one, and some readers then fall back to a heading style
      { id: 'Normal', name: 'Normal', quickFormat: true, run: { font: FONT, size: 24 } },
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { font: FONT, size: 26, bold: true }, paragraph: { outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { font: FONT, size: 24, bold: true, italics: true }, paragraph: { outlineLevel: 1 } },
    ],
  },
  sections: [
    { properties: { page: { size: { width: 11906, height: 16838 }, margin }, lineNumbers },
      footers: { default: footer }, children: [...front, ...main] },
    { properties: { type: SectionType.NEXT_PAGE, lineNumbers,
        page: { size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE }, margin } },
      footers: { default: footer }, children: t1 },
  ],
});
// docx 9.6 writes no default paragraph style; mark Normal as the default so every reader uses it for body text
const JSZip = require('jszip');
Packer.toBuffer(doc).then(async buf => {
  const zip = await JSZip.loadAsync(buf);
  let st = await zip.file('word/styles.xml').async('string');
  const before = st;
  st = st.replace('<w:style w:type="paragraph" w:styleId="Normal">', '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">');
  if (st === before) throw new Error('Normal style not found');
  zip.file('word/styles.xml', st);
  const out = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  fs.writeFileSync(OUT, out); console.log('written', OUT, out.length, 'bytes');
});
