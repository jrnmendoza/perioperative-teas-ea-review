"""Reference list for the revision: the 49 existing references plus the 41 included reports (audit finding M06; Wang 1997
added on 2 Nov 2026 after decision D1, from its PubMed record in included_report_pubmed_wang1997_2026-11-02.json).

Existing references: keys and formatted entries from references/bibliography.csv and REFERENCES_BMC.md (read-only;
all 49 were verified against PubMed in October 2026). Included reports: PubMed records retrieved on 2 November 2026
(included_reports_pubmed_2026-11-02.json); Gu 2019 is not indexed in PubMed and is taken from its PDF (page 11
header). Writes references_revision.csv (key, label, text, source). Numbering is done by the assembler in order of
first citation.
"""
import csv, json, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
bib = list(csv.DictReader(open(ROOT / 'references/bibliography.csv', encoding='utf-8-sig')))
lines = {int(l.split('. ', 1)[0]): l.split('. ', 1)[1] for l in (ROOT / 'references/REFERENCES_BMC.md').read_text(encoding='utf-8').splitlines()
         if re.match(r'^\d+\. ', l)}
rows = [dict(key=r['key'], label='', text=lines[int(r['number'])], source='Existing reference, verified against PubMed (Oct 2026)') for r in bib]

pm = {r['pmid']: r for f in ('included_reports_pubmed_2026-11-02.json', 'included_report_pubmed_wang1997_2026-11-02.json',
                                 'included_reports_pubmed_d3_2026-11-02.json')
      for r in json.load(open(HERE / f, encoding='utf-8'))}
# report label -> PMID (Gu 2019: no PubMed record). Year override where PubMed gives the e-publication year but the
# volume belongs to the following year (Vancouver uses the year of the issue).
PMID = {'Ao 2021': '33488793', 'Chen 1998': '9806695', 'Chen 2015': '26550304', 'Chen 2015 (Hyperalgesia)': '26131165',
        'Chen 2020': '32062864', 'Gao 2022': '35360742', 'He 2026 (hepatectomy/JIS)': '42003699', 'Jiang 2026': '42400966',
        'Lee 2011': '21716712', 'Liu 2026 (ESD)': '41396394', 'Liu 2026 (burn)': '41689159', 'Oztas 2019': '31169066',
        'Szmit 2021': '33406735', 'Tu 2024': '38150863', 'Wu 2016': '26893636', 'Wu 2025': '40546828', 'Xiong 2021': '33650089',
        'Yao 2015': '26170873', 'Yeh 2010': '21280458', 'Yeh 2011': '21122849', 'Yu 2020': '31915045', 'Zhang 2023': '36745198',
        'Zhang 2025': '41368598', 'Zhou 2021': '33603487', 'Zhou 2025': '40726729', 'An 2014': '25169910', 'Coura 2011': '21383391',
        'El-Rakshy 2009': '19369187', 'Grech 2016': '27776761', 'Jin 2023': '36464237', 'Lin 2002': '12406527', 'Ng 2013': '23142625',
        'Ntritsou 2014': '24480836', 'Seevaunnamtum 2016': '28975075', 'Sim 2002': '12216602', 'Wong 2006': '16731125',
        'Xie 2014': '25135729', 'Yang 2024': '38007308', 'Long 2025': '40848689', 'Wang 1997': '9249122',
        'Colak 2010': '20677584', 'Fu 2024': '38707419', 'Chen 2016': '27073400'}
YEAR = {'Wu 2016': '2016', 'Tu 2024': '2024', 'Yang 2024': '2024', 'Liu 2026 (ESD)': '2026', 'Ng 2013': '2013',
        'Jin 2023': '2023', 'Yeh 2011': '2011'}
PAGES = {'Szmit 2021': '146', 'Liu 2026 (burn)': '21'}       # article numbers printed on the reports
# PubMed drops subscripts from this title (Th1, Th2, Th17, Treg); wording from the report (Exp Ther Med 2016;11:495, p495)
TITLE = {'Wu 2016': 'Effects of transcutaneous acupoint electrical stimulation on the imbalance of Th1, Th2, Th17 and Treg '
                    'cells following thoracotomy of patients with lung cancer'}


def pages(p):
    m = re.fullmatch(r'(\d+)-(\d+)', p)
    if not m:
        return p.replace('-', '–')
    a, b = m.groups()
    if len(b) == len(a):                                    # 1099-1109 -> 1099–109 (Vancouver elision)
        i = next((k for k in range(len(a)) if a[k] != b[k]), len(a))
        b = b[i:]
    return f'{a}–{b}'


def fmt(rec, label):
    au = [f'{last} {ini}'.strip() for last, ini in rec['authors']]
    au = ', '.join(au[:6]) + (', et al' if len(au) > 6 else '')
    title = TITLE.get(label, rec['title']).rstrip('.')
    pg = PAGES.get(label) or pages(rec['pages'])
    year = YEAR.get(label, rec['year'])
    return f"{au}. {title}. {rec['journal']}. {year};{rec['volume']}:{pg}." + (f" doi:{rec['doi']}" if rec.get('doi') else '')


slug = lambda s: 'inc_' + re.sub(r'[^a-z0-9]+', '', s.lower())
for label, pmid in PMID.items():
    rows.append(dict(key=slug(label), label=label, text=fmt(pm[pmid], label), source=f'PubMed PMID {pmid}, retrieved 2026-11-02'))
rows.append(dict(key=slug('Gu 2019'), label='Gu 2019',
                 text='Gu S, Lang H, Gan J, Zheng Z, Zhao F, Tu Q. Effect of transcutaneous electrical acupoint stimulation on '
                      'gastrointestinal function recovery after laparoscopic radical gastrectomy – a randomized controlled trial. '
                      'Eur J Integr Med. 2019;26:11–7. doi:10.1016/j.eujim.2019.01.001',
                 source='Not indexed in PubMed; taken from the report (Eur J Integr Med 2019;26:11-17, p11 header)'))
assert len(rows) == 49 + 44 and len({r['key'] for r in rows}) == 93
with open(HERE / 'references_revision.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, ['key', 'label', 'text', 'source']); w.writeheader(); w.writerows(rows)
for r in rows[49:]:
    print(r['label'], '|', r['text'][:150])
