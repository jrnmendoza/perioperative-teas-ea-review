"""One-off: turn the submitted October text (BMC_2026-10-25/manuscript_spec.json) into editable revision sources.

Numbered citations are mapped back to bibliography keys ([@key]) so they can be renumbered after editing; figures and
additional files keep their manuscript numbers. Writes sources/*_SUBMITTED_2026-10-25.* (never overwritten afterwards:
the revised copies are made by hand from these). Reads only; run once.
"""
import csv, json, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SRC = HERE / 'sources'
spec = json.loads((HERE.parent / 'BMC_2026-10-25' / 'manuscript_spec.json').read_text(encoding='utf-8'))
bib = list(csv.DictReader(open(ROOT / 'references/bibliography.csv', encoding='utf-8-sig')))
KEY = {int(r['number']): r['key'] for r in bib}
assert len(KEY) == len(spec['references']) == 49


def keys(t):
    def rep(m):
        nums = []
        for part in m.group(1).split(','):
            part = part.strip()
            if '–' in part:
                a, b = map(int, part.split('–')); nums += list(range(a, b + 1))
            else:
                nums.append(int(part))
        return '[' + '; '.join('@' + KEY[n] for n in nums) + ']'
    return re.sub(r'\[(\d+(?:\s*[,–]\s*\d+)*)\]', rep, t)


def section(items):
    out = []
    for it in items:
        if isinstance(it, str):
            out.append(keys(it))
        elif it['kind'] == 'h2':
            out.append('## ' + it['text'])
        else:
            out.append(keys(it['text']))
    return '\n\n'.join(out) + '\n'


SRC.mkdir(exist_ok=True)
w = lambda name, text: (SRC / f'{name}_SUBMITTED_2026-10-25.md').write_text(text, encoding='utf-8')
w('background', section(spec['background']))
w('methods', section(spec['methods']))
w('results', section(spec['results']))
w('discussion', section(spec['discussion']))
w('conclusions', keys(spec['conclusions']) + '\n')
w('abstract', '\n\n'.join(f'**{h}:** {t}' for h, t in spec['abstract']) +
  f'\n\n**Registration:** {spec["registration"]}\n\n**Keywords:** {spec["keywords"]}\n')
w('table2', f'**Title:** {spec["table2"]["title"]}\n\n' + '\n'.join('| ' + ' | '.join(r) + ' |' for r in spec['table2']['rows']) +
  f'\n\n**Legend:** {keys(spec["table2"]["legend"])}\n')
w('table1_legend', f'**Title:** {spec["table1"]["title"]}\n\n**Legend:** {keys(spec["table1"]["legend"])}\n')
with open(SRC / 'table1_SUBMITTED_2026-10-25.csv', 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows(spec['table1']['rows'])
w('figures', '\n\n'.join(f'## Figure {f["n"]}\n\n**Title:** {f["title"]}\n\n**Legend:** {keys(f["legend"])}' for f in spec['figures']) + '\n')
with open(SRC / 'additional_files_SUBMITTED_2026-10-25.csv', 'w', newline='', encoding='utf-8') as f:
    wr = csv.DictWriter(f, ['n', 'fmt', 'title', 'desc']); wr.writeheader(); wr.writerows(spec['additional_files'])
txt = ' '.join(p.read_text(encoding='utf-8') for p in SRC.glob('*_SUBMITTED_2026-10-25.md'))
assert not re.search(r'\[\d', txt), re.findall(r'.{40}\[\d.{20}', txt)[:3]
print(sorted(p.name for p in SRC.iterdir()))
