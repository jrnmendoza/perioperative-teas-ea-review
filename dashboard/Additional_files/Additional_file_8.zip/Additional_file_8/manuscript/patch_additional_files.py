"""One-off: turn the October additional-files builder (copied here) into the revision builder. Each replacement asserts
that its target text occurs exactly once. Kept as the record of what changed (see REVISION_LOG.md)."""
from pathlib import Path

p = Path(__file__).resolve().parent / 'build_additional_files.py'
s = p.read_text(encoding='utf-8')
R = []   # (old, new)

# ---- header and tidy() (M10: the October tidy() broke 'www2' in URLs)
R.append(('"""Additional files 1-12 for the BMC Anesthesiology submission (25 October 2026).',
          '"""Additional files 1-12, revision after the Astra audit (2 November 2026; first built 25 October 2026).'))
R.append(('''def tidy(s):
    """Restore spaces lost between words and numbers in the conversion register (e.g. 'factor100')."""
    s = re.sub(r'(?<=[A-Za-z])(?=\\d)', ' ', s)
    s = re.sub(r'(?<=\\d)(?=(mg|µg)\\b)', ' ', s)
    return s.replace('IVMME', 'IV MME')''',
          '''def tidy(s):
    """Restore spaces lost between words and numbers in the conversion register (e.g. 'factor100'), outside URLs."""
    parts = re.split(r'(https?://\\S+)', s)
    for i in range(0, len(parts), 2):
        t = re.sub(r'(?<=[A-Za-z])(?=\\d)', ' ', parts[i])
        parts[i] = re.sub(r'(?<=\\d)(?=(mg|µg)\\b)', ' ', t)
    return ''.join(parts).replace('IVMME', 'IV MME')'''))
R.append(("REG = SPEC['title'], 'PROSPERO CRD420261452908'",
          "REG = SPEC['title'], 'PROSPERO CRD420261452908'\nREV = HERE  # revision folder: C01 triage, references and reproduction script"))

# ---- AF1 (PRISMA): items 6, 8, 14, 21, 24b; abstract item 4
R.append(("'Methods: Search and selection; Additional file 3. Trial registers were not searched (Additional file 2).'),",
          "'Methods: Search and selection; Additional file 3. Trial registers were not searched within the review; a separate September 2026 discovery audit is described in Additional file 2.'),"))
R.append(("'Methods: Search and selection (two reviewers, JRNM and SKP, screened titles and abstracts and then full texts independently)'),",
          "'Methods: Search and selection. [CONFIRM: screening roles. The screening logs record AI-cast votes in two Covidence accounts in JRNM\\'s name; the Methods states what must be confirmed (Additional file 2, section 9).]'),"))
R.append(("'Methods: Statistical analysis (small-study tests required at least 10 trials); Risk of bias and certainty of evidence (RoB 2 domain 5)'),",
          "'Methods: Statistical analysis (within-trial selective reporting through RoB 2 domain 5 only; non-reporting across trials not assessed; small-study tests required at least 10 trials)'),"))
R.append(("'Not performed: no synthesis had 10 or more trials (Methods: Statistical analysis). Selection of the reported result: Results: Risk of bias'),",
          "'Not assessed across trials (Methods: Statistical analysis); selection of the reported result within trials: Results: Risk of bias. The selection check of historical exclusions is reported separately (Results: Study selection; Additional file 4).'),"))
R.append(("'[CONFIRM: not yet stated. The PROSPERO record says a full protocol was written but not made public (\"team-review draft\"). Add one sentence to Methods: Protocol and registration.]'),",
          "'Methods: Protocol and registration (sentence proposed in this revision). [CONFIRM: wording.]'),"))
R.append(("'Yes (Methods: four databases, July 2026)'", "'Yes (Methods: four databases, 21–23 July 2026)'"))
R.append(("'Yes (Results: 40 reports of 39 trials, 7,420 participants)'",
          "'Yes (Results: 40 reports of 39 trials, 7,420 participants) [PROVISIONAL: membership awaits adjudication of nine reports]'"))

# ---- AF2: selection check, deviations, decision log, screening record, chronology
R.append(("""            'confirmed opioid identity or formulation. The 40 remaining reports form the review. Each excluded report '
            'and its finding is listed in Additional file 4.')""",
          """            'confirmed opioid identity or formulation. The 40 remaining reports form the review. Each excluded report '
            'and its finding is listed in Additional file 4.')
    para(d, '**Later check of the 113 outcome exclusions (2 November 2026).** Filter B was applied only to reports that '
            'had passed the 14 August rule, so a report wrongly excluded under that rule was never assessed under filter B. '
            'An AI-assisted triage of the existing source checks (24 September and 8 October 2026) and of four reports read '
            'for the revision found 9 reports that pass or may pass both outcome requirements (membership candidates, '
            'including Wang 1997, a sham-controlled TEAS trial with 24-hour hydromorphone and pain results, and Colak 2010, '
            'an EA trial with day-1 pain and a 7-day pethidine total); 8 that report pain at about 24 hours but no '
            'postoperative opioid result (they remain excluded, under the 9 October criterion); 7 whose exclusion is '
            'supported or fails another criterion first (Tzeng 2015: spinal anaesthesia without general anaesthesia); 8 '
            'with a keyword signal never followed by a full read; 36 with no signal; and 45 with no local full text. '
            'This triage is not an independent human screen and changes no decision. [PROVISIONAL: the review team must '
            'adjudicate the membership candidates; see AUTHOR_DECISION_SHEET.md and Additional file 4.]')"""))
R.append(("""        ['Other methods of identifying studies', '"contacting authors or experts, [...] forward citation searching, reference list checking [...] and searching trial or study registers"',
         'Trial registers were not searched. One report was identified by citation searching. Authors were contacted with data queries (section 11). [CONFIRM: whether reference lists and forward citations were checked for all included reports, and whether experts were contacted.]',
         'Unpublished and register-only trials may be missing'],
        ['Search update', '"Searches will be updated before manuscript submission when required."', 'Not updated; last search 23 July 2026',
         'Trials published after July 2026 are not included'],""",
          """        ['Other methods of identifying studies', '"contacting authors or experts, [...] forward citation searching, reference list checking [...] and searching trial or study registers"',
         'Trial registers were not searched within the review. One report was identified by citation searching; the citing source was not recorded. Authors were contacted with data queries (section 11). A separate discovery audit on 24 September 2026 searched ClinicalTrials.gov and the forward and backward citations of selected reports (section 13). [CONFIRM: whether reference lists of all included reports were checked, and whether experts were contacted.]',
         'Unpublished and register-only trials may be missing; the audit leads have not been screened'],
        ['Search update', '"Searches will be updated before manuscript submission when required."', 'The four review databases were not re-searched. The September discovery audit searched PubMed for records added after the July search; this was not an update of the review\\'s search, and its leads were not screened.',
         'Trials published after July 2026 are not included'],
        ['Selection process', '"Studies will be screened independently by at least two people (or person/machine combination) with a process to resolve differences."',
         '[CONFIRM: screening roles. The screening logs record that an AI agent (Codex) cast title-and-abstract votes on 23–28 July 2026 in two Covidence accounts in JRNM\\'s name ("JM", moderate rules; "JR Mendoza", inclusive rules; 2,441 votes in the second) and full-text votes on 9–20 August 2026 in the "JM" account. State who cast the other independent votes, whether SKP screened, and how conflicts were resolved.]',
         'Determines whether screening met the registered process'],"""))
R.append(("         'An AI assistant extracted all data with a page-located verbatim quotation for each value. Study characteristics, stimulation protocols, setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP). Arm-level outcome data were checked automatically against their quoted source text, not double-extracted.',",
          "         'An AI assistant extracted all data with a recorded source location for each value; verbatim quotations were recorded for characteristics, setting and regimens and for 74 of 264 outcome results. Study characteristics, stimulation protocols, setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP). The arm-level opioid inputs were re-checked by the AI assistant against the source reports; they were not double-extracted.',"))
R.append(("        ['24 Oct', 'Broader first-day GRADE profile updated for the Lee 2011 hold (6 trials, 547 participants; certainty unchanged). English abstracts of the 12 language exclusions checked.', 'Yes'],\n    ]",
          """        ['24 Oct', 'Broader first-day GRADE profile updated for the Lee 2011 hold (6 trials, 547 participants; certainty unchanged). English abstracts of the 12 language exclusions checked.', 'Yes'],
        ['2 Nov', 'Pre-submission audit (Codex Astra) and revision: AI-assisted triage of the 113 outcome exclusions (nine membership candidates; awaiting adjudication); Table 1 corrections (An 2014 female 53%, Coura 2011 3/15 Hz, Oztas 2019 2–100 Hz, comparator labels for Wu 2016, Grech 2016, Xie 2014, Lee 2011 and Yeh 2011); Szmit 2021 reclassified as routine multimodal analgesia (intraoperative metamizole to all) under the stated definition.', 'Yes'],
    ]
    rows.insert(1, ['23–28 Jul', 'Title and abstract screening in Covidence. [CONFIRM: screening roles (section 9).]', 'No'])
    rows.insert(5, ['9–20 Aug', 'Full-text screening in Covidence. [CONFIRM: screening roles (section 9).]', 'No'])
    rows.insert(-2, ['24 Sep', 'Discovery audit outside the review: PubMed records added after July, ClinicalTrials.gov, citation chaining, and targeted re-screens of 20 outcome exclusions (section 13). No inclusion decision changed.', 'Yes'])
    rows.insert(-2, ['8 Oct', 'Source triage of the 113 outcome exclusions: four reports flagged as having a postoperative opioid result (Colak 2010, Tzeng 2015, Wang 1997, Zhang 2025 spinal fixation); no decision changed.', 'Yes'])"""))
R.append(("""        ['Coura 2011', 'Fentanyl reported per kilogram', 'Sent 22 Sep 2026; did not reach the recipient'],""",
          """        ['Coura 2011', 'Fentanyl reported per kilogram', 'Sent 22 Sep 2026; did not reach the recipient'],"""))
R.append(("""        ['25 Oct', 'Five earlier RoB 2 assessments used in the broader first-day dose analysis: Chen 1998, Chen 2020, He 2026 (hepatectomy), Lin 2002 (versus sham) and Yang 2024', 'Confirmed'],
    ]
    table(d, rows, [2.6, 11.0, 3.4], size=8.5)""",
          """        ['25 Oct', 'Five earlier RoB 2 assessments used in the broader first-day dose analysis: Chen 1998, Chen 2020, He 2026 (hepatectomy), Lin 2002 (versus sham) and Yang 2024', 'Confirmed'],
        ['Not done', 'The 2 November 2026 triage of the outcome exclusions, the Table 1 corrections and the Szmit 2021 multimodal-analgesia change', '[CONFIRM: second review pending]'],
    ]
    table(d, rows, [2.6, 11.0, 3.4], size=8.5)

    head(d, '13. September 2026 discovery audit (outside the review)')
    para(d, 'On 24 September 2026 a discovery audit, run separately from the review\\'s search and screening, searched PubMed '
            'for records with publication or entry dates from 22 July to 24 September 2026 (the original strategy in eight '
            'chunks, a broader query and a 2026 safety net: 109 records), public Europe PMC proxies for Embase and CINAHL '
            '(171 records; not equivalent to those databases), ClinicalTrials.gov (148 unique records), backward citations '
            'of three reviews (104 citation events) and forward citations of five included reports (Wu 2016, Szmit 2021, '
            'Chen 1998, Lin 2002, Sim 2002; 322 unique citing records). It identified two new candidate trials (Shi 2026, an '
            'EA-versus-sham trial with day-1 pain; Xu 2026, full text not obtained), one report of unresolved trial identity '
            '(Li 2026) and two registry entries without results, and re-read 20 outcome exclusions. None of these leads has '
            'been screened into the review, and none is counted in Fig. 1. [CONFIRM: decide whether to screen these leads '
            'formally before submission.]')

    head(d, '14. Chronology')
    para(d, 'Searches 21–23 July 2026; title and abstract screening 23–28 July; review start date entered in PROSPERO 14 August; '
            'outcome-focused full-text rule 14 August; full-text screening votes 9–20 August; PROSPERO submitted 19 August '
            'and published 20 August; full-text exclusions recorded 20 August and 1 September; adjudication record 20 '
            'September; confirmed-opioid criterion 9 October. The PROSPERO record (version 1.0) marks formal searching as '
            'started and leaves screening unmarked, although title and abstract screening had been completed by then. '
            '[CONFIRM: explain this discrepancy, and state what, if anything, was reused from the earlier broader review '
            '(CRD420251090635); the search records show it was used only for terminology and known reports.]')"""))

# ---- AF3: discovery audit pointer
R.append(("""            '(Wu 2016) was identified by citation searching. Trial registers were not searched, and the searches were '
            'not updated before submission (Additional file 2).')""",
          """            '(Wu 2016) was identified by citation searching; the citing source was not recorded. Trial registers were not '
            'searched within the review, and the four databases were not re-searched before submission. A separate '
            'discovery audit on 24 September 2026 (PubMed records added after July, ClinicalTrials.gov, citation chaining) '
            'was not part of the review\\'s search; it is described in Additional file 2, section 13, and its leads have not '
            'been screened.')"""))

# ---- AF4: Wu 2016 identity; C01 triage sheet
R.append(("""        rows.append(dict(cid=r['covidence_id'], label=r['covidence_study_id'], report=r['registry_report'] if fd == 'INCLUDED' else '',
                         title=r['title'], doi=r['doi'],""",
          """        if r['covidence_id'] == 'CITATION-WU2016' and not r['title']:   # M06: identity from PubMed PMID 26893636
            wu = next(x for x in json.load(open(REV / 'references/included_reports_pubmed_2026-11-02.json')) if x['pmid'] == '26893636')
            r = dict(r, title='Effects of transcutaneous acupoint electrical stimulation on the imbalance of Th1, Th2, Th17 and '
                              'Treg cells following thoracotomy of patients with lung cancer (PMID 26893636)', doi=wu['doi'])
        rows.append(dict(cid=r['covidence_id'], label=r['covidence_study_id'], report=r['registry_report'] if fd == 'INCLUDED' else '',
                         title=r['title'], doi=r['doi'],"""))
R.append(("""    sheet(wb, 'Fig. 1 counts', summ, [('reason', 'Reason', 44), ('n', 'Reports', 10)])""",
          """    sheet(wb, 'Fig. 1 counts', summ, [('reason', 'Reason', 44), ('n', 'Reports', 10)])
    tri = recs(REV / 'C01_selection/C01_historical_outcome_exclusions_triage.csv')
    assert len(tri) == 113
    sheet(wb, 'Outcome exclusions recheck', tri, [('covidence_id', 'Covidence ID', 13), ('covidence_label', 'Covidence label', 16),
          ('title', 'Title', 50), ('doi', 'DOI', 24), ('category', 'Category (2 Nov 2026 triage)', 16), ('filter_A_14Aug', '14 Aug outcome rule', 40),
          ('filter_B_9Oct', '9 Oct opioid-result criterion', 40), ('other_criteria', 'Other criteria', 40),
          ('proposed_human_action', 'Proposed human action', 40), ('evidence_basis', 'Evidence basis', 40),
          ('local_full_text', 'Local full text', 9), ('covidence_date', 'Covidence date', 10)])"""))
R.append(("""                [('Reports', 'One row per report sought (225)'), ('Fig. 1 counts', 'Exclusion reasons, reconciled with Fig. 1'),""",
          """                [('Reports', 'One row per report sought (225)'), ('Fig. 1 counts', 'Exclusion reasons, reconciled with Fig. 1'),
                 ('Outcome exclusions recheck', 'AI-assisted triage (2 Nov 2026) of the 113 "No eligible analgesic outcome" exclusions under both dated outcome requirements; not a human screen [PROVISIONAL]'),"""))

# ---- AF6: analysis inputs (M04, M05)
R.append(("""    sheet(wb, 'All opioid results', allop,""",
          """    sheet(wb, 'Analysis inputs', analysis_inputs(), [('analysis', 'Analysis', 30), ('report', 'Report', 20), ('result_id', 'Result ID(s)', 22),
          ('outcome', 'Outcome', 30), ('window', 'Window', 14), ('raw_unit', 'Unit as reported', 16),
          ('raw_values', 'Values as reported (intervention; control)', 40), ('factor', 'Factor', 8), ('model_values', 'Values entering the model', 40),
          ('yi', 'Effect (model scale)', 10), ('vi', 'Variance', 10), ('source_location', 'Source location', 26),
          ('source_quote', 'Verbatim source text', 50), ('source_sha256', 'Source SHA-256', 20)])
    sheet(wb, 'All opioid results', allop,"""))
R.append(("""                [('Rules', 'Definitions and admission rules'),""",
          """                [('Rules', 'Definitions and admission rules'),
                 ('Analysis inputs', 'Every value entering an analysis reported in the main text: values as reported, factor, values as modelled, and source'),"""))
R.append(("""def af7():""",
          '''MAIN_MODELS = ['opioid24_TEAS_sham', 'opioid24_TEAS_usual', 'opioid24_EA_usual', 'E2_opioid24_TEAS_sham', 'E2_opioid24_TEAS_usual',
               'E2_opioid24_EA_sham', 'E2_opioid24_EA_usual', 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'ponv24_TEAS_sham', 'vomiting24_TEAS_sham',
               'pain24_rest_TEAS_sham', 'pain24_unclassified_TEAS_sham', 'QoR40_SHAM_24H', 'QoR15_SHAM_24H', 'flatus_TEAS_sham',
               'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY']


def analysis_inputs():
    """Inputs to every analysis reported in the main text, with values as reported (inventory) and as modelled."""
    inv = {r['result_id']: r for r in recs(C / 'all_40_result_inventory.csv')}
    src = recs(R / 'model_inputs.csv') + recs(R / 'e2/e2_model_inputs.csv') + recs(C / 'model_inputs.csv')
    out, seen = [], set()
    for r in src:
        m = r.get('model_id', '')
        if m not in MAIN_MODELS or r['study'] == 'Lee 2011' or (m, r['result_id']) in seen:
            continue
        seen.add((m, r['result_id']))
        ids = r['result_id'].split('+')
        raw = []
        for i in ids:
            v = inv.get(i)
            if not v:
                continue
            if v['events_i']:
                raw.append(f"{v['events_i']}/{v['n_i']} vs {v['events_c']}/{v['n_c']}")
            else:
                raw.append(f"{v['mean_i']} ({v['sd_i']}), n {v['n_i']} vs {v['mean_c']} ({v['sd_c']}), n {v['n_c']}")
        v0 = inv.get(ids[0], {})
        ev = r.get('events_i', '')
        mv = (f"{ev}/{r.get('n_i', '')} vs {r.get('events_c', '')}/{r.get('n_c', '')}" if ev else
              f"{r.get('mean_i', '')} ({r.get('sd_i', '')}), n {r.get('n_i', '')} vs {r.get('mean_c', '')} ({r.get('sd_c', '')}), n {r.get('n_c', '')}")
        quote = v0.get('source_quote', '') or r.get('source_quote', '') or r.get('source_excerpt', '')
        out.append(dict(analysis=m, report=r['study'], result_id=r['result_id'], outcome=v0.get('outcome', r.get('outcome', '')),
                        window=v0.get('window', r.get('window', '')), raw_unit=v0.get('unit', ''),
                        raw_values=' | '.join(raw) if raw else 'see result inventory',
                        factor=r.get('factor', ''), model_values=mv, yi=num(r.get('yi', ''), 4), vi=num(r.get('vi', ''), 5),
                        source_location=v0.get('source_location', r.get('source_location', '')),
                        source_quote=quote or 'Not recorded (location only)', source_sha256=v0.get('source_sha256', '')[:16]))
    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(), sorted(set(MAIN_MODELS) - {o['analysis'] for o in out})
    return sorted(out, key=lambda o: (MAIN_MODELS.index(o['analysis']), o['report']))


def af7():'''))

# ---- AF7: factor meaning and Gu derivation (M10)
R.append(("""    applied = [dict(e, models='; '.join(sorted(set(e['models'])))) for e in app.values()]""",
          """    applied = [dict(e, models='; '.join(sorted(set(e['models'])))) for e in app.values()]
    for e in applied:
        u = e['unit'].lower()
        if e['study'] == 'Gu 2019':
            e['meaning'] = ('PCIA solution in mL digitised from Fig. 4; 1 mL contains 1 µg sufentanil (100 µg in 100 mL), so mL = µg '
                            'sufentanil; then the sufentanil factor (0.5, with 0.25 and 1.0 as bounds)')
        elif e['factor'] == 1 and 'morphine' in u:
            e['meaning'] = 'Identity: already mg IV morphine (or author morphine equivalents, sensitivity only)'
        elif e['factor'] == 1:
            e['meaning'] = 'Native units: not converted (analysed in the drug\\'s own unit)'
        else:
            e['meaning'] = 'Converted to mg IV morphine with the register factor'"""))
R.append(("""    sheet(wb, 'Applied to results', applied, [('study', 'Report', 22), ('result_id', 'Result ID(s)', 26), ('unit', 'Source unit', 16),
                                              ('factor', 'Factor applied', 12), ('models', 'Analyses', 80)])""",
          """    sheet(wb, 'Applied to results', applied, [('study', 'Report', 22), ('result_id', 'Result ID(s)', 26), ('unit', 'Source unit', 16),
                                              ('factor', 'Factor applied', 12), ('meaning', 'What the factor does', 50), ('models', 'Analyses', 80)])"""))
R.append(("""                    'Sufentanil: 0.5 mg IV morphine per µg is the central factor, with 0.25 and 1.0 as sensitivity bounds. It is the '""",
          """                    'Timing: the factors were fixed on 20 September 2026, with trial results known; the registration anticipated '
                    'conversion rules but did not give the values.',
                    'Sufentanil: 0.5 mg IV morphine per µg is the central factor, with 0.25 and 1.0 as sensitivity bounds. It is a '
                    'research assumption: the '"""))

# ---- AF8: Szmit MMA; descriptive comparator; Lee effect-direction row (M11, M14, m04)
R.append(("""        r['sha'] = frc[k]['source_sha256']
        rows.append(r)""",
          """        r['sha'] = frc[k]['source_sha256']
        if k == 'Szmit 2021':   # M11: stated definition has no time boundary; report §2.5.1, PDF p3
            assert r['s_mma_all_groups'] == 'No'
            r['s_mma_all_groups'] = 'Yes (corrected 2 Nov 2026)'
            r['s_non_opioid_components'] = 'Metamizole 1 g to every patient before the end of surgery; further metamizole 1 g if needed before PCA'
            r['s_mma_quote'] = 'For basic pain control, 1 g of metamizole was given to every patient before completion of the surgery.'
            r['s_mma_page'] = '3'
        r['comp_desc'] = T1COMP[k]
        rows.append(r)"""))
R.append(("""    eff = recs(C / 'dose_protocol_effect_directions.csv')""",
          """    eff = recs(C / 'dose_protocol_effect_directions.csv')
    for e in eff:
        if e['study'] == 'Lee 2011':   # m04: historical row; Lee 2011 held from all pooled analyses since 23 Oct 2026
            e['limitation'] = 'Historical: Lee 2011 is held from all pooled analyses (23 Oct 2026); shown for completeness. ' + e['limitation']"""))
R.append(("""        ('modality', 'Modality', 9), ('comparator', 'Comparator', 30), ('comparator_class', 'Comparator class', 12),""",
          """        ('modality', 'Modality', 9), ('comparator', 'Comparator (as extracted)', 30), ('comparator_class', 'Comparator class (extraction)', 12),
        ('comp_desc', 'Comparator arms (as in Table 1)', 22),"""))
R.append(("""def af8():""",
          """T1COMP = {re.sub(r'\\s*\\[@[^\\]]+\\]', '', r[0]): r[8].replace('§', '') for r in list(csv.reader(open(REV / 'sources/table1_REVISED.csv', encoding='utf-8')))[1:]}


def af8():"""))
R.append(("""                 'Zhou 2021 analgesia corrected on 24 Oct 2026: all included patients had epidural-assisted general anaesthesia.',""",
          """                 'Zhou 2021 analgesia corrected on 24 Oct 2026: all included patients had epidural-assisted general anaesthesia.',
                 'Szmit 2021 multimodal analgesia corrected on 2 Nov 2026 (No to Yes): every patient received 1 g metamizole before the end of surgery. The stated definition counts routine non-opioid analgesia at any perioperative time; a keyword check of the other 39 reports found no similar omission.',
                 'Comparator arms (as in Table 1) gives the arms actually compared; for Wu 2016 the "sham" is identical current at non-acupoints (an active comparator), and Grech 2016 describes no sham procedure.',"""))

# ---- AF10: blank outcome labels; signalling recorded flag (M09)
R.append(("""    rows = []
    for u in sorted(units.values(), key=lambda x: (x['study'], x['outcome'], x['key'])):""",
          """    LABEL = {'ALLCAUSE-HE-DEATH': 'All-cause death (harms)', 'ALLCAUSE-ESD-BLEED': 'Bleeding, all-cause (harms)',
             'HARMS-BURN-SKIN': 'Skin injury at electrode sites (harms)', 'SAT-YAO2015-GE8': 'Satisfaction score of 8 or more',
             'HARMS-ZHANG-ITCH': 'Itching at electrode sites (harms)', 'HARMS-ZHANG-RED': 'Redness at electrode sites (harms)',
             'QOR-ZHOU2025-POD3-AS-PRINTED': 'QoR-15 on postoperative day 3, as printed'}
    for u in units.values():
        if not u['outcome']:
            u['outcome'] = LABEL[u['key']] + ' [label added 2 Nov 2026]'
    rows = []
    for u in sorted(units.values(), key=lambda x: (x['study'], x['outcome'], x['key'])):"""))
R.append(("""    with_sig = {s['aid'] for s in sig}
    n_with = sum(u['aid'] in with_sig for u in units.values())""",
          """    with_sig = {s['aid'] for s in sig}
    n_with = sum(u['aid'] in with_sig for u in units.values())
    for r in rows:
        r['sigrec'] = 'Recorded' if r['aid'] in with_sig else 'Not recorded (domain rationale only)'"""))
R.append(("""                                   ('r5', 'D5 rationale', 50), ('ro', 'Overall rationale', 50), ('aid', 'Assessment ID', 24),""",
          """                                   ('r5', 'D5 rationale', 50), ('ro', 'Overall rationale', 50), ('aid', 'Assessment ID', 24),
                                   ('sigrec', 'Signalling responses', 18),"""))

# ---- AF11: rescue precision and labels (m04)
R.append(("""        resc.append(dict(g, effect=num(g['effect'], 2), ci_low=num(g['ci_low'], 2), ci_high=num(g['ci_high'], 2)))""",
          """        lo = float(g['ci_low'])
        resc.append(dict(g, effect=num(g['effect'], 2), ci_low=float(f'{lo:.3g}') if lo < 0.01 else num(lo, 2), ci_high=num(g['ci_high'], 2)))"""))
R.append(("""                                              ('analyzed_N', 'Participants', 10), ('events_i', 'Events, TEAS', 9), ('n_i', 'N, TEAS', 8),""",
          """                                              ('analyzed_N', 'Participants', 10), ('events_i', 'Events, intervention (TEAS or EA)', 9), ('n_i', 'N, intervention', 8),"""))
R.append(("""                                              ('corresponding_intervention_per_1000', 'TEAS risk per 1000', 10), ('corresponding_low_per_1000', 'Low', 8),""",
          """                                              ('corresponding_intervention_per_1000', 'Intervention risk per 1000', 10), ('corresponding_low_per_1000', 'Low', 8),"""))

# ---- AF12: tau2 for the Lee 2011 refits (m04)
R.append(("""    lee = {r['model_id']: r for r in recs(R / 'lee_hold_rerun_2026-10-23.csv')}""",
          """    lee = {r['model_id']: r for r in recs(R / 'lee_hold_rerun_2026-10-23.csv')}
    rep = {r['model_id']: r for r in recs(REV / 'reproduce/reproduced_final_estimates.csv') if r['set'] == 'lee_hold_refit'}
    assert set(rep) == set(lee)
    for m in lee:
        lee[m]['tau2'] = rep[m]['tau2']   # tau2 from reproduce_final.R (same estimator); not stored by the refit"""))
R.append(("""            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'], tau2='',""",
          """            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'],"""))

# ---- AF9: reproduction script, revision builders and C01 records (M05)
R.append(("""    'manuscript': [HERE / 'assemble_manuscript.py', HERE / 'build_docx.js', HERE / 'build_additional_files.py'],""",
          """    'manuscript': [HERE / 'make_sources.py', HERE / 'assemble_revision.py', HERE / 'build_docx.js', HERE / 'build_additional_files.py',
                   HERE / 'patch_additional_files.py', HERE / 'references/build_references.py', HERE / 'references/references_revision.csv'],
    'manuscript/sources': sorted((HERE / 'sources').glob('*_REVISED.*')) + [HERE / 'sources/make_table1_revised.py', HERE / 'sources/table1_REVISED_edits.csv'],
    'selection_check': [HERE / 'C01_selection/build_c01_triage.py', HERE / 'C01_selection/C01_historical_outcome_exclusions_triage.csv',
                        HERE / 'C01_selection/c01_scenarios.R', HERE / 'C01_selection/C01_scenarios.csv', HERE / 'C01_selection/C01_FOUR_REPORTS.md'],
    'figures': [HERE / 'figures/manuscript_figures_REVISED_2026-11-02.do'],"""))
R.append(("""    'data/results': [R / 'model_results.csv', R / 'lee_hold_rerun_2026-10-23.csv', R / 'dose_restriction_rerun_2026-10-23.csv',""",
          """    'data/results': [R / 'model_results.csv', R / 'lee_hold_rerun_2026-10-23.csv', R / 'dose_restriction_rerun_2026-10-23.csv',
                     HERE / 'reproduce/reproduced_final_estimates.csv',"""))
R.append(("""        z.writestr('Additional_file_9/README.md', '\\n'.join(readme) + '\\n')""",
          """        z.writestr('Additional_file_9/README.md', '\\n'.join(readme) + '\\n')
        z.write(HERE / 'reproduce/reproduce_final.R', 'Additional_file_9/reproduce_final.R')"""))
R.append(("""              '## Running', '',""",
          """              '## Reproducing the final estimates', '',
              'From this folder, with R installed: `Rscript reproduce_final.R`. Base R only; it reads `data/inputs` and '
              '`data/results`, refits every final model (239: registered outcome, rescue receipt and other opioid models; the '
              'broader first-day models without Lee 2011; all other outcomes), writes `reproduced_final_estimates.csv`, and '
              'stops with an error if any effect or confidence limit differs from the archived result by more than 2 × 10⁻⁶. '
              'Expected output ends: "Reproduction passed." A passing run shows that the estimates follow from these inputs; it '
              'does not show that the inputs were extracted correctly or that the set of included trials is complete.', '',
              'Units: in `data/inputs/reviewer_rerun_model_inputs.csv` and `e2_model_inputs.csv` the arm means and SDs are '
              'already converted to mg IV morphine (`factor` gives the factor applied); the `unit` column gives the source '
              'unit. For example, Chen 1998 is stored as 32.5 and 53.5 (hydromorphone 6.5 and 10.7 mg × 5). Do not convert '
              'these values again. Values as reported are in Additional file 6, sheet Analysis inputs.', '',
              '## Running the build scripts', '',"""))

for old, new in R:
    assert s.count(old) == 1, old[:90]
    s = s.replace(old, new)
p.write_text(s, encoding='utf-8')
print('applied', len(R), 'replacements')
