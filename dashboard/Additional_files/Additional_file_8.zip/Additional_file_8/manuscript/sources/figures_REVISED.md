## Figure 1

**Title:** PRISMA 2020 flow diagram

**Legend:** Database searches were run in July 2026; one further report was identified by citation searching. ᵃ 1,652 duplicates removed in Covidence and 12 references merged by Covidence at import (5,100 references imported as 5,088 records). ᵇ At full text, eligibility required a 24-hour opioid or approximately 24-hour pain outcome, which is narrower than the registered eligibility (see Methods). Reasons for each report are in Additional file 4. ᶜ No named postoperative opioid or morphine-equivalent quantity could be confirmed in the source: none was located in the available report for 27, and for 15 the opioid identity, quantity or timing could not be confirmed (Additional file 4). ᵈ Two reports (Yeh 2010 and Yeh 2011) probably describe overlapping participants and are counted as one study. Adapted from Page et al. [@page2021statement].

## Figure 2

**Title:** Contribution of each included report to the analyses

**Legend:** Rows are reports grouped by modality; columns are outcome domains. P, contributed to a pooled main analysis; 1, single-trial main estimate; I, individual estimate in the report's original units, not pooled; S, sensitivity or diagnostic analysis only; H, held from synthesis; Q, qualitative finding only. The control column gives the principal comparator (Active, an active electrical comparator at non-acupoints). The bottom row counts reports in a main analysis for each domain. The broader first-day dose domain is itself a sensitivity analysis of the primary outcome. GI, gastrointestinal.

## Figure 3

**Title:** Risk of bias

**Legend:** (A) Result-specific RoB 2 judgements for the first-day opioid analyses (including the three primary-outcome trials, marked *), rescue opioid receipt and nausea and vomiting over 0–24 hours. (B) Distribution of judgements by domain across all 180 assessed results. D1, randomisation process; D2, deviations from intended interventions; D3, missing outcome data; D4, measurement of the outcome; D5, selection of the reported result.

## Figure 4

**Title:** Broader first-day opioid consumption, by modality and comparator

**Legend:** This is a sensitivity analysis of the primary outcome that admits results with incomplete capture of systemic opioid. Mean differences are in mg intravenous morphine equivalents; negative values favour TEAS or EA. Pooled estimates use random-effects models (REML) with Hartung–Knapp 95% confidence intervals, and weights are calculated within each comparison. Single trials show their own 95% confidence intervals. The line through the TEAS-versus-sham diamond is the 95% prediction interval. Nothing is pooled across comparisons. Szmit 2021, Wang 1997 and Lin 2002 appear twice because their active arms were compared with both sham and usual care. Arrows mark intervals that extend beyond the axis. Lee 2011 is held from all pooled analyses.

## Figure 5

**Title:** Receipt of additional rescue opioid, TEAS versus sham

**Legend:** Exploratory analysis of the proportion of participants given at least one rescue opioid dose. Risk ratios are shown on a log scale; values below 1 favour TEAS. Six of the seven trials were conducted in China and one in the USA. Follow-up was 6–24 hours, 24 hours, through the first postoperative day, 48 hours or 3 days, and was not stated in Yu 2020 or Fu 2024, so the pooled estimate is not a 0–24-hour effect. The pooled estimate uses a random-effects model (REML) with a Hartung–Knapp 95% confidence interval. τ² was estimated as zero, so the 95% prediction interval equals the confidence interval and does not show that effects were consistent.
