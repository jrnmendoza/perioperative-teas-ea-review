"""Revised Table 1 = submitted Table 1 + the corrections below (audit findings M06, M11, M13, M14) + the Wang 1997 row
(decision D1, 2 Nov 2026). Each edit asserts
the submitted value first. Sources: registered_completion_2026_10_09/protocol_characteristics.csv (AF8) and the report
pages cited. Writes table1_REVISED.csv."""
import csv, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
rows = list(csv.reader(open(HERE / 'table1_SUBMITTED_2026-10-25.csv', encoding='utf-8')))
hdr, body = rows[0], rows[1:]
col = {h: i for i, h in enumerate(hdr)}
by = {r[0]: r for r in body}
EDITS = [
    # (study, column, submitted value, revised value, basis)
    ('An 2014', 'Female, %', '65', '53', 'AF8: EA 24/41, control 19/40 female = 43/81; the parser had read the male/female ratio'),
    ('Coura 2011', 'Frequency', '15 Hz', '3/15 Hz', 'AF8: 3 and 15 Hz, alternating every 4 s'),
    ('Oztas 2019', 'Frequency', '100 Hz', '2–100 Hz', 'AF8: 2–100 Hz varying'),
    ('Chen 1998', 'Age, y', '43/45/44', '43/45/44/44', 'AF8: four arms (acupoint, sham, non-acupoint, dermatomal)'),
    ('Wu 2016', 'Comparator', 'Sham', 'Active non-acupoint; usual care', 'AF8: identical 2/100 Hz current at non-acupoints, and no-TAES control; analysed as active and usual-care contrasts (AF12)'),
    ('Grech 2016', 'Comparator', 'Sham', 'Usual care§', 'Report calls the control "sham (control)" but describes no sham procedure; classed usual care, as in AF8 and Fig. 2'),
    ('Xie 2014', 'Comparator', 'Sham', 'Sham; usual care', 'AF8: general-anaesthesia control and sham needling arms'),
    ('Lee 2011', 'Comparator', 'Sham', 'Sham; usual care', 'AF8: sham SSP and untreated control arms'),
    ('Yeh 2011', 'Comparator', 'Sham', 'Sham; usual care', 'AF8: electrical sham and no-AES control arms'),
    ('Szmit 2021', 'MMA', 'No', 'Yes', 'Report §2.5.1, PDF p3: 1 g metamizole given to every patient before the end of surgery'),
]
for study, c, old, new, _ in EDITS:
    assert by[study][col[c]] == old, (study, c, by[study][col[c]])
    by[study][col[c]] = new
# Wang 1997 added on 2 Nov 2026: the review owner judged its stimulation to be TEAS (decision D1; results known).
# Values from Anesth Analg 1997;85:406-13 (wang1997/wang1997_characteristics.csv). N: both active arms / sham.
WANG = ['Wang 1997', 'USA', 'Hospital', 'Gynecologic & Breast', '101 (50/25)', '44/44/45/43', '100', 'TEAS', 'Sham; usual care',
        'LI4 + 2 peri-incisional points', '2/100 Hz', 'Post; 30 min every 2 h while awake, until oral analgesia sufficed', 'No']
assert len(WANG) == len(hdr) and 'Wang 1997' not in by
body.insert(next(i for i, r in enumerate(body) if r[0] == 'Wu 2016'), WANG)
# Decision D3 (2 Nov 2026): Colak 2010 and Fu 2024 included; Chen 2016 included but held from pooled analyses (eligible ages 16-80).
# Values from d3/d3_characteristics.csv (source pages there). N: intervention/control analysed.
D3 = {'Fu 2024': (['Fu 2024', 'China', 'University', 'Neurosurgery', '60 (30/29)', '61/62', '39', 'TEAS', 'Sham', 'Bilateral ST36, SP6', '2/10 Hz',
                   'Intra; 1 through both stages, paused during microelectrode recording', 'Yes'], 'Gao 2022'),   # descriptor corrected 3 Nov 2026 (Fu p3)
      'Chen 2016': (['Chen 2016', 'China', 'University', 'Thoracic & Cardiac', '92 (46/46)', '56/57', '26', 'EA', 'Sham', 'Bilateral LR3, GB34, TE5, LU5',
                     '2 Hz', 'Post; 6 × 30 min (every 12 h for 3 days)', 'Yes'], 'Coura 2011'),
      'Colak 2010': (['Colak 2010', 'Turkey', 'University', 'Thoracic & Cardiac', '30 (15/15)', '52/52', '37', 'EA', 'Usual care', 'LI4, LI11, ST36, PC6, LR3',
                      '60 Hz', 'Post; 7 × 20 min (daily)', 'No'], 'Coura 2011')}
for name, (row, before) in D3.items():
    assert len(row) == len(hdr) and name not in [r[0] for r in body]
    body.insert(next(i for i, r in enumerate(body) if r[0] == before), row)
slug = lambda s: 'inc_' + re.sub(r'[^a-z0-9]+', '', s.lower())
for r in body:
    r[0] = f'{r[0]} [@{slug(r[0])}]'
with open(HERE / 'table1_REVISED.csv', 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows([hdr] + body)
with open(HERE / 'table1_REVISED_edits.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['study', 'column', 'submitted', 'revised', 'basis']); w.writerows(EDITS)
print(len(body), 'rows;', len(EDITS), 'cells corrected; Wang 1997 and the D3 reports added')
