**Title:** Summary of findings: TEAS or EA versus sham or usual care after surgery

| Outcome | Comparison | Trials (participants) | Effect (95% CI) | Certainty |
| Systemic opioid, 0–24 h (primary) | TEAS vs sham | 1 (48) | MD −7.70 mg (−10.62 to −4.78) | Low |
|  | EA vs sham | 0 | No eligible result | Not rated |
|  | TEAS vs usual care | 1 (47) | MD −8.00 mg (−10.92 to −5.08) | Low |
|  | EA vs usual care | 2 (159) | MD −6.83 mg (−76.39 to 62.73) | Very low |
| Rest pain, ~24 h (co-primary) | TEAS vs sham | 1 (60) | MD −1.03 points (−1.80 to −0.26) | Low* |
|  | EA vs usual care | 1 (30) | MD −0.20 points (−1.05 to 0.65) | Very low* |
| Broader first-day opioid (sensitivity analysis) | TEAS vs sham | 7 (622) | MD −7.22 mg (−14.13 to −0.32) | Very low |
|  | TEAS vs usual care | 2 (123) | MD −17.19 mg (−146.73 to 112.35) | Very low |
|  | EA vs sham | 1 (75) | MD −11.80 mg (−18.52 to −5.08) | Very low |
|  | EA vs usual care | 4 (414) | MD −8.14 mg (−23.06 to 6.77) | Very low |
| Rescue opioid receipt (exploratory; follow-up 6 h to 3 days)† | TEAS vs sham | 7 (612) | RR 0.51 (0.37 to 0.71); 17 fewer per 100 (10 to 22 fewer)‡ | Low |
|  | EA vs sham | 1 (40) | RR 0.17 (0.02 to 1.26) | Very low |
| PONV, 0–24 h | TEAS vs sham | 9 (2848) | RR 0.60 (0.45 to 0.79); 14 fewer per 100 (7 to 19 fewer)‡ | Low |

**Legend:** *Certainty that the intervention does not worsen pain by 1 point or more; neither result comes from a trial that reported the primary opioid outcome. Adding the two rest-pain trials removed by the opioid-result requirement gave MD −0.21 (−0.75 to 0.33). †Proportion of participants given at least one rescue opioid dose, over each trial's own follow-up (not stated in two trials); excluding the two trials at high risk of bias gave RR 0.52 (0.32 to 0.84). ‡Illustrative absolute effects at the observed comparator risk (34.5% for rescue, 34.1% for PONV). Reasons for downgrading are given in Additional file 11. CI, confidence interval; EA, electroacupuncture; MD, mean difference; PONV, postoperative nausea and vomiting; RR, risk ratio; TEAS, transcutaneous electrical acupoint stimulation.
