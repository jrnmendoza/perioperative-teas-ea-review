"""Dated 40-report opioid-focused PRISMA; preserves canonical v38 decisions.
Run using the bundled Python (reportlab). Generated files are reproducible.
"""
import csv, json, hashlib, math, html, shutil
from collections import Counter
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase.pdfmetrics import stringWidth

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
DATE='2026-10-09'
def read(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def csvwrite(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
        w.writeheader();w.writerows(rows)

source=ROOT/'10_FINAL_ADJUDICATION/02_DECISIONS/v38'
base=json.loads((source/'prisma_counts.json').read_text())
ledger=read(source/'prisma_record_ledger.csv')
audit={r['report']:r for r in read(ROOT/'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv')}
reason_map={
 'NO_POSTOP_OPIOID_RESULT_LOCATED':'No postoperative opioid result located in available report',
 'REQUEST_PROXY_ONLY':'Pump requests/presses only; opioid quantity not verified',
 'AUTHOR_IDENTIFIED_OPIOID_DELIVERIES':'Reported pump deliveries; opioid identity/formulation unconfirmed',
 'UNRESOLVED':'Opioid outcome identity, timing or treatment comparison unresolved'}
focused=[];added=[];included=[]
for old in ledger:
    row=dict(old,historical_disposition=old['final_disposition'],historical_reason=old['final_reason'],
             focused_disposition=old['final_disposition'],focused_reason=old['final_reason'],
             focused_decision_date=DATE,focused_decision_basis='Historical v38 disposition retained under review-owner instruction',
             outcome_clarification_status='',source_pdf='',source_sha256='')
    if old['final_disposition']=='INCLUDED':
        a=audit[old['registry_report']]
        row.update(source_pdf=a['source_pdf'],source_sha256=a['source_sha256'],
                   outcome_evidence_category=a['category'],outcome_finding=a['finding'],outcome_limit=a['limitation'])
        if a['source_confirmed_named_opioid_or_author_MME']=='YES':
            row.update(focused_decision_basis='Retained in owner-selected 40-report opioid-focused manuscript set; full eligibility not re-adjudicated',
                       trial_family=a['trial_id'],outcome_clarification_status='Named opioid/author MME confirmed; report-specific pooling holds retained')
            included.append(row)
        else:
            row.update(focused_disposition='EXCLUDED_FROM_FOCUSED_WORKING_SET',
                       focused_reason=reason_map[a['category']],
                       focused_decision_basis='Review owner requested the fixed 40-report opioid-focused manuscript set on 2026-10-09; outcome audit dated 2026-10-08',
                       outcome_clarification_status='Outcome clarification pending' if a['category']!='NO_POSTOP_OPIOID_RESULT_LOCATED' else 'No result located; does not establish never measured')
            added.append(row)
    focused.append(row)
assert len(included)==40 and len(added)==30 and len(focused)==225
assert len({r['trial_family'] for r in included})==39
assert Counter(r['route'] for r in included)=={'DATABASE':39,'CITATION SEARCH':1}
reasons=dict(base['exclusion_reasons'])
reasons.update(Counter(r['focused_reason'] for r in added))
assert sum(reasons.values())==177
for r in audit.values():
    assert hashlib.sha256((ROOT/r['source_pdf']).read_bytes()).hexdigest()==r['source_sha256']
counts=dict(base)
counts.update(version='OPIOID_FOCUSED_40_REPORT_WORKING_SELECTION',date=DATE,
    database_excluded=177,database_included=39,included_reports=40,operational_trial_families=39,
    exclusion_reasons=reasons,original_included_reports=70,original_database_excluded=147,
    additional_focused_exclusions=30,additional_exclusion_reasons=dict(Counter(r['focused_reason'] for r in added)),
    pending_outcome_clarification_outside_set=12,final_eligibility_verified=False,
    scope_amendment='Opioid-focused manuscript selected after original protocol and knowledge of results; authorized 2026-10-09',
    chart_status='Working selection for the authorized 40-report manuscript; not a fresh completed eligibility re-screen',
    caveats=base['caveats']+[
        'The 30 additional reports are excluded from the selected manuscript working set, not all proven to lack opioid outcomes: 18 no result located, 4 request proxies, 2 drug-unconfirmed delivery results, 6 other unresolved outcomes.',
        'Some retained reports have unresolved intervention/anesthesia eligibility or overlap; exclusion from an individual synthesis does not remove a report from this chart.',
        'The 39 trial families are provisional because Yeh 2010/2011 overlap has not been established. Earlier exclusions remain outside under the owner instruction; historical evidence-completeness limitations remain disclosed.'
    ])
assert counts['reported_import_records']-counts['automatic_duplicates']-counts['manual_duplicates']-counts['automation_exclusions']==counts['screened']
assert counts['screened']-counts['title_abstract_excluded']==counts['database_sought']
assert counts['database_sought']-counts['database_not_retrieved']-counts['late_duplicates']==counts['database_assessed']
assert counts['database_assessed']-counts['database_excluded']==counts['database_included']
assert counts['database_included']+counts['citation_included']==counts['included_reports']
(HERE/'prisma_counts.json').write_text(json.dumps(counts,indent=2)+'\n')
csvwrite(HERE/'prisma_record_ledger.csv',focused)
csvwrite(HERE/'additional_30_report_dispositions.csv',added)
csvwrite(HERE/'included_40_report_ledger.csv',included)

# One scene generates the editable SVG and vector PDF; coordinates are top-down.
W,H=595.276,841.89
scene=[];text_regions=[]
INK='#172B39';EDGE='#7C929F';FILL='#F4F7F9';TEAL='#DBF0EB'
def rect(x,y,w,h,fill=FILL,stroke=EDGE):scene.append(('rect',x,y,w,h,fill,stroke))
def text(x,y,value,size=9.2,bold=False,color=INK,rotate=0):
    assert all(ord(c)<128 for c in value),value
    scene.append(('text',x,y,value,size,bold,color,rotate))
def line(x1,y1,x2,y2,arrow=False):scene.append(('line',x1,y1,x2,y2,arrow))
def wrap(value,width,size,bold=False):
    font='Helvetica-Bold' if bold else 'Helvetica';out=[];current=''
    for word in value.split():
        test=(current+' '+word).strip()
        if current and stringWidth(test,font,size)>width:out.append(current);current=word
        else:current=test
    if current:out.append(current)
    return out
def box(x,y,w,h,heading,body=(),fill=FILL,size=9.2,title_size=9.7):
    rect(x,y,w,h,fill);baseline=y+16
    for value,bold,fs in [(heading,True,title_size)]+[(v,False,size) for v in body]:
        for value_line in wrap(value,w-20,fs,bold):
            text(x+10,baseline,value_line,fs,bold);baseline+=fs+3
        baseline+=1
    assert baseline-(size+3)<=y+h-7,(heading,baseline,y+h)
    text_regions.append(dict(heading=heading,x=x,y=y,w=w,h=h,last_baseline=baseline-(size+3)))

text(39,31,'PRISMA 2020 - opioid-focused review',17,True)
text(39,49,'40-report manuscript working selection | 9 October 2026',10)
text(39,64,'Scope narrowed after the original protocol and after results were known.',8.5)
for y,h,label in [(78,142,'Identification'),(235,465,'Screening'),(718,48,'Included')]:
    rect(15,y,23,h,'#E3EBF0',None)
    text(30,y+h/2+stringWidth(label,'Helvetica-Bold',8.7)/2,label,8.7,True,rotate=-90)

X,L,R,RW=52,230,310,235
box(X,78,L,73,'Database references identified (n = 5100)',[
    'Embase 1928; CENTRAL 1698', 'CINAHL 465; PubMed 1009', 'Original searches; no new search in this update.'],size=8.8)
box(R,78,RW,83,'Citation searching: Wu 2016 (n = 1)',[
    'Reports sought: 1; not retrieved: 0', 'Reports assessed: 1; excluded: 0', 'Reports retained in focused set: 1'],size=8.8)
line(X+L/2,151,X+L/2,169,True)
box(X,169,L,45,'Reported imported records (n = 5088)', ['12-reference difference remains unmapped.'],size=8.6)
box(R,174,RW,56,'Records removed before screening (n = 2160)',[
    'Automatic duplicates 1651; manual duplicate 1', 'Automation exclusions 508'],size=8.2,title_size=9.1)
line(X+L,189,R,189,True)
line(X+L/2,214,X+L/2,245,True)
box(X,245,L,40,'Records screened (n = 2928)')
box(R,248,RW,37,'Records excluded (n = 2704)')
line(X+L,264,R,264,True)
line(X+L/2,285,X+L/2,322,True)
box(X,322,L,40,'Reports sought for retrieval (n = 224)')
box(R,325,RW,37,'Reports not retrieved (n = 2)')
line(X+L,341,R,341,True)
line(X+L/2,362,X+L/2,399,True)
box(X,399,L,40,'Retrieved records (n = 222)')
box(R,402,RW,37,'Late duplicate records removed (n = 6)')
line(X+L,418,R,418,True)
line(X+L/2,439,X+L/2,476,True)
box(X,476,L,48,'Distinct reports assessed for eligibility (n = 216)')
reason_lines=[
    'Historical full-text exclusions (147):',
    'Historical analgesia-outcome reason 113*',
    'Wrong intervention 7; comparator 3',
    'Publication language 12; setting 8',
    'Patient population 2; study design 1',
    'Abstract only 1',
    'Additional focused-set exclusions (30):',
    'No postoperative opioid result located 18',
    'Pump requests/presses only 4',
    'Pump drug/formulation unconfirmed 2',
    'Other opioid outcome information unresolved 6',
    'These last three categories require clarification.'
]
box(R,476,RW,219,'Reports outside focused set (n = 177)',reason_lines,size=8.7,title_size=9.4)
line(X+L,500,R,500,True)
line(X+L/2,524,X+L/2,577,True)
box(X,577,L,64,'Database reports retained (n = 39)',[
    'Outcome-specific synthesis holds retained.',
    'Some other eligibility questions remain unresolved.'],fill=TEAL,size=8.7)
line(X+L/2,641,X+L/2,718,True)
# Citation-route connection goes around the exclusion box, without crossing text.
line(R+RW,115,564,115);line(564,115,564,707);line(564,707,420,707);line(420,707,420,718,True)
box(X,718,R+RW-X,48,'Reports included in the opioid-focused manuscript working set (n = 40)',[
    '39 provisional trial families; Yeh 2010/2011 linkage unresolved.'],fill=TEAL,title_size=10,size=9.3)
footnotes=[
    '* Historical v38 reasons retained; earlier exclusions were not newly re-screened.',
    'The focused set has confirmed opioid results; this chart is not a completed fresh eligibility review.',
    'The 12 unresolved/proxy reports outside the set are not all proven to lack opioid outcomes.',
    'Upstream screening totals are historical aggregates. Original 70-report chart and source ledgers preserved.',
    'Adapted from PRISMA 2020: www.prisma-statement.org/prisma-2020-flow-diagram'
]
for i,value in enumerate(footnotes):text(39,781+i*11,value,7.5)

svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc">',
 '<title id="title">PRISMA flow for the 40-report opioid-focused manuscript</title>',
 '<desc id="desc">Working selection: 216 database reports assessed, 177 outside the focused set, 39 retained, plus one citation report. Forty reports represent 39 provisional families. Pending outcome and eligibility clarifications are disclosed.</desc>',
 '<rect width="100%" height="100%" fill="white"/>',
 '<defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="#526977"/></marker></defs>']
pdf_dir=ROOT/'output/pdf';pdf_dir.mkdir(parents=True,exist_ok=True)
pdf=pdf_dir/'opioid_focused_prisma_40_reports.pdf'
c=canvas.Canvas(str(pdf),pagesize=(W,H));c.setTitle('PRISMA 2020 - 40-report opioid-focused manuscript');c.setAuthor('Review working materials')
for item in scene:
    if item[0]=='rect':
        _,x,y,w,h,fill,stroke=item;c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke or fill));c.setLineWidth(.7)
        c.rect(x,H-y-h,w,h,stroke=bool(stroke),fill=1)
        svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="2" fill="{fill}" stroke="{stroke or "none"}" stroke-width=".7"/>')
    elif item[0]=='text':
        _,x,y,value,size,bold,color,rotate=item;c.saveState();c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
        c.translate(x,H-y);c.rotate(-rotate);c.drawString(0,0,value);c.restoreState()
        transform=f' transform="rotate({rotate} {x} {y})"' if rotate else ''
        svg.append(f'<text x="{x}" y="{y}" font-family="Arial, Helvetica, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}"{transform}>{html.escape(value)}</text>')
    else:
        _,x1,y1,x2,y2,arrow=item;c.setStrokeColor(HexColor('#526977'));c.setLineWidth(.8);c.line(x1,H-y1,x2,H-y2)
        if arrow:
            angle=math.atan2(y2-y1,x2-x1);p=c.beginPath();p.moveTo(x2,H-y2)
            for side in [-1,1]:
                a=angle+side*.45;p.lineTo(x2-5*math.cos(a),H-(y2-5*math.sin(a)))
            p.close();c.setFillColor(HexColor('#526977'));c.drawPath(p,fill=1,stroke=0)
        svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#526977" stroke-width=".8"'+(' marker-end="url(#arrow)"' if arrow else '')+'/>')
c.showPage();c.save();svg.append('</svg>')
(HERE/'prisma_40_reports.svg').write_text('\n'.join(svg)+'\n')
(HERE/'layout_checks.json').write_text(json.dumps(text_regions,indent=2)+'\n')
reasons_md='\n'.join(f'| {r} | {n} |' for r,n in reasons.items())
readme=f'''# PRISMA for the 40-report opioid-focused manuscript

{DATE}. Review-owner instruction: use the fixed 40-report opioid-focused manuscript set. This is a dated working selection, not a new completed eligibility re-screen. Original v38 files and Covidence dispositions are unchanged.

## Counts

Database route: 5100 raw references; 5088 historical reported imports, with a 12-reference unmapped difference. Pre-screen removals: 1651 automatic duplicates, 1 manual duplicate, 508 automation exclusions. 2928 records screened; 2704 excluded; 224 reports sought; 2 not retrieved; 222 retrieved records; 6 late duplicates removed; 216 distinct reports assessed. Of these, 177 are outside the focused set and 39 retained.

Citation route: Wu 2016, 1 report sought/retrieved/assessed/retained. Combined focused set: **40 reports /39 provisional trial families**. Yeh linkage is unconfirmed; both reports remain held from pooled dose estimates.

The 177 comprise 147 historical exclusions plus 30 newly omitted from the requested focused working set. Each of the 30 has a report-level reason in [additional_30_report_dispositions.csv](additional_30_report_dispositions.csv). The original reason fields and focused-set disposition fields remain separate.

| Reason | Reports |
|---|---:|
{reasons_md}

No result located does not establish never measured. The 12 unresolved/proxy reports are not all confirmed to lack opioid outcomes. Some retained reports also have unresolved anesthesia, intervention or linkage eligibility. Historical exclusions remain outside under the owner's confirmation; this chart does not erase the source-audit findings or resolve historical completeness limitations.

Removing trials in a risk-of-bias sensitivity analysis does not remove them from the chart. The 38 numerically informative reports and two qualitative-only reports both remain in the 40. Five trials in the rescue pool and one in the original strict primary endpoint are synthesis contributions, not PRISMA selection counts.

## Figure caption for the manuscript

**Figure 1. PRISMA 2020 flow diagram for the opioid-focused manuscript working selection.** Original search and screening counts were retained. After a post-hoc scope restriction, 40 reports with source-confirmed named postoperative opioid or author-defined morphine-equivalent results were retained, representing 39 provisional trial families. Thirty reports from the original 70-report inventory were omitted from this focused working set for the reasons shown; 12 have unresolved outcome or delivery-proxy information. Eligibility and report-linkage uncertainties remain in some retained reports. Earlier exclusions were not newly re-screened. The difference between 5100 raw references and 5088 reported imports remains unmapped. Scope restriction occurred after the protocol and knowledge of results.

## Files

- [Vector PDF](../../output/pdf/opioid_focused_prisma_40_reports.pdf)
- [Editable SVG](prisma_40_reports.svg)
- [Focused counts](prisma_counts.json)
- [Complete 225-record accounting ledger](prisma_record_ledger.csv)
- [40-report membership ledger](included_40_report_ledger.csv)
- [PRISMA 2020 template guidance](https://www.prisma-statement.org/prisma-2020-flow-diagram)

Chart wording states the current working status; it must not be described as a final independently adjudicated selection. Source and canonical file hashes are recorded in verification.json.
'''
(HERE/'PRISMA_ACCOUNTING.md').write_text(readme)
assets=ROOT/'dashboard/current'
for filename in ['prisma_counts.json','prisma_record_ledger.csv','included_40_report_ledger.csv','additional_30_report_dispositions.csv','PRISMA_ACCOUNTING.md','prisma_40_reports.svg']:
    dest=assets/('opioid_'+filename if filename not in ['prisma_40_reports.svg'] else filename)
    if filename=='PRISMA_ACCOUNTING.md':
        web_md=readme.replace('../../output/pdf/opioid_focused_prisma_40_reports.pdf','opioid_focused_prisma_40_reports.pdf')
        for csvname in ['prisma_counts.json','prisma_record_ledger.csv','included_40_report_ledger.csv','additional_30_report_dispositions.csv']:
            web_md=web_md.replace(']('+csvname+')','](opioid_'+csvname+')')
        dest.write_text(web_md)
    else:
        shutil.copyfile(HERE/filename,dest)
shutil.copyfile(pdf,assets/pdf.name)
(ROOT/'dashboard/opioid_prisma.js').write_text('// Generated by opioid_only_review/prisma/build_prisma.py\nwindow.OPIOID_FOCUSED_PRISMA = '+json.dumps(counts,ensure_ascii=True)+';\n')
verification=dict(date=DATE,records=len(focused),included_reports=len(included),provisional_families=39,
    additional_exclusions=len(added),database_assessed=216,database_excluded=177,database_included=39,citation_included=1,
    reasons_total=sum(reasons.values()),pending_outcome_clarification_outside_set=12,source_pdf_hash_checks=70,
    arithmetic='PASS',layout_text_bounds='PASS',visual_check='Pending raster inspection',
    input_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source/'prisma_counts.json',source/'prisma_record_ledger.csv',ROOT/'opioid_only_review/source_audit/postoperative_opioid_source_audit.csv']})
(HERE/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps(verification,indent=2))
print(pdf)
