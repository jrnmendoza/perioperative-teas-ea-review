"""Text repairs after Astra's re-audit of the D3 work (ASTRA_D3_audit_2026-11-03/ASTRA_D3_REAUDIT_REPORT.md, 3 Nov 2026).

Runs after audit_d3/apply_audit_text.py and edits sources/*_REVISED.md in place; every passage is asserted once, and a passage
already repaired is skipped, so the script is re-runnable. Findings addressed here: R04 (name the Fu 2024 omission estimates
beside the rescue and QoR-15 results, and its source problems among the limitations), R05 (Wang 1997's pain at 48 hours is
now assessed: 180 results), R06 (revised Fu 2024 drafts: randomisation Some concerns), R11 (the abstract, with its
registration line, is now 342 words including headings; it was 356) and R12 (figures first cited in numerical order). The
Methods also record that the D3 refits were recomputed in Astra's independent re-check (35 rows in
reaudit_d3/astra_recompute_2026-11-03.csv: effects and limits within 4.8e-7, tau2 and I2 within 1.5e-6)."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'abstract': [
  # R11: the abstract is counted with its registration line (BMC: 350 words); trimmed from 356 to 342 words including headings
  ('are used perioperatively, mainly in Asia, partly to reduce analgesic requirements.',
   'are used perioperatively, partly to reduce analgesic requirements.'),
  ('(intravenous morphine equivalents), with pain at about 24 hours co-primary;', '(intravenous morphine equivalents), with 24-hour pain co-primary;'),
  ('(95% CI −10.62 to −4.78; low certainty), a point estimate below 10 mg with an interval that included it.',
   '(95% CI −10.62 to −4.78; low certainty), an interval including a 10 mg reduction.'),
  ('In a different trial (60 participants)', 'In another trial (60 participants)'),
  ('Fewer patients receiving TEAS had nausea and vomiting (low certainty).', 'Fewer TEAS recipients had nausea and vomiting (low certainty).'),
  ('Of 178 assessed results, 29% were at high risk of bias.', 'Of 180 assessed results, 29% were at high risk of bias.'),
  ('and the assessments for two reports included on 2 November 2026 await second review;',
   'and assessments for two reports included on 2 November 2026 and for Wang 1997\'s pain at 48 hours await second review;'),
 ],
 'results': [
  ('Of 178 assessed results, two (1%) were at low risk of bias, 125 (70%) had some concerns and 51 (29%) were at high risk',
   'Of 180 assessed results, two (1%) were at low risk of bias, 126 (70%) had some concerns and 52 (29%) were at high risk'),
  ('[PROVISIONAL: the 14 judgements for Colak 2010 and Fu 2024 are drafts awaiting second review.]',
   '[PROVISIONAL: the 14 judgements for Colak 2010 and Fu 2024 and the two for Wang 1997 (pain at 48 hours) are drafts awaiting second review.]'),
  ('Twenty were rated high for outcome measurement', 'Twenty-one were rated high for outcome measurement'),
  ('Almost every result (175 of 178)', 'Almost every result (177 of 180)'),
  ('Just over half (96) had some concerns about randomisation', 'Just over half (103) had some concerns about randomisation'),
  ('Leave-one-out estimates ranged from 0.50 to 0.52.',
   'Leave-one-out estimates ranged from 0.50 to 0.52; without Fu 2024, whose printed P values do not match its printed summaries '
   '(Additional file 5), the RR was 0.52 (0.37 to 0.74).'),
  ('QoR-15: MD 8.47 points, −5.18 to 22.12, three trials; very low certainty).',
   'QoR-15: MD 8.47 points, −5.18 to 22.12, three trials; very low certainty). Without Fu 2024, the QoR-15 estimate was 9.64 points '
   '(−57.20 to 76.47; two trials).'),
 ],
 'discussion': [
  ('Of 178 assessed results, 29% were at high risk of bias', 'Of 180 assessed results, 29% were at high risk of bias'),
  ('AI tools extracted data and made risk-of-bias and GRADE assessments, which one human reviewer checked;',
   'AI tools extracted data and made risk-of-bias and GRADE assessments, which one human reviewer checked [PROVISIONAL: except those '
   'added on 2 and 3 November 2026, which await this check];'),
  ('Trial authors were contacted with data queries, but none replied.',
   'Trial authors were contacted with data queries, but none replied. One trial (Fu 2024) prints P values that its own summaries '
   'cannot produce and quartiles above its scale\'s maximum; without it, the rescue estimate barely changed, but the QoR-15 estimate '
   'became very imprecise.'),
 ],
 'figures': [
  ('across all 178 assessed results', 'across all 180 assessed results'),
 ],
 'conclusions': [
  ('second review of the assessments for Colak 2010 and Fu 2024.]',
   'second review of the assessments for Colak 2010 and Fu 2024 and for Wang 1997\'s pain at 48 hours.]'),
 ],
 'methods': [
  # R12: Figs. 4 and 5 were first cited here, before Figs. 2 and 3
  ('three of the refits including Wang 1997 (the pooled models in Figs. 4 and 5) were also reproduced in Stata',
   'three of the refits including Wang 1997 (the pooled models shown as forest plots) were also reproduced in Stata'),
  ('and the pooled rescue model was also reproduced in Stata; these refits have not been independently re-checked.',
   'and the pooled rescue model was also reproduced in Stata; all of them were recomputed in a further independent AI re-check '
   '(3 November 2026), with effects and confidence limits agreeing to within 4.8 × 10⁻⁷ and τ² and I² to within 1.5 × 10⁻⁶.'),
  ('A second reviewer (SKP) checked and confirmed all of them except those for Colak 2010 and Fu 2024 [PROVISIONAL: drafted on 2 and 3 '
   'November 2026, they await this check]. Results held from synthesis were not assessed (Additional files 10 and 11).',
   'A second reviewer (SKP) checked and confirmed all of them except those for Colak 2010 and Fu 2024 and the risk-of-bias assessments '
   'of Wang 1997\'s pain at 48 hours [PROVISIONAL: drafted on 2 and 3 November 2026, they await this check]. Results held from '
   'synthesis or reported only descriptively were not assessed (Additional files 10 and 11).'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if new in s:   # already repaired (some new passages contain the old one)
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages repaired after the D3 re-audit')
