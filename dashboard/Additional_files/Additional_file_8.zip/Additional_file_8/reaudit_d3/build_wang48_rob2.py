"""RoB 2 drafts for Wang 1997's pain at 48 hours (3 Nov 2026, after Astra's re-audit, finding R05).

The two single-trial sensitivity estimates WANG_PAIN48_SHAM and WANG_PAIN48_USUAL were listed as "not assessed, as for Yu
2020 at 48 h", but Yu 2020's 48-hour pain is assessed (V33-OD-0368, confirmed by SKP on 23 Oct 2026, linked to both of its
SD variants), and the Methods assess each result used in an analysis. These drafts follow Wang's confirmed 24-hour pain
assessments (WANG97-VAS24-S/U): the trial, comparison and self-report pathway are the same, and Table 6 gives 48-hour
values for every arm. They are AI drafts awaiting SKP's review; the 12 confirmed Wang assessments are not changed.
(SKP confirmed both on 3 Nov 2026; skp_d3_review/record_skp_review.py records it.) The result's own record in
wang1997/wang1997_results.csv still said "not risk-of-bias assessed, as for that result"; that clause is corrected here too
(found 3 Nov 2026 while recording SKP's review).

Reads wang1997/wang1997_rob2_DRAFT.csv; writes reaudit_d3/wang48_rob2_DRAFT.csv and corrects wang1997/wang1997_results.csv."""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
src = {r['assessment_id']: r for r in csv.DictReader(open(REV / 'wang1997/wang1997_rob2_DRAFT.csv', encoding='utf-8'))}
ST = ('AI draft (Claude), 3 Nov 2026, after Astra\'s re-audit (R05: Yu 2020 at 48 h is assessed, so this result is too); '
      'second review by SKP pending')
rows = []
for comp, model in (('S', 'WANG_PAIN48_SHAM'), ('U', 'WANG_PAIN48_USUAL')):
    r = dict(src[f'WANG97-VAS24-{comp}'])
    r.pop('change_from_previous_draft', None)
    r.update(assessment_id=f'WANG97-VAS48-{comp}', result_id='WANG97-PAIN48', window='48 h', analyses=model, decision_status=ST)
    r['d3_rationale'] = ('Table 6 gives 48-hour values for all four arms (26/25/25/25); no losses or exclusions are reported. Proposed Low, '
                         'as at 24 h; SKP to judge whether the absence of outcome-specific denominators should lower this.')
    r['d5_rationale'] += ' Pain at 48 h is a sensitivity result (rest or movement not stated).'
    rows.append(r)
assert [r['overall'] for r in rows] == ['Some concerns', 'High'], [r['overall'] for r in rows]
with open(HERE / 'wang48_rob2_DRAFT.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('Wang 1997 48-h pain RoB 2 drafts:', [(r['assessment_id'], r['overall']) for r in rows])

res_p = REV / 'wang1997/wang1997_results.csv'   # rewritten from its snapshot by recheck/update_wang_records.py each run
res = list(csv.DictReader(open(res_p, encoding='utf-8-sig', newline='')))
p48 = next(r for r in res if r['result_id'] == 'WANG97-PAIN48')
old = 'not pooled; not risk-of-bias assessed, as for that result.'
assert p48['classification'].count(old) == 1, p48['classification']
p48['classification'] = p48['classification'].replace(old, 'not pooled; risk-of-bias assessed, as that result is (WANG97-VAS48-S and -U).')
with open(res_p, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(res[0])); w.writeheader(); w.writerows(res)
