"""Additional-files repairs after Astra's re-audit of the D3 work (ASTRA_D3_audit_2026-11-03/ASTRA_D3_REAUDIT_REPORT.md,
3 Nov 2026).

Run after audit_d3/patch_af_audit.py (the chain rewrites build_additional_files.py from its snapshot each time); this script
edits build_additional_files.py in place, each replacement asserted once. Findings addressed: R02 (AF2's deviations table and
section 12 name the work SKP has not checked), R03 and R08 (AF5: Fu 2024's further source problems; Chen 2016's pethidine
text against its Fig. 2c), R05 (AF10: Wang 1997's 48-hour pain assessed, 180 results; the false "as for Yu 2020" reason
removed), R06 (revised Fu 2024 drafts, from d3/), R09 (AF8: the remaining D3 characteristics) and AF9 (the re-audit scripts
and records). Nothing is re-estimated here."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


PEND = '[PROVISIONAL]'

# ---- AF2: deviations table, decision log, section 12 (R02) ----------------------------------------------------------
rep("Study characteristics, stimulation protocols, setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP). The arm-level opioid inputs",
    "Study characteristics, stimulation protocols, setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP) "
    "for every report except Colak 2010, Fu 2024 and Chen 2016 (decision D3), whose extraction awaits this check " + PEND + ". The arm-level opioid inputs")
rep("'Each RoB 2 and GRADE assessment was made by an AI assistant and checked and confirmed by SKP (section 12), including the 12 RoB 2 and 11 GRADE assessments for Wang 1997 (2 Nov 2026)'",
    "'Each RoB 2 and GRADE assessment was made by an AI assistant. SKP checked and confirmed them (section 12), including the 12 RoB 2 and 11 GRADE "
    "assessments for Wang 1997 (2 Nov 2026), except the 14 RoB 2 and 7 GRADE drafts for Colak 2010 and Fu 2024 and the 2 RoB 2 drafts for Wang 1997\\'s "
    "pain at 48 h, which await this check " + PEND + "'")
rep("    para(d, 'Assessments and extractions made by the AI assistant were checked by a second reviewer (SKP), including '\n"
    "            'those for Wang 1997 (2 November 2026). Each check '",
    "    para(d, 'Assessments and extractions made by the AI assistant were checked by a second reviewer (SKP), including '\n"
    "            'those for Wang 1997 (2 November 2026), except the items listed below as pending. Each check '")
rep("(9 and 2 of them added on 3 Nov after an independent AI audit)', '[CONFIRM: second review pending]'],",
    "(9 and 2 of them added on 3 Nov after an independent AI audit; the Fu 2024 randomisation and QoR-15 measurement drafts revised the "
    "same day after an AI re-audit)', '[CONFIRM: second review pending]'],\n"
    "        ['Pending', '2 RoB 2 assessments for Wang 1997 (pain at 48 h against sham and usual care; added 3 Nov after the AI re-audit found "
    "them unassessed)', '[CONFIRM: second review pending]'],")
rep("    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:",
    "    rows.append(['3 Nov', 'Independent AI audit (Codex Astra) of the D3 work and a re-audit of its repairs. Added: results at the other '\n"
    "                 'reported time points (Colak 2010 rest pain on days 2 to 7 and 7-day metamizole; Fu 2024 QoR-15 on day 7), an inventory '\n"
    "                 'of every result the three reports give, and RoB 2 drafts for Wang 1997\\'s pain at 48 hours (earlier listed as not '\n"
    "                 'assessed on a mistaken precedent). Revised: Fu 2024 randomisation and QoR-15 measurement drafts (Low to Some concerns, '\n"
    "                 'as for confirmed assessments of similar reports); stimulation-timing, eligibility-age and pain wording. Fu 2024\\'s '\n"
    "                 'source problems recorded (Additional file 5). Every refit affected by D3 recomputed independently. All drafts await '\n"
    "                 'second review.', 'Yes'])\n"
    "    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:")

# ---- AF5: Fu 2024 and Chen 2016 source problems (R03, R08) --------------------------------------------------------
rep("'3 × 10⁻⁸ on days 1, 3 and 7 against printed 0.004, 0.008 and 0.020; remifentanil ≈ 0.006 and propofol ≈ 0.016 against '\n"
    "                'printed < 0.001; baseline QoR-15 ≈ 0.88 and age ≈ 0.69 against printed 0.761 and 0.606; agitation 3/30 versus 11/29 '",
    "'2 × 10⁻⁸ on days 1, 3 and 7 against printed 0.004, 0.008 and 0.020; remifentanil ≈ 0.006 and propofol ≈ 0.016 against '\n"
    "                'printed < 0.001; baseline QoR-15 ≈ 0.88, age ≈ 0.69, duration of surgery ≈ 0.64 and duration of anaesthesia ≈ 0.78 '\n"
    "                'against printed 0.761, 0.606, 0.364 and 0.463 (Tables 2-4, pp6-7); agitation 3/30 versus 11/29 '")
rep("     'review of the Fu 2024 RoB 2 and GRADE drafts; analyses omitting Fu 2024 are reported (Additional file 12).'),",
    "     'review of the Fu 2024 RoB 2 and GRADE drafts. Without Fu 2024, rescue receipt RR 0.52 (0.37 to 0.74) and QoR-15 at about 24 h '\n"
    "     'MD 9.64 (−57.20 to 76.47) (Results; Additional file 12). Whether the report\\'s data can be relied on is for the second '\n"
    "     'reviewer; inclusion (decision D3) is unchanged.'),\n"
    "    ('Fu 2024', 'Table 3 (p6) gives day-7 MMSE interquartile ranges of 21.0 to 32.0 (TEAS) and 19.0 to 31.0 (control), although the '\n"
    "                'MMSE is a 30-point scale (Methods p4); Table 2 (p6) prints 7 of 29 control participants with ASA III as 23.3% (7/30).',\n"
    "     'MMSE is not an outcome of this review; neither value corrected. Recorded with the P-value discrepancies as evidence on the '\n"
    "     'reliability of the report.'),\n"
    "    ('Chen 2016', 'Results (p3) give total supplementary pethidine (Sauteralgyl) of 9.2 ± 2.8 versus 11.5 ± 1.8 mg/kg, but Fig. 2c (p4) '\n"
    "                  'plots about 3.7 versus 4.6 mg/kg on a 0-6 mg/kg axis; the relative reduction (20%) agrees, the amounts do not.',\n"
    "     'Text values recorded; figure not read. Chen 2016 is held from all analyses (decision D3), so no estimate is affected.'),")

# ---- AF8: the remaining D3 characteristics (R09) -------------------------------------------------------------------
rep("                         frequency=c['frequency'], timing=c['timing'], s_mma_all_groups=c['mma'], s_non_opioid_components=c['mma_basis'],",
    "                         frequency=c['frequency'], timing=c['timing'], s_mma_all_groups=c['mma'], s_non_opioid_components=c['mma_basis'],\n"
    "                         s_setting_page=c['setting_page'], bmi=c['bmi'], asa=c['asa'], intervention_arms=c['intervention_arms'],\n"
    "                         control_arms=c['control_arms'], intensity=c['intensity'], sessions=c['sessions'], session_duration=c['session_duration'],\n"
    "                         cumulative_duration=c['cumulative_duration'], m_timing_before24_category=c['timing_category'],\n"
    "                         m_planned_active_minutes_before24=c['planned_minutes_24'], m_before24_coding_note=c['coding_note'],\n"
    "                         postoperative_analgesia=c['postop_analgesia'], pca_regimen=c['pca'], rescue_analgesia=c['rescue'],\n"
    "                         s_mma_quote=c['mma_quote'], s_mma_page=c['mma_page'],")
rep("                 'decision (setting source, anaesthesia, regimen and stimulation protocol); the other fields are blank, and SKP has not yet checked them.'])",
    "                 'decision (setting source, anaesthesia, regimen and stimulation protocol), completed on 3 Nov 2026 from the sources (arms, '\n"
    "                 'intensity, sessions, analgesic and rescue regimens); \"Not reported\" means the report gives nothing. SKP has not yet checked them.'])")

# ---- AF10: Wang 1997 48-h pain assessed; 180 results (R05, R06) ----------------------------------------------------
rep("    assert len(units) == 178, len(units)   # 169 + 9 D3 drafts added 3 Nov 2026\n",
    "    assert len(units) == 178, len(units)   # 169 + 9 D3 drafts added 3 Nov 2026\n"
    "    for s in recs(REV / 'reaudit_d3/wang48_rob2_DRAFT.csv'):   # Wang 1997 pain at 48 h, 3 Nov 2026 (re-audit R05): AI drafts; pending\n"
    "        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],\n"
    "            s['decision_status'], rationale(s))\n"
    "    assert len(units) == 180, len(units)\n")
rep("    for m in ('WANG_PAIN48_SHAM', 'WANG_PAIN48_USUAL'):\n"
    "        held.append(dict(model=m, result='WANG97-PAIN48', study='Wang 1997',\n"
    "                         reason='Single-trial sensitivity estimate of pain at 48 h (rest or movement not stated); not assessed, as for Yu 2020 at 48 h (PAIN48_YU_TABLE).'))\n",
    "")
rep("not counted among the 178.'))", "not counted among the 180.'))")
rep("    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 178 results used in the analyses,",
    "    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 180 results used in the analyses,")
rep("'checked and confirmed every assessment except the 14 for Colak 2010 and Fu 2024 (below); a check is not '",
    "'checked and confirmed every assessment except the 14 for Colak 2010 and Fu 2024 and the 2 for Wang 1997\\'s pain at 48 hours (below); a check is not '")
rep("'7-day analgesic totals) are AI drafts awaiting second review by SKP [PROVISIONAL].'],",
    "'7-day analgesic totals) are AI drafts awaiting second review by SKP [PROVISIONAL]. After an independent AI re-audit (3 Nov 2026), the '\n"
    "                     'Fu 2024 randomisation drafts (all five results) and QoR-15 measurement drafts (three) were revised from Low to Some '\n"
    "                     'concerns, for consistency with confirmed assessments of similar reports (Xiong 2021; Gu 2019 and Yao 2015), and two '\n"
    "                     'drafts were added for Wang 1997\\'s pain at 48 hours, a sensitivity result earlier listed as not assessed; Yu 2020\\'s '\n"
    "                     '48-hour pain had been assessed (V33-OD-0368). These are also AI drafts awaiting second review [PROVISIONAL].'],")
rep("[('Judgements', 'One row per assessed result (178), with domain judgements and rationales'),",
    "[('Judgements', 'One row per assessed result (180), with domain judgements and rationales'),")
rep("f'Signalling responses recorded for {n_with} of the 178 results'),", "f'Signalling responses recorded for {n_with} of the 180 results'),")
rep("('Not assessed', 'Results held from synthesis, which were not assessed')],",
    "('Not assessed', 'Results held from synthesis or reported only descriptively, which were not assessed')],")

# ---- AF11 README: name the drafts SKP has not checked (R02/R13: every sign-off surface) -------------------------------
rep("                     'Assessments were made by an AI assistant under the review team\\'s delegation and checked and confirmed by '\n"
    "                     'a second reviewer (SKP); the profiles in sheet \"With Wang 1997\" were confirmed on 2 Nov 2026. Where one '",
    "                     'Assessments were made by an AI assistant under the review team\\'s delegation and checked and confirmed by '\n"
    "                     'a second reviewer (SKP), except the seven profiles in sheet \"D3 drafts\", which await this check [PROVISIONAL]; '\n"
    "                     'the profiles in sheet \"With Wang 1997\" were confirmed on 2 Nov 2026. Where one '")

# ---- AF9: the re-audit scripts and records -------------------------------------------------------------------------
rep("    'audit_d3': [REV / 'audit_d3' / f for f in ('apply_audit_text.py', 'patch_af_audit.py', 'update_verify_audit.py')],\n",
    "    'audit_d3': [REV / 'audit_d3' / f for f in ('apply_audit_text.py', 'patch_af_audit.py', 'update_verify_audit.py')],\n"
    "    'reaudit_d3': [REV / 'reaudit_d3' / f for f in ('build_wang48_rob2.py', 'wang48_rob2_DRAFT.csv', 'apply_reaudit_text.py',\n"
    "                                                    'patch_af_reaudit.py', 'update_verify_reaudit.py', 'astra_recompute_2026-11-03.csv')]\n"
    "          + [REV / 'reaudit_d3/figure_builds/build_rob_figure_reaudit.py'],\n")

rep("              '`forty_report_analysis/reviewer_rerun/dose_restriction_rerun_2026_10_23.R` and `lee_hold_rerun_2026_10_23.R`.', '',\n",
    "              '`forty_report_analysis/reviewer_rerun/dose_restriction_rerun_2026_10_23.R` and `lee_hold_rerun_2026_10_23.R`.',\n"
    "              '- `reaudit_d3/astra_recompute_2026-11-03.csv`: an independent AI re-check (3 Nov 2026) recomputed every refit '\n"
    "              'affected by decision D3 (35 rows) with its own code: effects and confidence limits within 4.8 × 10⁻⁷, τ² and I² '\n"
    "              'within 1.5 × 10⁻⁶ (the largest, τ² for QoR15_SHAM_24H_LOO_Zhou_2025, reflects optimiser precision).', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after the D3 re-audit')
