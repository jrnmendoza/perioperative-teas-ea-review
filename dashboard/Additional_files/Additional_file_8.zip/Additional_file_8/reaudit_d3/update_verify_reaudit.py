"""After Astra's re-audit of the D3 work (3 Nov 2026): adapt verification/verify_revision.py, as written by
d3/update_verify_d3.py and audit_d3/update_verify_audit.py.

Run after audit_d3/update_verify_audit.py. Counts the re-audit repairs change are updated (each replacement asserted once),
and checks are added that recompute or join rather than look for strings where they can (finding R13): every sign-off
statement in the Word files and Additional-file READMEs names the pending work; the abstract is counted from the Word file
with its headings and registration line; figures and Additional files are first cited in order; the RoB 2 high-domain
overlap is counted from the AF10 rows; Fu 2024's duration P values and rescue Fisher P are recomputed from its printed
summaries; every single-trial model from Wang 1997, Colak 2010 or Fu 2024 has an AF10 assessment; the D3 refits agree with
the independent recompute. The legacy screening label is renamed, and the script exits nonzero if any check fails.
Re-run d3/update_verify_d3.py and audit_d3/update_verify_audit.py first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')
assert 'Astra re-audit of the D3 work' not in s, 'already applied: run d3/update_verify_d3.py and audit_d3/update_verify_audit.py first'


def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


rep("of the D3 build (3 Nov 2026; audit_d3/).", "of the D3 build and its re-audit (3 Nov 2026; audit_d3/, reaudit_d3/).")
rep("'Of 178 assessed results', 'reported no 24-hour pain result']))", "'Of 180 assessed results', 'reported no 24-hour pain result']))")
rep("check('Abstract <= 350 words, no citations',", "check('Abstract prose (four sections) <= 350 words, no citations',")
rep("and 'r(9)' not in sd3 and 'reproduced in Stata; these refits have not been independently re-checked' in methods)",
    "and 'r(9)' not in sd3 and 'reproduced in Stata; all of them were recomputed in a further independent AI re-check' in methods)")
rep("""check('RoB: 178 results; 2 low, 125 some concerns, 51 high; text matches', [int(rob['Overall'][k]) for k in ('Low', 'Some concerns', 'High')] == [2, 125, 51]
      and 'Of 178 assessed results, two (1%) were at low risk of bias, 125 (70%) had some concerns and 51 (29%)' in results
      and [int(rob['D4 Measurement of the outcome'][k]) for k in ('Low', 'Some concerns', 'High')] == [76, 81, 21]
      and 'Twenty were rated high for outcome measurement' in results and int(rob['D3 Missing outcome data']['High']) == 31
      and 'One was rated high for both' in results and 30 + 20 + 1 == 51
      and 'Almost every result (175 of 178)' in results and int(rob['D5 Selection of the reported result']['Some concerns']) == 175
      and 'Just over half (96)' in results and int(rob['D1 Randomisation process']['Some concerns']) == 96)""",
    """check('RoB: 180 results; 2 low, 126 some concerns, 52 high; text matches', [int(rob['Overall'][k]) for k in ('Low', 'Some concerns', 'High')] == [2, 126, 52]
      and 'Of 180 assessed results, two (1%) were at low risk of bias, 126 (70%) had some concerns and 52 (29%)' in results
      and [round(100 * x / 180) for x in (2, 126, 52)] == [1, 70, 29]
      and [int(rob['D4 Measurement of the outcome'][k]) for k in ('Low', 'Some concerns', 'High')] == [73, 85, 22]
      and 'Twenty-one were rated high for outcome measurement' in results and int(rob['D3 Missing outcome data']['High']) == 31
      and 'One was rated high for both' in results
      and 'Almost every result (177 of 180)' in results and int(rob['D5 Selection of the reported result']['Some concerns']) == 177
      and 'Just over half (103)' in results and int(rob['D1 Randomisation process']['Some concerns']) == 103)""")
rep("""check('AF10: 178 judgements; 12 for Wang 1997 confirmed by SKP; 14 D3 drafts pending', len(j) == 178""",
    """check('AF10: 180 judgements; 12 for Wang 1997 confirmed by SKP and 2 (48-h pain) pending; 14 D3 drafts pending', len(j) == 180
      and sum(x[1] == 'Wang 1997' and 'second review by SKP pending' in str(x[-1]) and x[3] == '48 h' for x in j) == 2""")
rep("check('No claim that JRNM and SKP screened independently', 'Two reviewers (JRNM and SKP) independently screened' not in methods)",
    "check('Legacy October screening sentence absent (the attested D2 account is checked separately below)', "
    "'Two reviewers (JRNM and SKP) independently screened' not in methods)")
rep("check('m01: Stata scope stated as three models', 'three of the refits including Wang 1997 (the pooled models in Figs. 4 and 5) were also reproduced in Stata' in methods)",
    "check('m01: Stata scope stated as three models', 'three of the refits including Wang 1997 (the pooled models shown as forest plots) were also reproduced in Stata' in methods)")
rep("""check('SKP review recorded: no Wang RoB 2/GRADE text says awaiting second review', not any('Wang 1997' in x and any(p in x for p in (
      'drafts awaiting second review', 'await second review', 'await this check', 'second review pending')) for x in _sent))""",
    """check('SKP review recorded: no Wang RoB 2/GRADE text says awaiting second review, except the two 48-hour pain drafts added 3 Nov',
      not any('Wang 1997' in x and '48' not in x and any(p in x for p in (
      'drafts awaiting second review', 'await second review', 'await this check', 'second review pending')) for x in _sent))""")
rep("""      and 'the 14 judgements for Colak 2010 and Fu 2024 are drafts awaiting second review' in results
      and 'checked and confirmed all of them except those for Colak 2010 and Fu 2024 [PROVISIONAL: drafted on 2 and 3 November 2026, they await this check]' in methods""",
    """      and 'the 14 judgements for Colak 2010 and Fu 2024 and the two for Wang 1997 (pain at 48 hours) are drafts awaiting second review' in results
      and 'checked and confirmed all of them except those for Colak 2010 and Fu 2024 and the risk-of-bias assessments of Wang 1997\\'s pain at 48 hours [PROVISIONAL' in methods""")
rep("t = (HERE / 'af9_unzip_test_audit_2026-11-03.txt').read_text()   # clean unzip after the D3 audit repairs",
    "t = (HERE / 'af9_unzip_test_reaudit_2026-11-03.txt').read_text()   # clean unzip after the D3 re-audit repairs")
rep("check('AF4: D3 decisions sheet (8) and D3 extracted results (21)', len(xl(4, 'D3 decisions', 'Covidence ID')) == 8 and len(xl(4, 'D3 extracted results', 'Result ID')) == 21)",
    "check('AF4: D3 decisions sheet (8) and D3 extracted results (22)', len(xl(4, 'D3 decisions', 'Covidence ID')) == 8 and len(xl(4, 'D3 extracted results', 'Result ID')) == 22)")
rep("""check('Audit 4: D3 outcome inventory (29 rows) in AF4; Colak rest pain days 1-7 and Fu QoR-15 days 1, 3 and 7 extracted',
      len(inv) == 29 and len(xl(4, 'D3 outcomes', 'Report')) == 29""",
    """check('Audit 4: D3 outcome inventory (40 rows) in AF4; Colak rest pain days 1-7 and Fu QoR-15 days 1, 3 and 7 extracted',
      len(inv) == 40 and len(xl(4, 'D3 outcomes', 'Report')) == 40""")
rep("""      'paused during microelectrode recording' in _t1['Fu 2024'][11] and""",
    """      'paused during microelectrode recording' in _t1['Fu 2024'][11]
      and 'paused during microelectrode recording' in ' '.join(str(c) for c in next(x for x in xl(8, 'Characteristics', 'Report') if x[0] == 'Fu 2024')) and""")

REAUDIT = r'''
# Astra re-audit of the D3 work (ASTRA_D3_audit_2026-11-03/ASTRA_D3_REAUDIT_REPORT.md; repairs 3 Nov 2026)
import math as _m
_DOC = REV / 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx'
_paras = [p.text for p in _docx.Document(_DOC).paragraphs]
_readme = []
for _f in sorted((REV / 'additional_files').glob('*.xlsx')):
    _wb = _ox.load_workbook(_f, read_only=True)
    if 'README' in _wb.sheetnames:
        _readme += [str(c) for r in _wb['README'].iter_rows(values_only=True) for c in r if c]
_claims = [x for x in _sent + [y for t in _readme for y in re.split(r'(?<=[.\]])\s+', t)]
           if re.search(r'SKP|second reviewer|human reviewer', x) and re.search(r'checked|confirmed', x)]
_blanket = [x[:90] for x in _claims if not re.search(r'except|await|pending|PROVISIONAL|CONFIRM|not yet|are listed above', x)
            and not re.search(r'Wang 1997|20(20|26)-1[01]-\d\d|\d+ (Sep|Oct|Nov)', x)]
check('Re-audit R02/R13: every sign-off statement names the pending work unless it is about a dated item (Word files, AF tables and READMEs)',
      not _blanket and len(_claims) >= 10, str(_blanket[:3]) if _blanket else f'{len(_claims)} statements')
_i = next(k for k, p in enumerate(_paras) if p.startswith('Background:'))
_ab = []
for p in _paras[_i:]:
    if p.startswith(('Keywords:', 'Note:')):
        break
    _ab.append(p)
_abw = sum(len(p.split()) for p in _ab)
check('Re-audit R11: abstract counted from the Word file, with headings and the registration line, is at most 345 words',
      _ab[-1].startswith(('Registration:', 'Systematic review registration:')) and _abw <= 345, f'{_abw} words in {len(_ab)} paragraphs')
_body = _paras[next(k for k, p in enumerate(_paras) if p.strip() == 'Background'):]
_figs = []
for p in _body:
    if p.startswith(('Figure 1', 'Fig. 1.', 'Figure legends')):
        break
    for a, b in re.findall(r'Figs?\.\s*(\d)(?:\s*(?:and|–|-)\s*(\d))?', p):
        for x in [a] + ([b] if b else []):
            if int(x) not in _figs:
                _figs.append(int(x))
check('Re-audit R12: figures first cited in numerical order in the Word text', _figs == [1, 2, 3, 4, 5], str(_figs))
_afs = []
for p in _body:
    for g in re.findall(r'Additional files? (\d+(?:(?:,| and|–) ?\d+)*)', p):
        for x in re.findall(r'\d+', g):
            if int(x) not in _afs:
                _afs.append(int(x))
check('Re-audit R13: Additional files first cited in numerical order', _afs == sorted(_afs) and _afs[:1] == [1] and len(_afs) == 12, str(_afs))
_refs = []
for sec in ('background', 'methods', 'results', 'discussion'):
    for t_ in spec[sec]:
        for grp in re.findall(r'\[(\d[\d,–\s]*)\]', t_ if isinstance(t_, str) else t_.get('text', '')):
            for part in grp.split(','):
                a_, _, b_ = part.strip().partition('–')
                for x in (range(int(a_), int(b_) + 1) if b_ else [int(a_)]):
                    if x not in _refs:
                        _refs.append(x)
check('Re-audit R13: references cited in the text are numbered in order of first mention (all sections, not only Background)',
      _refs == list(range(1, len(_refs) + 1)), f'{len(_refs)} numbers, first out of order: ' + str(next((x for k, x in enumerate(_refs) if x != k + 1), None)))
_j10 = xl(10, 'Judgements', 'Result ID')
_hm = sum(x[8] == 'High' and x[9] != 'High' for x in _j10); _hd = sum(x[9] == 'High' and x[8] != 'High' for x in _j10)
_hb = sum(x[8] == 'High' and x[9] == 'High' for x in _j10)
check('Re-audit R13: high-risk overlap counted from the AF10 rows (30 missing data only, 21 measurement only, 1 both = 52)',
      (_hm, _hd, _hb) == (30, 21, 1) and sum(x[11] == 'High' for x in _j10) == 52
      and 'Thirty results were rated high for missing outcome data' in results, str((_hm, _hd, _hb)))
_w48 = recs(REV / 'reaudit_d3/wang48_rob2_DRAFT.csv')
_na = xl(10, 'Not assessed', 'Analysis')
_an = ' ; '.join(str(x[5]) for x in _j10)
_single = [m for m, r in mw.items() if r['k'] == '1' and r['reports'] in ('Wang 1997', 'Colak 2010', 'Fu 2024')
           and not re.search(r'LOO|NOT_HIGH|LOW_ONLY|MISSING|_SD$|ABSTRACT', m)]
_alias = {'E2_WANG_1997_SHAM_SINGLE': 'E2_opioid24_TEAS_sham', 'pain24_WANG_1997_SHAM_SINGLE': 'pain24_unclassified_TEAS_sham'}   # Wang alone: same results
_unassessed = [m for m in _single if m not in _an and _alias.get(m, m) not in _an]
check('Re-audit R05: Wang 1997 48-h pain assessed (2 drafts; no "as for Yu" exemption); every single-trial model from Wang 1997, Colak 2010 or Fu 2024 has an AF10 assessment',
      len(_w48) == 2 and {r['analyses'] for r in _w48} == {'WANG_PAIN48_SHAM', 'WANG_PAIN48_USUAL'}
      and not any('as for Yu' in str(x[3]) for x in _na) and not any(str(x[0]).startswith('WANG_PAIN48') for x in _na)
      and any(x[0] == 'V33-OD-0368' and 'PAIN48_YU_TABLE' in str(x[5]) for x in _j10) and not _unassessed and len(_single) >= 20,
      f'{len(_single)} single-trial models; unassessed {_unassessed}')
_fu = [r for r in dr if r['study'] == 'Fu 2024']
check('Re-audit R06: Fu 2024 drafts revised (randomisation Some concerns in all five; QoR-15 measurement Some concerns), overall unchanged, still pending',
      len(_fu) == 5 and all(r['d1'] == 'Some concerns' for r in _fu) and all(r['d4'] == 'Some concerns' for r in _fu if r['result_id'].startswith('FU24-QOR'))
      and all(r['overall'] == 'Some concerns' for r in _fu) and all('second review by SKP pending' in r['decision_status'] for r in _fu)
      and all('Imprecision one level' in g['reason'] for g in dg if g['model_id'] in ('QoR15_SHAM_POD3', 'QoR15_SHAM_POD7', 'RESCUE_METAMIZOLE_7D_EA_USUAL', 'intraop_remifentanil_TEAS_sham')))


def _betacf(a, b, x):
    qab, qap, qam, c, d = a + b, a + 1, a - 1, 1.0, 1 - (a + b) * x / (a + 1)
    d = 1 / (d if abs(d) > 1e-30 else 1e-30); h = d
    for mm in range(1, 300):
        m2 = 2 * mm
        for aa in (mm * (b - mm) * x / ((qam + m2) * (a + m2)), -(a + mm) * (qab + mm) * x / ((a + m2) * (qap + m2))):
            d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-30 else 1e-30)
            c = 1 + aa / c; c = c if abs(c) > 1e-30 else 1e-30
            h *= d * c
    return h


def _tp(t, df):   # two-sided P for Student's t
    x = df / (df + t * t)
    bt = _m.exp(_m.lgamma((df + 1) / 2) - _m.lgamma(df / 2) - _m.lgamma(0.5) + df / 2 * _m.log(x) + 0.5 * _m.log(1 - x))
    return bt * _betacf(df / 2, 0.5, x) / (df / 2) if x < (df / 2 + 1) / (df / 2 + 2.5) else 1 - bt * _betacf(0.5, df / 2, 1 - x) / 0.5


def _welch(m1, s1, n1, m2, s2, n2):
    v1, v2 = s1 * s1 / n1, s2 * s2 / n2
    return _tp((m1 - m2) / _m.sqrt(v1 + v2), (v1 + v2) ** 2 / (v1 * v1 / (n1 - 1) + v2 * v2 / (n2 - 1)))


def _fisher(a, n1, c, n2):
    tot, k = n1 + n2, a + c
    pr = lambda x: _m.comb(n1, x) * _m.comb(n2, k - x) / _m.comb(tot, k)
    p0 = pr(a)
    return sum(pr(x) for x in range(max(0, k - n2), min(k, n1) + 1) if pr(x) <= p0 * (1 + 1e-9))


_ps, _pa, _pq, _pr = _welch(186.3, 23.5, 30, 183.1, 28.7, 29), _welch(82.0, 24.6, 30, 80.0, 29.4, 29), _welch(134.9, 6.1, 30, 125.8, 4.5, 29), _fisher(2, 30, 6, 29)
_fut = (ROOT / '10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/1879896270.txt').read_text(encoding='utf-8')
_c5 = ' '.join(str(x[1]) + ' ' + str(x[2]) for x in xl(5, 'Contradictions', 'Report') if x[0] in ('Fu 2024', 'Chen 2016'))
check('Re-audit R03: Fu 2024 P values recomputed from its printed summaries (surgery 0.64, anaesthesia 0.78, QoR-15 day 7 2e-8, rescue Fisher 0.15) and recorded in AF5 with the MMSE quartiles above 30',
      abs(_ps - 0.6419) < 0.002 and abs(_pa - 0.7783) < 0.002 and 1e-8 < _pq < 3e-8 and abs(_pr - 0.1455) < 0.001
      and 'duration of surgery ≈ 0.64 and duration of anaesthesia ≈ 0.78' in _c5 and '2 × 10⁻⁸' in _c5
      and '26.5 (21.0, 32.0)' in _fut and '25.0 (19.0, 31.0)' in _fut and '30-point questionnaire' in _fut and '21.0 to 32.0' in _c5,
      f'surgery {_ps:.4f}, anaesthesia {_pa:.4f}, QoR day 7 {_pq:.2e}, rescue {_pr:.4f}')
check('Re-audit R08: Chen 2016 pethidine text (9.2 vs 11.5 mg/kg) against Fig. 2c recorded in AF5 and the extraction row',
      'Fig. 2c (p4)' in _c5 and 'Fig. 2c p4 contradicts' in _res['CHEN16-PETH-72']['source_location'] if 'CHEN16-PETH-72' in _res else False)
_res = {r['result_id']: r for r in recs(REV / 'd3/d3_results.csv')}
inv = recs(REV / 'd3/d3_outcome_inventory.csv')
_ch = [r['result'] for r in inv if r['report'] == 'Chen 2016']
check('Re-audit R07: inventory names Colak\'s atelectasis and every Chen 2016 result (defecation, Fig. 2a time points); Chen defecation extracted',
      any('atelectasis' in r['result'] for r in inv if r['report'] == 'Colak 2010') and not any('type not stated' in r['reason'] for r in inv)
      and any('defecation' in x for x in _ch) and all(any(f'at {h} h' in x for x in _ch) for h in (1, 2, 24, 48, 72))
      and 'CHEN16-DEFEC' in _res and len(_res) == 22 and all(r['disposition'] == 'Held' for r in inv if r['report'] == 'Chen 2016'))
_c8 = xl(8, 'Characteristics', 'Report')
_h8 = next(r for r in [list(r) for r in _ox.load_workbook(REV / 'additional_files/Additional_file_8.xlsx', read_only=True)['Characteristics'].iter_rows(values_only=True)] if r and r[0] == 'Report')
_blank8 = [(x[0], _h8[k]) for x in _c8 if x[0] in ('Colak 2010', 'Fu 2024', 'Chen 2016') for k in range(len(_h8)) if x[k] in (None, '')]
check('Re-audit R09: AF8 rows for the three D3 reports have no blank field', not _blank8, str(_blank8[:4]))
_ta = (REV / 'human_TA_screen/README.md').read_text(encoding='utf-8')
check('Re-audit R10: held screening README marks its old workflow conditional and requires reconciliation before activation',
      'SKP now screens' not in _ta and 'probably reflects' not in _ta and 'before the screen is activated, not after' in _ta
      and 'on hold, not started' in _ta and 'must not be used' in _ta)
check('Re-audit R04: Results name the Fu 2024 omission estimates; Discussion names its source problems',
      'without Fu 2024, whose printed P values do not match its printed summaries (Additional file 5), the RR was 0.52 (0.37 to 0.74)' in results
      and 'Without Fu 2024, the QoR-15 estimate was 9.64 points (−57.20 to 76.47; two trials)' in results
      and [f2(mw['RESCUE_LOO_Fu_2024'][k]) for k in ('effect', 'ci_low', 'ci_high')] == ['0.52', '0.37', '0.74']
      and [f2(mw['QoR15_SHAM_24H_LOO_Fu_2024'][k]) for k in ('effect', 'ci_low', 'ci_high')] == ['9.64', '−57.20', '76.47']
      and 'prints P values that its own summaries cannot produce' in discussion)
_ar = {r['model_id']: r for r in recs(REV / 'reaudit_d3/astra_recompute_2026-11-03.csv')}
_d3m = [m for m, r in mw.items() if re.search(r'Colak 2010|Fu 2024', r['reports'] + r['description'])]
_dif = lambda cols: max(abs(float(_ar[m][c]) - float(mw[m][c])) for m in _ar if m in mw for c in cols if _ar[m][c] not in ('', 'NA') and mw[m][c] not in ('', 'NA'))
check('Re-audit: every D3 refit independently recomputed (effects and limits within 4.8e-7; tau2 and I2 within 1.5e-6), as the Methods say',
      set(_d3m) <= set(_ar) and len(_d3m) == 34 and _dif(('effect', 'ci_low', 'ci_high')) < 4.8e-7 and _dif(('tau2', 'I2')) < 1.5e-6
      and 'all of them were recomputed in a further independent AI re-check (3 November 2026)' in methods,
      f"{len(_d3m)} D3 models; {_dif(('effect', 'ci_low', 'ci_high')):.2e}, {_dif(('tau2', 'I2')):.2e}")
'''
rep("\n(HERE / 'verification_results.txt').write_text(", REAUDIT + "\n(HERE / 'verification_results.txt').write_text(")
rep("print(sum(o.startswith('PASS') for o in out), 'pass;', sum(o.startswith('FAIL') for o in out), 'fail')",
    "print(sum(o.startswith('PASS') for o in out), 'pass;', sum(o.startswith('FAIL') for o in out), 'fail')\n"
    "if any(o.startswith('FAIL') for o in out):\n    raise SystemExit(1)")
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted for the D3 re-audit repairs')
