"""Re-check round (2 Nov 2026): apply the Astra re-check text repairs to the manuscript sources.
Starts from the post-Wang text in recheck/pre_recheck_snapshot/sources/ and asserts each passage, so it can be re-run.
M01: Wang 1997 dose capture stated as uncertain, not as omitted. M02: paired pain (Chen 2020, Gu 2019 and Wang 1997 report
unclassified 24-h pain; none satisfies the registered rest/movement criterion). M08 and M05: RoB counts after the revised
drafts (164 results). m01: scope of the Stata check. e01: abstract denominators."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / 'sources'
SNAP = HERE / 'pre_recheck_snapshot/sources'

EDITS = {
'abstract_REVISED.md': [
    ('We used random-effects meta-analysis (REML, Hartung–Knapp), result-specific RoB 2 and GRADE.',
     'We used random-effects meta-analysis (REML, Hartung–Knapp), RoB 2 and GRADE.'),
    ('a point estimate below 10 mg with an interval that included it; the trial reported no pain.',
     'a point estimate below 10 mg with an interval that included it.'),
    ('Post-hoc analyses gave −7.22 mg (−14.13 to −0.32; seven trials; very low certainty) when results with incomplete opioid capture were admitted, and fewer participants receiving rescue opioid over each trial\'s follow-up (risk ratio 0.52, 0.37 to 0.74; six trials; exploratory; low certainty). Nausea and vomiting were less frequent with TEAS (risk ratio 0.60, 0.45 to 0.79; nine trials; low certainty). Of 162 assessed results, 27% were at high risk of bias.',
     'Post-hoc analyses gave −7.22 mg (−14.13 to −0.32; seven trials, 622 participants; very low certainty) admitting results with incomplete or uncertain opioid capture, and fewer participants receiving rescue opioid over each trial\'s follow-up (risk ratio 0.52, 0.37 to 0.74; six trials, 553 participants; exploratory; low certainty). Nausea and vomiting were less frequent with TEAS (risk ratio 0.60, 0.45 to 0.79; nine trials, 2,848 participants; low certainty). Of 164 assessed results, 27% were at high risk of bias.'),
    ('and the registered criterion could not be evaluated because no opioid trial reported pain.',
     'and the registered criterion could not be evaluated because the primary-outcome trial reported no pain.'),
    ('[PROVISIONAL: eight historically excluded reports may meet both full-text outcome requirements and await adjudication by the review team, and the risk-of-bias and certainty assessments for Wang 1997, included on 2 November 2026, await second review; the counts and estimates above may change.]',
     '[PROVISIONAL: eight historically excluded reports may meet both full-text outcome requirements and await adjudication by the review team; the counts and estimates above may change.]'),
],
'methods_REVISED.md': [
    ('when the review owner judged that its stimulation met the TEAS definition.',
     'when the review owner judged that its stimulation met the TEAS definition. Because its report does not establish that its 24-hour opioid total includes every supplemental dose, it was analysed only in the broader first-day analysis, as Chen 1998 was.'),
    (' [PROVISIONAL: the assessments for Wang 1997, drafted on 2 November 2026, await this check.]', ''),
    (' [PROVISIONAL: SKP has not yet checked the Wang 1997 extraction, added on 2 November 2026.]', ''),
    ('were screened in Covidence (Fig. 1). [CONFIRM screening roles: the screening logs record that an AI agent (Codex) cast title-and-abstract votes in two Covidence reviewer accounts in JRNM\'s name ("JM" and "JR Mendoza") and full-text votes in the "JM" account. State who cast each independent vote at each stage, whether SKP screened, and how and by whom conflicts were resolved.]',
     'were screened independently in Covidence by JRNM and SKP (Fig. 1). Disagreements were resolved by consensus between JRNM and SKP, with an AI agent (Codex) supporting the resolution of some conflicts.'),
    (' [CONFIRM: add AI-assisted screening once the screening roles above are confirmed.]',
     ' An AI agent also supported the screening reviewers, particularly in resolving some conflicts.'),
    ('the refits including Wang 1997 were also reproduced in Stata.',
     'three of the refits including Wang 1997 (the pooled models in Figs. 4 and 5) were also reproduced in Stata, and all of them were recomputed in an independent re-check.'),
],
'results_REVISED.md': [
    ('Of 162 assessed results, two (1%) were at low risk of bias, 116 (72%) had some concerns and 44 (27%) were at high risk (Fig. 3). [PROVISIONAL: the ten judgements for Wang 1997 are drafts awaiting second review.]',
     'Of 164 assessed results, two (1%) were at low risk of bias, 118 (72%) had some concerns and 44 (27%) were at high risk (Fig. 3).'),
    ('Almost every result (159 of 162)', 'Almost every result (161 of 164)'),
    ('Just over half (85) had some concerns about randomisation', 'Just over half (87) had some concerns about randomisation'),
    ('Wang 1997 did not meet the primary outcome definition: its 24-hour hydromorphone totals did not include intramuscular supplemental opioid, given to 19 of its 101 participants.',
     'Wang 1997 was not admitted to this analysis because its report does not establish that its 24-hour hydromorphone quantities include the intramuscular supplemental opioid given to 19 of its 101 participants; supplemental meperidine was converted to hydromorphone equivalents for the report\'s analysis, but rescue was not itemised. It was therefore analysed in the broader first-day analysis only, as Chen 1998 was.'),
    ('excluding the two trials whose totals omitted supplemental opioid (Chen 1998 and Wang 1997) gave',
     'excluding the two trials whose totals may not capture supplemental opioid (Chen 1998 and Wang 1997) gave'),
    ('Wang 1997 was the only trial in this analysis that also reported pain at about 24 hours: −15.00 mg (−31.00 to 1.00), with pain −0.35 points (−1.44 to 0.74; rest or movement not stated). Because its total omitted supplemental opioid, this pair does not apply the registered criterion.',
     'Three trials in this analysis also reported pain at about 24 hours in the same arms, without stating whether at rest or on movement: Chen 2020 (opioid −14.10 mg; pain −3.06 points), Gu 2019 (−1.57 mg; −0.74 points) and Wang 1997 (−15.00 mg, −31.00 to 1.00; −0.35 points, −1.44 to 0.74). None of these pairs applies the registered criterion, which requires the primary opioid outcome and pain at rest or on movement.'),
],
'discussion_REVISED.md': [
    ('[CONFIRM: add AI-assisted screening once screening roles are confirmed.]', 'An AI agent supported the resolution of some screening conflicts.'),
    ('That trial reported no pain at 24 hours, so the registered criterion for clinical importance could not be evaluated; the one pain result came from a different trial.',
     'That trial reported no pain at 24 hours, so the registered criterion for clinical importance could not be evaluated. The one rest-pain result came from a different trial, and the three broader-analysis trials that reported pain in the same arms did not state whether it was at rest or on movement.'),
    ('In a post-hoc analysis admitting results with incomplete capture of systemic opioid,',
     'In a post-hoc analysis admitting results with incomplete or uncertain capture of systemic opioid,'),
    ('pooling rescue receipt over mixed follow-up and the inclusion of Wang 1997.',
     'pooling rescue receipt over mixed follow-up, and the inclusion of Wang 1997 and its assignment to the broader analysis.'),
    ('Of 162 assessed results, 27% were at high risk of bias', 'Of 164 assessed results, 27% were at high risk of bias'),
],
'conclusions_REVISED.md': [
    ('and no opioid trial reported the pain result needed to apply the registered criterion.',
     'and that trial did not report the pain result needed to apply the registered criterion.'),
    ('[PROVISIONAL: pending adjudication of eight historically excluded reports and second review of the Wang 1997 assessments.]',
     '[PROVISIONAL: pending adjudication of eight historically excluded reports.]'),
],
'table2_REVISED.md': [
    ('[PROVISIONAL: estimates may change after adjudication of eight historically excluded reports; certainty ratings for analyses that include Wang 1997 are drafts awaiting second review.]',
     '[PROVISIONAL: estimates may change after adjudication of eight historically excluded reports.]'),
],
'figures_REVISED.md': [
    ('Distribution of judgements by domain across all 162 assessed results. † Draft judgements for Wang 1997, awaiting second review.',
     'Distribution of judgements by domain across all 164 assessed results.'),
],
}

for name, edits in EDITS.items():
    s = (SNAP / name).read_text(encoding='utf-8')   # always start from the post-Wang text
    for old, new in edits:
        assert s.count(old) == 1, (name, old[:70], s.count(old))
        s = s.replace(old, new)
    (SRC / name).write_text(s, encoding='utf-8')
print(sum(len(e) for e in EDITS.values()), 'replacements in', len(EDITS), 'files')
