"""Re-check round (2 Nov 2026): apply the Astra re-check repairs to the additional-file builder and reproduction script.
Starts from the post-Wang copies in recheck/pre_recheck_snapshot/ and asserts every replaced passage, so it can be re-run.
Findings: M01 (Wang dose-capture wording), M03 (legacy expanded-dose rows), M04 (diagnostics), M05 (Wang outcome
inventory), M06 (sign-off statements; current vs superseded GRADE rows), M07/M08 (revised drafts), M09 (locators),
m01 (Stata scope), m02 (version labels), m04 (stopping rule)."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
SNAP = HERE / 'pre_recheck_snapshot'


def patch(src, edits):
    for old, new in edits:
        assert src.count(old) == 1, (old[:90], src.count(old))
        src = src.replace(old, new)
    return src


CAPTURE_SHORT = ('the report does not establish whether its 24-hour hydromorphone quantities include the intramuscular supplemental '
                 'opioid given to 19 of its 101 participants (it converted supplemental meperidine to hydromorphone equivalents '
                 'for its analysis but does not itemise rescue)')

B = [
# ---- screening provenance (D2), as attested by the review owner (2 Nov 2026, latest): JRNM ("JR Mendoza") and SKP
#      ("JM") screened titles/abstracts and full texts independently; consensus, with AI support for some conflicts.
#      The automation logs describe the AI casting the votes; see set_screening_account.py.
("         'Methods: Search and selection. [CONFIRM: screening roles. The screening logs record AI-cast votes in two Covidence accounts in JRNM\\'s name; the Methods states what must be confirmed (Additional file 2, section 9).]'),",
 "         'Methods: Search and selection. Titles and abstracts, and then full texts, were screened independently by JRNM and SKP; disagreements were resolved by consensus, with an AI agent (Codex) supporting some conflict resolution (Additional file 2, section 9). Automation before screening: see the CONFIRM marker on the 508 automated exclusions.'),"),
('         \'[CONFIRM: screening roles. The screening logs record that an AI agent (Codex) cast title-and-abstract votes on 23–28 July 2026 in two Covidence accounts in JRNM\\\'s name ("JM", moderate rules; "JR Mendoza", inclusive rules; 2,441 votes in the second) and full-text votes on 9–20 August 2026 in the "JM" account. State who cast the other independent votes, whether SKP screened, and how conflicts were resolved.]\',',
 '         \'Titles and abstracts (23–28 July 2026) and full texts (9–20 August 2026) were screened independently in Covidence by JRNM (reviewer account shown as "JR Mendoza") and SKP (account shown as "JM"). Disagreements were resolved by consensus between JRNM and SKP, with an AI agent (Codex) supporting the resolution of some conflicts (reported by the review owner, 2 Nov 2026).\','),
("         'Determines whether screening met the registered process'],",
 "         'Consistent with the registered process: two people at both stages'],"),
("    after('21–23 Jul', ['23–28 Jul', 'Title and abstract screening in Covidence. [CONFIRM: screening roles (section 9).]', 'No'])",
 "    after('21–23 Jul', ['23–28 Jul', 'Title and abstract screening in Covidence by JRNM and SKP, independently; disagreements resolved by consensus, with AI support for some conflicts (section 9).', 'No'])"),
("    after('14 Aug', ['9–20 Aug', 'Full-text screening in Covidence. [CONFIRM: screening roles (section 9).]', 'No'])",
 "    after('14 Aug', ['9–20 Aug', 'Full-text screening in Covidence by JRNM and SKP, independently; disagreements resolved by consensus, with AI support for some conflicts (section 9).', 'No'])"),
("            'review team must adjudicate the other eight membership candidates, and SKP has not yet checked the Wang 1997 '\n"
 "            'extraction or its risk-of-bias and GRADE assessments; see AUTHOR_DECISION_SHEET.md and Additional file 4.]')",
 "            'review team must adjudicate the other eight membership candidates; SKP checked the Wang 1997 extraction and '\n"
 "            'confirmed its RoB 2 and GRADE assessments on 2 November 2026; see AUTHOR_ACTIONS.md and Additional file 4.]')"),
("        ['Not done', 'The 2 November 2026 triage of the outcome exclusions, the Table 1 corrections and the Szmit 2021 multimodal-analgesia change', '[CONFIRM: second review pending]'],",
 "        ['2 Nov', 'Wang 1997 extraction (characteristics, Table 1 row and outcome values); 12 RoB 2 assessments and 11 GRADE profiles for Wang 1997, as revised after the independent re-check', 'Confirmed'],\n"
 "        ['Not done', 'The 2 November 2026 triage of the outcome exclusions, the Table 1 corrections and the Szmit 2021 multimodal-analgesia change', '[CONFIRM: second review pending]'],"),
# ---- shared facts: Wang outcome inventory
("""W97_NOTE = 'Wang 1997, included 2 Nov 2026 (decision D1)'
""",
 """W97_NOTE = 'Wang 1997, included 2 Nov 2026 (decision D1)'
W97_INV = recs(W97 / 'wang1997_outcome_inventory.csv')   # every reported Wang result and its disposition (re-check, M05)
"""),
# ---- AF2 section 6: dose-capture wording (M01); count of outcome-inventory dispositions (M05)
("""            'beside the incision, as in Szmit 2021) is TEAS, and the trial was included, with its results known. Its '
            '24-hour hydromorphone totals exclude the intramuscular supplemental opioid given to 19 of its 101 participants, '
            'so under the rules in Additional file 6 it enters the broader first-day analysis, not the primary analysis; it '
            'also enters rescue receipt, pain without stated rest or movement, and nausea and vomiting. [PROVISIONAL: the '""",
 f"""            'beside the incision; the sites are not identical to Szmit 2021, which used bilateral LI4) is TEAS, and the '
            'trial was included, with its results known. Complete capture of systemic opioid is not established: '
            '{CAPTURE_SHORT}. Under the rules in Additional file 6, which never assume complete capture, it therefore '
            'enters the broader first-day analysis and not the primary analysis (decision D1b, 2 November 2026). It also '
            'enters rescue receipt, pain without stated rest or movement, nausea and vomiting, and single-trial estimates '
            'of length of stay and 48-hour pain; every other result it reports is listed in Additional file 4 (sheet '
            '"Wang 1997 outcomes") with its disposition. [PROVISIONAL: the '"""),
# ---- AF2 decision log: Wang row (M01, m01) and the re-check row
("""    rows.append(['2 Nov', 'Wang 1997 included as TEAS by the review owner after reading the report, with its results known '
                 '(decision D1). It enters the broader first-day analysis (its totals omit quantified rescue), rescue receipt, '
                 'pain without stated rest or movement, and nausea and vomiting; every affected analysis was refitted in R and '
                 'checked in Stata. RoB 2 and GRADE drafted by the AI assistant; second review pending.', 'Yes'])""",
 """    rows.append(['2 Nov', 'Wang 1997 included as TEAS by the review owner after reading the report, with its results known '
                 '(decision D1). It enters the broader first-day analysis (capture of supplemental doses not established; '
                 'kept out of the primary analysis by decision D1b), rescue receipt, pain without stated rest or '
                 'movement, and nausea and vomiting. Every affected analysis was refitted in R; the three pooled models shown '
                 'in Figs. 4 and 5 were also reproduced in Stata. RoB 2 and GRADE assessed by the AI assistant and confirmed by '
                 'SKP on 2 Nov.', 'Yes'])
    rows.append(['2 Nov', 'Decision D1b: Wang 1997 kept in the broader first-day analysis only, because its report does not '
                 'establish that its 24-hour opioid total includes every supplemental dose (the basis on which Chen 1998 is in '
                 'that analysis).', 'Yes'])
    rows.append(['2 Nov', 'Independent AI re-check (Codex Astra) of the revision. Corrected: Wang 1997 dose-capture wording; '
                 'the statement that Wang 1997 was the only broader-dose trial with paired pain (Chen 2020 and Gu 2019 also '
                 'report unclassified 24-hour pain). Completed: six legacy expanded-dose sensitivity models refitted with '
                 'Wang 1997; nausea and vomiting diagnostics; inventory of every Wang 1997 result (length of stay and 48-hour '
                 'pain added as single-trial estimates). RoB 2 and GRADE assessments revised, then confirmed by SKP on 2 Nov.', 'Yes'])"""),
# ---- AF2 deviations table and section 12: sign-off statements (M06)
("""         'Each RoB 2 and GRADE assessment was made by an AI assistant and checked and confirmed by SKP (section 12)', 'A check of a first assessment is not an independent duplicate assessment'],""",
 """         'Each RoB 2 and GRADE assessment was made by an AI assistant and checked and confirmed by SKP (section 12), including the 12 RoB 2 and 11 GRADE assessments for Wang 1997 (2 Nov 2026)', 'A check of a first assessment is not an independent duplicate assessment'],"""),
("""    para(d, 'Assessments and extractions made by the AI assistant were checked by a second reviewer (SKP). Each is '
            'recorded on the date the review owner reported it. No judgement was changed at review unless stated.')""",
 """    para(d, 'Assessments and extractions made by the AI assistant were checked by a second reviewer (SKP), including '
            'those for Wang 1997 (2 November 2026). Each check '
            'is recorded on the date the review owner reported it. No judgement was changed at review unless stated.')"""),
# ---- AF4: Wang outcome inventory sheet (M05)
("""                 ('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language')],""",
 """                 ('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language'),
                 ('Wang 1997 outcomes', 'Every result reported by Wang 1997 (included 2 Nov 2026), with its disposition: existing analysis, single-trial estimate, narrative, hold or excluded by rule')],"""),
("""    return save(wb, 4, '.xlsx')""",
 """    sheet(wb, 'Wang 1997 outcomes', W97_INV, [('source', 'Source (printed page)', 18), ('result', 'Result', 50),
                                              ('disposition', 'Disposition', 22), ('reason', 'Reason', 90)])
    return save(wb, 4, '.xlsx')"""),
# ---- AF6: Wang classification (M01) and missing locators (M09)
("""                   E1_disposition='NOT ADMITTED: intramuscular supplemental opioid (hydromorphone or meperidine), given to 19 of 101 participants in the first 24 h, is not quantified in the totals',
                   E2_disposition='ADMIT', E2_basis=W97_RES['WANG97-HM24']['classification'], flags='Unquantified rescue (as Chen 1998)',""",
 """                   E1_disposition='NOT ADMITTED (decision D1b, 2 Nov 2026): capture of the intramuscular supplemental opioid given to 19 of 101 participants in the first 24 h is not established (supplemental meperidine was converted to hydromorphone equivalents for the report\\'s analysis, but rescue is not itemised)',
                   E2_disposition='ADMIT', E2_basis=W97_RES['WANG97-HM24']['classification'], flags='Capture of rescue not established (as Chen 1998)',"""),
("""def analysis_inputs():
    \"\"\"Inputs to every analysis reported in the main text, with values as reported (inventory) and as modelled.\"\"\"
    inv = {r['result_id']: r for r in recs(C / 'all_40_result_inventory.csv')}""",
 """# Source locators for the two amendment-E2.1 results, which are not in the 40-report result inventory (re-check, M09).
# Sources: opioid_only_review/source_audit/postoperative_opioid_source_audit.csv and
# 10_FINAL_ADJUDICATION/02_DECISIONS/v38/E2_digitisation_gu2019.md.
E21_SRC = {
    'E2.1-GU2019-FIG4-T4': dict(loc='Fig. 4, PDF pp3-4 (24-h point, T4): values not printed; digitised against the axis gridlines (E2_digitisation_gu2019.md). PCIA 100 µg sufentanil in 100 mL, Methods p2',
                                raw='L-TEAS 55.71 (7.93) mL, n 58 vs C-TEAS 58.84 (7.41) mL, n 59 (digitised; 1 mL = 1 µg sufentanil)',
                                quote='Not printed (figure only). Digitisation record: 24-h control value probably overstated relative to the text; leave-out analysis mandatory',
                                sha='b6fb0c0901f5f6716bd6cc6facc06f0844dca5c5e9d357527f55936d5de0aa33'),
    'E2.1-ZHANG2025-POD1': dict(loc='Results table, PDF p9 (postoperative day 1; taken as the first 24 h under amendment E2.1)',
                                raw='50.53 (4.46) µg sufentanil, n 45 vs 53.79 (5.14) µg, n 48',
                                quote='Total sufentanil consumption (μg) 50.53±4.46 53.79±5.14 MD:-3.26(−5.25 to −1.27)',
                                sha='691899a10069da68a1525a13662118fca1d4f9ed245d4304b120c426d27bb053'),
}


def analysis_inputs():
    \"\"\"Inputs to every analysis reported in the main text, with values as reported (inventory) and as modelled.\"\"\"
    inv = {r['result_id']: r for r in recs(C / 'all_40_result_inventory.csv')}"""),
("""        quote = v0.get('source_quote', '') or r.get('source_quote', '') or r.get('source_excerpt', '')
        out.append(dict(analysis=m, report=r['study'], result_id=r['result_id'], outcome=v0.get('outcome', r.get('outcome', '')),
                        window=v0.get('window', r.get('window', '')), raw_unit=v0.get('unit', ''),
                        raw_values=' | '.join(raw) if raw else 'see result inventory',
                        factor=r.get('factor', ''), model_values=mv, yi=num(r.get('yi', ''), 4), vi=num(r.get('vi', ''), 5),
                        source_location=v0.get('source_location', r.get('source_location', '')),
                        source_quote=quote or 'Not recorded (location only)', source_sha256=v0.get('source_sha256', '')[:16]))""",
 """        quote = v0.get('source_quote', '') or r.get('source_quote', '') or r.get('source_excerpt', '')
        e21 = E21_SRC.get(r['result_id'], {})
        loc = v0.get('source_location', '') or r.get('source_location', '') or e21.get('loc', '')
        sha = v0.get('source_sha256', '') or r.get('source_sha256', '') or r.get('source_pdf_sha256', '') or e21.get('sha', '')
        out.append(dict(analysis=m, report=r['study'], result_id=r['result_id'], outcome=v0.get('outcome', r.get('outcome', '')),
                        window=v0.get('window', r.get('window', '')), raw_unit=v0.get('unit', ''),
                        raw_values=' | '.join(raw) if raw else (e21.get('raw') or 'see result inventory'),
                        factor=r.get('factor', ''), model_values=mv, yi=num(r.get('yi', ''), 4), vi=num(r.get('vi', ''), 5),
                        source_location=loc,
                        source_quote=quote or e21.get('quote') or ('Not recorded (location only)' if loc else 'NOT RECORDED: no location or quotation'),
                        source_sha256=sha[:16]))"""),
# ---- AF8: stopping rule (m04) and dose-capture wording (M01)
("""                     cumulative_duration='Until PCA stopped (TAES used for 35, 36 and 29 h in arms II–IV; Table 4)',""",
 """                     cumulative_duration='Until patients could control pain with oral analgesics (p408); mean TAES use 35, 36 and 29 h in arms II–IV (Table 4, p410)',"""),
("""                        limitation='Added 2 Nov 2026 (decision D1). PCA total omits IM supplemental opioid. Descriptive association only; shared-arm comparisons must not be counted independently.'))""",
 """                        limitation='Added 2 Nov 2026 (decision D1). Completeness of the 24-h quantity is uncertain (supplemental doses not itemised). Descriptive association only; shared-arm comparisons must not be counted independently.'))"""),
("""                    'quotations are given here). Study characteristics, stimulation protocols, setting and analgesic regimens were '
                    'checked by a second reviewer (SKP).'],""",
 """                    'quotations are given here). Study characteristics, stimulation protocols, setting and analgesic regimens were '
                    'checked by a second reviewer (SKP), including those of Wang 1997 (added and checked 2 Nov 2026).'],"""),
("                     s_note=W97_NOTE + '; AI extraction, check by SKP pending', s_source_pdf=W97_PDF, sha=W97_SHA))",
 "                     s_note=W97_NOTE + '; AI extraction, checked by SKP (reported 2 Nov 2026)', s_source_pdf=W97_PDF, sha=W97_SHA))"),
("                 'Wang 1997 was added on 2 Nov 2026 (decision D1); its characteristics were extracted by the AI assistant and have not yet been checked by SKP.',",
 "                 'Wang 1997 was added on 2 Nov 2026 (decision D1); its characteristics were extracted by the AI assistant and checked by SKP (reported 2 Nov 2026).',"),
# ---- AF10: 12 Wang drafts; pain-at-48-h results not assessed (as Yu 2020)
("""    assert len(units) == 162, len(units)""", """    assert len(units) == 164, len(units)"""),
("""    held.append(dict(model='E2_opioid24_TEAS_sham', result='V33-OD-0184+V33-OD-0185', study='Lee 2011',""",
 """    for m in ('WANG_PAIN48_SHAM', 'WANG_PAIN48_USUAL'):
        held.append(dict(model=m, result='WANG97-PAIN48', study='Wang 1997',
                         reason='Single-trial sensitivity estimate of pain at 48 h (rest or movement not stated); not assessed, as for Yu 2020 at 48 h (PAIN48_YU_TABLE).'))
    held.append(dict(model='E2_opioid24_TEAS_sham', result='V33-OD-0184+V33-OD-0185', study='Lee 2011',"""),
("not counted among the 162.'))", "not counted among the 164.'))"),
("""    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 162 results used in the analyses, with the rationale for each '""",
 """    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 164 results used in the analyses, with the rationale for each '"""),
("""                     'the ten assessments for Wang 1997 (included 2 Nov 2026), which are drafts awaiting second review.'],""",
 """                     'not an exception: the 12 assessments for Wang 1997 (included 2 Nov 2026) were revised after an independent AI '
                     're-check (sham rescue receipt: measurement domain Low to Some concerns; two length-of-stay results added) and '
                     'confirmed by SKP on 2 Nov 2026.'],"""),
("                 [('Judgements', 'One row per assessed result (162), with domain judgements and rationales'),",
 "                 [('Judgements', 'One row per assessed result (164), with domain judgements and rationales'),"),
("                  ('Signalling questions', f'Signalling responses recorded for {n_with} of the 162 results'),",
 "                  ('Signalling questions', f'Signalling responses recorded for {n_with} of the 164 results'),"),
# ---- AF11: current vs superseded rows (M06); revised drafts with target and absolute effects (M07)
("""    wdr = [dict(model=g['model_id'], k=g['k'], n=g['N'], eff=num(g['effect'], 2), lo=num(g['ci_low'], 2), hi=num(g['ci_high'], 2),
                cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'], prev=g['previous'], reason=g['reason'],
                status=g['status']) for g in recs(W97 / 'wang1997_grade_DRAFT.csv')]""",
 """    wdr = []
    for g in recs(W97 / 'wang1997_grade_DRAFT.csv'):
        x = W97_MOD[g['model_id']]
        ab = ''
        if g['model_id'] == 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP':   # control risk = pooled sham events / sham participants (96/267)
            cr = 96 / 267
            ab = (f'Control {1000 * cr:.0f} per 1,000; with TEAS {1000 * cr * float(x["effect"]):.0f} '
                  f'({1000 * cr * float(x["ci_low"]):.0f} to {1000 * cr * float(x["ci_high"]):.0f}) per 1,000')
        wdr.append(dict(model=g['model_id'], target=g['target'], k=x['k'], n=x['N'], eff=num(x['effect'], 2), lo=num(x['ci_low'], 2),
                        hi=num(x['ci_high'], 2), cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'],
                        prev=g['previous'], reason=g['reason'], ab=ab, status=g['status'], version='Current'))
    SUPER = {d['model'] for d in wdr}
    SUP_TXT = 'Superseded: profile for the membership before Wang 1997. Current profile: sheet "With Wang 1997"'
    RESC_SUP = {'TEAS/sham: each trial postoperative follow-up': 'RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'TEAS/sham: approximate first day': 'RESCUE_TEAS_SHAM_FIRST_DAY_APPROX'}
    for rows_, key in ((prim, 'model'), (exp, 'model'), (oth, 'model')):
        for r in rows_:
            r['version'] = SUP_TXT if r[key] in SUPER else 'Current'
    for r in resc:
        r['version'] = SUP_TXT if RESC_SUP.get(r['outcome_comparison']) in SUPER else 'Current'"""),
("""                     'Assessments were made by an AI assistant under the review team\\'s delegation and checked and confirmed by '
                     'a second reviewer (SKP).'],""",
 """                     'Assessments were made by an AI assistant under the review team\\'s delegation and checked and confirmed by '
                     'a second reviewer (SKP); the profiles in sheet "With Wang 1997" were confirmed on 2 Nov 2026. Where one '
                     'exists, the corresponding pre-Wang row in the other sheets is marked "Superseded" in its Version column.'],"""),
("""                  ('With Wang 1997 (draft)', 'Profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026); AI drafts awaiting second review. They supersede the corresponding rows in the other sheets once confirmed.')],""",
 """                  ('With Wang 1997', 'Current profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026): revised after an independent AI re-check and confirmed by SKP on 2 Nov 2026')],"""),
("""          [('rob', 'Risk of bias', 45), ('inc', 'Inconsistency', 40), ('ind', 'Indirectness', 40), ('imp', 'Imprecision', 45),
           ('pub', 'Publication bias', 45), ('status', 'Assessor and second review', 30)])""",
 """          [('rob', 'Risk of bias', 45), ('inc', 'Inconsistency', 40), ('ind', 'Indirectness', 40), ('imp', 'Imprecision', 45),
           ('pub', 'Publication bias', 45), ('status', 'Assessor and second review', 30), ('version', 'Version', 40)])"""),
("""          [('reason', 'Reasons', 60), ('status', 'Assessor and second review', 50)])
    sheet(wb, 'Rescue opioid receipt', resc,""",
 """          [('reason', 'Reasons', 60), ('status', 'Assessor and second review', 50), ('version', 'Version', 40)])
    sheet(wb, 'Rescue opioid receipt', resc,"""),
("""                                              ('assessor', 'Assessor and second review', 40)])""",
 """                                              ('assessor', 'Assessor and second review', 40), ('version', 'Version', 40)])"""),
("""          [('reason', 'Reasons', 60), ('pub', 'Publication bias', 40), ('status', 'Assessor and second review', 40)])""",
 """          [('reason', 'Reasons', 60), ('pub', 'Publication bias', 40), ('status', 'Assessor and second review', 40), ('version', 'Version', 40)])"""),
("""    sheet(wb, 'With Wang 1997 (draft)', wdr, [('model', 'Analysis', 30), ('k', 'Trials', 7), ('n', 'Participants', 10), ('eff', 'Effect', 8),
                                              ('lo', '95% CI low', 9), ('hi', '95% CI high', 9), ('cert', 'Certainty (draft)', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('status', 'Assessor and second review', 50)])""",
 """    sheet(wb, 'With Wang 1997', wdr, [('model', 'Analysis', 30), ('target', 'Target of the rating', 40), ('k', 'Trials', 7),
                                              ('n', 'Participants', 10), ('eff', 'Effect', 8), ('lo', '95% CI low', 9), ('hi', '95% CI high', 9),
                                              ('cert', 'Certainty', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('ab', 'Absolute effect (illustrative)', 36),
           ('status', 'Assessor and second review', 50), ('version', 'Version', 16)])"""),
# ---- AF12: legacy expanded rows (M03), missing values, all new Wang-era models (M04, M05), labels (m02)
("""            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'],
                       tau2=x['tau2'], i2=x['I2'], reports=x['reports'],
                       note=(row['note'] + '; ' if row['note'] else '') + ('Refitted with Wang 1997 (included 2 Nov 2026)' if 'Wang 1997' in x['reports']
                                                                          else 'Unchanged: Wang 1997 excluded by this analysis\\'s rule'))""",
 """            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'],
                       tau2=x['tau2'], i2=x['I2'], reports=x['reports'],
                       note=(row['note'] + '; ' if row['note'] else '') + ('Refitted with Wang 1997 (included 2 Nov 2026)' if 'Wang 1997' in x['reports']
                                                                          else 'Unchanged: Wang 1997 excluded by this analysis\\'s rule'))
            if m.startswith('opioid24_TEAS_sham_expanded'):   # re-check M03
                row['note'] += ('. Legacy construct (device or uncertain-capture 0-24-h quantity, before amendment E2.1), kept as a '
                                'sensitivity analysis; with Wang 1997 the central-factor model equals E2_TEAS_sham_excl_E2.1, and the '
                                'three models without Chen 2020 are identical because no sufentanil result remains')
            for c in ('eff', 'lo', 'hi'):
                row[c] = '' if row[c] == 'NA' else row[c]"""),
("""    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']""",
 """    have = {r['model'] for r in op}
    for m, x in W97_MOD.items():   # re-check: every remaining Wang-era opioid model not already shown
        if m in have or not m.startswith(('E2', 'RESCUE', 'opioid')):
            continue
        row = dict(model=m, family='Broader first-day opioid' if m.startswith('E2') else 'Rescue opioid receipt', analysis=x['description'],
                   measure='MD' if m.startswith('E2') else 'RR', k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'],
                   pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'], reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)',
                   post_hoc='Yes', role='Added 2 Nov 2026', note='Added after the re-check of the Wang 1997 inclusion')
        for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
            row[c] = '' if row[c] == 'NA' else num(row[c], dp)
        op.append(row)
    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']"""),
("""                        note='Added with Wang 1997 (decision D1)'))""",
 """                        note='Added with Wang 1997 (decision D1)'))
    have = {r['model'] for r in oth} | {r['model'] for r in op}
    for m, x in W97_MOD.items():   # re-check (M04, M05): nausea and vomiting diagnostics, low-risk-only cells, single-trial results
        if m in have:
            continue
        rr = m.startswith(('nausea', 'vomiting'))
        role = 'Diagnostic' if ('_LOO_' in m or m.endswith(('NOT_HIGH_LINKED', 'LOW_ONLY'))) else ('Sensitivity' if 'PAIN48' in m else 'Additional')
        oth.append(dict(model=m, label=x['description'], role=role, family='nausea' if m.startswith('nausea') else 'vomiting' if m.startswith('vomiting')
                        else 'length_of_stay' if 'LOS' in m else 'pain', measure='RR' if rr else 'MD',
                        unit='risk ratio' if rr else 'days' if 'LOS' in m else 'points (0-10)', k=x['k'], n=x['N'],
                        eff='' if x['effect'] == 'NA' else num(x['effect']),
                        lo='' if x['ci_low'] == 'NA' else num(x['ci_low']), hi='' if x['ci_high'] == 'NA' else num(x['ci_high']),
                        pil='', pih='', tau2='' if x['tau2'] == 'NA' else num(x['tau2'], 4), i2='' if x['I2'] == 'NA' else num(x['I2'], 1),
                        status='Empty: no low-risk result' if x['k'] == '0' else ('Single trial, normal interval' if x['k'] == '1' else 'REML + Hartung-Knapp (floored at 1)'),
                        reports=x['reports'], parent='', basis='Wang 1997 re-check (2 Nov 2026)', note=x['description']))"""),
("""                  'Wang 1997 was included on 2 Nov 2026 (decision D1). Every analysis it enters was refitted (Note column); without it, '
                  'the broader first-day TEAS-versus-sham estimate is the earlier one (E2_TEAS_sham_LOO_Wang_1997).'])""",
 """                  'Wang 1997 was included on 2 Nov 2026 (decision D1). Every analysis it enters was refitted (Note column); without it, '
                  'the broader first-day TEAS-versus-sham estimate is the earlier one (E2_TEAS_sham_LOO_Wang_1997).',
                  'Notes such as "membership restricted to the fixed 40 reports" describe the membership when an analysis was built; '
                  'rows refitted or added with Wang 1997 say so. The two Lee 2011 leave-out aliases equal the pre-Wang main analysis, '
                  'not the current one.'])"""),
("            r.update(k=x['k'], N=x['N'], effect=x['effect'], ci_low=x['ci_low'], ci_high=x['ci_high'], pi_low=x['pi_low'].replace('NA', ''),",
 "            r.update(k=x['k'], N=x['N'], effect=x['effect'].replace('NA', ''), ci_low=x['ci_low'].replace('NA', ''), ci_high=x['ci_high'].replace('NA', ''), pi_low=x['pi_low'].replace('NA', ''),"),
# ---- AF9: re-check records and scripts
("""                                   'apply_wang_text.py', 'patch_af_wang.py')],""",
 """                                   'apply_wang_text.py', 'patch_af_wang.py', 'wang1997_outcome_inventory.csv')],
    'recheck': [REV / 'recheck' / f for f in ('update_wang_records.py', 'apply_recheck_text.py', 'patch_af_recheck.py')],"""),
("""              'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026) to every analysis it enters, '
              'and compares the result with `data/results/models_with_wang.csv`. '""",
 """              'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026) to every analysis it enters '
              '(including the legacy expanded-dose sensitivity models, the nausea and vomiting diagnostics and Wang\\'s '
              'single-trial results), and compares the result with `data/results/models_with_wang.csv`. A passing run shows '
              'that the distributed models reproduce; it does not show that every eligible analysis or result is included. '"""),
]

R = [
("  wd <- max(abs(c(num(wa$effect) - wn$effect, num(wa$ci_low) - wn$ci_low, num(wa$ci_high) - wn$ci_high)))",
 "  stopifnot(identical(is.na(num(wa$effect)), is.na(wn$effect)))   # empty (k = 0) diagnostic cells must stay empty\n"
 "  wd <- max(abs(c(num(wa$effect) - wn$effect, num(wa$ci_low) - wn$ci_low, num(wa$ci_high) - wn$ci_high)), na.rm = TRUE)"),
]
(REV / 'build_additional_files.py').write_text(patch((SNAP / 'build_additional_files.py').read_text(), B))
(REV / 'reproduce/reproduce_final.R').write_text(patch((SNAP / 'reproduce_final.R').read_text(), R))
print(len(B), 'builder edits;', len(R), 'reproduction-script edit')
