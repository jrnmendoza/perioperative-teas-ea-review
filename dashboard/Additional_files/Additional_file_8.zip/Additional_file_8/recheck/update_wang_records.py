"""Re-check round (2 Nov 2026, after the Astra re-check): rebuild the Wang 1997 records from the post-Wang snapshot.
Changes: dose-capture wording (finding M01), stopping rule and source pages (m04), two further results (length of stay
and 48-h pain; M05), the full outcome inventory (M05), revised RoB 2 drafts (M08) and GRADE drafts (M07). Every
judgement written here was proposed by the AI assistant; SKP reviewed and confirmed all 12 RoB 2 and 11 GRADE
assessments on 2 Nov 2026 (reported by the review owner). Reads recheck/pre_recheck_snapshot/wang1997/ and
writes wang1997/. Source: Wang B et al. Anesth Analg 1997;85:406-13 (local PDF, SHA-256 68b137a7...)."""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'pre_recheck_snapshot/wang1997'
W = HERE.parent / 'wang1997'
ST = 'AI assessment (Claude), 2 Nov 2026, revised after the Astra re-check; second review SKP, 2026-11-02 (confirmed)'


def rd(p):
    return list(csv.DictReader(open(p, encoding='utf-8-sig', newline='')))


def wr(p, rows, fields=None):
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0])); w.writeheader(); w.writerows(rows)


CAPTURE = ('Completeness of capture not established; kept in the broader construct (decision D1b, 2 Nov 2026). Table 3 (p409) reports "Hydromorphone delivered (mg) '
           '... Total in 24 h". The text (pp408-409) states: "To analyze the opioid requirement, the supplemental doses of '
           'meperidine were converted to HM equivalents (100 mg meperidine = 2 mg HM)", and the stated 20%, 31% and 54% '
           'reductions match the Table 3 totals, so the totals may include converted supplemental doses. The report does not '
           'say whether the 24-h quantities include every IM supplemental dose (hydromorphone or meperidine; given to 7/26, '
           '5/25, 3/25 and 4/25 participants), the IV doses nurses could give in the PACU before PCA, or any oral opioid in '
           'the first 24 h; and the sham time-bin means (1.4 + 3.3 + 3.5 + 3.4 = 11.6 mg) do not sum to the stated 10.7 mg. '
           'Primary construct: not admitted (decision D1b). Broader first-day construct: ADMIT '
           '(24-h hydromorphone-equivalent quantity as reported; completeness uncertain; handled like Chen 1998). Factor 5 '
           '(mg IV morphine per mg hydromorphone). Rescue doses are not added to the reported quantity.')

# ---- results: five analysed results (HM24 wording corrected) + two further results admitted to single-trial summaries
res = rd(SNAP / 'wang1997_results.csv')
f = list(res[0])
for r in res:
    if r['result_id'] == 'WANG97-HM24':
        r['outcome'] = 'Hydromorphone delivered (24-h quantity as reported)'
        r['classification'] = CAPTURE
res += [
    dict(result_id='WANG97-LOS', outcome='Days in hospital postoperatively', window='Postoperative stay', unit='days',
         arm_I_pca_only='3 ± 2 (n 26)', arm_II_sham='3 ± 1 (n 25)', arm_III_low='4 ± 1 (n 25)', arm_IV_high='3 ± 1 (n 25)',
         data_type='Mean ± SD', source_location='Table 4, p410 (PDF p5)',
         source_text='Days in hospital postoperatively (d) 3 ± 2 | 3 ± 1 | 4 ± 1 | 3 ± 1',
         classification='Length of stay (registered secondary outcome): single-trial ADDITIONAL estimates against sham and against usual care, in native days, as for Wu 2016 and Ng 2013; not pooled. Values printed to whole days; distribution probably skewed.'),
    dict(result_id='WANG97-PAIN48', outcome='Pain (VAS 0-100; rest or movement not stated)', window='48 h', unit='points (0-100)',
         arm_I_pca_only='29 ± 26 (n 26)', arm_II_sham='32 ± 19 (n 25)', arm_III_low='28 ± 21 (n 25)', arm_IV_high='23 ± 21 (n 25)',
         data_type='Mean ± SD', source_location='Table 6, p412 (PDF p7)', source_text='Pain ... 48 h 29 ± 26 | 32 ± 19 | 28 ± 21 | 23 ± 21',
         classification='Pain at 48 h, rest or movement not stated: single-trial sensitivity estimate (0-10 scale after dividing by 10), as for Yu 2020 at 48 h (PAIN48_YU_TABLE); not pooled; not risk-of-bias assessed, as for that result.'),
]
wr(W / 'wang1997_results.csv', res, f)

# ---- characteristics: stopping rule, source pages, linkage
ch = rd(SNAP / 'wang1997_characteristics.csv')
fix = {
    'covidence_id': ('1879897512', 'Stable Covidence ID; AF4 sheet "Reports"'),
    'population': ('101 ASA I-II women having elective lower abdominal gynaecological surgery; recruited August 1995 to February 1996; mean age 43-45 y by arm; no minimum age stated',
                   'Methods p407; recruitment dates p408; Table 2 p409'),
    'timing': ('Postoperative: started on arrival in the PACU and used for 30 min every 2 h while awake; TAES was discontinued when patients could control their pain with oral analgesics (PCA was discontinued separately, when IV analgesia was no longer needed). Mean TAES use 35, 36 and 29 h in arms II-IV, distinct from mean PCA use 33, 35 and 27 h',
               'Start and schedule: Methods p407; stopping rules: Methods p408; durations: Table 4 p410'),
    'missing_data': ('Arm sizes are given in Table 2 (26, 25, 25, 25). Table 5 percentages use the full arm sizes (e.g. 22/26 = 85%); Tables 3, 4 and 6 give no outcome-specific denominators, and no losses or exclusions are reported',
                     'Table 2 p409; Tables 3-6 pp409-412'),
}
for r in ch:
    if r['field'] in fix:
        r['value'], r['source'] = fix[r['field']]
ch += [dict(field='trial_linkage', value='Chen 1998 (same department and investigators, same PCA regimen) cites Wang 1997 as its preliminary study; the trial arms differ and Chen 1998 gives no recruitment dates, so independence of the two samples is probable but not proven. Counted as separate trials.',
            source='Chen 1998 reference 9; C01_selection/C01_FOUR_REPORTS.md'),
       dict(field='source_note', value='Table 5 prints pruritus 24-48 h in arm III as "7 (44)", but 7/25 is 28%; the count is used only narratively.',
            source='Table 5 p411')]
wr(W / 'wang1997_characteristics.csv', ch)

# ---- outcome inventory (M05): every reported result and its disposition
INV = [
 ('Table 3 p409', 'Hydromorphone delivered, total 0-24 h', 'Existing analysis', 'Broader first-day dose (sham, usual care) and its sensitivity analyses; primary only if the authors judge capture complete (D1b).'),
 ('Table 3 p409', 'Hydromorphone delivered by period (PACU, PACU-8 h, 8-16 h, 16-24 h)', 'Hold', 'Components of the 24-h total, not separate registered outcomes; the sham period means sum to 11.6 mg, not the stated 10.7 mg.'),
 ('Table 3 p409', 'Hydromorphone delivered after 24 h; total over the PCA course', 'Hold', 'No fixed window: PCA ran a mean of 27-36 h (SD up to 14 h), so neither a 0-48-h nor a 24-48-h quantity can be formed; summing period means without their covariance is a prohibited conversion (Additional file 7).'),
 ('Table 3 p409', 'PCA demands by period and in 24 h', 'Excluded by rule', 'Demands (button presses) are not delivered opioid (Additional file 6, Rules).'),
 ('Table 3 p409', 'Number of hydromorphone deliveries by period and in 24 h', 'Excluded by rule', 'Count of boluses, not a quantity; the delivered quantity is already used.'),
 ('Table 3 p409', 'Patients given IM supplemental opioid, first 24 h', 'Existing analysis', 'Rescue opioid receipt, against sham (pooled) and usual care (single trial).'),
 ('Table 3 p409', 'Patients given IM supplemental opioid, after 24 h', 'Narrative', 'Interval count; overlap with the first-24-h recipients is unknown, so it cannot be added to give cumulative receipt. The rescue analysis uses one window per trial (here, the first 24 h).'),
 ('Table 3 p409', 'Oral analgesic doses, acetaminophen (g), oxycodone (mg)', 'Hold', 'Given after PCA stopped, over variable periods not split by day; oral oxycodone has no adopted factor (Additional file 7).'),
 ('Table 4 p410', 'Duration in PACU (min)', 'Narrative', 'Recovery-unit time; not a registered outcome and not hospital length of stay.'),
 ('Table 4 p410', 'Duration of PCA (h)', 'Narrative', 'Descriptive; reflects the stopping rule as well as analgesic need.'),
 ('Table 4 p410', 'Duration of TAES use (h)', 'Intervention delivery', 'Recorded with the characteristics (Table 1, Additional file 8).'),
 ('Table 4 p410', 'Days in hospital postoperatively', 'Single-trial estimate', 'Length of stay, a registered secondary outcome: TEAS vs sham and vs usual care, in days, as for Wu 2016 and Ng 2013; not pooled.'),
 ('Table 5 p411', 'Nausea, first 24 h', 'Existing analysis', 'Nausea 0-24 h (sham pooled with Yao 2015; usual care single trial).'),
 ('Table 5 p411', 'Nausea, 24-48 h', 'Narrative', 'Interval incidence; patients overlapping with the first 24 h are unknown, so it is not cumulative 0-48-h incidence and is not used in the 0-48-h analyses.'),
 ('Table 5 p411', 'Vomiting, first 24 h', 'Existing analysis', 'Vomiting 0-24 h (sham pooled; usual care single trial).'),
 ('Table 5 p411', 'Vomiting, 24-48 h', 'Narrative', 'Interval incidence, as for nausea; no composite PONV is derived from separate symptom counts.'),
 ('Table 5 p411', 'Dizziness, first 24 h and 24-48 h', 'Narrative (harms)', 'Opioid-related symptom; harms were summarised descriptively.'),
 ('Table 5 p411', 'Pruritus, first 24 h and 24-48 h', 'Narrative (harms)', 'As for dizziness; arm III 24-48 h is printed as "7 (44)" although 7/25 is 28%.'),
 ('Table 5 p411', 'Patients treated for nausea and vomiting, first 24 h and after 24 h', 'Narrative', 'Antiemetic treatment; not composite PONV incidence and not a registered outcome model.'),
 ('Table 5 p411', 'Patients treated for pruritus; patients given IV sedatives', 'Narrative (harms)', 'Descriptive only.'),
 ('Table 6 p412', 'Pain VAS, 24 h', 'Existing analysis', 'Pain at about 24 h, rest or movement not stated (sensitivity; sham pooled, usual care single trial).'),
 ('Table 6 p412', 'Pain VAS, 48 h', 'Single-trial estimate (sensitivity)', 'Rest or movement not stated; as for Yu 2020 at 48 h; not pooled.'),
 ('Table 6 p412', 'Sedation, fatigue, comfort and nausea-severity VAS (baseline, 24 h, 48 h)', 'Narrative', 'Not registered outcome constructs; nausea severity is not nausea incidence.'),
 ('p410; Appendix I p412', 'Questionnaire: pain "adequately" treated (90-95% overall)', 'Narrative', 'Satisfaction-type item reported only for all patients together; not QoR.'),
 ('p410', 'Questionnaire: stimulation uncomfortable (no patient)', 'Narrative (harms)', 'Device tolerability.'),
 ('p410', 'Questionnaire: belief that TAES reduced pain (35%, 72%, 84% in arms II-IV)', 'Narrative (risk of bias)', 'Bears on masking of the sham comparison; used in the RoB 2 rationale, not as an outcome.'),
 ('p410', 'Questionnaire: sleep disturbed by the device (28% high, 40% low intensity)', 'Narrative (harms)', 'Device-related harm.'),
 ('p410', 'Questionnaire: willing to pay for TAES (50%, 50%, 76%)', 'Narrative', 'Acceptability; not a registered outcome.'),
]
wr(W / 'wang1997_outcome_inventory.csv', [dict(source=a, result=b, disposition=c, reason=d) for a, b, c, d in INV])

# ---- RoB 2 drafts (M08)
D1 = 'Computer-generated randomisation sequence (Methods p407); allocation concealment not described. Baseline characteristics similar across the four arms (Table 2 p409).'
D2S = ('Patients in arms II-IV were told only that TAES was being studied, not that intensity was compared (p412); the 9-12 mA arm could feel the current and the 0-mA sham could not. Care-provider masking is not described. No departures from the intended regimens arising from the trial context are reported, and PCA and rescue rules were common to all arms; awareness alone is not rated High.')
D2U = ('The PCA-only arm received no device, so participants and staff could know the allocation. No departures from the intended regimens are reported, and PCA and rescue rules were common to all arms; awareness alone is not rated High.')
D3_NV = 'Table 5 percentages use the full arm sizes (e.g. 22/26 = 85%), so every randomised participant contributes; no losses are reported.'
D3_OTHER = ('Arm sizes appear only in Table 2 (26/25/25/25); this table gives no outcome-specific denominators, and no losses or exclusions are reported. Proposed Low because there is no indication of missing data; SKP to judge whether the absence of denominators should lower this.')
D5 = ('No protocol, registration or prespecified analysis plan was identified (the trial predates routine registration). Outcomes and time points match the Methods, and results are given for all four arms at each stated time; no direct evidence of selective reporting.')
D4 = {
 'dose': ('Low', 'The 24-h quantity is read from the PCA record (Table 3); patient demand is part of the effect of assignment (as for Szmit 2021 and Chen 1998). Whether the quantity captures every supplemental dose is a question of construct (D1b), not of measurement bias.'),
 'rescue_s': ('Some concerns', 'IM supplemental opioid was given when relief with PCA was inadequate, a decision that depends on the patient\'s report and on staff judgement. Patients were masked to the comparison, but the high-intensity arm could feel the current, and staff masking is not described. (Changed from Low after the re-check.)'),
 'rescue_u': ('Some concerns', 'IM supplemental opioid depended on patient requests and staff decisions; PCA-only patients knew they had no stimulation device. A recorded event, not a rating scale.'),
 'pain_s': ('Some concerns', 'Self-reported VAS. Patients were masked to the comparison, but the high-intensity arm could feel the current and 35% of sham patients, against 84% of high-intensity patients, believed TAES reduced their pain (p410).'),
 'pain_u': ('High', 'Self-reported VAS by participants who knew they had received no stimulation device; knowledge of the allocation could plausibly influence the rating.'),
 'nausea_s': ('Some concerns', 'Self-reported nausea. Patients were masked to the comparison, but the current was perceptible in the high-intensity arm; observer masking is not described.'),
 'nausea_u': ('High', 'Self-reported nausea by participants who knew they had received no stimulation device.'),
 'vomit_s': ('Some concerns', 'Vomiting is an observed event, but observer masking is not described and the current was perceptible in the high-intensity arm.'),
 'vomit_u': ('Some concerns', 'Vomiting is an observed event; observer masking is not described and the PCA-only arm was unmasked.'),
 'los': ('Some concerns', 'Discharge was decided by clinicians whose masking is not described; length of stay is recorded, but its timing involves judgement.'),
}
units = [
 ('WANG97-HM24-S', 'WANG97-HM24', 'Hydromorphone delivered, 24-h quantity as reported (broader first-day construct)', '0-24 h', 'TEAS vs sham', 'E2_opioid24_TEAS_sham and its sensitivity analyses', D2S, D3_OTHER, 'dose'),
 ('WANG97-HM24-U', 'WANG97-HM24', 'Hydromorphone delivered, 24-h quantity as reported (broader first-day construct)', '0-24 h', 'TEAS vs usual care', 'E2_opioid24_TEAS_usual', D2U, D3_OTHER, 'dose'),
 ('WANG97-RESCUE-S', 'WANG97-RESCUE24', 'Patients given IM supplemental opioid', '0-24 h', 'TEAS vs sham', 'Rescue opioid receipt', D2S, D3_OTHER, 'rescue_s'),
 ('WANG97-RESCUE-U', 'WANG97-RESCUE24', 'Patients given IM supplemental opioid', '0-24 h', 'TEAS vs usual care', 'RESCUE_TEAS_USUAL', D2U, D3_OTHER, 'rescue_u'),
 ('WANG97-VAS24-S', 'WANG97-VAS24', 'Pain, VAS (rest or movement not stated)', '24 h', 'TEAS vs sham', 'pain24_unclassified_TEAS_sham', D2S, D3_OTHER, 'pain_s'),
 ('WANG97-VAS24-U', 'WANG97-VAS24', 'Pain, VAS (rest or movement not stated)', '24 h', 'TEAS vs usual care', 'pain24_unclassified_TEAS_usual', D2U, D3_OTHER, 'pain_u'),
 ('WANG97-NAUSEA-S', 'WANG97-NAUSEA24', 'Nausea', '0-24 h', 'TEAS vs sham', 'nausea24_TEAS_sham', D2S, D3_NV, 'nausea_s'),
 ('WANG97-NAUSEA-U', 'WANG97-NAUSEA24', 'Nausea', '0-24 h', 'TEAS vs usual care', 'nausea24_TEAS_usual', D2U, D3_NV, 'nausea_u'),
 ('WANG97-VOMIT-S', 'WANG97-VOMIT24', 'Vomiting', '0-24 h', 'TEAS vs sham', 'vomiting24_TEAS_sham', D2S, D3_NV, 'vomit_s'),
 ('WANG97-VOMIT-U', 'WANG97-VOMIT24', 'Vomiting', '0-24 h', 'TEAS vs usual care', 'vomiting24_TEAS_usual', D2U, D3_NV, 'vomit_u'),
 ('WANG97-LOS-S', 'WANG97-LOS', 'Days in hospital postoperatively', 'Postoperative stay', 'TEAS vs sham', 'WANG_LOS_SHAM', D2S, D3_OTHER, 'los'),
 ('WANG97-LOS-U', 'WANG97-LOS', 'Days in hospital postoperatively', 'Postoperative stay', 'TEAS vs usual care', 'WANG_LOS_USUAL', D2U, D3_OTHER, 'los'),
]
old = {r['assessment_id']: r for r in rd(SNAP / 'wang1997_rob2_DRAFT.csv')}
rows = []
for aid, rid, outc, win, comp, an, d2, d3, k4 in units:
    d = [('Some concerns', D1), ('Some concerns', d2), ('Low', d3), D4[k4], ('Some concerns', D5)]
    j = [x[0] for x in d]
    overall = 'High' if 'High' in j else ('Low' if all(x == 'Low' for x in j) else 'Some concerns')
    rows.append(dict(assessment_id=aid, result_id=rid, study='Wang 1997', outcome=outc, window=win, comparison=comp, analyses=an,
                     d1=j[0], d2=j[1], d3=j[2], d4=j[3], d5=j[4], overall=overall,
                     d1_rationale=d[0][1], d2_rationale=d[1][1], d3_rationale=d[2][1], d4_rationale=d[3][1], d5_rationale=d[4][1],
                     overall_rationale='High because outcome measurement was rated High.' if overall == 'High' else
                     'Several domains with some concerns, none judged to make material bias likely; not counted mechanically to High.',
                     source_pdf='10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/1879897512.pdf',
                     source_sha256='68b137a7876f976afd74bf0620c80d4cda08c8f7de73ae1740309d8b5d3b0d2f',
                     decision_status=ST, change_from_previous_draft='' if aid not in old else
                     ', '.join(f'D{i} {old[aid][f"d{i}"]} -> {j[i-1]}' for i in range(1, 6) if old[aid][f'd{i}'] != j[i-1]) or 'Rationale wording only'))
    if aid not in old:
        rows[-1]['change_from_previous_draft'] = 'New result (length of stay) added after the re-check'
wr(W / 'wang1997_rob2_DRAFT.csv', rows)

# ---- GRADE drafts (M07); numbers are filled by refit_with_wang.R output in a later step (fill_grade below)
G = [
 ('E2_opioid24_TEAS_sham', 'Mean difference in 24-h opioid (mg IV morphine) from results admitted to the broader construct', 'Very low', 1, 1, 1, 2, 0, 'Very low (6 trials, second-reviewed)',
  'Risk of bias: one result high, most some concerns. Inconsistency: I2 98%, prediction interval -24.81 to 10.36. Indirectness: totals with incomplete or uncertain capture of systemic opioid (including Wang 1997, whose completeness is uncertain) relative to the registered construct. Imprecision: the interval (-14.13 to -0.32) spans a reduction beyond 10 mg and a trivial one.'),
 ('E2_opioid24_TEAS_usual', 'As above, against usual care', 'Very low', 1, 1, 1, 2, 0, 'Low (Szmit 2021 alone)',
  'Two trials with some concerns; effects differ (-8.0 and -28.5 mg; I2 89%); the completeness of the Wang 1997 quantity is uncertain (indirect); two-trial Hartung-Knapp interval -146.7 to 112.4 mg.'),
 ('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'Proportion of participants given any rescue opioid over each trial\'s own follow-up (exploratory; not a fixed 0-24-h effect)', 'Low', 1, 0, 0, 1, 0, 'Low (5 trials, second-reviewed: risk of bias 1, imprecision 1)',
  'Risk of bias: two of six trials at high risk (missing data). Inconsistency: none (I2 0%, all point estimates 0.38-0.70). Indirectness: not downgraded against the stated target (mixed follow-up is part of the exploratory question; against a fixed 0-24-h question it would be serious). Imprecision: serious; 147 events in 553 participants, below the about 830 participants needed to detect a 25% relative reduction from a 36% control risk (alpha 0.05, power 0.8), although the interval (0.37 to 0.74) excludes no effect. Same domains as the second-reviewed five-trial profile; the earlier draft had exchanged imprecision for indirectness, which is withdrawn.'),
 ('RESCUE_TEAS_SHAM_FIRST_DAY_APPROX', 'As above, trials with approximately first-day follow-up', 'Very low', 1, 0, 0, 2, 0, 'Very low (2 trials)',
  'Three small trials, 276 participants; the interval (0.12 to 2.42) includes appreciable benefit and harm.'),
 ('RESCUE_TEAS_USUAL', 'Rescue receipt, 0-24 h, against usual care', 'Very low', 1, 0, 0, 2, 0, 'No result (new)',
  'Single trial, 76 participants, 14 events; unmasked comparator; interval 0.20 to 1.32.'),
 ('nausea24_TEAS_sham', 'Nausea, 0-24 h, against sham', 'Very low', 1, 0, 0, 2, 0, 'Very low (Yao 2015 alone)',
  'Risk of bias: both trials some concerns. Inconsistency: not downgraded (I2 0%; risk ratios 0.67 and 0.82, same direction); the earlier draft deduction is withdrawn. Imprecision: very serious; the two-trial interval (0.22 to 2.78) includes appreciable benefit and harm.'),
 ('vomiting24_TEAS_sham', 'Vomiting, 0-24 h, against sham', 'Very low', 1, 1, 0, 1, 0, 'Very low (3 trials)',
  'Risk of bias: some concerns. Inconsistency: trials differ in setting and size of effect (Wang 1997 RR 1.00 against 0.38-0.59 in the others). Imprecision: interval 0.40 to 0.81 below 1, but outside Gao 2022 the event count is small (Gao contributes 233 of the events).'),
 ('nausea24_TEAS_usual', 'Nausea, 0-24 h, against usual care', 'Very low', 2, 0, 0, 1, 0, 'No result (new)',
  'Single trial; self-reported nausea by unmasked PCA-only participants (High); interval 0.67 to 1.08.'),
 ('vomiting24_TEAS_usual', 'Vomiting, 0-24 h, against usual care', 'Very low', 1, 0, 0, 2, 0, 'Not rated (empty cell)',
  'Single trial, 76 participants, 19 events; interval 0.40 to 1.99.'),
 ('WANG_LOS_SHAM', 'Postoperative length of stay (days), against sham', 'Very low', 1, 0, 0, 2, 0, 'No result (new)',
  'Single trial, 75 participants; values printed as whole days (probably skewed); interval includes no difference and a 1-day increase.'),
 ('WANG_LOS_USUAL', 'Postoperative length of stay (days), against usual care', 'Very low', 1, 0, 0, 2, 0, 'No result (new)',
  'Single trial, 76 participants; unmasked comparator; whole-day values; interval includes no difference.'),
]
wr(W / 'wang1997_grade_DRAFT.csv', [dict(model_id=m, target=t, certainty=c, rob=a, inc=b, ind=i, imp=p, pub=u, previous=pv, reason=rs, status=ST)
                                   for m, t, c, a, b, i, p, u, pv, rs in G])
print('results', len(res), '| inventory', len(INV), '| RoB units', len(rows), '| GRADE bodies', len(G))
