# Refit of every analysis that Wang 1997 enters, after the review owner judged on 2 Nov 2026 (results known) that its
# stimulation is TEAS. Wang 1997 enters the broader first-day analysis, not the primary one (decision D1b, 2 Nov 2026): the
# report does not establish whether its 24-h hydromorphone quantities capture the IM supplemental doses given to 19 of
# 101 patients (supplemental meperidine was converted to hydromorphone equivalents for its analysis, but the table does
# not itemise rescue), and complete capture is never assumed (as for Chen 1998). Low- and high-intensity arms are combined (Cochrane Handbook formula) and compared with the
# sham arm and, separately, with the PCA-only arm.
# Estimator as in the review: REML; Hartung-Knapp variance multiplier floored at 1; t(k-1) intervals; a single trial
# keeps its own normal interval; prediction intervals for k >= 5. Lee 2011 is held from all pooled analyses.
# Reads the archived inputs read-only (or data/ when run inside the unpacked Additional file 9) and writes, beside this
# script, wang1997_analysis_inputs.csv and models_with_wang.csv. Values: wang1997_results.csv.
# Re-check round (2 Nov 2026): Wang's 24-h quantity is "as reported; completeness uncertain" (the source neither confirms
# nor excludes supplemental doses), so it stays in the broader construct (decision D1b). Added: the six legacy
# expanded-dose sensitivity models (same device-or-uncertain-capture construct that admits Chen 1998), the diagnostics the
# registered-completion rule generates once nausea vs sham reaches two trials, the Wang-omitted vomiting model, explicit
# empty low-risk-only cells, and single-trial length of stay and 48-h pain (Tables 4 and 6).
# Decision D3 (2 Nov 2026): Fu 2024 (TEAS vs sham; rescue IV tramadol receipt, follow-up not stated; intraoperative
# remifentanil; QoR-15 at POD1 and POD3) and Colak 2010 (EA vs usual care; resting pain on day 1; 7-day pethidine) are
# added below; Chen 2016 is held from pooled analyses. Values: d3/d3_results.csv. The output file keeps its name.
# After Astra's audit of the D3 build (3 Nov 2026): single-trial estimates at the other registered windows (Colak rest pain
# on days 2-7, each reported day being analysed, and 7-day metamizole; Fu QoR-15 on day 7). None changes an existing model.
args <- commandArgs(trailingOnly = FALSE)
f <- sub("^--file=", "", args[grep("^--file=", args)])
here <- if (length(f)) dirname(normalizePath(f)) else getwd()
proj <- normalizePath(file.path(here, "..", "..", "..", ".."), mustWork = FALSE)
fa <- file.path(proj, "opioid_only_review", "forty_report_analysis")
inpkg <- dir.exists(file.path(here, "data", "inputs"))
src <- function(proj_path, pkg_path) if (inpkg) file.path(here, pkg_path) else file.path(fa, proj_path)
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^﻿", "", names(x)); x }
num <- function(x) suppressWarnings(as.numeric(x))
fit <- function(y, v) {
  k <- length(y)
  if (k == 1) return(c(k = 1, effect = y, lo = y - qnorm(.975) * sqrt(v), hi = y + qnorm(.975) * sqrt(v), tau2 = NA, I2 = NA, pil = NA, pih = NA))
  nll <- function(t) { w <- 1 / (v + t); mu <- sum(w * y) / sum(w); .5 * (sum(log(v + t)) + log(sum(w)) + sum(w * (y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2) * 10, max(v) * 10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1 / (v + tau); mu <- sum(w * y) / sum(w); q <- sum(w * (y - mu)^2) / (k - 1)
  se <- sqrt(max(1, q) / sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1 / v; C <- sum(w0) - sum(w0^2) / sum(w0)
  pil <- pih <- NA
  if (k >= 5) { h <- qt(.975, k - 1) * sqrt(tau + se^2); pil <- mu - h; pih <- mu + h }
  c(k = k, effect = mu, lo = mu - cr * se, hi = mu + cr * se, tau2 = tau, I2 = 100 * tau / (tau + (k - 1) / C), pil = pil, pih = pih)
}
comb <- function(n1, m1, s1, n2, m2, s2) {
  n <- n1 + n2; m <- (n1 * m1 + n2 * m2) / n
  c(n = n, m = m, s = sqrt(((n1 - 1) * s1^2 + (n2 - 1) * s2^2 + n1 * n2 / n * (m1 - m2)^2) / (n - 1)))
}

# ---- Wang 1997 contrasts (Anesth Analg 1997;85:406-13; arms: PCA only 26, sham 25, low 25, high 25)
hm <- comb(25, 9.3, 6.2, 25, 6.1, 3.3)               # Table 3: hydromorphone delivered, 0-24 h (mg)
va <- comb(25, 4.5, 2.6, 25, 4.4, 2.3)               # Table 6: VAS 0-100 at 24 h, divided by 10
W <- list()
wmd <- function(id, model, ctrl, f, a, nc, mc, sc, unit) {
  W[[length(W) + 1]] <<- data.frame(result_id = id, model_family = model, comparator = ctrl, factor = f, n_i = a[["n"]],
    mean_i = f * a[["m"]], sd_i = f * a[["s"]], n_c = nc, mean_c = f * mc, sd_c = f * sc, events_i = NA, events_c = NA,
    yi = f * (a[["m"]] - mc), vi = (f * a[["s"]])^2 / a[["n"]] + (f * sc)^2 / nc, unit = unit, stringsAsFactors = FALSE)
}
wrr <- function(id, model, ctrl, ei, ni, ec, nc, unit) {
  W[[length(W) + 1]] <<- data.frame(result_id = id, model_family = model, comparator = ctrl, factor = NA, n_i = ni, mean_i = NA,
    sd_i = NA, n_c = nc, mean_c = NA, sd_c = NA, events_i = ei, events_c = ec, yi = log((ei / ni) / (ec / nc)),
    vi = 1 / ei - 1 / ni + 1 / ec - 1 / nc, unit = unit, stringsAsFactors = FALSE)
}
wmd("WANG97-HM24", "broader first-day dose", "sham", 5, hm, 25, 10.7, 7.3, "mg IV morphine (hydromorphone x 5)")
wmd("WANG97-HM24", "broader first-day dose", "usual care", 5, hm, 26, 13.4, 5.8, "mg IV morphine (hydromorphone x 5)")
wrr("WANG97-RESCUE24", "rescue opioid receipt", "sham", 3 + 4, 50, 5, 25, "patients given IM supplemental opioid, 0-24 h")
wrr("WANG97-RESCUE24", "rescue opioid receipt", "usual care", 3 + 4, 50, 7, 26, "patients given IM supplemental opioid, 0-24 h")
wmd("WANG97-VAS24", "pain at 24 h, rest or movement not stated", "sham", 0.1, c(n = va[["n"]], m = va[["m"]] * 10, s = va[["s"]] * 10), 25, 48, 22, "points (0-10)")
wmd("WANG97-VAS24", "pain at 24 h, rest or movement not stated", "usual care", 0.1, c(n = va[["n"]], m = va[["m"]] * 10, s = va[["s"]] * 10), 26, 44, 32, "points (0-10)")
wrr("WANG97-NAUSEA24", "nausea, 0-24 h", "sham", 21 + 15, 50, 22, 25, "participants")
wrr("WANG97-NAUSEA24", "nausea, 0-24 h", "usual care", 21 + 15, 50, 22, 26, "participants")
wrr("WANG97-VOMIT24", "vomiting, 0-24 h", "sham", 8 + 4, 50, 6, 25, "participants")
wrr("WANG97-VOMIT24", "vomiting, 0-24 h", "usual care", 8 + 4, 50, 7, 26, "participants")
los <- comb(25, 4, 1, 25, 3, 1)                       # Table 4: days in hospital postoperatively
p48 <- comb(25, 28, 21, 25, 23, 21)                   # Table 6: VAS 0-100 at 48 h, divided by 10
wmd("WANG97-LOS", "length of stay", "sham", 1, los, 25, 3, 1, "days")
wmd("WANG97-LOS", "length of stay", "usual care", 1, los, 26, 3, 2, "days")
wmd("WANG97-PAIN48", "pain at 48 h, rest or movement not stated", "sham", 0.1, p48, 25, 32, 19, "points (0-10)")
wmd("WANG97-PAIN48", "pain at 48 h, rest or movement not stated", "usual care", 0.1, p48, 26, 29, 26, "points (0-10)")
W <- do.call(rbind, W)
wg <- function(id, ctrl) W[W$result_id == id & W$comparator == ctrl, ]

# ---- archived inputs and results
e2 <- rd(src(file.path("reviewer_rerun_2026_10_09", "e2", "e2_model_inputs.csv"), file.path("data", "inputs", "e2_model_inputs.csv")))
lee <- rd(src(file.path("reviewer_rerun_2026_10_09", "lee_hold_rerun_2026-10-23.csv"), file.path("data", "results", "lee_hold_rerun_2026-10-23.csv")))
rmi <- rd(src(file.path("reviewer_rerun_2026_10_09", "model_inputs.csv"), file.path("data", "inputs", "reviewer_rerun_model_inputs.csv")))
rmr <- rd(src(file.path("reviewer_rerun_2026_10_09", "model_results.csv"), file.path("data", "results", "model_results.csv")))
cmi <- rd(src(file.path("registered_completion_2026_10_09", "model_inputs.csv"), file.path("data", "inputs", "registered_completion_model_inputs.csv")))
cmr <- rd(src(file.path("registered_completion_2026_10_09", "model_results_python.csv"), file.path("data", "results", "model_results_python.csv")))

out <- list()
add <- function(id, desc, ratio, y, v, n, reports, old_k, old) {
  f <- fit(y, v); tr <- if (ratio) exp else identity
  out[[length(out) + 1]] <<- data.frame(model_id = id, description = desc, k = f[["k"]], N = n, effect = tr(f[["effect"]]),
    ci_low = tr(f[["lo"]]), ci_high = tr(f[["hi"]]), tau2 = f[["tau2"]], I2 = f[["I2"]], pi_low = tr(f[["pil"]]), pi_high = tr(f[["pih"]]),
    october_k = old_k, october_effect = old[1], october_ci_low = old[2], october_ci_high = old[3],
    reports = paste(reports, collapse = "; "), stringsAsFactors = FALSE)
}
old <- function(r) c(num(r$effect), num(r$ci_low), num(r$ci_high))

# 1. Broader first-day dose, TEAS vs sham: every Lee-held model, refitted with Wang where it qualifies
nWs <- 75; nWu <- 76
for (m in lee$model_id) {
  r <- lee[lee$model_id == m, ]
  base <- e2[e2$model_id == if (m == "E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE") "E2_opioid24_TEAS_sham" else m, ]
  d <- base[base$study %in% strsplit(r$reports, ";")[[1]] & base$study != "Lee 2011", ]
  stopifnot(nrow(d) == as.integer(r$k), abs(fit(num(d$yi), num(d$vi))[["effect"]] - num(r$effect)) < 2e-6)
  w <- wg("WANG97-HM24", "sham")
  add(m, "Broader first-day opioid, TEAS vs sham, with Wang 1997", FALSE, c(num(d$yi), w$yi), c(num(d$vi), w$vi),
      sum(num(d$n_i) + num(d$n_c)) + nWs, c(d$study, "Wang 1997"), as.integer(r$k), old(r))
}
add("E2_TEAS_sham_LOO_Wang_1997", "Broader first-day opioid, TEAS vs sham, without Wang 1997 (= October estimate)", FALSE,
    num(e2$yi[e2$model_id == "E2_opioid24_TEAS_sham" & e2$study != "Lee 2011"]), num(e2$vi[e2$model_id == "E2_opioid24_TEAS_sham" & e2$study != "Lee 2011"]),
    547, e2$study[e2$model_id == "E2_opioid24_TEAS_sham" & e2$study != "Lee 2011"], NA, rep(NA, 3))
d <- e2[e2$model_id == "E2_TEAS_sham_excl_unquantified_rescue", ]
add("E2_TEAS_sham_excl_unquantified_rescue", "Without results whose totals do not establish capture of rescue (Chen 1998 and Wang 1997 excluded)", FALSE,
    num(d$yi), num(d$vi), sum(num(d$n_i) + num(d$n_c)), d$study, nrow(d), old(rmr[rmr$model_id == "E2_TEAS_sham_excl_unquantified_rescue", ]))
d <- e2[e2$model_id == "E2_opioid24_TEAS_usual", ]; w <- wg("WANG97-HM24", "usual care")
add("E2_opioid24_TEAS_usual", "Broader first-day opioid, TEAS vs usual care, with Wang 1997 (vs PCA only)", FALSE,
    c(num(d$yi), w$yi), c(num(d$vi), w$vi), sum(num(d$n_i) + num(d$n_c)) + nWu, c(d$study, "Wang 1997"), 1,
    old(rmr[rmr$model_id == "E2_opioid24_TEAS_usual", ]))
add("E2_opioid24_TEAS_usual_NOT_HIGH_WITH_LINKAGE", "Broader first-day opioid, TEAS vs usual care, excluding results at high risk of bias (none; both some concerns)",
    FALSE, c(num(d$yi), w$yi), c(num(d$vi), w$vi), sum(num(d$n_i) + num(d$n_c)) + nWu, c(d$study, "Wang 1997"), 1,
    old(rmr[rmr$model_id == "E2_opioid24_TEAS_usual_NOT_HIGH_WITH_LINKAGE", ]))
add("E2_WANG_1997_SHAM_SINGLE", "Wang 1997 alone, broader first-day opioid vs sham", FALSE, wg("WANG97-HM24", "sham")$yi,
    wg("WANG97-HM24", "sham")$vi, nWs, "Wang 1997", NA, rep(NA, 3))

# 2. Rescue opioid receipt, TEAS vs sham (Wang: IM supplemental opioid in the first 24 h, a complete 0-24 h window;
#    Fu 2024 (D3): rescue IV tramadol, follow-up not stated, so it enters the analyses that admit Yu 2020's unstated
#    window; one control participant (of 30 randomised) has no outcome, which the missing-data scenarios assign)
w <- wg("WANG97-RESCUE24", "sham")
lrr <- function(ei, ni, ec, nc) c(y = log((ei / ni) / (ec / nc)), v = 1 / ei - 1 / ni + 1 / ec - 1 / nc)
FU <- list(obs = lrr(2, 30, 6, 29), NONE = lrr(2, 30, 6, 30), ALL = lrr(2, 30, 7, 30),
           UNFAVOURABLE_TO_TEAS = lrr(2, 30, 6, 30), FAVOURABLE_TO_TEAS = lrr(2, 30, 7, 30))
fu_in <- function(m) !grepl("KNOWN_PERIODS|FIRST_DAY_APPROX|LOW_ONLY", m)
for (m in unique(rmi$model_id[grepl("^RESCUE_", rmi$model_id)])) {
  d <- rmi[rmi$model_id == m & !is.na(num(rmi$yi)), ]; r <- rmr[rmr$model_id == m, ]
  if (!nrow(d) || nrow(r) != 1) next
  stopifnot(abs(exp(fit(num(d$yi), num(d$vi))[["effect"]]) - num(r$effect)) < 2e-6)
  y <- c(num(d$yi), w$yi); v <- c(num(d$vi), w$vi); n <- as.integer(r$N) + 75; rp <- c(strsplit(r$reports, ";")[[1]], "Wang 1997")
  if (fu_in(m)) {
    sc <- sub("^RESCUE_MISSING_", "", m); f <- if (grepl("^RESCUE_MISSING_", m)) FU[[sc]] else FU$obs
    y <- c(y, f[["y"]]); v <- c(v, f[["v"]]); n <- n + if (grepl("^RESCUE_MISSING_", m)) 60 else 59; rp <- c(rp, "Fu 2024")
  }
  add(m, paste0("Rescue opioid receipt, TEAS vs sham, with Wang 1997", if (fu_in(m)) " and Fu 2024" else " (Fu 2024 not eligible for this subset)"),
      TRUE, y, v, n, rp, as.integer(r$k), old(r))
}
d <- rmi[rmi$model_id == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP", ]
add("RESCUE_LOO_Wang_1997", "Rescue opioid receipt without Wang 1997 (with Fu 2024)", TRUE, c(num(d$yi), FU$obs[["y"]]), c(num(d$vi), FU$obs[["v"]]),
    478 + 59, c(strsplit(rmr$reports[rmr$model_id == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP"], ";")[[1]], "Fu 2024"), NA, rep(NA, 3))
add("RESCUE_LOO_Fu_2024", "Rescue opioid receipt without Fu 2024 (= the six-trial estimate with Wang 1997)", TRUE, c(num(d$yi), w$yi),
    c(num(d$vi), w$vi), 478 + 75, c(strsplit(rmr$reports[rmr$model_id == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP"], ";")[[1]], "Wang 1997"), NA, rep(NA, 3))
w <- wg("WANG97-RESCUE24", "usual care")
add("RESCUE_TEAS_USUAL", "Rescue opioid receipt, TEAS vs usual care (new; Wang 1997 vs PCA only)", TRUE, w$yi, w$vi, nWu, "Wang 1997", 0, rep(NA, 3))

# 3. Registered-completion outcomes that Wang enters
fam <- list(pain24_unclassified_TEAS_sham = "WANG97-VAS24", nausea24_TEAS_sham = "WANG97-NAUSEA24", vomiting24_TEAS_sham = "WANG97-VOMIT24",
            vomiting24_TEAS_sham_LOO_Yao_2015 = "WANG97-VOMIT24", vomiting24_TEAS_sham_LOO_Gao_2022 = "WANG97-VOMIT24",
            vomiting24_TEAS_sham_LOO_Xiong_2021 = "WANG97-VOMIT24", vomiting24_TEAS_sham_NOT_HIGH_LINKED = "WANG97-VOMIT24")
for (m in names(fam)) {
  d <- cmi[cmi$model_id == m & !is.na(num(cmi$yi)), ]; r <- cmr[cmr$model_id == m, ]
  ratio <- r$measure %in% c("RR", "OR"); tr <- if (ratio) exp else identity
  stopifnot(nrow(d) == as.integer(r$k), abs(tr(fit(num(d$yi), num(d$vi))[["effect"]]) - num(r$effect)) < 2e-6)
  w <- wg(fam[[m]], "sham")
  add(m, paste0(r$label, ", with Wang 1997"), ratio, c(num(d$yi), w$yi), c(num(d$vi), w$vi), num(r$N) + 75, c(d$study, "Wang 1997"),
      as.integer(r$k), old(r))
}
for (x in list(c("pain24_unclassified_TEAS_usual", "WANG97-VAS24", "Pain at 24 h, rest or movement not stated, TEAS vs usual care (new)", "0"),
               c("nausea24_TEAS_usual", "WANG97-NAUSEA24", "Nausea 0-24 h, TEAS vs usual care (new)", "0"),
               c("vomiting24_TEAS_usual", "WANG97-VOMIT24", "Vomiting 0-24 h, TEAS vs usual care (archived with k = 0)", "0"))) {
  w <- wg(x[2], "usual care")
  add(x[1], x[3], x[2] != "WANG97-VAS24", w$yi, w$vi, nWu, "Wang 1997", as.integer(x[4]), rep(NA, 3))
}
add("pain24_WANG_1997_SHAM_SINGLE", "Wang 1997 alone, pain at 24 h vs sham (paired with its broader dose result)", FALSE,
    wg("WANG97-VAS24", "sham")$yi, wg("WANG97-VAS24", "sham")$vi, nWs, "Wang 1997", NA, rep(NA, 3))

# 4. Re-check round additions
add0 <- function(id, desc, old_k) out[[length(out) + 1]] <<- data.frame(model_id = id, description = desc, k = 0, N = 0, effect = NA,
  ci_low = NA, ci_high = NA, tau2 = NA, I2 = NA, pi_low = NA, pi_high = NA, october_k = old_k, october_effect = NA, october_ci_low = NA,
  october_ci_high = NA, reports = "", stringsAsFactors = FALSE)
# 4a. Legacy expanded-dose models (device or equivalence-uncertain 0-24-h quantity; admit Chen 1998, so Wang 1997 too)
w <- wg("WANG97-HM24", "sham")
for (m in unique(rmi$model_id[grepl("^opioid24_TEAS_sham_expanded", rmi$model_id)])) {
  d <- rmi[rmi$model_id == m & !is.na(num(rmi$yi)), ]; r <- rmr[rmr$model_id == m, ]
  stopifnot(nrow(d) == as.integer(r$k), abs(fit(num(d$yi), num(d$vi))[["effect"]] - num(r$effect)) < 2e-6)
  add(m, "Legacy expanded-dose sensitivity (device or uncertain-capture 0-24-h quantity), with Wang 1997", FALSE,
      c(num(d$yi), w$yi), c(num(d$vi), w$vi), sum(num(d$n_i) + num(d$n_c)) + nWs, c(d$study, "Wang 1997"), nrow(d), old(r))
}
# 4b. Diagnostics generated by the registered-completion rule (LOO, NOT_HIGH_LINKED, LOW_ONLY when k >= 2)
d <- cmi[cmi$model_id == "nausea24_TEAS_sham", ]; w <- wg("WANG97-NAUSEA24", "sham")
add("nausea24_TEAS_sham_LOO_Yao_2015", "Nausea 0-24 h vs sham; omit Yao 2015", TRUE, w$yi, w$vi, 75, "Wang 1997", NA, rep(NA, 3))
add("nausea24_TEAS_sham_LOO_Wang_1997", "Nausea 0-24 h vs sham; omit Wang 1997 (= earlier single-trial body)", TRUE, num(d$yi), num(d$vi),
    num(cmr$N[cmr$model_id == "nausea24_TEAS_sham"]), d$study, 1, old(cmr[cmr$model_id == "nausea24_TEAS_sham", ]))
add("nausea24_TEAS_sham_NOT_HIGH_LINKED", "Nausea 0-24 h vs sham; results not at high risk (both some concerns)", TRUE, c(num(d$yi), w$yi),
    c(num(d$vi), w$vi), num(cmr$N[cmr$model_id == "nausea24_TEAS_sham"]) + 75, c(d$study, "Wang 1997"), NA, rep(NA, 3))
d <- cmi[cmi$model_id == "vomiting24_TEAS_sham", ]
add("vomiting24_TEAS_sham_LOO_Wang_1997", "Vomiting 0-24 h vs sham; omit Wang 1997 (= earlier three-trial body)", TRUE, num(d$yi), num(d$vi),
    num(cmr$N[cmr$model_id == "vomiting24_TEAS_sham"]), d$study, 3, old(cmr[cmr$model_id == "vomiting24_TEAS_sham", ]))
for (x in c("nausea24_TEAS_sham_LOW_ONLY", "vomiting24_TEAS_sham_LOW_ONLY", "E2_opioid24_TEAS_sham_LOW_ONLY", "E2_opioid24_TEAS_usual_LOW_ONLY",
            "RESCUE_LOW_ONLY"))
  add0(x, "Low-risk-only diagnostic: empty. No contributing result, including Wang 1997's, is at low risk of bias", 0)
# 4c. Single-trial results admitted after the outcome inventory (Tables 4 and 6)
for (x in list(c("WANG_LOS_SHAM", "WANG97-LOS", "sham", "Wang 1997: length of stay (days) vs sham"),
               c("WANG_LOS_USUAL", "WANG97-LOS", "usual care", "Wang 1997: length of stay (days) vs usual care"),
               c("WANG_PAIN48_SHAM", "WANG97-PAIN48", "sham", "Wang 1997: pain at 48 h, rest or movement not stated, vs sham (sensitivity)"),
               c("WANG_PAIN48_USUAL", "WANG97-PAIN48", "usual care", "Wang 1997: pain at 48 h, rest or movement not stated, vs usual care (sensitivity)"))) {
  w <- wg(x[2], x[3]); add(x[1], x[4], FALSE, w$yi, w$vi, if (x[3] == "sham") nWs else nWu, "Wang 1997", NA, rep(NA, 3))
}

# 5. Decision D3 additions (Colak 2010, Fu 2024)
md2 <- function(ni, mi, si, nc, mc, sc) c(y = mi - mc, v = si^2 / ni + sc^2 / nc)
x <- md2(15, 5.033, 0.719, 15, 5.233, 1.522)      # Colak Table 1: day-1 resting VAS 0-100 / 10 (EA 50.33 +/- 7.19; control 52.33 +/- 15.22)
add("pain24_rest_EA_usual", "Pain at rest at about 24 h (day 1), EA vs usual care (Colak 2010)", FALSE, x[["y"]], x[["v"]], 30, "Colak 2010", 0, rep(NA, 3))
x <- md2(15, 76.67, 84.23, 15, 223.33, 132.10)     # Colak Table 1: pethidine over 7 days (mg)
add("opioid7d_pethidine_EA_usual_COLAK", "Pethidine over postoperative days 0-7 (mg, native units), EA vs usual care (Colak 2010); single trial, not a 0-24-h analysis",
    FALSE, x[["y"]], x[["v"]], 30, "Colak 2010", NA, rep(NA, 3))
x <- md2(30, 572.3, 82.0, 29, 662.0, 148.2)        # Fu Table 4: stage-2 remifentanil (ug)
add("intraop_remifentanil_TEAS_sham", "Intraoperative remifentanil (ug), TEAS vs sham (Fu 2024)", FALSE, x[["y"]], x[["v"]], 59, "Fu 2024", 0, rep(NA, 3))
q1 <- md2(30, 118.4, 3.5, 29, 112.0, 4.8)           # Fu Table 3: QoR-15 at T1 (POD1)
d <- cmi[cmi$model_id == "QoR15_SHAM_24H" & !is.na(num(cmi$yi)), ]; r <- cmr[cmr$model_id == "QoR15_SHAM_24H", ]
stopifnot(nrow(d) == 2, abs(fit(num(d$yi), num(d$vi))[["effect"]] - num(r$effect)) < 2e-6)
add("QoR15_SHAM_24H", "QoR-15 at about 24 h, TEAS vs sham, with Fu 2024", FALSE, c(num(d$yi), q1[["y"]]), c(num(d$vi), q1[["v"]]), num(r$N) + 59,
    c(d$study, "Fu 2024"), 2, old(r))
for (i in seq_len(nrow(d))) {
  keep <- setdiff(seq_len(nrow(d)), i)
  add(paste0("QoR15_SHAM_24H_LOO_", d$trial_id[i]), paste0("QoR-15 at about 24 h; omit ", d$study[i], ", with Fu 2024"), FALSE,
      c(num(d$yi)[keep], q1[["y"]]), c(num(d$vi)[keep], q1[["v"]]), sum(num(d$n_i[keep]) + num(d$n_c[keep])) + 59, c(d$study[keep], "Fu 2024"), 1,
      old(cmr[cmr$model_id == paste0("QoR15_SHAM_24H_LOO_", d$trial_id[i]), ]))
}
add("QoR15_SHAM_24H_LOO_Fu_2024", "QoR-15 at about 24 h; omit Fu 2024 (= earlier two-trial body)", FALSE, num(d$yi), num(d$vi), num(r$N), d$study, 2, old(r))
add("QoR15_SHAM_24H_NOT_HIGH_LINKED", "QoR-15 at about 24 h; results not at high risk, with Fu 2024", FALSE, c(num(d$yi), q1[["y"]]), c(num(d$vi), q1[["v"]]),
    num(r$N) + 59, c(d$study, "Fu 2024"), 2, old(cmr[cmr$model_id == "QoR15_SHAM_24H_NOT_HIGH_LINKED", ]))
add0("QoR15_SHAM_24H_LOW_ONLY", "Low-risk-only diagnostic: empty. No contributing result, including Fu 2024's, is at low risk of bias", 0)
q2 <- md2(30, 125.5, 4.9, 29, 119.1, 4.6)           # Fu Table 3: QoR-15 at T2 (POD3)
add("QoR15_SHAM_POD3", "QoR-15 on postoperative day 3, TEAS vs sham (Fu 2024)", FALSE, q2[["y"]], q2[["v"]], 59, "Fu 2024", 0, rep(NA, 3))

# 6. After Astra's audit of the D3 build (3 Nov 2026): the other registered windows (single trials, not pooled)
for (x in list(c("COLAK_PAIN_DAY2_EA_USUAL", "2 (about 48 h)", 3.333, 0.772, 3.967, 1.343),   # Colak Table 1, VAS 0-100 / 10
               c("COLAK_PAIN_DAY3_EA_USUAL", "3 (about 72 h)", 2.167, 0.556, 3.333, 1.496),
               c("COLAK_PAIN_DAY4_EA_USUAL", "4", 1.833, 0.556, 2.667, 1.345),
               c("COLAK_PAIN_DAY5_EA_USUAL", "5", 1.100, 0.387, 2.667, 1.759),
               c("COLAK_PAIN_DAY6_EA_USUAL", "6", 1.067, 0.417, 2.600, 1.765),
               c("COLAK_PAIN_DAY7_EA_USUAL", "7 (longest reported acute time point)", 0.933, 0.176, 2.333, 2.059))) {
  v <- as.numeric(x[3:6]); y <- md2(15, v[1], v[2], 15, v[3], v[4])
  add(x[1], paste0("Pain at rest on day ", x[2], ", EA vs usual care (Colak 2010)"), FALSE, y[["y"]], y[["v"]], 30, "Colak 2010", NA, rep(NA, 3))
}
x <- md2(15, 0.53, 0.51, 15, 2.0, 0.73)             # Colak Table 1: metamizole over 7 days (g)
add("RESCUE_METAMIZOLE_7D_EA_USUAL", "Metamizole on request over postoperative days 0-7 (g, native units), EA vs usual care (Colak 2010)",
    FALSE, x[["y"]], x[["v"]], 30, "Colak 2010", NA, rep(NA, 3))
q3 <- md2(30, 134.9, 6.1, 29, 125.8, 4.5)           # Fu Table 3: QoR-15 at T3 (POD7)
add("QoR15_SHAM_POD7", "QoR-15 on postoperative day 7, TEAS vs sham (Fu 2024)", FALSE, q3[["y"]], q3[["v"]], 59, "Fu 2024", NA, rep(NA, 3))

o <- do.call(rbind, out)
write.csv(W, file.path(here, "wang1997_analysis_inputs.csv"), row.names = FALSE)
write.csv(o, file.path(here, "models_with_wang.csv"), row.names = FALSE)
p <- o; for (c in c("effect", "ci_low", "ci_high", "october_effect", "october_ci_low", "october_ci_high", "pi_low", "pi_high")) p[[c]] <- round(p[[c]], 3)
p$I2 <- round(p$I2, 1)
print(p[, c("model_id", "k", "N", "effect", "ci_low", "ci_high", "I2", "pi_low", "pi_high", "october_k", "october_effect")], row.names = FALSE)
