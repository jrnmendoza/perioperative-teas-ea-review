# Reproduce the final estimates of the review from the archived inputs (Additional file 8; revision of 2 Nov 2026).
# Run from the unpacked Additional_file_8 folder:   Rscript reproduce_final.R
# Needs only base R and the files under data/. Writes reproduced_final_estimates.csv and stops with an error if any
# effect or confidence limit differs from the archived result by more than 2e-6 (the archived results came from
# Python; REML optimisers in different engines agree to about 1.4e-6).
# Estimator, as in the review: REML; Hartung-Knapp variance multiplier floored at 1; t(k-1) intervals; a single trial
# keeps its own normal interval; prediction intervals for k >= 5 as t(k-1) * sqrt(tau2 + SE^2).
# Lee 2011 is held from all pooled analyses (23 Oct 2026): broader first-day models are refitted without it and
# compared with data/results/lee_hold_rerun_2026-10-23.csv. Wang 1997 was included on 2 Nov 2026: refit_with_wang.R
# refits every analysis it enters, and the result is compared with data/results/models_with_wang.csv.
# What this shows: the archived estimates follow from the archived inputs by the stated methods. It does NOT show that
# the inputs were extracted correctly or that the set of included trials is complete.
args <- commandArgs(trailingOnly = FALSE)
f <- sub("^--file=", "", args[grep("^--file=", args)])
here <- if (length(f)) dirname(normalizePath(f)) else getwd()
rd <- function(p) { x <- read.csv(file.path(here, p), stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8")
                    names(x) <- sub("^﻿", "", names(x)); x }
num <- function(x) suppressWarnings(as.numeric(x))
fit <- function(y, v) {
  k <- length(y)
  if (k == 1) return(c(k = 1, effect = y, lo = y - qnorm(.975) * sqrt(v), hi = y + qnorm(.975) * sqrt(v), tau2 = NA, I2 = NA, pil = NA, pih = NA))
  nll <- function(t) { w <- 1 / (v + t); mu <- sum(w * y) / sum(w); .5 * (sum(log(v + t)) + log(sum(w)) + sum(w * (y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2) * 10, max(v) * 10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1 / (v + tau); mu <- sum(w * y) / sum(w); q <- sum(w * (y - mu)^2) / (k - 1)
  se <- sqrt(max(1, q) / sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1 / v; C <- sum(w0) - sum(w0^2) / sum(w0)
  pil <- pih <- NA
  if (k >= 5) { h <- qt(.975, k - 1) * sqrt(tau + se^2); pil <- mu - h; pih <- mu + h }
  c(k = k, effect = mu, lo = mu - cr * se, hi = mu + cr * se, tau2 = tau, I2 = 100 * tau / (tau + (k - 1) / C), pil = pil, pih = pih)
}
out <- list(); add <- function(set, id, scale, f, exp_eff, exp_lo, exp_hi) {
  tr <- if (scale == "ratio") exp else identity
  e <- tr(f[["effect"]]); l <- tr(f[["lo"]]); h <- tr(f[["hi"]])
  d <- max(abs(c(e - exp_eff, l - exp_lo, h - exp_hi)))
  out[[length(out) + 1]] <<- data.frame(set = set, model_id = id, k = f[["k"]], effect = e, ci_low = l, ci_high = h,
    tau2 = f[["tau2"]], I2 = f[["I2"]], pi_low = tr(f[["pil"]]), pi_high = tr(f[["pih"]]), archived_effect = exp_eff,
    max_abs_difference = d, stringsAsFactors = FALSE)
}

# 1. Registered outcome, rescue receipt and other opioid models (reviewer rerun), Lee-free models only
mi <- rd("data/inputs/reviewer_rerun_model_inputs.csv"); mr <- rd("data/results/model_results.csv")
for (m in unique(mi$model_id)) {
  d <- mi[mi$model_id == m & !is.na(num(mi$yi)), ]
  r <- mr[mr$model_id == m, ]
  if (!nrow(d) || nrow(r) != 1 || is.na(num(r$effect)) || any(d$study == "Lee 2011")) next
  scale <- if (r$effect_measure %in% c("RR", "OR")) "ratio" else "difference"
  add("reviewer_rerun", m, scale, fit(num(d$yi), num(d$vi)), num(r$effect), num(r$ci_low), num(r$ci_high))
}
# 2. Broader first-day models refitted without Lee 2011
e2 <- rd("data/inputs/e2_model_inputs.csv"); lee <- rd("data/results/lee_hold_rerun_2026-10-23.csv")
for (m in lee$model_id) {
  # the high-risk exclusion keeps the main model's trials not rated High (second-reviewed dose assessments); its
  # membership is the trial list archived with the refit
  src <- e2[e2$model_id == if (m == "E2_opioid24_TEAS_sham_NOT_HIGH_WITH_LINKAGE") "E2_opioid24_TEAS_sham" else m, ]
  r <- lee[lee$model_id == m, ]
  d <- src[src$study %in% strsplit(r$reports, ";")[[1]] & src$study != "Lee 2011", ]
  stopifnot(nrow(d) == as.integer(r$k))
  add("lee_hold_refit", m, "difference", fit(num(d$yi), num(d$vi)), num(r$effect), num(r$ci_low), num(r$ci_high))
}
# 3. Other outcomes (registered-outcome completion): every model with a fitted estimate
ci <- rd("data/inputs/registered_completion_model_inputs.csv"); cr <- rd("data/results/model_results_python.csv")
for (m in unique(ci$model_id)) {
  d <- ci[ci$model_id == m & !is.na(num(ci$yi)), ]; r <- cr[cr$model_id == m, ]
  if (!nrow(d) || nrow(r) != 1 || is.na(num(r$effect)) || nrow(d) != as.integer(r$k)) next
  scale <- if (r$measure %in% c("RR", "OR")) "ratio" else "difference"
  add("registered_completion", m, scale, fit(num(d$yi), num(d$vi)), num(r$effect), num(r$ci_low), num(r$ci_high))
}
res <- do.call(rbind, out)
write.csv(res, file.path(here, "reproduced_final_estimates.csv"), row.names = FALSE)
# 4. Analyses with Wang 1997 (decision D1, 2 Nov 2026): rerun refit_with_wang.R and compare with the archived refit
if (file.exists(file.path(here, "refit_with_wang.R")) && file.exists(file.path(here, "data", "results", "models_with_wang.csv"))) {
  wenv <- new.env(); invisible(capture.output(sys.source(file.path(here, "refit_with_wang.R"), envir = wenv)))
  wa <- rd("data/results/models_with_wang.csv"); wn <- wenv$o
  stopifnot(identical(wa$model_id, wn$model_id))
  stopifnot(identical(is.na(num(wa$effect)), is.na(wn$effect)))   # empty (k = 0) diagnostic cells must stay empty
  wd <- max(abs(c(num(wa$effect) - wn$effect, num(wa$ci_low) - wn$ci_low, num(wa$ci_high) - wn$ci_high)), na.rm = TRUE)
  cat(sprintf("Refitted %d analyses with Wang 1997 and the D3 reports (Colak 2010, Fu 2024); maximum absolute difference from the archived refit %.2e\n", nrow(wn), wd))
  w1 <- wn[wn$model_id == "E2_opioid24_TEAS_sham", ]
  cat(sprintf("Broader first-day TEAS vs sham with Wang 1997: k = %d, MD %.2f (%.2f to %.2f)\n", w1$k, w1$effect, w1$ci_low, w1$ci_high))
  if (wd > 1e-9) stop("Wang 1997 refit differs from the archived refit")
}
# 5. D6 post-hoc what-ifs (3 Nov 2026; Astra, 4 Nov 2026): rerun d6/d6_scenarios.R from d6/d6_inputs.csv and compare
if (file.exists(file.path(here, "d6", "d6_scenarios.R")) && file.exists(file.path(here, "d6", "d6_inputs.csv"))) {
  out6 <- file.path(tempdir(), "d6_scenarios_rerun.csv")
  st6 <- system2(file.path(R.home("bin"), "Rscript"), c(shQuote(file.path(here, "d6", "d6_scenarios.R")), shQuote(out6)), stdout = FALSE)
  if (st6 != 0) stop("D6 what-ifs failed to run")
  a6 <- rd("d6/d6_scenarios.csv"); n6 <- read.csv(out6, stringsAsFactors = FALSE)
  stopifnot(identical(a6$scenario, n6$scenario))
  d6d <- max(abs(c(num(a6$effect) - n6$effect, num(a6$ci_low) - n6$ci_low, num(a6$ci_high) - n6$ci_high)))
  cat(sprintf("Refitted %d D6 what-ifs (rest pain and PONV with the trials removed by the opioid-result requirement); maximum absolute difference %.2e\n", nrow(n6), d6d))
  if (d6d > 1e-9) stop("D6 what-ifs differ from the archived values")
}
worst <- max(res$max_abs_difference)
cat(sprintf("Refitted %d models (%s); maximum absolute difference from archived results %.2e\n", nrow(res),
            paste(names(table(res$set)), table(res$set), sep = " ", collapse = ", "), worst))
main <- res[res$model_id == "E2_opioid24_TEAS_sham", ]
cat(sprintf("Broader first-day TEAS vs sham without Lee 2011 (archived, before Wang 1997): k = %d, MD %.2f (%.2f to %.2f), tau2 = %.2f, I2 = %.1f%%\n",
            main$k, main$effect, main$ci_low, main$ci_high, main$tau2, main$I2))
if (worst > 2e-6) stop("reproduction failed: see reproduced_final_estimates.csv")
cat("Reproduction passed.\n")
