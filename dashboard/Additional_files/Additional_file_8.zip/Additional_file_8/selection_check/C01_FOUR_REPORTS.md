# C01: the four flagged exclusions and the 113 historical outcome exclusions

Prepared 2 November 2026 for the revision after the Astra audit. This is an AI-assisted reading of the source reports
and of the project's earlier checks. **It is not an independent human screen, and it changes no decision.** Every
"candidate" below needs a decision by the review team. Until the team decides, the review's counts, figures, certainty
ratings and conclusions are provisional with respect to these reports.

## The two dated outcome filters

| | Filter A, 14 August 2026 (before registration) | Filter B, 9 October 2026 (after registration, results known) |
|---|---|---|
| Applied to | every full text (Covidence, 20 August and 1 September 2026) | the 70 reports that passed filter A and the other criteria |
| Requirement | extractable comparative 0–24 h systemic opioid convertible to IV morphine equivalents, **or** pain at about 24 h on an interpretable scale | a named postoperative opioid, or an author-defined morphine-equivalent quantity, confirmed in the source (any window; receipt and rescue results counted for the 40 included reports) |
| Removed | 113 reports ("no eligible analgesic outcome") | 30 reports ("no confirmed postoperative opioid result") |

A report can fail one filter and pass the other. Filter B was applied only to reports that had already passed filter A,
so a report wrongly excluded under filter A was never assessed under filter B.

## The four reports flagged by the 8 October source triage

Report identity is given by Covidence ID, title and DOI. Two of these share a surname and year with included reports;
they are different trials.

### 1. Colak 2010 — Covidence 1879897298; AF4 Reports row 82

- **Report.** Colak MC, Kavaklı A, Kılınç A, Rahman A. Postoperative pain and respiratory function in patients treated
  with electroacupuncture following coronary surgery. Neurosciences (Riyadh). 2010;15(1):7–10. No DOI in the record.
- **Historical reason.** Covidence "Wrong outcomes", 1 September 2026 (after registration).
- **Design.** 30 adults after CABG via median sternotomy, randomised by random-number tables, although the authors call
  it a "case-control study" (Methods, p8).
- **Intervention and comparator.** Needle EA (LI4, LI11, ST36, PC6, LR3; 60 Hz, 20 min) plus analgesia, versus
  analgesia alone (usual care). The first session was about 2 h after extubation, then daily for 7 days.
- **Anaesthesia.** General anaesthesia is implied by intubation and extubation (Table 1) but is not described in Methods.
- **Outcomes (Table 1, p9; values are control vs EA):**
  - pethidine over 7 days: 223.33 ± 132.10 vs 76.67 ± 84.23 mg;
  - metamizole: 2.0 ± 0.73 vs 0.53 ± 0.51 g;
  - resting VAS (0–100) on day 1: 52.33 ± 15.22 vs 50.33 ± 7.19.
- **Filter A: met.** Day-1 resting pain is reported. The historical reason does not hold.
- **Filter B: met.** Pethidine is a named postoperative opioid, although its window is 7 days.
- **Other criteria.** Adults: yes. Stimulation before 24 h: yes. Randomised: by table, against the authors' own design
  label. General anaesthesia: not stated in Methods; under the review's rule this would mean "retained but not pooled",
  as for Jin 2023.
- **Synthesis if included:**
  - EA versus usual care, resting pain at about 24 h: a single trial, MD −0.20 (−1.05 to 0.65) on 0–10 (C01_scenarios.csv,
    row P2).
  - The 7-day pethidine total cannot enter any 0–24 h opioid analysis.
  - The primary analyses would not change.
- **Status.** Membership candidate: report 41, trial 40.

### 2. Tzeng 2015 — Covidence 1879897043; AF4 Reports row 149

- **Report.** Tzeng C-Y, Chang S-L, Wu C-C, et al. Single-blinded, randomised preliminary study evaluating the effects
  of 2 Hz electroacupuncture for postoperative pain in patients with total knee arthroplasty. Acupunct Med.
  2015;33:284–8. doi:10.1136/acupmed-2014-010722. (The 8 October triage note calls it "Zeng 2015".)
- **Historical reason.** "Wrong outcomes", 1 September 2026.
- **Anaesthesia.** **Spinal (subarachnoid) anaesthesia, 0.5% bupivacaine; no general anaesthesia** (Interventions, p2).
- **Intervention and comparator.** Needle EA (ST36, GB34, 2 Hz) versus non-point EA versus PCA alone.
- **Outcomes.**
  - Epidural PCA solution (fentanyl 1.5 µg/mL with bupivacaine): 4.6 ± 0.9, 4.2 ± 1.0 and 4.5 ± 1.0 mL/kg over 48 h
    (Table 2, p4).
  - Time to first PCA demand.
  - VAS only before PCA set-up.
- **Filter A: not met.** There is no 0–24 h systemic opioid and no 24 h pain.
- **Filter B: nominally met** (fentanyl), but the route is epidural.
- **Other criteria: fails the registered population criterion** (neuraxial anaesthesia without general anaesthesia),
  which settles eligibility on its own.
- **Status.** The exclusion stands. Its reason should be "Wrong setting" (no general anaesthesia), not "Wrong outcomes".
  This moves one report between two Fig. 1 categories without changing the total excluded.

### 3. Wang 1997 — Covidence 1879897512; AF4 Reports row 150

- **Report.** Wang B, Tang J, White PF, et al. Effect of the intensity of transcutaneous acupoint electrical stimulation
  on the postoperative analgesic requirement. Anesth Analg. 1997;85:406–13. doi:10.1097/00000539-199708000-00029;
  PMID 9249122.
- **Historical reason.** "Wrong outcomes", 20 August 2026.
- **Design and population.**
  - 101 ASA I–II women having elective lower abdominal gynaecological surgery at Cedars-Sinai, Los Angeles, from
    August 1995 to February 1996.
  - Randomised by a computer-generated sequence.
  - General anaesthesia: fentanyl and thiopental induction, desflurane and N2O, intubation (Methods p407).
  - Mean age 43–45 years by arm; no minimum age stated (Table 2).
- **Intervention** (Methods pp407–408, Fig. 1).
  - Surface electrodes at **LI4** (dorsum of the hand, with a thenar return electrode) and two electrodes on either side
    of the **incision**. Hand and incision were stimulated alternately every 6 s.
  - HANS LY257 device, 2/100 Hz alternating every 3 s; low intensity 4–5 mA, high intensity 9–12 mA.
  - From arrival in the PACU, 30 min every 2 h while awake.
- **Comparators.** Sham (identical pads, no current, indicator light on) and PCA alone.
- **Outcomes (Table 3 p409, Table 6 p412).** Arms are PCA only, sham, low intensity and high intensity:

  | Outcome | PCA only | Sham | Low | High |
  |---|---|---|---|---|
  | Hydromorphone delivered over 24 h, mg | 13.4 ± 5.8 | 10.7 ± 7.3 | 9.3 ± 6.2 | 6.1 ± 3.3 |
  | Patients given an IM supplemental opioid in the first 24 h, n | 7/26 | 5/25 | 3/25 | 4/25 |
  | VAS pain at 24 h (0–100) | 44 ± 32 | 48 ± 22 | 45 ± 26 | 44 ± 23 |

- **Filter A: met.** Both a 24 h opioid total and 24 h pain are reported. The historical reason does not hold.
- **Filter B: met.** Hydromorphone is a named postoperative opioid.
- **The deciding question is the intervention.** The stimulation combines a recognised acupoint (LI4) with surface
  stimulation beside the incision, and the trial cannot separate the two.
  - The registered record excludes TENS "delivered only at non-acupuncture locations" and "mixed interventions in which
    the independent effect of TEAS or EA cannot be separated".
  - The included primary trial, Szmit 2021, used an almost identical arrangement: bilateral LI4 plus two
    "peri-incisional ashi points within 5 cm of the incision", the same 2/100 Hz alternation, and 30 min every 2 h from
    the PACU.
  - The two differ only in that Szmit names the peri-incisional sites as ashi points. The review states that modality is
    assigned by physical method, not by label.
  - Treating the two differently needs a stated reason.

**Side-by-side comparison**

| | Wang 1997 | Szmit 2021 (included, primary) | Chen 1998 (included, broader analysis only) |
|---|---|---|---|
| Site, period | Cedars-Sinai, USA; Aug 1995–Feb 1996 | Poland | Cedars-Sinai IRB (UT Southwestern and Cedars-Sinai authors); dates not reported |
| Population | 101 women, lower abdominal gynaecological surgery, GA | 71 adults, inguinal hernia repair, GA | 100 women, hysterectomy or myomectomy, GA |
| Stimulation sites | LI4 + incision (surface) | bilateral LI4 + 2 peri-incisional "ashi" points (surface) | arms: ST36; peri-incisional dermatomal; shoulder; sham ST36 |
| Parameters | 2/100 Hz, every 3 s; 4–5 or 9–12 mA | 2/100 Hz, every 3 s; to muscle twitch | 2/100 Hz; 9–12 mA |
| Schedule | from PACU, 30 min every 2 h awake | from PACU, 30 min every 2 h to 24 h | PACU, then self-applied every 2–3 h |
| Inert comparator | pads, no current | devices, no current | ST36 pads, 0 mA |
| Opioid measure | hydromorphone delivered, 0–24 h (PCA; PACU row) | IV morphine PCA total, 0–24 h | hydromorphone PCA total, 0–24 h |
| Other opioid in 0–24 h | IV hydromorphone by PACU nurses before PCA; IM hydromorphone or meperidine supplements in 7/5/3/4 patients, not quantified in Table 3; oral oxycodone after PCA stopped | none described (metamizole 1 g before PCA if needed) | IM hydromorphone supplements, not quantified |
| Review's handling | excluded ("wrong outcomes") | primary analysis | broader first-day analysis only (unquantified rescue) |

- **Rescue coverage.** The text (p409) says supplemental meperidine was converted to hydromorphone equivalents "to
  analyze the opioid requirement". The percentage reductions it gives (20%, 31%, 54%) equal the ratios of the Table 3
  hydromorphone totals, but Table 3 labels the rows "hydromorphone delivered". It cannot be established that the totals
  include the IM supplements. Applying the rule used for Chen 1998, which has the same design and the same unquantified
  IM rescue, Wang would enter the broader first-day analysis but not the primary analysis.
- **Cohort overlap.** Wang and Chen 1998 come from the same group, the same institution and the same PCA protocol.
  Chen 1998 cites Wang 1997 as its "preliminary study" (ref. 9) and used it for its power calculation. The samples were
  randomised separately: 101 and 100 participants, with different arm structures, sham SDs (7.3 vs 5.0 mg) and ages.
  Overlap is unlikely, but Chen 1998 does not give its recruitment dates.
- **Adult eligibility.** Probable. ASA I–II gynaecological patients with arm means of 43–45 years (SD 8–10); no minimum
  age is stated.
- **Status.** Membership candidate. The intervention-definition decision comes first.

### 4. Zhang 2025, internal spinal fixation — Covidence 1879896047; AF4 Reports row 178

- **Report.** Zhang et al. Effects of transcutaneous electrical acupoint stimulation on recovery after internal spinal
  fixation: a randomised controlled trial. BMC Anesthesiol. 2025;25:530. doi:10.1186/s12871-025-03400-8.
- **Not the included Zhang 2025.** The included report is the colorectal trial, Covidence 1879896013.
- **Historical reason.** "Wrong outcomes", 1 September 2026.
- **Design.** 74 adults having lumbar, thoracic or cervical internal fixation.
- **Intervention and comparator.** TEAS at PC6, LI4 and ST36 (2/100 Hz, 8–12 mA) from 30 min before induction to the end
  of surgery, versus sham pads.
- **Outcomes (Tables 3–5, p4).**
  - Opioid in morphine equivalents over 72 h (sufentanil 1 µg = 1 mg morphine; oliceridine 1.5 mg = 7.5 mg; p3):
    101.16 ± 9.00 vs 125.38 ± 14.13 mg.
  - QoR-15 at 24 h and 72 h.
  - Time to first PCA use; PONV 2/37 vs 6/37.
  - No 24 h pain score: resting VAS was kept at 3 or below by protocol.
- **Filter A: not met.** There is no 0–24 h opioid and no 24 h pain. The historical reason is **correct** under the
  14 August rule.
- **Filter B: met.**
- **Other criteria: met** under the registered criteria. It would contribute QoR-15, PONV and a 72 h opioid result.
- **Status.** The exclusion stands under filter A. The report shows that filter A removed trials with registered
  secondary outcomes (finding M01).

## What the four reports change

Neither of the reports whose exclusion stands (Tzeng, spinal-fixation Zhang) changes membership; Tzeng's reason
category does change. Colak and Wang could change membership.
What-if estimates using the review's own estimator are in `C01_scenarios.csv`. They are assumptions, not results.

| Scenario | k | N | Estimate (95% CI) |
|---|---|---|---|
| As submitted: broader first-day, TEAS vs sham | 6 | 547 | −6.67 (−14.53 to 1.18) mg |
| + Wang 1997 in the broader analysis (as for Chen 1998) | 7 | 622 | −7.22 (−14.13 to −0.32) mg |
| Wang judged complete, so it enters the primary 0–24 h analysis with Szmit | 2 | 123 | −7.94 (−26.58 to 10.71) mg |
| + Wang vs PCA only in broader TEAS vs usual care | 2 | 123 | −17.19 (−146.73 to 112.35) mg |
| Rescue receipt as submitted, TEAS vs sham | 5 | 478 | RR 0.51 (0.35 to 0.75) |
| + Wang IM supplements in the first 24 h | 6 | 553 | RR 0.52 (0.37 to 0.74) |
| Wang 24 h pain, TEAS vs sham (0–10; paired with its dose result) | 1 | 75 | −0.35 (−1.44 to 0.74) |
| Colak day-1 resting pain, EA vs usual care (0–10) | 1 | 30 | −0.20 (−1.05 to 0.65) |

- **Broader analysis.** Adding Wang would move the broader first-day interval from including zero to just excluding it.
- **Primary analysis.** Admitting Wang to the primary analysis would replace a single-trial result with a two-trial
  estimate whose interval spans benefit and harm.
- **Clinical-importance criterion.** Wang supplies paired 24 h pain, so for the first time the criterion could be
  evaluated within one trial.
- **Rescue receipt.** Adding Wang would add a US trial, so "all five rescue trials were conducted in China" would no
  longer hold.

## The 113 historical outcome exclusions

`C01_historical_outcome_exclusions_triage.csv` has one row per report, built by `build_c01_triage.py` from these sources:
- the 8 October 2026 source triage;
- the 24 September 2026 recheck and the 20 targeted re-screens;
- the reports read for this revision.

| Category | n | Meaning | Effect on the 40-report set |
|---|---:|---|---|
| MEMBERSHIP | 9 | Passes, or may pass, both filters: Colak 2010, Wang 1997, Fu 2024, Tu 2018, Zhou 2025 (Covidence 1879896127, not the included Zhou 2025), Zhang 2022, Chen 2016, Li 2017, Poulain 1997 | Could add reports. Tu 2018 probably fails the comparator criterion (unbalanced scheduled tramadol). |
| REASON | 8 | 24 h pain reported, so filter A was met, but no confirmed postoperative opioid result: Hou 2023, Li 2025, Liu 2024, Liu 2008, Qin 2023, Tong 2022, Yue 2023, Zheng 2008 | None. They remain excluded, under filter B instead of "no eligible analgesic outcome". |
| STANDS | 7 | A documented source check supports exclusion, or another criterion fails first: Tzeng 2015, Zhang 2025 (spinal fixation), Gao 2018, Bai 2018, Ertas 2015, Sun 2025, McMillan 1994 | None. Tzeng's reason changes to the anaesthesia criterion. |
| UNREAD_SIGNAL | 8 | A keyword signal was never followed by a full read | Unknown |
| NO_SIGNAL | 36 | The local full text has no keyword or recheck signal | None proposed. Keyword checks are not proof of absence. |
| UNAVAILABLE | 45 | No ID-matched full text in the project, so the Covidence decision cannot be re-checked locally | Unknown |

**What this means for the manuscript.**
- The claim that the single primary trial exhausts eligible evidence cannot be made until the MEMBERSHIP rows are
  decided.
- The 45 UNAVAILABLE and 8 UNREAD_SIGNAL reports limit any completeness claim.
- The revised draft therefore labels the affected counts and conclusions provisional, states the open selection
  question, and confines completeness statements to the reports checked.
