"""Triage of the 113 full-text exclusions recorded as 'no eligible analgesic outcome' (audit finding C01).

Reads existing records only and writes C01_historical_outcome_exclusions_triage.csv beside this script:
  - opioid_only_review/prisma/prisma_record_ledger.csv (historical reason, Covidence date)
  - opioid_only_review/source_audit/historical_outcome_exclusion_triage.csv (8 Oct 2026 source triage)
  - search_augmentation_2026-09-24/wrong_outcome_recheck.csv and wrong_outcome_targeted_rescreen.csv (24 Sep 2026)
plus the assessments in ASSESSED below, each taken from those records or from the report pages read for this revision
(cited per row). This is an AI-assisted triage, not an independent human screen: every 'candidate' row needs a human
decision, and no row changes the review's dataset.

Filter A = outcome rule of 14 Aug 2026: extractable comparative 0-24 h systemic opioid (convertible) or ~24 h pain.
Filter B = criterion of 9 Oct 2026: a named postoperative opioid or author-defined morphine-equivalent result,
confirmed in the source (any window; receipt and rescue results count, as for the 40 included reports).
"""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def recs(p):
    return list(csv.DictReader(open(ROOT / p, encoding='utf-8-sig', newline='')))


ledger = {r['covidence_id']: r for r in recs('opioid_only_review/prisma/prisma_record_ledger.csv')}
oct8 = {r['covidence_id']: r for r in recs('opioid_only_review/source_audit/historical_outcome_exclusion_triage.csv')}
sep = {r['covidence_id']: r for r in recs('search_augmentation_2026-09-24/wrong_outcome_recheck.csv')}
tgt = {}
for r in recs('search_augmentation_2026-09-24/wrong_outcome_targeted_rescreen.csv'):
    cid = r['STUDY'].split('Covidence ')[1].split(';')[0]
    tgt[cid] = r
assert len(oct8) == 113 and all(ledger[c]['focused_reason'] == 'no perioperative analgesia outcome found' for c in oct8)

# Assessments for the 24 reports examined individually. Columns: filter A, filter B, other criteria, category, action,
# source basis. Categories:
#   MEMBERSHIP  passes or may pass both dated filters: could change the 40-report set
#   REASON      meets the 14 Aug rule but has no confirmed postoperative opioid result: stays excluded, under the 9 Oct
#               criterion instead of 'no eligible analgesic outcome' (reason and Fig. 1 label change only)
#   STANDS      the 14 Aug exclusion is supported by the documented source check (or another criterion fails first)
MEM, REA, STA = 'MEMBERSHIP', 'REASON', 'STANDS'
ASSESSED = {
    '1879897298': ('Met: POD1 resting VAS 0-100, 52.33 +/- 15.22 vs 50.33 +/- 7.19 (Table 1, p9)',
                   'Met: pethidine total over 7 postoperative days, 223.33 +/- 132.10 vs 76.67 +/- 84.23 mg (Table 1, p9)',
                   'Needle EA (LI4, LI11, ST36, PC6, LR3; 60 Hz) vs analgesia alone (usual care); first session about 2 h after '
                   'extubation; adults (mean 51-52 y); randomised by random-number tables although called "case-control"; '
                   'general anaesthesia implied by intubation but not described in Methods', MEM,
                   'Decide design (randomised?) and whether general anaesthesia is established; if eligible, report 41 and '
                   'EA-vs-usual-care pain at ~24 h; the 7-day pethidine total cannot enter any 0-24 h opioid analysis',
                   'Source read for this revision (PDF pp2-3); 24 Sep targeted re-screen'),
    '1879897043': ('Not met: epidural PCA solution in mL/kg over 48 h; VAS recorded only before PCA set-up (Table 2, p4)',
                   'Nominally met: fentanyl-containing epidural PCA, but neuraxial route',
                   'Spinal (subarachnoid) anaesthesia for TKA, no general anaesthesia (Interventions, p2): fails the '
                   'registered population criterion', STA,
                   'Keep excluded; record the reason as neuraxial anaesthesia without general anaesthesia ("Wrong setting")',
                   'Source read for this revision (PDF pp1-4)'),
    '1879897512': ('Met: 24-h hydromorphone delivered (Table 3, p409) and 24-h VAS pain (Table 6, p412)',
                   'Met: named opioid (hydromorphone) quantity',
                   'Surface electrodes at LI4 plus two pairs beside the incision, stimulation alternated every 6 s (Methods '
                   'pp407-408, Fig. 1); sham = same pads, no current; PCA-only arm; general anaesthesia (desflurane, N2O, '
                   'intubation); ASA I-II women, mean age 43-45 y, no minimum stated', MEM,
                   'Decide whether LI4 plus incisional surface stimulation meets the TEAS definition (consistency with Szmit '
                   '2021); then rescue coverage and synthesis assignment (see C01_FOUR_REPORTS.md)',
                   'Source read for this revision (Tables 2, 3, 6 rendered); 24 Sep Wang adjudication'),
    '1879896047': ('Not met: opioid total over 72 h only; QoR-15 at 24 h; no 24-h pain result (Tables 3-4, p4)',
                   'Met: author-defined morphine equivalents over 72 h, 101.16 +/- 9.00 vs 125.38 +/- 14.13 mg (Table 4)',
                   'TEAS (PC6, LI4, ST36; 2/100 Hz) vs sham pads; spinal-fixation surgery; distinct from the included '
                   'colorectal Zhang 2025', STA,
                   'Keep excluded under the 14 Aug rule; eligible under the registered criteria (QoR-15, 72-h opioid, PONV), '
                   'so it illustrates finding M01',
                   'Source read for this revision (pp3-4)'),
    '1879896874': ('Not met on available evidence: no numeric 24-h dose; pain measured but no arm-level values',
                   'Met: postoperative opioid-use incidence 2/37 vs 9/38 (Table 4, p343)', '', STA,
                   'Keep excluded unless arm-level 24-h pain is obtained', '24 Sep targeted re-screen (SOURCE STILL INCOMPLETE)'),
    '1879896981': ('Met: VAS at 24 h, figure only (Fig. 2a, PDF p4)',
                   'Unresolved: fentanyl-containing pump prescribed; compared rescue drug (Sauteralgyl) not identified as an opioid',
                   'Age 16-80 y: adult proportion not established', MEM,
                   'Identify the rescue drug; if not an opioid, reason changes to the 9 Oct criterion',
                   '24 Sep targeted re-screen; 8 Oct triage note'),
    '1879897063': ('Not met on available evidence: no arm-level 24-h pain; no numeric dose',
                   'Unresolved: rescue meperidine administrations not numerically reported',
                   'PC6 ReliefBand acustimulation: modality to confirm', STA,
                   'Keep excluded unless numeric outcomes are obtained', '24 Sep targeted re-screen (SOURCE STILL INCOMPLETE)'),
    '1879896270': ('Met: POD1 VAS, median (IQR) 5 (4, 6) vs 6 (5, 7) (Tables 1 and 3, PDF p6)',
                   'Met: rescue tramadol receipt (incidence), not dose',
                   'Awake electrode-placement stage then general anaesthesia (deep brain stimulation): timing relative to GA '
                   'to confirm; TEAS vs sham', MEM,
                   'Decide whether rescue-opioid receipt alone satisfied the 9 Oct criterion for this report (it did for the '
                   'included reports) and confirm GA timing',
                   '24 Sep targeted re-screen'),
    '1879896778': ('Not met: 24-h pain assessed but no numeric result; intraoperative remifentanil only',
                   'Not met', '', STA, 'No change', '24 Sep targeted re-screen (NO CHANGE)'),
    '1879896346': ('Met: POD1 NRS at rest and movement (Fig. 3, PDF p7; highlights 1.4 +/- 1.2 vs 1.7 +/- 1.1)',
                   'Not met: PCIA regimen described, no opioid result', 'Distinct from the included Hou reports', REA,
                   'Reason becomes the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879896126': ('Met if an ordinal 0-4 scale counts as interpretable: Prince Henry pain at 24 h (Table 3, PDF p7)',
                   'Not met', 'EA vs usual care', REA, 'Reason becomes the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879896900': ('Unclear: NRS over the 12-24 h interval (Table 2)',
                   'Unclear: zero rescue recipients over 0-48 h; rescue drug to identify', 'EA vs usual care', MEM,
                   'Identify the rescue drug and decide the interval-pain window', '24 Sep targeted re-screen'),
    '1879896245': ('Met: NRS at 24 h, median (IQR) 4 (3, 5) vs 5 (3, 6) (Table 2, PDF p5)',
                   'Not met: rescue parecoxib (non-opioid); sufentanil PCA prescribed only', '', REA,
                   'Reason becomes the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879897366': ('Unclear: binary severe pain at 24 h (Table 3, p96)', 'Not met', 'Surface electrodes confirmed in Methods', REA,
                   'Decide whether binary pain meets the 14 Aug rule; excluded under the 9 Oct criterion either way',
                   '24 Sep targeted re-screen'),
    '1879896407': ('Unclear: NRS over the 6-24 h interval (Table 3, PDF p6)', 'Not met', '', REA,
                   'Excluded under the 9 Oct criterion either way', '24 Sep targeted re-screen'),
    '1879896040': ('Not met: Fig. 3 is preoperative pain', 'Not met', 'Supplement (Data Sheet 1) inaccessible', STA,
                   'No change unless the supplement is obtained', '24 Sep targeted re-screen (SOURCE STILL INCOMPLETE)'),
    '1879896482': ('Met: pain at 24 h, median (IQR) (Table 5, PDF p8)', 'Not met', 'Three EA timings share one usual-care control', REA,
                   'Reason becomes the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879896817': ('Met: VAS at 24 h 2.21 +/- 0.88 vs 3.38 +/- 0.74 (Table 2, PDF p5)',
                   'Met: rescue tramadol over the first 24 h, 86.84 +/- 16.44 vs 232.68 +/- 43.52 mg',
                   'TEAS + scheduled placebo vs sham TEAS + scheduled tramadol 100 mg twice daily: unbalanced co-intervention '
                   '(registered comparator exclusion)', MEM,
                   'Likely excluded for an unbalanced co-intervention ("Wrong comparator"); confirm', '24 Sep targeted re-screen'),
    '1879896360': ('Met (approximately): POD1 NRS, possibly about 30 h after surgery (Table 2, PDF p5)', 'Not met', '', REA,
                   'Reason becomes the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879897384': ('Unclear: VAS over the 12-24 h interval (Table 3, p63)', 'Not met: PCA button presses only', '', REA,
                   'Excluded under the 9 Oct criterion either way (presses, as for four excluded reports)', '24 Sep targeted re-screen'),
    '1879896127': ('Met: rest and movement VAS at 24 h (Table 6, PDF p7)',
                   'Unresolved: morphine equivalents reported for the perioperative period, not postoperatively (Table 1)',
                   'TEAS vs control arms both receive sham injections: plausible sham contrast; distinct from the included '
                   'Zhou 2025 (Covidence 1879896105)', MEM,
                   'Decide whether a perioperative opioid total satisfies the 9 Oct criterion', '24 Sep targeted re-screen'),
    '1879896437': ('Unclear: postoperative IV morphine equivalents without an established 24-h window; NRS timing not '
                   'established (registry: 6-8 h)', 'Met: postoperative IV morphine equivalents (Table 1, p1756)',
                   '598 randomised, 547 analysed', MEM, 'Establish the windows; if ~24 h, assess as a membership candidate',
                   '24 Sep targeted re-screen (SOURCE STILL INCOMPLETE)'),
    '1881841314': ('Unclear: pain endpoints are times to events; 24-h pain not identified',
                   'Unresolved: patients requiring postoperative analgesics; drug not identified (Table 7)',
                   'Needle EA; GA', MEM, 'Human read of Table 7 and the analgesic protocol', '8 Oct triage note'),
    '1881841335': ('Not met on available evidence: PONV primary; analgesic requirements narrative only',
                   'Unresolved: PCA morphine, epidural or intrathecal diamorphine by anaesthetist choice',
                   'General or spinal anaesthesia by anaesthetist choice: GA not universal', STA,
                   'Keep excluded (population and outcome)', '8 Oct triage note; source checked for anaesthesia'),
}
assert set(ASSESSED) <= set(oct8) and len(ASSESSED) == 24

rows = []
for cid, o in oct8.items():
    L, s = ledger[cid], sep.get(cid, {})
    base = dict(covidence_id=cid, covidence_label=L['covidence_study_id'], title=L['title'], doi=L['doi'],
                covidence_date=L['excluded_on'], historical_reason='Wrong outcomes (Fig. 1: No eligible analgesic outcome)',
                local_full_text='yes' if o['local_source'] else 'no', oct8_status=o['audit_status'],
                sep24_pain_24h=s.get('pain_24h', ''), sep24_opioid_24h=s.get('opioid_24h', ''),
                sep24_targeted=tgt[cid]['RECOMMENDED HUMAN ACTION'] if cid in tgt else '')
    if cid in ASSESSED:
        a, b, other, cat, action, basis = ASSESSED[cid]
    elif o['audit_status'] == 'LOCAL_SOURCE_NOT_FOUND':
        a, b, other, cat = 'Not assessable', 'Not assessable', '', 'UNAVAILABLE'
        action = 'Locate the full text; the Covidence decision cannot be re-checked from local files'
        basis = '8 Oct triage (no ID-matched PDF); 24 Sep metadata check found no extractable result'
    elif o['audit_status'] == 'TEXT_TRIAGE_SIGNAL_REQUIRES_MANUAL_REVIEW':
        a, b, other, cat = 'Not established (keyword signal only)', 'Not established', '', 'UNREAD_SIGNAL'
        action = 'Human read of the outcome tables (keyword signal not followed up by a full read)'
        basis = '8 Oct keyword triage; 24 Sep recheck: ' + s.get('finding', '')[:160]
    else:
        a, b, other, cat = 'No signal', 'No signal', '', 'NO_SIGNAL'
        action = 'None proposed; the Covidence decision stands (keyword checks are not proof of absence)'
        basis = '8 Oct keyword triage; 24 Sep recheck found no new positive signal'
    rows.append(dict(base, filter_A_14Aug=a, filter_B_9Oct=b, other_criteria=other, category=cat,
                     proposed_human_action=action, evidence_basis=basis))
order = {MEM: 0, REA: 1, STA: 2, 'UNREAD_SIGNAL': 3, 'UNAVAILABLE': 4, 'NO_SIGNAL': 5}
rows.sort(key=lambda r: (order[r['category']], r['covidence_label']))
with open(HERE / 'C01_historical_outcome_exclusions_triage.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, list(rows[0]))
    w.writeheader(); w.writerows(rows)
import collections
print(collections.Counter(r['category'] for r in rows))
