# What-if estimates for the C01 author decisions. NOT results of the review: each row assumes a decision the authors
# have not made. Same estimator as the review (REML, Hartung-Knapp variance floored at 1, t(k-1); single trials with a
# normal interval). Reads the review's final inputs read-only and writes C01_scenarios.csv beside this script.
# Wang 1997 values: Anesth Analg 1997;85:406-13, Table 3 (p409) and Table 6 (p412). Hydromorphone x 5 = mg IV morphine
# (the factor applied to Chen 1998). Low- and high-intensity arms combined against the shared sham, as for multi-arm
# trials in the review. Colak 2010 values: Neurosciences 2010;15:7-10, Table 1 (p9).
args <- commandArgs(trailingOnly = FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grep("^--file=", args)])))
root <- normalizePath(file.path(here, "..", "..", "..", ".."))
rr <- file.path(root, "opioid_only_review", "forty_report_analysis")
rd <- function(p) { x <- read.csv(p, stringsAsFactors = FALSE, check.names = FALSE, encoding = "UTF-8"); names(x) <- sub("^﻿", "", names(x)); x }
fit <- function(y, v, N) {
  k <- length(y)
  if (k == 1) return(c(k = 1, N = N, effect = y, lo = y - qnorm(.975) * sqrt(v), hi = y + qnorm(.975) * sqrt(v), I2 = NA))
  nll <- function(t) { w <- 1 / (v + t); mu <- sum(w * y) / sum(w); .5 * (sum(log(v + t)) + log(sum(w)) + sum(w * (y - mu)^2)) }
  o <- optimize(nll, c(0, max(1, mean((y - mean(y))^2) * 10, max(v) * 10)), tol = 1e-12)
  tau <- if (o$objective < nll(0)) o$minimum else 0
  w <- 1 / (v + tau); mu <- sum(w * y) / sum(w); q <- sum(w * (y - mu)^2) / (k - 1)
  se <- sqrt(max(1, q) / sum(w)); cr <- qt(.975, k - 1)
  w0 <- 1 / v; C <- sum(w0) - sum(w0^2) / sum(w0)
  c(k = k, N = N, effect = mu, lo = mu - cr * se, hi = mu + cr * se, I2 = 100 * tau / (tau + (k - 1) / C))
}
comb <- function(n1, m1, s1, n2, m2, s2) {  # Cochrane Handbook formula for combining two arms
  n <- n1 + n2; m <- (n1 * m1 + n2 * m2) / n
  s <- sqrt(((n1 - 1) * s1^2 + (n2 - 1) * s2^2 + n1 * n2 / n * (m1 - m2)^2) / (n - 1)); c(n, m, s)
}
md <- function(ni, mi, si, nc, mc, sc) c(y = mi - mc, v = si^2 / ni + sc^2 / nc)
lrr <- function(ei, ni, ec, nc) c(y = log((ei / ni) / (ec / nc)), v = 1 / ei - 1 / ni + 1 / ec - 1 / nc)

wa <- comb(25, 9.3, 6.2, 25, 6.1, 3.3)                     # combined active arms, mg hydromorphone
wang_sham <- md(wa[1], 5 * wa[2], 5 * wa[3], 25, 5 * 10.7, 5 * 7.3)
wang_pca <- md(wa[1], 5 * wa[2], 5 * wa[3], 26, 5 * 13.4, 5 * 5.8)
out <- list()
add <- function(id, desc, f, reports) out[[id]] <<- data.frame(scenario = id, assumption = desc, k = f[["k"]], N = f[["N"]],
  effect = f[["effect"]], ci_low = f[["lo"]], ci_high = f[["hi"]], I2 = f[["I2"]], reports = reports, stringsAsFactors = FALSE)

e2 <- rd(file.path(rr, "reviewer_rerun_2026_10_09", "e2", "e2_model_inputs.csv"))
base <- e2[e2$model_id == "E2_opioid24_TEAS_sham" & e2$study != "Lee 2011", ]
N0 <- sum(as.numeric(base$n_i) + as.numeric(base$n_c))
f0 <- fit(as.numeric(base$yi), as.numeric(base$vi), N0)
stopifnot(abs(f0[["effect"]] - (-6.672549)) < 1e-5, f0[["k"]] == 6, N0 == 547)  # reproduces the submitted estimate
add("S0", "As submitted: broader first-day TEAS vs sham, Lee 2011 held", f0, paste(base$study, collapse = "; "))
add("S1", "Wang 1997 admitted to the broader first-day analysis (24-h quantity as reported; capture of IM supplements not established, as for Chen 1998)",
    fit(c(as.numeric(base$yi), wang_sham[["y"]]), c(as.numeric(base$vi), wang_sham[["v"]]), N0 + 75),
    paste(c(base$study, "Wang 1997"), collapse = "; "))
add("S2", "Wang 1997 judged to capture all delivered systemic opioid: primary 0-24 h TEAS vs sham (Szmit 2021 + Wang 1997)",
    fit(c(-7.7, wang_sham[["y"]]), c(3.8^2 / 24 + 6.24^2 / 24, wang_sham[["v"]]), 48 + 75), "Szmit 2021; Wang 1997")
add("S3", "Wang 1997 vs PCA only added to the broader first-day TEAS vs usual care analysis (Szmit 2021 + Wang 1997)",
    fit(c(-8.0, wang_pca[["y"]]), c(3.8^2 / 24 + 6.1^2 / 23, wang_pca[["v"]]), 47 + 76), "Szmit 2021; Wang 1997")
res <- rd(file.path(rr, "rescue_model_inputs.csv"))
res <- res[res$model_id == "RESCUE_TEAS_SHAM_ANY_FOLLOWUP", ]
y0 <- as.numeric(res$y); v0 <- as.numeric(res$variance); Nr <- sum(as.numeric(res$n_i) + as.numeric(res$n_c))
fr <- fit(y0, v0, Nr); stopifnot(abs(exp(fr[["effect"]]) - 0.509180) < 1e-5)
fr[c("effect", "lo", "hi")] <- exp(fr[c("effect", "lo", "hi")])
add("R0", "As submitted: rescue receipt, TEAS vs sham (risk ratio)", fr, paste(res$report, collapse = "; "))
w <- lrr(7, 50, 5, 25)                                       # IM supplemental opioid in the first 24 h (Table 3)
f1 <- fit(c(y0, w[["y"]]), c(v0, w[["v"]]), Nr + 75); f1[c("effect", "lo", "hi")] <- exp(f1[c("effect", "lo", "hi")])
add("R1", "Wang 1997 IM supplemental opioid in the first 24 h added to rescue receipt (risk ratio)", f1,
    paste(c(res$report, "Wang 1997"), collapse = "; "))
wp <- comb(25, 4.5, 2.6, 25, 4.4, 2.3)                       # 0-100 VAS / 10
p <- md(wp[1], wp[2], wp[3], 25, 4.8, 2.2)
add("P1", "Wang 1997 pain at 24 h, TEAS vs sham (0-10; rest or movement not stated): single trial, paired with its dose result",
    fit(p[["y"]], p[["v"]], 75), "Wang 1997")
cp <- md(15, 5.033, 0.719, 15, 5.233, 1.522)
add("P2", "Colak 2010 resting pain on day 1, EA vs usual care (0-10): single trial", fit(cp[["y"]], cp[["v"]], 30), "Colak 2010")
o <- do.call(rbind, out)
for (c in c("effect", "ci_low", "ci_high")) o[[c]] <- round(o[[c]], 3)
o$I2 <- round(o$I2, 1)
write.csv(o, file.path(here, "C01_scenarios.csv"), row.names = FALSE)
print(o[, c("scenario", "k", "N", "effect", "ci_low", "ci_high", "I2")], row.names = FALSE)
