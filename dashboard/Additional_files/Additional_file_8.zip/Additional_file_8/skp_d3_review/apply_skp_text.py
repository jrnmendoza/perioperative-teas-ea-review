"""Manuscript text after SKP's second review of the D3 work and of Wang 1997's 48-hour pain drafts (reported 3 Nov 2026).

Runs after reaudit_d3/apply_reaudit_text.py and edits sources/*_REVISED.md in place; every passage is asserted once and a
passage already edited is skipped. The D3 and Wang 48-hour PROVISIONAL markers are removed, as was done for Wang 1997 on
2 Nov 2026. The other markers stay (53 historically excluded reports; D4, D5 and D8 open). The review owner then reported
that SKP had also checked the 2 November 2026 corrections (Table 1 values and comparator labels; Szmit 2021 multimodal
analgesia; confirmed as made), so the extraction and Discussion sentences carry no exception. The Methods also state the
assessment rule that JRNM and SKP confirmed (sensitivity results are assessed)."""
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'sources'

EDITS = {
 'abstract': [
  ('re-checked against both full-text outcome requirements, and assessments for two reports included on 2 November 2026 and '
   'for Wang 1997\'s pain at 48 hours await second review; the counts and estimates above may change.]',
   're-checked against both full-text outcome requirements; the counts and estimates above may change.]'),
 ],
 'methods': [
  ('A second reviewer (SKP) checked the study characteristics, stimulation protocols, hospital setting, analgesic regimens and '
   'narrative outcome tables of every report except Colak 2010, Fu 2024 and Chen 2016 [PROVISIONAL: their extraction, added on '
   '2 and 3 November 2026, awaits this check].',
   'A second reviewer (SKP) checked the study characteristics, stimulation protocols, hospital setting, analgesic regimens and '
   'narrative outcome tables of every report.'),
  ('each outcome, time window, comparison and analysis population was judged separately.',
   'each outcome, time window, comparison and analysis population was judged separately, including results used only in '
   'sensitivity analyses.'),
  ('Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation. A second reviewer '
   '(SKP) checked and confirmed all of them except those for Colak 2010 and Fu 2024 and the risk-of-bias assessments of Wang '
   '1997\'s pain at 48 hours [PROVISIONAL: drafted on 2 and 3 November 2026, they await this check].',
   'Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation and checked and '
   'confirmed by a second reviewer (SKP).'),
 ],
 'results': [
  (' [PROVISIONAL: the 14 judgements for Colak 2010 and Fu 2024 and the two for Wang 1997 (pain at 48 hours) are drafts '
   'awaiting second review.]', ''),
 ],
 'table2': [
  ('[PROVISIONAL: estimates may change after a re-check of 53 historically excluded reports; certainty ratings for analyses '
   'that include Colak 2010 or Fu 2024 are drafts awaiting second review.]',
   '[PROVISIONAL: estimates may change after a re-check of 53 historically excluded reports.]'),
 ],
 'discussion': [
  ('which one human reviewer checked [PROVISIONAL: except those added on 2 and 3 November 2026, which await this check];',
   'which one human reviewer checked;'),
 ],
 'figures': [
  (' † Draft judgement for Fu 2024 (included 2 November 2026), awaiting second review [PROVISIONAL].', ''),
 ],
 'conclusions': [
  ('[PROVISIONAL: pending a re-check of 53 historically excluded reports and second review of the assessments for Colak 2010 '
   'and Fu 2024 and for Wang 1997\'s pain at 48 hours.]',
   '[PROVISIONAL: pending a re-check of 53 historically excluded reports.]'),
 ],
}

n = 0
for sec, pairs in EDITS.items():
    p = SRC / f'{sec}_REVISED.md'
    s = p.read_text(encoding='utf-8')
    for old, new in pairs:
        if old not in s and (new and new in s):   # already edited
            continue
        assert s.count(old) == 1, (sec, old[:80], s.count(old))
        s = s.replace(old, new)
        n += 1
    p.write_text(s, encoding='utf-8')
print(f'{n} passages edited after SKP\'s second review of the D3 work')
