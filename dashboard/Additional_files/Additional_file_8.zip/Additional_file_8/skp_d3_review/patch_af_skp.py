"""Additional-files edits after SKP's second review of the D3 work and of Wang 1997's 48-hour pain drafts (reported by the
review owner, 3 Nov 2026; all confirmed as drafted).

Run after reaudit_d3/patch_af_reaudit.py (the chain rewrites build_additional_files.py from its snapshot each time); this
script edits build_additional_files.py in place, each replacement asserted once. It removes the D3 and Wang 48-hour
PROVISIONAL markers and pending wording (AF2 sections 6, 10 and 12 and the deviations table; AF5; AF8; AF10; AF11; AF12),
renames the AF11 sheet "D3 drafts" to "With Colak and Fu" (its profiles are no longer drafts), records the rule for which
results are assessed (confirmed by JRNM and SKP) and adds this folder to AF9. The review owner then reported that SKP had
also checked the three items AF2 section 12 still listed: the 2 November 2026 corrections (Table 1 values and comparator
labels; Szmit 2021 multimodal analgesia; confirmed as made), the 2 November AI-assisted triage of the 113 outcome exclusions
and the 24 October English-abstract check of the 12 language exclusions (no change reported). Section 12 now lists nothing
pending, the AF4 "Second review" column of the language check reads SKP (its source record in opioid_only_review/ is not
edited), and the triage is still described as not an independent human screen. The AF4 README said the "No eligible
analgesic outcome" exclusions "were not repeated by a second reviewer"; at the review owner's instruction (3 Nov 2026) it
now says that JRNM and SKP screened the full texts independently, as in the Methods (decision D2); so does the same
statement in AF2 section 6. Nothing is re-estimated."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent / 'build_additional_files.py'
s = B.read_text(encoding='utf-8')
n = 0


def rep(old, new):
    global s, n
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)
    n += 1


CHECKED = 'reported 3 Nov 2026'
SHEET = 'With Colak and Fu'

# ---- code comments that describe the records ------------------------------------------------------------------------
rep("RoB 2 and GRADE drafts are in wang1997/; the RoB 2 and GRADE drafts await SKP's second review.",
    "RoB 2 and GRADE assessments are in wang1997/; SKP confirmed them on 2 Nov 2026.")
rep("Records in d3/; the RoB 2 and GRADE drafts await SKP's second review.",
    "Records in d3/; SKP confirmed the extraction and the RoB 2 and GRADE assessments on 3 Nov 2026.")

# ---- AF2 section 6, deviations table, decision log, section 12 -------------------------------------------------------
rep("            '[PROVISIONAL: SKP has not yet '\n"
    "            'checked the extraction for the three reports or the 14 RoB 2 and seven GRADE drafts for Colak 2010 and Fu 2024; '\n"
    "            '45 outcome exclusions",
    "            'SKP checked the extraction for the three reports and confirmed the 14 RoB 2 and seven GRADE assessments for '\n"
    "            'Colak 2010 and Fu 2024 on 3 November 2026 (section 12). [PROVISIONAL: '\n"
    "            '45 outcome exclusions")
rep("for every report except Colak 2010, Fu 2024 and Chen 2016 (decision D3), whose extraction awaits this check [PROVISIONAL].",
    "for every report (Colak 2010, Fu 2024 and Chen 2016, decision D3, and the corrections of 2 Nov 2026: 3 Nov 2026).")
rep("(2 Nov 2026), except the 14 RoB 2 and 7 GRADE drafts for Colak 2010 and Fu 2024 and the 2 RoB 2 drafts for Wang 1997",
    "(2 Nov 2026), and the 14 RoB 2 and 7 GRADE assessments for Colak 2010 and Fu 2024 and the 2 RoB 2 assessments for Wang 1997")
rep("pain at 48 h, which await this check [PROVISIONAL]'", "pain at 48 h (3 Nov 2026)'")
rep("RoB 2 and GRADE drafted by the AI '\n                 'assistant; second review pending.', 'Yes'])",
    "RoB 2 and GRADE drafted by the AI '\n                 'assistant; confirmed by SKP on 3 Nov.', 'Yes'])")
rep("All drafts await '\n                 'second review.', 'Yes'])",
    "All confirmed by SKP '\n                 'on 3 Nov (section 12).', 'Yes'])")
rep("'those for Wang 1997 (2 November 2026), except the items listed below as pending.",
    "'those for Wang 1997 (2 November 2026) and those added under decision D3 (3 November 2026); every item is listed '\n"
    "            'below.")
rep("        ['Pending', 'Decision D3 extraction (",
    "        ['3 Nov', 'Decision D3 extraction (")
rep("revised the same day after an AI re-audit)', '[CONFIRM: second review pending]'],",
    "revised the same day after an AI re-audit). Points put to the reviewer: Fu 2024 rescue measurement (kept Low); one imprecision level "
    "for the small single-trial bodies (kept); Fu 2024 source problems (arm summaries kept as printed, ratings unchanged; Additional file 5); "
    "Chen 2016 pethidine (text values kept)', 'Confirmed'],")
rep("        ['Pending', '2 RoB 2 assessments for Wang 1997 (pain at 48 h against sham and usual care; added 3 Nov after the AI re-audit "
    "found them unassessed)', '[CONFIRM: second review pending]'],",
    "        ['3 Nov', '2 RoB 2 assessments for Wang 1997 (pain at 48 h against sham and usual care; added 3 Nov after the AI re-audit "
    "found them unassessed; missing outcome data kept Low)', 'Confirmed'],\n"
    "        ['3 Nov', 'Rule for which results are assessed: every result used in an analysis, including sensitivity results; transcription "
    "variants of one result share one assessment; results held from synthesis or reported only descriptively are not assessed (JRNM and "
    "SKP)', 'Confirmed'],")
rep("        ['Pending', 'English-abstract check of the 12 language exclusions', '[CONFIRM: pending]'],\n", "")
rep("        ['Not done', 'The 2 November 2026 triage of the outcome exclusions, the Table 1 corrections and the Szmit 2021 "
    "multimodal-analgesia change', '[CONFIRM: second review pending]'],",
    "        ['3 Nov', 'Corrections of 2 November 2026: Table 1 values (An 2014, Coura 2011, Oztas 2019, Chen 1998 ages) and comparator "
    "labels (Wu 2016, Grech 2016, Xie 2014, Lee 2011, Yeh 2011); Szmit 2021 multimodal analgesia (No to Yes)', 'Confirmed'],\n"
    "        ['3 Nov', 'The 2 November 2026 AI-assisted triage of the 113 outcome exclusions (Additional file 4) and the English-abstract "
    "check of the 12 language exclusions (24 October 2026)', 'Checked; no change reported'],")

# ---- AF2 sections 5, 6 and 10: the English-abstract check, the triage and the corrections ------------------------------
rep("[CONFIRM: second review of this '\n            'abstract check by SKP is pending.]",
    "SKP checked this abstract '\n            'check (" + CHECKED + ").")
rep("This triage is not an independent human screen and changed no decision itself.",
    "This triage is not an independent human screen and changed no decision itself; SKP checked it (" + CHECKED + ").")
rep("English abstracts of the 12 language exclusions checked.', 'Yes'],",
    "English abstracts of the 12 language exclusions checked (second review by SKP, 3 Nov).', 'Yes'],")
rep("Szmit 2021 reclassified as routine multimodal analgesia (intraoperative metamizole to all) under the stated definition.', 'Yes'],",
    "Szmit 2021 reclassified as routine multimodal analgesia (intraoperative metamizole to all) under the stated definition. Triage "
    "and corrections checked by SKP on 3 Nov.', 'Yes'],")

# ---- AF4: triage and language-check descriptions; the language check's second-review column ---------------------------
rep("the triage itself is not a human screen [PROVISIONAL:", "the triage itself is not a human screen; SKP checked it (" + CHECKED + ") [PROVISIONAL:")
rep("('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language'),",
    "('Language exclusions', 'English-abstract check of the 12 reports excluded for publication language; checked by SKP (" + CHECKED + ")'),")
rep("    lang = rd(PR / 'language_exclusions_abstract_check_2026-10-24.csv').to_dict('records')\n",
    "    lang = rd(PR / 'language_exclusions_abstract_check_2026-10-24.csv').to_dict('records')\n"
    "    assert all(r['second_review'] == 'Pending (SP)' for r in lang), {r['second_review'] for r in lang}   # source record, not edited\n"
    "    for r in lang:   # SKP's check, reported by the review owner on 3 Nov 2026\n"
    "        r['second_review'] = 'SKP (" + CHECKED + ")'\n")

# ---- AF5: Fu 2024 and Chen 2016 dispositions ------------------------------------------------------------------------
rep("Flagged for the human source check (D9) and for the second '\n"
    "     'review of the Fu 2024 RoB 2 and GRADE drafts. Without Fu 2024,",
    "Flagged for the human source check (D9). At second review '\n"
    "     '(SKP, 3 Nov 2026) the arm summaries were kept as printed and the Fu 2024 RoB 2 and GRADE assessments confirmed. Without Fu 2024,")
rep("Whether the report\\'s data can be relied on is for the second '\n     'reviewer; inclusion (decision D3) is unchanged.'),",
    "Inclusion '\n     '(decision D3) is unchanged.'),")
rep("'Text values recorded; figure not read. Chen 2016", "'Text values recorded (kept at second review, 3 Nov 2026); figure not read. Chen 2016")

# ---- AF8: characteristics ----------------------------------------------------------------------------------------------
rep("# D3, 2 Nov 2026: AI extraction from the source PDFs; second review by SKP pending",
    "# D3, 2 Nov 2026: AI extraction from the source PDFs; checked by SKP (reported 3 Nov 2026)")
rep("AI extraction, second review by SKP pending [PROVISIONAL]\",", "AI extraction, checked by SKP (reported 3 Nov 2026)\",")
rep("(added and checked 2 Nov 2026); those of Colak 2010, '\n"
    "                    'Fu 2024 and Chen 2016 (added 2 Nov 2026, decision D3) await this check [PROVISIONAL].'],",
    "(added and checked 2 Nov 2026) and those of Colak 2010, '\n"
    "                    'Fu 2024 and Chen 2016 (added 2 Nov 2026, decision D3; checked 3 Nov 2026); the corrections of 2 Nov 2026 (Table 1 '\n"
    "                    'values and comparator labels; Szmit 2021 multimodal analgesia) were checked on 3 Nov 2026.'],")
rep("'Szmit 2021 multimodal analgesia corrected on 2 Nov 2026 (No to Yes):",
    "'Szmit 2021 multimodal analgesia corrected on 2 Nov 2026 (No to Yes; checked by SKP, " + CHECKED + "):")
rep('"Not reported" means the report gives nothing. SKP has not yet checked them.\'])',
    '"Not reported" means the report gives nothing. SKP checked them (reported 3 Nov 2026).\'])')

# ---- AF10: risk of bias -----------------------------------------------------------------------------------------------
rep("# D1, 2 Nov 2026: AI drafts; second review pending", "# D1, 2 Nov 2026: AI assessments; confirmed by SKP 2 Nov 2026")
rep("# D3, 2 Nov 2026: AI drafts; second review pending", "# D3, 2 Nov 2026: AI assessments; confirmed by SKP 3 Nov 2026")
rep("(re-audit R05): AI drafts; pending", "(re-audit R05): AI assessments; confirmed by SKP 3 Nov 2026")
rep("# Fig. 3 rebuilt with Wang 1997 and the D3 drafts", "# Fig. 3 rebuilt with Wang 1997 and the D3 assessments")
rep("'checked and confirmed every assessment except the 14 for Colak 2010 and Fu 2024 and the 2 for Wang 1997\\'s pain at 48 hours (below); a check is not '",
    "'checked and confirmed every assessment (below); a check is not '")
rep("'7-day analgesic totals) are AI drafts awaiting second review by SKP [PROVISIONAL]. After an independent AI re-audit (3 Nov 2026), the '",
    "'7-day analgesic totals) were made by the AI assistant. After an independent AI re-audit (3 Nov 2026), the '")
rep("'Fu 2024 randomisation drafts (all five results) and QoR-15 measurement drafts (three) were revised",
    "'Fu 2024 randomisation judgements (all five results) and QoR-15 measurement judgements (three) were revised")
rep("'drafts were added for Wang 1997\\'s pain at 48 hours", "'assessments were added for Wang 1997\\'s pain at 48 hours")
rep("'48-hour pain had been assessed (V33-OD-0368). These are also AI drafts awaiting second review [PROVISIONAL].'],",
    "'48-hour pain had been assessed (V33-OD-0368). SKP confirmed all 16 on 3 Nov 2026. Every result used in an analysis is '\n"
    "                     'assessed, including sensitivity results; transcription variants of one result (Yu 2020\\'s two SDs) share one '\n"
    "                     'assessment; results held from synthesis or reported only descriptively are not (rule confirmed by JRNM and SKP, '\n"
    "                     '3 Nov 2026).'],")

# ---- AF11: GRADE ------------------------------------------------------------------------------------------------------
rep("# D3, 2 Nov 2026: AI drafts awaiting SKP's second review", "# D3, 2 Nov 2026: AI assessments, confirmed by SKP 3 Nov 2026")
rep("current draft in sheet \"D3 drafts\"'", f"current profile in sheet \"{SHEET}\"'")
rep("version='Current (draft) [PROVISIONAL]'", "version='Current'")
rep("Current draft profile: sheet \"D3 drafts\"'", f"Current profile: sheet \"{SHEET}\"'")
rep("'a second reviewer (SKP), except the seven profiles in sheet \"D3 drafts\", which await this check [PROVISIONAL]; '\n"
    "                     'the profiles in sheet \"With Wang 1997\" were confirmed on 2 Nov 2026. Where one '",
    "'a second reviewer (SKP); the profiles in sheet \"With Wang 1997\" were confirmed on 2 Nov 2026 and those in sheet '\n"
    f"                     '\"{SHEET}\" on 3 Nov 2026. Where one '")
rep("('D3 drafts', 'Profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): AI drafts awaiting "
    "second review by SKP [PROVISIONAL]')],",
    f"('{SHEET}', 'Current profiles for the bodies of evidence that Colak 2010 and Fu 2024 enter (decision D3, 2 Nov 2026): revised "
    "after independent AI audits and confirmed by SKP on 3 Nov 2026')],")
rep("The seven-trial draft is in sheet \"D3 drafts\".'", f"The seven-trial profile is in sheet \"{SHEET}\".'")
rep("    sheet(wb, 'D3 drafts', ddr,", f"    sheet(wb, '{SHEET}', ddr,")

# ---- AF4 README: who made the outcome exclusions (review owner's instruction, 3 Nov 2026; decision D2) -------------------
rep("'\"No eligible analgesic outcome\" preserves the exclusion decisions made during screening under the 14 August '\n"
    "                 '2026 outcome rule. They were not repeated by a second reviewer, and the label does not show that every '\n"
    "                 'excluded report lacked every registered outcome.',",
    "'\"No eligible analgesic outcome\" preserves the exclusion decisions made at full-text screening under the 14 '\n"
    "                 'August 2026 outcome rule; JRNM and SKP screened the full texts independently (Methods). The label does not '\n"
    "                 'show that every excluded report lacked every registered outcome.',")
# the same statement in AF2 section 6 (found 3 Nov 2026 while recording decision D4)
rep("'(\"No eligible analgesic outcome\" in Fig. 1). These exclusions were recorded during screening and were not '\n"
    "            'repeated by a second reviewer; the label",
    "'(\"No eligible analgesic outcome\" in Fig. 1). These exclusions were made at full-text screening, which JRNM and SKP '\n"
    "            'did independently (Methods); the label")

# ---- AF12: Colak 2010 pethidine note -------------------------------------------------------------------------------------
rep("outside every 0–24-h analysis; RoB 2 draft added 3 Nov 2026',",
    "outside every 0–24-h analysis; RoB 2 assessment added and confirmed 3 Nov 2026',")

# ---- AF9: this folder ---------------------------------------------------------------------------------------------------
rep("          + [REV / 'reaudit_d3/figure_builds/build_rob_figure_reaudit.py'],\n",
    "          + [REV / 'reaudit_d3/figure_builds/build_rob_figure_reaudit.py'],\n"
    "    'skp_d3_review': [REV / 'skp_d3_review' / f for f in ('record_skp_review.py', 'apply_skp_text.py', 'patch_af_skp.py',\n"
    "                                                          'update_verify_skp.py')]\n"
    "          + [REV / 'skp_d3_review/figure_builds/build_rob_figure_skp.py'],\n")
rep("'within 1.5 × 10⁻⁶ (the largest, τ² for QoR15_SHAM_24H_LOO_Zhou_2025, reflects optimiser precision).', '',\n",
    "'within 1.5 × 10⁻⁶ (the largest, τ² for QoR15_SHAM_24H_LOO_Zhou_2025, reflects optimiser precision).',\n"
    "              '- `skp_d3_review/`: records the second review by SKP (reported 3 Nov 2026) of the decision-D3 extraction and '\n"
    "              'assessments, of Wang 1997\\'s 48-hour pain assessments and of the 2 November corrections, triage and '\n"
    "              'English-abstract check. All were confirmed as made or drafted, so no judgement, value or estimate changed.', '',\n")

B.write_text(s, encoding='utf-8')
print(n, 'builder edits after SKP\'s second review of the D3 work')
