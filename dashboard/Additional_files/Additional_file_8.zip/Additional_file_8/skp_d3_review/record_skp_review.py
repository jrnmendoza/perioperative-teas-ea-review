"""SKP's second review of the decision-D3 work and of Wang 1997's 48-hour pain drafts (reported by the review owner, 3 Nov 2026).

The review owner reported that SKP reviewed the D3 extraction (d3_results, d3_characteristics, d3_outcome_inventory), the 14
RoB 2 and 7 GRADE drafts for Colak 2010 and Fu 2024 and the 2 RoB 2 drafts for Wang 1997's pain at 48 hours, and confirmed
all of them as drafted. On the points the drafts put to the reviewer: Fu 2024's rescue measurement stays Low; the small
single-trial GRADE bodies keep one imprecision level; Fu 2024 stays in the estimates with its arm summaries as printed and
its ratings unchanged; Wang 1997's 48-hour missing-data domain stays Low; and Chen 2016's text pethidine values are the ones
recorded. JRNM and SKP both confirmed the rule for which results are assessed (every result used in an analysis, including
sensitivity results; transcription variants share one assessment; held and descriptive-only results are not assessed).

No judgement, rating or value changes here. Runs after reaudit_d3/build_wang48_rob2.py and rewrites, in place, the review
status of the 23 records and the sentences that put a question to the second reviewer, including eight in the Wang 1997
records that SKP confirmed as drafted on 2 Nov 2026. The _DRAFT file names are historical."""
import csv
from pathlib import Path

REV = Path(__file__).resolve().parent.parent
DONE = 'second review SKP, 2026-11-03 (confirmed)'
ANSWERS = [   # question put to the reviewer -> what the reviewer decided (all as drafted)
    ('kept Low as for the identical VAS-triggered rules in Tu 2024 and Zhou 2025 (confirmed), a point for the second reviewer.',
     'kept Low as for the identical VAS-triggered rules in Tu 2024 and Zhou 2025 (confirmed); the second reviewer kept Low (3 Nov 2026).'),
    ('whether its data can be relied on is for the second reviewer.',
     'the second reviewer kept its arm summaries as printed (3 Nov 2026).'),
    ('Whether two levels are warranted is for the second reviewer.', 'The second reviewer kept one level (3 Nov 2026).'),
    ('whether two levels are warranted is for the second reviewer (', 'the second reviewer kept one level (3 Nov 2026; '),
    ('Proposed Low, as at 24 h; SKP to judge whether the absence of outcome-specific denominators should lower this.',
     'Low, as at 24 h; the second reviewer kept Low despite the absence of outcome-specific denominators (3 Nov 2026).'),
]


def status(v):
    assert 'second review by SKP pending' in v, v
    v = v.replace('AI draft (Claude)', 'AI assessment (Claude)').replace('; second review by SKP pending', '')
    return f'{v}; {DONE}'


used = {old: 0 for old, _ in ANSWERS}
counts = {}
for rel, key in (('d3/d3_rob2_DRAFT.csv', 'decision_status'), ('d3/d3_grade_DRAFT.csv', 'status'),
                 ('reaudit_d3/wang48_rob2_DRAFT.csv', 'decision_status')):
    p = REV / rel
    rows = list(csv.DictReader(open(p, encoding='utf-8-sig', newline='')))
    for r in rows:
        r[key] = status(r[key])
        for k, v in r.items():
            for old, new in ANSWERS:
                if old in v:
                    v = v.replace(old, new); used[old] += v.count(new)
            r[k] = v
        assert not any('for the second reviewer' in v or 'SKP to judge' in v for v in r.values()), r
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    counts[rel] = len(rows)
assert counts == {'d3/d3_rob2_DRAFT.csv': 14, 'd3/d3_grade_DRAFT.csv': 7, 'reaudit_d3/wang48_rob2_DRAFT.csv': 2}, counts
assert all(used.values()), used

# Wang 1997 (confirmed by SKP as drafted on 2 Nov 2026): eight missing-data rationales still put their question to the
# reviewer, so the answer is recorded with the date of that review. Found 3 Nov 2026 when checking that no question was left open.
p = REV / 'wang1997/wang1997_rob2_DRAFT.csv'   # rewritten from its snapshot by recheck/update_wang_records.py each run
rows = list(csv.DictReader(open(p, encoding='utf-8-sig', newline='')))
old = 'Proposed Low because there is no indication of missing data; SKP to judge whether the absence of denominators should lower this.'
assert sum(r['d3_rationale'].count(old) for r in rows) == 8 and all(r['decision_status'].endswith('2026-11-02 (confirmed)') for r in rows)
for r in rows:
    r['d3_rationale'] = r['d3_rationale'].replace(old, 'Low because there is no indication of missing data; the second reviewer kept Low '
                                                       'despite the absence of denominators (2 Nov 2026).')
with open(p, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('SKP second review recorded (3 Nov 2026):', counts, 'answered questions:', sum(used.values()), '+ 8 in the Wang 1997 records (2 Nov)')
