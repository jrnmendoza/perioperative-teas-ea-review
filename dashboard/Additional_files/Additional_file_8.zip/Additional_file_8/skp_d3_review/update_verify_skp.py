"""After SKP's second review of the D3 work and of Wang 1997's 48-hour pain drafts (reported by the review owner, 3 Nov 2026):
adapt verification/verify_revision.py, as written by reaudit_d3/update_verify_reaudit.py.

Run after reaudit_d3/update_verify_reaudit.py. Checks that expected the D3 and Wang 48-hour work to be pending now expect it
confirmed (each replacement asserted once). Added checks compare with the snapshot taken before the review
(skp_d3_review/pre_skp/): no judgement, rating, extracted value or estimate changed; the 23 records carry SKP's
confirmation and no question to the reviewer is left open; the D3 markers are gone from the Word file and the Additional
files and Fig. 3 no longer marks Fu 2024 as a draft; AF2 section 12 dates every confirmation of 3 Nov (including the 2 Nov
corrections, the triage and the English-abstract check, which the review owner reported SKP had also checked) and lists
nothing pending; AF4's language check names SKP; no statement still calls those items unchecked; the assessment rule
confirmed by JRNM and SKP is stated; and the AF4 README attributes the outcome exclusions to independent full-text
screening by JRNM and SKP (D2; review owner's instruction, 3 Nov 2026). The sign-off scan (re-audit R02/R13) now allows an undated statement that a reviewer
checked the work only while AF2 section 12 lists nothing pending (for assessments: no RoB 2 or GRADE work pending), and
never for the arm-level values, whose human check is D9.
Re-run d3/update_verify_d3.py, audit_d3/update_verify_audit.py and reaudit_d3/update_verify_reaudit.py first to start again."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
V = HERE.parent / 'verification/verify_revision.py'
s = V.read_text(encoding='utf-8')
assert 'SKP second review of the D3 work' not in s, 'already applied: re-run the earlier update_verify scripts first'


def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


rep("""check('AF10: 180 judgements; 12 for Wang 1997 confirmed by SKP and 2 (48-h pain) pending; 14 D3 drafts pending', len(j) == 180
      and sum(x[1] == 'Wang 1997' and 'second review by SKP pending' in str(x[-1]) and x[3] == '48 h' for x in j) == 2
      and sum(x[1] == 'Wang 1997' and '2026-11-02 (confirmed)' in str(x[-1]) for x in j) == 12
      and sum(x[1] in ('Colak 2010', 'Fu 2024') and 'second review by SKP pending' in str(x[-1]) for x in j) == 14)""",
    """check('AF10: 180 judgements; 12 for Wang 1997 confirmed by SKP on 2 Nov; 14 D3 and 2 Wang 48-h confirmed on 3 Nov; none pending', len(j) == 180
      and sum(x[1] == 'Wang 1997' and '2026-11-03 (confirmed)' in str(x[-1]) and x[3] == '48 h' for x in j) == 2
      and sum(x[1] == 'Wang 1997' and '2026-11-02 (confirmed)' in str(x[-1]) for x in j) == 12
      and sum(x[1] in ('Colak 2010', 'Fu 2024') and '2026-11-03 (confirmed)' in str(x[-1]) for x in j) == 14
      and not any('pending' in str(x[-1]) for x in j))""")
rep("t = (HERE / 'af9_unzip_test_reaudit_2026-11-03.txt').read_text()   # clean unzip after the D3 re-audit repairs",
    "t = (HERE / 'af9_unzip_test_skp_2026-11-03.txt').read_text()   # clean unzip after SKP's second review was recorded")
rep("""check('SKP review recorded: no Wang RoB 2/GRADE text says awaiting second review, except the two 48-hour pain drafts added 3 Nov',
      not any('Wang 1997' in x and '48' not in x and any(p in x for p in (
      'drafts awaiting second review', 'await second review', 'await this check', 'second review pending')) for x in _sent))""",
    """check('SKP review recorded: no Word or AF text says the Wang 1997, Colak 2010, Fu 2024 or Chen 2016 work awaits second review',
      not any(re.search(r'Wang 1997|Colak 2010|Fu 2024|Chen 2016|D3', x) and 'corrections' not in x and any(p in x for p in (
      'awaiting second review', 'await second review', 'await this check', 'awaits this check', 'second review pending',
      'has not yet checked', 'drafts await')) for x in _sent))""")
rep("""check('D3 RoB 2 (14) and GRADE (7) drafts marked AI drafts pending SKP, with PROVISIONAL markers in Results, Methods and Table 2',
      len(dr) == 14 and len(dg) == 7 and all('second review by SKP pending' in r['decision_status'] for r in dr)
      and all('second review by SKP pending' in g['status'] for g in dg)
      and 'the 14 judgements for Colak 2010 and Fu 2024 and the two for Wang 1997 (pain at 48 hours) are drafts awaiting second review' in results
      and 'checked and confirmed all of them except those for Colak 2010 and Fu 2024 and the risk-of-bias assessments of Wang 1997\\'s pain at 48 hours [PROVISIONAL' in methods
      and 'of every report except Colak 2010, Fu 2024 and Chen 2016 [PROVISIONAL: their extraction, added on 2 and 3 November 2026, awaits this check]' in methods)""",
    """check('D3 RoB 2 (14) and GRADE (7) recorded as confirmed by SKP on 3 Nov 2026; their markers removed from Results, Methods and Table 2',
      len(dr) == 14 and len(dg) == 7 and all(r['decision_status'].endswith('second review SKP, 2026-11-03 (confirmed)') for r in dr)
      and all(g['status'].endswith('second review SKP, 2026-11-03 (confirmed)') for g in dg)
      and not any('pending' in r['decision_status'] for r in dr) and not any('pending' in g['status'] for g in dg)
      and 'drafts awaiting second review' not in results and 'they await this check' not in methods
      and "under the review team's delegation and checked and confirmed by a second reviewer (SKP)." in methods
      and 'Colak 2010 or Fu 2024 are drafts' not in json.dumps(spec, ensure_ascii=False))""")
rep("check('AF11: D3 drafts sheet (7 profiles)', len(xl(11, 'D3 drafts', 'Analysis')) == 7)",
    "check('AF11: sheet \"With Colak and Fu\" (7 current profiles); no \"D3 drafts\" sheet', len(xl(11, 'With Colak and Fu', 'Analysis')) == 7\n"
    "      and all(x[-1] == 'Current' for x in xl(11, 'With Colak and Fu', 'Analysis'))\n"
    "      and 'D3 drafts' not in openpyxl.load_workbook(REV / 'additional_files/Additional_file_11.xlsx', read_only=True).sheetnames)")
rep("""      and 'A second reviewer (SKP) checked and confirmed all of them except those for Colak 2010 and Fu 2024' in methods
      and 'except the 14 for Colak 2010 and Fu 2024' in ' '.join(""",
    """      and 'except those for Colak 2010 and Fu 2024' not in methods and 'narrative outcome tables of every report.' in methods
      and 'SKP confirmed all 16 on 3 Nov 2026' in ' '.join(""")
rep("""_blanket = [x[:90] for x in _claims if not re.search(r'except|await|pending|PROVISIONAL|CONFIRM|not yet|are listed above', x)
            and not re.search(r'Wang 1997|20(20|26)-1[01]-\\d\\d|\\d+ (Sep|Oct|Nov)', x)]""",
    """_af2 = _docx.Document(REV / 'additional_files/Additional_file_2.docx')   # section 12: what SKP has and has not checked
_s12 = next([[c.text for c in r.cells] for r in tb.rows] for tb in _af2.tables if [c.text for c in tb.rows[0].cells][:2] == ['Date (2026)', 'Items checked'])
_open12 = [r for r in _s12[1:] if r[0] in ('Pending', 'Not done')]
_open_assess = any(re.search(r'RoB 2|GRADE|risk-of-bias', r[1]) for r in _open12)
_assess_only = lambda x: re.search(r'(?i)assessment|RoB 2|risk-of-bias|GRADE|profile', x) and not re.search(r'(?i)extract|characteristic|regimen|Table 1|outcome tables', x)
_d9 = lambda x: re.search(r'(?i)arm-level|outcome values|analysis inputs', x) and not re.search(r'automatically|not double-extracted|by the AI assistant', x)
_blanket = [x[:90] for x in _claims if not re.search(r'except|await|pending|PROVISIONAL|CONFIRM|not yet|are listed above', x)
            and not re.search(r'Wang 1997|20(20|26)-1[01]-\\d\\d|\\d+ (Sep|Oct|Nov)', x)
            and not (_assess_only(x) and not _open_assess)   # 'every assessment confirmed' is exact only while none is pending
            and not (not _open12 and not _d9(x))]   # an undated claim is exact only while section 12 lists nothing pending""")
rep("""check('Re-audit R06: Fu 2024 drafts revised (randomisation Some concerns in all five; QoR-15 measurement Some concerns), overall unchanged, still pending',""",
    """check('Re-audit R06: Fu 2024 assessments revised (randomisation Some concerns in all five; QoR-15 measurement Some concerns), overall unchanged, confirmed by SKP 3 Nov',""")
rep("and all(r['overall'] == 'Some concerns' for r in _fu) and all('second review by SKP pending' in r['decision_status'] for r in _fu)",
    "and all(r['overall'] == 'Some concerns' for r in _fu) and all('2026-11-03 (confirmed)' in r['decision_status'] for r in _fu)")

SKP = r'''
# SKP second review of the D3 work and of Wang 1997's 48-hour pain drafts (reported by the review owner, 3 Nov 2026)
_P = REV / 'skp_d3_review/pre_skp'
_JD = ('d1', 'd2', 'd3', 'd4', 'd5', 'overall')
_same = lambda a, b, cols: [tuple(r[c] for c in cols) for r in a] == [tuple(r[c] for c in cols) for r in b]
_w48 = recs(REV / 'reaudit_d3/wang48_rob2_DRAFT.csv')
check('SKP review: no judgement, rating, extracted value, figure count or estimate changed (against the snapshot before the review)',
      _same(dr, recs(_P / 'd3/d3_rob2_DRAFT.csv'), ('assessment_id',) + _JD) and _same(_w48, recs(_P / 'reaudit_d3/wang48_rob2_DRAFT.csv'), ('assessment_id',) + _JD)
      and _same(dg, recs(_P / 'd3/d3_grade_DRAFT.csv'), ('model_id', 'certainty', 'rob', 'inc', 'ind', 'imp', 'pub'))
      and _same(wd, recs(_P / 'wang1997/wang1997_rob2_DRAFT.csv'), ('assessment_id', 'decision_status') + _JD)
      and all((REV / 'd3' / f).read_bytes() == (_P / 'd3' / f).read_bytes() for f in ('d3_results.csv', 'd3_characteristics.csv',
              'd3_outcome_inventory.csv', 'd3_decisions.csv', 'rob_domain_summary_d3.csv'))
      and (REV / 'wang1997/models_with_wang.csv').read_bytes() == (_P / 'wang1997/models_with_wang.csv').read_bytes())
_qs = ('for the second reviewer', 'SKP to judge', 'a point for the second', 'Proposed Low')
_cells = [str(c) for n in (10, 11) for sh in openpyxl.load_workbook(REV / f'additional_files/Additional_file_{n}.xlsx', read_only=True).worksheets
          for r in sh.iter_rows(values_only=True) for c in r if c]
_fr = next(r for r in dr if r['assessment_id'] == 'D3-FU-RESCUE')
_gr = {g['model_id']: g for g in dg}
check('SKP review: the 2 Wang 48-h records confirmed; no question to the reviewer left open in the D3 or Wang records, AF10 or AF11; the answers recorded',
      len(_w48) == 2 and all(r['decision_status'].endswith('second review SKP, 2026-11-03 (confirmed)') for r in _w48)
      and not any(q in v for q in _qs for r in dr + dg + _w48 + wd for v in r.values()) and not any(q in c for q in _qs for c in _cells)
      and 'the second reviewer kept Low (3 Nov 2026)' in _fr['d4_rationale']
      and 'the second reviewer kept its arm summaries as printed (3 Nov 2026)' in _fr['overall_rationale']
      and 'The second reviewer kept one level (3 Nov 2026)' in _gr['intraop_remifentanil_TEAS_sham']['reason']
      and 'the second reviewer kept one level (3 Nov 2026;' in _gr['RESCUE_METAMIZOLE_7D_EA_USUAL']['reason']
      and all('kept Low despite the absence of outcome-specific denominators' in r['d3_rationale'] for r in _w48))
_prov = re.findall(r'\[PROVISIONAL[^\]]*\]', ' '.join(p.text for p in _docx.Document(REV / 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx').paragraphs)
                   + ' '.join(c.text for tb in _docx.Document(REV / 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx').tables for r in tb.rows for c in r.cells))
_d3prov = [m for m in _prov if re.search(r'Colak|Fu 2024|Chen 2016|48 hours|2 and 3 November|second review|corrections|await this check', m)]
check('SKP review: no D3, Wang 48-h or 2 Nov correction PROVISIONAL marker left in the Word file; the 53-report and membership markers remain',
      not _d3prov and len(set(_prov)) == 7 and sum('53 historically excluded' in m for m in set(_prov)) == 3
      and any('study membership awaits the decisions' in m for m in _prov), f'{len(set(_prov))} distinct markers; D3 {_d3prov[:2]}')
_kf = recs(REV / 'd3/rob_key_analyses_d3.csv')
_wx = zipfile.ZipFile(REV / 'TEAS_EA_opioid_review_BMC_Anesthesiology_REVISION_DRAFT_2026-11-02.docx').read('word/document.xml').decode()
_fb = (REV / 'skp_d3_review/figure_builds/build_rob_figure_skp.py').read_text(encoding='utf-8')
check('SKP review: Fig. 3 no longer marks Fu 2024 as a draft (panel A row, figure footnote, Word legend); domain counts unchanged',
      len(_kf) == 33 and not any('†' in r['study'] for r in _kf) and any(r['study'] == 'Fu 2024' for r in _kf)
      and 'Draft judgement' not in _wx and 'u2020' not in _fb and 'Draft judgement' not in _fb
      and (rob['Overall']['Low'], rob['Overall']['Some concerns'], rob['Overall']['High']) == ('2', '126', '52'))
_r12 = {r[1][:40]: r for r in _s12[1:]}
_n3 = [r for r in _s12 if r[0] == '3 Nov']
check('SKP review: AF2 section 12 dates the five checks of 3 Nov (D3, Wang 48 h, the rule, the 2 Nov corrections, the triage and abstract check) and lists nothing pending',
      len(_n3) == 5 and not _open12 and sum(r[2] == 'Confirmed' for r in _n3) == 4
      and any('Corrections of 2 November 2026' in r[1] and 'Szmit 2021' in r[1] and r[2] == 'Confirmed' for r in _n3)
      and any('triage' in r[1] and 'English-abstract' in r[1] and r[2] == 'Checked; no change reported' for r in _n3)
      and any('Rule for which results are assessed' in r[1] and '(JRNM and SKP)' in r[1] for r in _s12))
_ext = [x for x in _claims if re.search(r'characteristic|extract|regimen', x)
        and re.search(r'every report|were checked by a second reviewer|one human reviewer checked', x)]
_lx = xl(4, 'Language exclusions', 'Covidence ID')
_c4 = ' '.join(str(c) for c in _cells + [str(c) for r in openpyxl.load_workbook(REV / 'additional_files/Additional_file_4.xlsx', read_only=True)['README'].iter_rows(values_only=True) for c in r if c])
check('SKP review: the 2 Nov corrections, triage and English-abstract check are no longer called unchecked (Methods, Discussion, AF2, AF4, AF8); the triage is still not called a human screen',
      len(_ext) >= 4 and not any(re.search(r'await|pending|not yet', x) for x in _ext)
      and 'corrections of 2 November 2026' not in methods + discussion and 'abstract check by SKP is pending' not in _t
      and len(_lx) == 12 and all(x[-1] == 'SKP (reported 3 Nov 2026)' for x in _lx)
      and 'not a human screen; SKP checked it (reported 3 Nov 2026)' in _c4 and 'not an independent human screen and changed no decision itself; SKP checked it' in _t,
      f'{len(_ext)} extraction statements')
check('AF4 README and AF2 section 6: the outcome exclusions are attributed to independent full-text screening by JRNM and SKP (D2), not to a single reviewer',
      'not repeated by a second reviewer' not in _c4 and 'JRNM and SKP screened the full texts independently (Methods)' in _c4
      and 'not repeated by a second reviewer' not in _t and 'made at full-text screening, which JRNM and SKP did independently (Methods)' in _t
      and 'screened independently in Covidence by JRNM and SKP' in methods)
_wr = {r['result_id']: r for r in recs(REV / 'wang1997/wang1997_results.csv')}
_r10 = ' '.join(c for c in _cells if 'transcription variants' in c)
check('SKP review: assessment rule confirmed by JRNM and SKP stated (Methods, AF10); Wang 48-h result record no longer says "not assessed"',
      'judged separately, including results used only in sensitivity analyses' in methods
      and 'rule confirmed by JRNM and SKP, 3 Nov 2026' in _r10 and 'Results held from synthesis or reported only descriptively were not assessed' in methods
      and 'not risk-of-bias assessed' not in _wr['WANG97-PAIN48']['classification'] and 'WANG97-VAS48-S' in _wr['WANG97-PAIN48']['classification'])
'''
rep("\n(HERE / 'verification_results.txt').write_text(", SKP + "\n(HERE / 'verification_results.txt').write_text(")
V.write_text(s, encoding='utf-8')
print('verify_revision.py adapted after SKP\'s second review of the D3 work')
