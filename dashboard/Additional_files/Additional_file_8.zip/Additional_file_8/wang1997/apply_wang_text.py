"""Apply decision D1 (2 Nov 2026: the review owner judged Wang 1997 to be TEAS) to the revised manuscript sources.
Every replacement asserts the pre-Wang text first, so the script runs once on the pre-Wang sources; those are kept in
wang1997/pre_wang_snapshot/. Numbers come from wang1997/models_with_wang.csv (refit_with_wang.R), the rebuilt Table 1,
the Fig. 2 and Fig. 3 rebuilds, and wang1997_rob2_DRAFT.csv / wang1997_grade_DRAFT.csv."""
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / 'sources'
SNAP = HERE / 'pre_wang_snapshot'

EDITS = {
'abstract_REVISED.md': [
    ('**Results:** Forty reports of 39 trials (7,420 participants) were included.',
     '**Results:** Forty-one reports of 40 trials (7,521 participants) were included.'),
    ('Post-hoc analyses gave −6.67 mg (−14.53 to 1.18; six trials; very low certainty) when results with incomplete opioid capture were admitted, and fewer participants receiving rescue opioid over each trial\'s follow-up (risk ratio 0.51, 0.35 to 0.75; five trials, all in China; exploratory; low certainty).',
     'Post-hoc analyses gave −7.22 mg (−14.13 to −0.32; seven trials; very low certainty) when results with incomplete opioid capture were admitted, and fewer participants receiving rescue opioid over each trial\'s follow-up (risk ratio 0.52, 0.37 to 0.74; six trials; exploratory; low certainty).'),
    ('Of 152 assessed results, 28% were at high risk of bias.', 'Of 162 assessed results, 27% were at high risk of bias.'),
    ('[PROVISIONAL: nine historically excluded reports may meet both full-text outcome requirements and await adjudication by the review team; the counts and estimates above may change.]',
     '[PROVISIONAL: eight historically excluded reports may meet both full-text outcome requirements and await adjudication by the review team, and the risk-of-bias and certainty assessments for Wang 1997, included on 2 November 2026, await second review; the counts and estimates above may change.]'),
],
'methods_REVISED.md': [
    ('All adjudication decisions were made with trial results known.',
     'All adjudication decisions were made with trial results known. One report excluded at full text (Wang 1997 [@inc_wang1997]) was included on 2 November 2026, after a recheck of the outcome exclusions, when the review owner judged that its stimulation met the TEAS definition.'),
    ('with at least one session before 24 hours postoperatively.',
     'with at least one session before 24 hours postoperatively. Surface stimulation of acupoints combined with electrodes beside the incision was classed as TEAS.'),
    ('Study characteristics, stimulation protocols, hospital setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP).',
     'Study characteristics, stimulation protocols, hospital setting, analgesic regimens and the narrative outcome tables were checked by a second reviewer (SKP). [PROVISIONAL: SKP has not yet checked the Wang 1997 extraction, added on 2 November 2026.]'),
    ('Later refits, after the risk-of-bias update and the hold of Lee 2011, were run in R after reproducing the existing estimates.',
     'Later refits, after the risk-of-bias update, the hold of Lee 2011 and the inclusion of Wang 1997, were run in R after reproducing the existing estimates; the refits including Wang 1997 were also reproduced in Stata.'),
    ('Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation, and all were checked and confirmed by a second reviewer (SKP).',
     'Assessments were made by an artificial intelligence (AI) assistant under the review team\'s delegation and checked and confirmed by a second reviewer (SKP). [PROVISIONAL: the assessments for Wang 1997, drafted on 2 November 2026, await this check.]'),
],
'results_REVISED.md': [
    ('Forty reports of 39 trials were included [', 'Forty-one reports of 40 trials were included ['),
    ('@inc_tu2024; @inc_wu2016;', '@inc_tu2024; @inc_wang1997; @inc_wu2016;'),
    ('no 24-hour opioid or pain outcome (113 reports)', 'no 24-hour opioid or pain outcome (112 reports)'),
    ('[PROVISIONAL: A later check of the 113 outcome exclusions found nine reports that may meet both outcome requirements, including one sham-controlled TEAS trial with a 24-hour hydromorphone result and 24-hour pain; 45 could not be re-checked because no full text was held. These await adjudication by the review team, and the counts, estimates and certainty ratings below may change (Additional files 2 and 4).]',
     'A later check of the 113 outcome exclusions found nine reports that may meet both outcome requirements. One of them, Wang 1997, a sham-controlled TEAS trial, was included on 2 November 2026 after the review owner judged its stimulation to be TEAS. [PROVISIONAL: The other eight, and 45 that could not be re-checked because no full text was held, await adjudication by the review team, and the counts, estimates and certainty ratings below may change (Additional files 2 and 4).]'),
    ('on that convention the 39 trials randomised 7,420 participants (7,510 across the 40 reports)',
     'on that convention the 40 trials randomised 7,521 participants (7,611 across the 41 reports)'),
    ('Twenty-six evaluated TEAS, 13 evaluated EA', 'Twenty-seven evaluated TEAS, 13 evaluated EA'),
    ('The remaining seven came from the USA (2), Brazil', 'The remaining eight came from the USA (3), Brazil'),
    ('The median trial randomised 88 participants', 'The median trial randomised 89 participants'),
    ('Thirty-two reports included a sham arm.', 'Thirty-three reports included a sham arm.'),
    ('nine named another hospital', 'ten named another hospital'),
    ('No routine non-opioid component was described in 25 reports', 'No routine non-opioid component was described in 26 reports'),
    ('Thirty-nine reports used at least one of PC6 (29 reports), ST36 (25) or LI4 (23).',
     'Forty reports used at least one of PC6 (29 reports), ST36 (25) or LI4 (24); two TEAS trials combined LI4 with electrodes beside the incision (Szmit 2021, Wang 1997).'),
    ('2/100 Hz in 15 reports', '2/100 Hz in 16 reports'),
    ('Stimulation was given postoperatively only in 12 reports', 'Stimulation was given postoperatively only in 13 reports'),
    ('Although all 40 reports contained postoperative opioid data', 'Although all 41 reports contained postoperative opioid data'),
    ('Ten reports contributed to the broader first-day dose analysis, six to rescue opioid receipt and 11 to nausea and vomiting. Thirty-two reports contributed',
     'Eleven reports contributed to the broader first-day dose analysis, seven to rescue opioid receipt and 12 to nausea and vomiting. Thirty-three reports contributed'),
    ('Of 152 assessed results, two (1%) were at low risk of bias, 108 (71%) had some concerns and 42 (28%) were at high risk (Fig. 3).',
     'Of 162 assessed results, two (1%) were at low risk of bias, 116 (72%) had some concerns and 44 (27%) were at high risk (Fig. 3). [PROVISIONAL: the ten judgements for Wang 1997 are drafts awaiting second review.]'),
    ('Eleven were rated high for outcome measurement, when someone who knew the allocation reported or determined the outcome: self-reported pain or bowel function,',
     'Thirteen were rated high for outcome measurement, when someone who knew the allocation reported or determined the outcome: self-reported pain, nausea or bowel function,'),
    ('Almost every result (149 of 152)', 'Almost every result (159 of 162)'),
    ('Half (75) had some concerns about randomisation', 'Just over half (85) had some concerns about randomisation'),
    ('[PROVISIONAL: one historically excluded sham-controlled TEAS trial could enter this analysis if the review team judges it eligible and its opioid total complete (Additional file 2).]',
     'Wang 1997 did not meet the primary outcome definition: its 24-hour hydromorphone totals did not include intramuscular supplemental opioid, given to 19 of its 101 participants.'),
    ('In a sensitivity analysis of four trials that did not specify rest or movement, the MD was −1.93 points (−3.54 to −0.31; 417 participants; I² = 98%).',
     'In a sensitivity analysis of five trials that did not specify rest or movement, the MD was −1.66 points (−3.03 to −0.29; 492 participants; I² = 98%; prediction interval −4.91 to 1.59).'),
    ('Admitting results with incomplete capture of systemic opioid, six TEAS-versus-sham trials (547 participants) gave an MD of −6.67 mg (−14.53 to 1.18; I² = 99%; prediction interval −25.58 to 12.24; very low certainty) (Fig. 4). Lee 2011 was held from this and all other pooled analyses. Every leave-one-out interval included no difference. The sufentanil conversion bounds gave −4.56 mg (−10.89 to 1.76) and −10.18 mg (−21.99 to 1.62). Excluding the one result at high risk of bias left five trials and 454 participants (−7.91 mg, −17.84 to 2.02).',
     'Admitting results with incomplete capture of systemic opioid, seven TEAS-versus-sham trials (622 participants) gave an MD of −7.22 mg (−14.13 to −0.32; I² = 98%; prediction interval −24.81 to 10.36; very low certainty) (Fig. 4). Lee 2011 was held from this and all other pooled analyses. Without Wang 1997, the estimate was −6.67 mg (−14.53 to 1.18; six trials), and four of the seven leave-one-out intervals included no difference (estimates −5.33 to −8.60 mg). The sufentanil conversion bounds gave −5.14 mg (−11.02 to 0.75) and −10.61 mg (−20.71 to −0.52). Excluding the one result at high risk of bias left six trials and 529 participants (−8.48 mg, −16.64 to −0.32); excluding the two trials whose totals omitted supplemental opioid (Chen 1998 and Wang 1997) gave −5.07 mg (−12.23 to 2.10; five trials). Wang 1997 was the only trial in this analysis that also reported pain at about 24 hours: −15.00 mg (−31.00 to 1.00), with pain −0.35 points (−1.44 to 0.74; rest or movement not stated). Because its total omitted supplemental opioid, this pair does not apply the registered criterion.'),
    ('For EA, a single sham-controlled trial at high risk of bias gave −11.80 mg',
     'Against usual care, two TEAS trials (Szmit 2021 and Wang 1997) gave −17.19 mg (−146.73 to 112.35; 123 participants; I² = 89%; very low certainty). For EA, a single sham-controlled trial at high risk of bias gave −11.80 mg'),
    ('Five TEAS-versus-sham trials, all conducted in China, reported whether participants received rescue opioid (478 participants, 135 events). In this post-hoc exploratory analysis, fewer participants received rescue opioid with TEAS (risk ratio [RR] 0.51, 95% CI 0.35 to 0.75; I² = 0%; low certainty) (Fig. 5). Follow-up was 6–24 hours, through the first postoperative day, 48 hours and 3 days in four trials, and was not stated in one (Yu 2020); the four trials with stated follow-up gave RR 0.49 (0.28 to 0.86). At the observed comparator risk of 37.6%, the pooled ratio corresponds to about 18 fewer participants per 100 receiving rescue opioid (9 to 25 fewer);',
     'Six TEAS-versus-sham trials, five conducted in China and one in the USA, reported whether participants received rescue opioid (553 participants, 147 events). In this post-hoc exploratory analysis, fewer participants received rescue opioid with TEAS (risk ratio [RR] 0.52, 95% CI 0.37 to 0.74; I² = 0%; low certainty) (Fig. 5). Follow-up was 6–24 hours, 24 hours, through the first postoperative day, 48 hours and 3 days in five trials, and was not stated in one (Yu 2020); the five trials with stated follow-up gave RR 0.51 (0.32 to 0.81). At the observed comparator risk of 36.0%, the pooled ratio corresponds to about 17 fewer participants per 100 receiving rescue opioid (10 to 23 fewer);'),
    ('Leave-one-out estimates ranged from 0.49 to 0.52. After excluding the two trials at high risk of bias, the point estimate was unchanged but the interval included no effect (RR 0.51, 0.22 to 1.18; three trials, 243 participants). The two trials with approximately first-day follow-up gave RR 0.43 (0.001 to 164; 201 participants; very low certainty). Assigning rescue opioid to every participant with a missing outcome in the TEAS arm and to none in the sham arm gave RR 0.61 (0.43 to 0.87).',
     'Leave-one-out estimates ranged from 0.51 to 0.53. After excluding the two trials at high risk of bias, the RR was 0.53 (0.30 to 0.95; four trials, 318 participants). The three trials with first-day follow-up gave RR 0.53 (0.12 to 2.42; 276 participants; very low certainty). Assigning rescue opioid to every participant with a missing outcome in the TEAS arm and to none in the sham arm gave RR 0.61 (0.45 to 0.85). Against usual care, Wang 1997 gave RR 0.52 (0.20 to 1.32; 76 participants; very low certainty).'),
    ('the largest broader-dose analysis had six trials', 'the largest broader-dose analysis had seven trials'),
    ('Vomiting was also less frequent (RR 0.55, 0.34 to 0.89; three trials, 1,788 participants; very low certainty).',
     'Vomiting was also less frequent (RR 0.57, 0.40 to 0.81; four trials, 1,863 participants; very low certainty); nausea reported separately did not clearly differ (RR 0.78, 0.22 to 2.78; two trials, 146 participants; very low certainty).'),
],
'discussion_REVISED.md': [
    ('In 40 reports of 39 randomised trials', 'In 41 reports of 40 randomised trials'),
    ('the TEAS-versus-sham estimate (−6.67 mg) remained compatible with no difference (very low certainty).',
     'the TEAS-versus-sham estimate (−7.22 mg) was smaller than the 10 mg threshold; its upper limit (−0.32 mg) only just excluded no difference, and the interval included no difference without Wang 1997 (very low certainty).'),
    ('(nine historically excluded reports awaiting adjudication)', '(eight historically excluded reports awaiting adjudication)'),
    ('All five trials were conducted in China, follow-up ranged', 'Five of the six trials were conducted in China, follow-up ranged'),
    ('Without the two trials at high risk of bias, the interval included no effect (RR 0.51, 0.22 to 1.18).',
     'Without the two trials at high risk of bias, the estimate was similar (RR 0.53, 0.30 to 0.95), but the follow-up periods still differed.'),
    ('All 40 reports contained postoperative opioid data', 'All 41 reports contained postoperative opioid data'),
    ('Trials that randomised 7,420 participants', 'Trials that randomised 7,521 participants'),
    ('near-total heterogeneity (I² = 99%)', 'near-total heterogeneity (I² = 98%)'),
    ('no routine non-opioid component was described in 25.', 'no routine non-opioid component was described in 26.'),
    ('Of 152 assessed results, 28% were at high risk of bias', 'Of 162 assessed results, 27% were at high risk of bias'),
    ('PC6 was stimulated in 29 of the 40 reports.', 'PC6 was stimulated in 29 of the 41 reports.'),
    ('Thirty-three of the 40 reports came from Asia, 25 of them from China, and all five rescue trials were conducted in China.',
     'Thirty-three of the 41 reports came from Asia, 25 of them from China, and five of the six TEAS rescue trials were conducted in China.'),
    ('the broader first-day analysis and pooling rescue receipt over mixed follow-up.',
     'the broader first-day analysis, pooling rescue receipt over mixed follow-up and the inclusion of Wang 1997.'),
    ('a later check found reports whose recorded exclusion reason was not supported and which await adjudication, and 45 excluded reports could not be re-checked.',
     'a later check found reports whose recorded exclusion reason was not supported; one was included and eight await adjudication, and 45 excluded reports could not be re-checked.'),
],
'conclusions_REVISED.md': [
    ('[PROVISIONAL: pending adjudication of nine historically excluded reports.]',
     '[PROVISIONAL: pending adjudication of eight historically excluded reports and second review of the Wang 1997 assessments.]'),
],
'table2_REVISED.md': [
    ('| Broader first-day opioid (post-hoc sensitivity analysis) | TEAS vs sham | 6 (547) | MD −6.67 mg (−14.53 to 1.18) | Very low |',
     '| Broader first-day opioid (post-hoc sensitivity analysis) | TEAS vs sham | 7 (622) | MD −7.22 mg (−14.13 to −0.32) | Very low |\n|  | TEAS vs usual care | 2 (123) | MD −17.19 mg (−146.73 to 112.35) | Very low |'),
    ('| TEAS vs sham | 5 (478) | RR 0.51 (0.35 to 0.75); 18 fewer per 100 (9 to 25 fewer)‡ | Low |',
     '| TEAS vs sham | 6 (553) | RR 0.52 (0.37 to 0.74); 17 fewer per 100 (10 to 23 fewer)‡ | Low |'),
    ('excluding the two trials at high risk of bias gave RR 0.51 (0.22 to 1.18).', 'excluding the two trials at high risk of bias gave RR 0.53 (0.30 to 0.95).'),
    ('(37.6% for rescue, 34.1% for PONV)', '(36.0% for rescue, 34.1% for PONV)'),
    ('[PROVISIONAL: estimates may change after adjudication of nine historically excluded reports.]',
     '[PROVISIONAL: estimates may change after adjudication of eight historically excluded reports; certainty ratings for analyses that include Wang 1997 are drafts awaiting second review.]'),
],
'figures_REVISED.md': [
    ('Reasons are as recorded at screening; a later check found reports in this category with a 24-hour pain or postoperative opioid result, which await adjudication (Additional file 4).',
     'Reasons are as recorded at screening, except for Wang 1997, which was included after a later check; that check found further reports in this category with a 24-hour pain or postoperative opioid result, which await adjudication (Additional file 4).'),
    ('Distribution of judgements by domain across all 152 assessed results.',
     'Distribution of judgements by domain across all 162 assessed results. † Draft judgements for Wang 1997, awaiting second review.'),
    ('Szmit 2021 and Lin 2002 appear twice because their active arms were compared with both sham and usual care.',
     'Szmit 2021, Wang 1997 and Lin 2002 appear twice because their active arms were compared with both sham and usual care. Arrows mark intervals that extend beyond the axis.'),
    ('All five trials were conducted in China. Follow-up was 6–24 hours, through the first postoperative day, 48 hours or 3 days,',
     'Five of the six trials were conducted in China and one in the USA. Follow-up was 6–24 hours, 24 hours, through the first postoperative day, 48 hours or 3 days,'),
],
'table1_legend_REVISED.md': [
    ('N, number randomised (analysed in intervention/control arms as reported).',
     'N, number randomised (analysed in intervention/control arms as reported; Wang 1997, both active arms combined/sham).'),
    ('(Chen 1998: acupoint, sham, non-acupoint and dermatomal arms)',
     '(Chen 1998: acupoint, sham, non-acupoint and dermatomal arms; Wang 1997: PCA only, sham, low and high intensity)'),
],
'additional_files_REVISED.csv': [
    ('characteristics of the 40 reports.', 'characteristics of the 41 reports.'),
],
}

if not SNAP.exists():
    SNAP.mkdir()
    for name in EDITS:
        shutil.copy2(SRC / name, SNAP / name)
for name, edits in EDITS.items():
    p = SRC / name
    s = (SNAP / name).read_text(encoding='utf-8')   # always start from the pre-Wang text
    for old, new in edits:
        assert s.count(old) == 1, (name, old[:70], s.count(old))
        s = s.replace(old, new)
    p.write_text(s, encoding='utf-8')
print(sum(len(e) for e in EDITS.values()), 'replacements in', len(EDITS), 'files')
