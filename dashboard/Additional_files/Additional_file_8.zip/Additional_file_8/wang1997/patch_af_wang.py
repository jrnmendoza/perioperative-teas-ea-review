"""Apply decision D1 (2 Nov 2026: Wang 1997 included as TEAS) to the additional-file builder and the reproduction script.
Starts from the pre-Wang copies in wang1997/pre_wang_snapshot/ and asserts each replaced passage, so it can be re-run.
Writes build_additional_files.py and reproduce/reproduce_final.R in the revision folder."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
SNAP = HERE / 'pre_wang_snapshot'


def patch(src, edits):
    s = src
    for old, new in edits:
        assert s.count(old) == 1, (old[:80], s.count(old))
        s = s.replace(old, new)
    return s


B = [
# ---- shared facts: PRISMA counts with Wang 1997 moved to inclusion; Wang records
("""pc = json.loads((PR / 'prisma_counts.json').read_text())
INCL = rd(C / 'protocol_characteristics.csv')
REPORTS = sorted(INCL.report_id)
assert len(REPORTS) == 40
""",
"""pc = json.loads((REV / 'wang1997/prisma_counts_with_wang1997.json').read_text())  # D1: one outcome exclusion moved to inclusion
INCL = rd(C / 'protocol_characteristics.csv')
REPORTS = sorted(INCL.report_id)
assert len(REPORTS) == 40 and pc['included_reports'] == 41  # the 40 project reports + Wang 1997 (records in wang1997/)
# Decision D1 (2 Nov 2026): the review owner judged Wang 1997 to be TEAS, with its results known. Its extraction, refit,
# RoB 2 and GRADE drafts are in wang1997/; the RoB 2 and GRADE drafts await SKP's second review.
W97 = REV / 'wang1997'
W97_RES = {r['result_id']: r for r in recs(W97 / 'wang1997_results.csv')}
W97_CHAR = {r['field']: r for r in recs(W97 / 'wang1997_characteristics.csv')}
W97_IN = recs(W97 / 'wang1997_analysis_inputs.csv')
W97_MOD = {r['model_id']: r for r in recs(W97 / 'models_with_wang.csv')}
W97_PDF = '10_FINAL_ADJUDICATION/01_SOURCE_EVIDENCE/exclusions/1879897512.pdf'
W97_SHA = '68b137a7876f976afd74bf0620c80d4cda08c8f7de73ae1740309d8b5d3b0d2f'
W97_NOTE = 'Wang 1997, included 2 Nov 2026 (decision D1)'
"""),
# ---- AF1 item 7 (abstract checklist)
("'Yes (Results: 40 reports of 39 trials, 7,420 participants) [PROVISIONAL: membership awaits adjudication of nine reports]'",
 "'Yes (Results: 41 reports of 40 trials, 7,521 participants) [PROVISIONAL: membership awaits adjudication of eight reports]'"),
# ---- AF2 section 6
("""            f'{pc["exclusion_reasons"]["no perioperative analgesia outcome found"]} reports were excluded under it '""",
 """            f'{pc["exclusion_reasons"]["no perioperative analgesia outcome found"]} reports remain excluded under it (113 '
            'before Wang 1997 was included on 2 November 2026) '"""),
("""            'confirmed opioid identity or formulation. The 40 remaining reports form the review. Each excluded report '""",
 """            'confirmed opioid identity or formulation. The 40 remaining reports formed the review until Wang 1997 was '
            'added on 2 November 2026 (below). Each excluded report '"""),
("""            'This triage is not an independent human screen and changes no decision. [PROVISIONAL: the review team must '
            'adjudicate the membership candidates; see AUTHOR_DECISION_SHEET.md and Additional file 4.]')""",
 """            'This triage is not an independent human screen and changed no decision itself. On 2 November 2026, after '
            'reading the report, the review owner judged that the stimulation in Wang 1997 (surface electrodes at LI4 and '
            'beside the incision, as in Szmit 2021) is TEAS, and the trial was included, with its results known. Its '
            '24-hour hydromorphone totals exclude the intramuscular supplemental opioid given to 19 of its 101 participants, '
            'so under the rules in Additional file 6 it enters the broader first-day analysis, not the primary analysis; it '
            'also enters rescue receipt, pain without stated rest or movement, and nausea and vomiting. [PROVISIONAL: the '
            'review team must adjudicate the other eight membership candidates, and SKP has not yet checked the Wang 1997 '
            'extraction or its risk-of-bias and GRADE assessments; see AUTHOR_DECISION_SHEET.md and Additional file 4.]')"""),
("""    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:""",
 """    rows.append(['2 Nov', 'Wang 1997 included as TEAS by the review owner after reading the report, with its results known '
                 '(decision D1). It enters the broader first-day analysis (its totals omit quantified rescue), rescue receipt, '
                 'pain without stated rest or movement, and nausea and vomiting; every affected analysis was refitted in R and '
                 'checked in Stata. RoB 2 and GRADE drafted by the AI assistant; second review pending.', 'Yes'])
    after('8 Oct', ['8 Oct', 'Source triage of the 113 outcome exclusions:"""),
# ---- AF4: Wang 1997 moves from exclusion to inclusion
("""        if fd == 'INCLUDED':
            disp, fig = 'Included', ''""",
 """        if r['covidence_id'] == '1879897512':   # D1, 2 Nov 2026
            assert fd == 'EXCLUDED' and fr == 'no perioperative analgesia outcome found'
            fd, r = 'INCLUDED', dict(r, registry_report='Wang 1997')
            note = ('Excluded at full-text screening (no eligible analgesic outcome); included on 2 Nov 2026 after the '
                    'outcome-exclusion recheck, when the review owner judged its stimulation to be TEAS (results known)')
        if fd == 'INCLUDED':
            disp, fig = 'Included', ''"""),
("    assert sum(x['disp'] == 'Included' for x in rows) == pc['included_reports'] == 40",
 "    assert sum(x['disp'] == 'Included' for x in rows) == pc['included_reports'] == 41"),
("dict(reason='Included', n=40)]", "dict(reason='Included', n=41)]"),
("""    assert len(tri) == 113
""",
 """    assert len(tri) == 113
    for t in tri:
        if t['covidence_id'] == '1879897512':
            assert t['category'] == 'MEMBERSHIP'
            t['category'] = 'MEMBERSHIP: included 2 Nov 2026'
            t['proposed_human_action'] += ' Decided 2 Nov 2026 by the review owner: TEAS; included (broader first-day analysis).'
"""),
# ---- AF6: Wang results in the classification sheets
("""    inv = rd(C / 'all_40_result_inventory.csv')
    allop = [""",
 """    ta.append(dict(body='TEAS vs sham; TEAS vs usual care', report='Wang 1997', result_ids='WANG97-HM24',
                   E1_disposition='NOT ADMITTED: intramuscular supplemental opioid (hydromorphone or meperidine), given to 19 of 101 participants in the first 24 h, is not quantified in the totals',
                   E2_disposition='ADMIT', E2_basis=W97_RES['WANG97-HM24']['classification'], flags='Unquantified rescue (as Chen 1998)',
                   mandatory_sensitivity='Excluded from the analysis without unquantified rescue; leave-one-out', addendum_note=W97_NOTE,
                   now='Included 2 Nov 2026'))
    inv = rd(C / 'all_40_result_inventory.csv')
    allop = ["""),
("""             for r in inv.to_dict('records') if r['family'] in OPIOID_FAMILIES]
""",
 """             for r in inv.to_dict('records') if r['family'] in OPIOID_FAMILIES]
    for rid, fam, mods in (('WANG97-HM24', 'Postoperative opioid consumption', 'E2_opioid24_TEAS_sham (and sensitivity analyses); E2_opioid24_TEAS_usual'),
                           ('WANG97-RESCUE24', 'Rescue opioid use', 'RESCUE_TEAS_SHAM_* ; RESCUE_TEAS_USUAL')):
        w = W97_RES[rid]
        allop.append(dict(result_id=rid, study='Wang 1997', family=fam, outcome=w['outcome'], window=w['window'], unit=w['unit'],
                          comparison='TEAS vs sham; TEAS vs usual care', decision='Include' if rid.endswith('RESCUE24') else 'Admit (broader only)',
                          rationale=w['classification'], models=mods, loc=w['source_location'], quote=w['source_text']))
"""),
("    wb = new_wb(6, 'Classification of every candidate opioid result in the 40 reports against the registered primary '",
 "    wb = new_wb(6, 'Classification of every candidate opioid result in the 41 reports against the registered primary '"),
("                 ('All opioid results', 'Every opioid-related result in the 40 reports, with its disposition in the analyses')],",
 "                 ('All opioid results', 'Every opioid-related result in the 41 reports, with its disposition in the analyses')],"),
# ---- AF6 analysis inputs: Wang rows; two further main-text analyses
("""               'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY']""",
 """               'MOBILISATION24_ZHANG23', 'HARMS_JIANG_ANY', 'nausea24_TEAS_sham', 'RESCUE_TEAS_USUAL']
W97_MAIN = {('E2_opioid24_TEAS_sham', 'sham'): 'WANG97-HM24', ('E2_opioid24_TEAS_usual', 'usual care'): 'WANG97-HM24',
            ('RESCUE_TEAS_SHAM_ANY_FOLLOWUP', 'sham'): 'WANG97-RESCUE24', ('RESCUE_TEAS_USUAL', 'usual care'): 'WANG97-RESCUE24',
            ('pain24_unclassified_TEAS_sham', 'sham'): 'WANG97-VAS24', ('nausea24_TEAS_sham', 'sham'): 'WANG97-NAUSEA24',
            ('vomiting24_TEAS_sham', 'sham'): 'WANG97-VOMIT24'}"""),
("""    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(), sorted(set(MAIN_MODELS) - {o['analysis'] for o in out})""",
 """    arm = {'sham': 'sham', 'usual care': 'PCA only'}
    for (m, comp), rid in W97_MAIN.items():   # D1, 2 Nov 2026: values as reported (Wang 1997 Tables 3, 5, 6) and as modelled
        w, x = W97_RES[rid], next(i for i in W97_IN if i['result_id'] == rid and i['comparator'] == comp)
        ctrl = w['arm_II_sham'] if comp == 'sham' else w['arm_I_pca_only']
        mv = (f"{x['events_i']}/{x['n_i']} vs {x['events_c']}/{x['n_c']}" if x['events_i'] not in ('', 'NA') else
              f"{num(x['mean_i'], 2)} ({num(x['sd_i'], 2)}), n {x['n_i']} vs {num(x['mean_c'], 2)} ({num(x['sd_c'], 2)}), n {x['n_c']}")
        out.append(dict(analysis=m, report='Wang 1997', result_id=rid, outcome=w['outcome'], window=w['window'], raw_unit=w['unit'],
                        raw_values=f"low {w['arm_III_low']}; high {w['arm_IV_high']} (combined) vs {arm[comp]} {ctrl}",
                        factor=x['factor'] if x['factor'] not in ('', 'NA') else '', model_values=mv, yi=num(x['yi'], 4), vi=num(x['vi'], 5),
                        source_location=w['source_location'], source_quote=w['source_text'], source_sha256=W97_SHA[:16]))
    assert {o['analysis'] for o in out} == set(MAIN_MODELS) - set(), sorted(set(MAIN_MODELS) - {o['analysis'] for o in out})"""),
# ---- AF7: hydromorphone factor applied to Wang 1997
("""    applied = [dict(e, models='; '.join(sorted(set(e['models'])))) for e in app.values()]""",
 """    app[('Wang 1997', 'WANG97-HM24', '5')] = dict(study='Wang 1997', result_id='WANG97-HM24', factor=5, unit='mg hydromorphone',
                                                 models=['E2_opioid24_TEAS_sham and its sensitivity analyses', 'E2_opioid24_TEAS_usual'])
    applied = [dict(e, models='; '.join(sorted(set(e['models'])))) for e in app.values()]"""),
# ---- AF8: Wang 1997 characteristics row and effect directions
("""        r['comp_desc'] = T1COMP[k]
        rows.append(r)
""",
 """        r['comp_desc'] = T1COMP[k]
        rows.append(r)
    wc = {k: v['value'] for k, v in W97_CHAR.items()}
    rows.append(dict(report_id='Wang 1997', year='1997', trial_family='Wang 1997', country='USA', s_setting='Named hospital, level not stated',
                     s_setting_quote='101 ASA physical status I-II gynecological patients scheduled to undergo elective lower abdominal surgery were studied at Cedars-Sinai Medical Center in Los Angeles, CA.',
                     s_setting_page='407', modality='TEAS', comparator='Sham TAES (no current); PCA only', comparator_class='Sham; usual care',
                     comp_desc=T1COMP['Wang 1997'], randomized_n='101', analysed_n='101 (PCA only 26, sham 25, low 25, high 25)',
                     anaesthesia=wc['anaesthesia'], surgical_category='Gynecologic & Breast', procedure='Elective lower abdominal gynaecological surgery',
                     age='Mean 44, 44, 45, 43 y (PCA only, sham, low, high)', female='100%', bmi='Not extracted', asa='I–II',
                     intervention_arms='Low-intensity TAES 4–5 mA (25); high-intensity TAES 9–12 mA (25)',
                     control_arms='Sham TAES, no current (25); PCA only (26)', acupoints=wc['intervention'],
                     frequency='2/100 Hz, alternating every 3 s; hand and incision alternated every 6 s', intensity='4–5 mA or 9–12 mA',
                     timing=wc['timing'], sessions='30 min every 2 h while awake', session_duration='30 min',
                     cumulative_duration='Until PCA stopped (TAES used for 35, 36 and 29 h in arms II–IV; Table 4)',
                     m_timing_before24_category='Postoperative only', m_planned_active_minutes_before24='Not determinable from current source schedule',
                     m_before24_coding_note='Sessions while awake; planned schedule, not measured adherence.',
                     postoperative_analgesia=wc['postoperative_analgesia'],
                     pca_regimen='Hydromorphone 0.2 mg (>55 y) or 0.4 mg bolus on demand, lockout 10 min',
                     rescue_analgesia='IM hydromorphone 0.5–1 mg or meperidine 25–50 mg if PCA relief inadequate',
                     s_mma_all_groups='No', s_non_opioid_components='None routine during PCA (oral analgesics on demand only after PCA)',
                     s_mma_quote='After discontinuation of PCA, oral pain medications were administered on demand.', s_mma_page='406',
                     s_note=W97_NOTE + '; AI extraction, check by SKP pending', s_source_pdf=W97_PDF, sha=W97_SHA))
"""),
("""    for e in eff:
        for x in ('effect', 'ci_low', 'ci_high'):""",
 """    for m, comp in (('E2_opioid24_TEAS_sham', 'sham'), ('E2_opioid24_TEAS_usual', 'usual care')):
        x = next(i for i in W97_IN if i['result_id'] == 'WANG97-HM24' and i['comparator'] == comp)
        y, se = float(x['yi']), float(x['vi']) ** 0.5
        eff.append(dict(model_id=m, study='Wang 1997', modality='TEAS', timing='Postoperative only',
                        minutes_before24='Not determinable from current source schedule', frequency='2/100 Hz, alternating every 3 s',
                        intensity='4–5 mA or 9–12 mA (arms combined)', effect=y, ci_low=y - 1.959964 * se, ci_high=y + 1.959964 * se,
                        descriptive_direction='Lower point estimate',
                        limitation='Added 2 Nov 2026 (decision D1). PCA total omits IM supplemental opioid. Descriptive association only; shared-arm comparisons must not be counted independently.'))
    for e in eff:
        for x in ('effect', 'ci_low', 'ci_high'):"""),
("""    wb = new_wb(8, ['Study, participant, analgesic-regimen and stimulation-protocol characteristics of the 40 included reports, '""",
 """    wb = new_wb(8, ['Study, participant, analgesic-regimen and stimulation-protocol characteristics of the 41 included reports, '"""),
("""                 'Zhou 2021 analgesia corrected on 24 Oct 2026: all included patients had epidural-assisted general anaesthesia.',""",
 """                 'Zhou 2021 analgesia corrected on 24 Oct 2026: all included patients had epidural-assisted general anaesthesia.',
                 'Wang 1997 was added on 2 Nov 2026 (decision D1); its characteristics were extracted by the AI assistant and have not yet been checked by SKP.',"""),
# ---- AF10: Wang 1997 RoB 2 drafts
("""    assert len(units) == 152, len(units)
    for rv in recs(C / 'rob2_revisions_2026-10-24.csv'):""",
 """    assert len(units) == 152, len(units)
    for s in recs(W97 / 'wang1997_rob2_DRAFT.csv'):   # D1, 2 Nov 2026: AI drafts; second review pending
        add(s['assessment_id'], s['study'], s, s['analyses'], s['outcome'], s['window'], s['comparison'], s['assessment_id'],
            s['decision_status'], rationale(s))
    assert len(units) == 162, len(units)
    for rv in recs(C / 'rob2_revisions_2026-10-24.csv'):"""),
("    fig = {r['domain']: r for r in recs(FA / 'rob_domain_summary_2026-10-23.csv')}",
 "    fig = {r['domain']: r for r in recs(W97 / 'rob_domain_summary_2026-10-23.csv')}   # Fig. 3 rebuilt with Wang 1997"),
("reason='Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years); not counted among the 152.'))",
 "reason='Held from all pooled analyses since 23 Oct 2026 (participants aged 14–59 years); not counted among the 162.'))"),
("""    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 152 results used in the analyses, with the rationale for each '""",
 """    wb = new_wb(10, ['Result-specific RoB 2 judgements for all 162 results used in the analyses, with the rationale for each '"""),
("""                     'Assessments were made by an AI assistant under the review team\\'s delegation, and each was checked and '
                     'confirmed by a second reviewer (SKP); a check is not an independent duplicate assessment.'],""",
 """                     'Assessments were made by an AI assistant under the review team\\'s delegation, and each was checked and '
                     'confirmed by a second reviewer (SKP); a check is not an independent duplicate assessment. The exception is '
                     'the ten assessments for Wang 1997 (included 2 Nov 2026), which are drafts awaiting second review.'],"""),
("                 [('Judgements', 'One row per assessed result (152), with domain judgements and rationales'),",
 "                 [('Judgements', 'One row per assessed result (162), with domain judgements and rationales'),"),
("                  ('Signalling questions', f'Signalling responses recorded for {n_with} of the 152 results'),",
 "                  ('Signalling questions', f'Signalling responses recorded for {n_with} of the 162 results'),"),
# ---- AF11: GRADE drafts for the bodies Wang 1997 enters
("""    wb = new_wb(11, ['GRADE evidence profiles for each outcome and comparison, with the reasons for downgrading.',""",
 """    wdr = [dict(model=g['model_id'], k=g['k'], n=g['N'], eff=num(g['effect'], 2), lo=num(g['ci_low'], 2), hi=num(g['ci_high'], 2),
                cert=g['certainty'], rd=g['rob'], idn=g['inc'], nd=g['ind'], md=g['imp'], pd=g['pub'], prev=g['previous'], reason=g['reason'],
                status=g['status']) for g in recs(W97 / 'wang1997_grade_DRAFT.csv')]
    wb = new_wb(11, ['GRADE evidence profiles for each outcome and comparison, with the reasons for downgrading.',"""),
("""                  ('Other outcomes', 'Pain, nausea and vomiting, recovery, gastrointestinal and other outcomes, including empty comparisons')],""",
 """                  ('Other outcomes', 'Pain, nausea and vomiting, recovery, gastrointestinal and other outcomes, including empty comparisons'),
                  ('With Wang 1997 (draft)', 'Profiles for the bodies of evidence that Wang 1997 enters (included 2 Nov 2026); AI drafts awaiting second review. They supersede the corresponding rows in the other sheets once confirmed.')],"""),
("""    return save(wb, 11, '.xlsx')""",
 """    sheet(wb, 'With Wang 1997 (draft)', wdr, [('model', 'Analysis', 30), ('k', 'Trials', 7), ('n', 'Participants', 10), ('eff', 'Effect', 8),
                                              ('lo', '95% CI low', 9), ('hi', '95% CI high', 9), ('cert', 'Certainty (draft)', 14)] + dn +
          [('prev', 'Previous certainty', 30), ('reason', 'Reasons', 60), ('status', 'Assessor and second review', 50)])
    return save(wb, 11, '.xlsx')"""),
# ---- AF12: analyses refitted with Wang 1997
("            row['note'] = 'Superseded: identical to the main broader first-day analysis after the Lee 2011 hold'",
 "            row['note'] = 'Superseded: identical to the main broader first-day analysis after the Lee 2011 hold, before Wang 1997 was added (2 Nov 2026)'"),
("""        if 'Lee 2011' in row['reports'] and not row['note']:
            raise AssertionError(m)""",
 """        if m in W97_MOD:   # D1, 2 Nov 2026: refitted with Wang 1997 (wang1997/refit_with_wang.R)
            x = W97_MOD[m]
            row.update(k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'], pil=x['pi_low'], pih=x['pi_high'],
                       tau2=x['tau2'], i2=x['I2'], reports=x['reports'],
                       note=(row['note'] + '; ' if row['note'] else '') + ('Refitted with Wang 1997 (included 2 Nov 2026)' if 'Wang 1997' in x['reports']
                                                                          else 'Unchanged: Wang 1997 excluded by this analysis\\'s rule'))
            for c in ('pil', 'pih', 'tau2', 'i2'):
                row[c] = '' if row[c] == 'NA' else row[c]
        if 'Lee 2011' in row['reports'] and not row['note']:
            raise AssertionError(m)"""),
("""    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']
    assert (main['k'], main['n'], main['eff'], main['lo'], main['hi']) == ('6', '547', -6.673, -14.529, 1.184), main""",
 """    for m in ('E2_TEAS_sham_LOO_Wang_1997', 'E2_WANG_1997_SHAM_SINGLE', 'RESCUE_LOO_Wang_1997', 'RESCUE_TEAS_USUAL'):
        x = W97_MOD[m]
        row = dict(model=m, family='Broader first-day opioid' if m.startswith('E2') else 'Rescue opioid receipt', analysis=x['description'],
                   measure='MD' if m.startswith('E2') else 'RR', k=x['k'], n=x['N'], eff=x['effect'], lo=x['ci_low'], hi=x['ci_high'],
                   pil=x['pi_low'], pih=x['pi_high'], tau2=x['tau2'], i2=x['I2'], reports=x['reports'], status='REML + Hartung-Knapp (floored at 1)',
                   post_hoc='Yes', role='Added 2 Nov 2026', note='Added with Wang 1997 (decision D1)')
        for c, dp in (('eff', 3), ('lo', 3), ('hi', 3), ('pil', 3), ('pih', 3), ('tau2', 4), ('i2', 1)):
            row[c] = '' if row[c] == 'NA' else num(row[c], dp)
        op.append(row)
    main = {r['model']: r for r in op}['E2_opioid24_TEAS_sham']
    assert (main['k'], main['n'], main['eff'], main['lo'], main['hi']) == ('7', '622', -7.221, -14.126, -0.316), main"""),
("""        oth.append(dict(model=r['model_id'], label=r['label'], role=r['role'].title(), family=r['family'], measure=r['measure'], unit=r['unit'],
                        k=r['k'], n=r['N'], eff=num(r['effect']), lo=num(r['ci_low']), hi=num(r['ci_high']), pil=num(r['pi_low']),
                        pih=num(r['pi_high']), tau2=num(r['tau2'], 4), i2=num(r['I2'], 1), status=r['status'], reports=r['reports'],
                        parent=r['parent_model_id'], basis=r['basis'], note=r['note']))""",
 """        r = dict(r)
        if r['model_id'] in W97_MOD:   # D1, 2 Nov 2026
            x = W97_MOD[r['model_id']]
            r.update(k=x['k'], N=x['N'], effect=x['effect'], ci_low=x['ci_low'], ci_high=x['ci_high'], pi_low=x['pi_low'].replace('NA', ''),
                     pi_high=x['pi_high'].replace('NA', ''), tau2=x['tau2'].replace('NA', ''), I2=x['I2'].replace('NA', ''),
                     reports=x['reports'].replace('; ', ';'), note=(r['note'] + ' ' if r['note'] else '') + 'Refitted with Wang 1997 (included 2 Nov 2026).')
        oth.append(dict(model=r['model_id'], label=r['label'], role=r['role'].title(), family=r['family'], measure=r['measure'], unit=r['unit'],
                        k=r['k'], n=r['N'], eff=num(r['effect']), lo=num(r['ci_low']), hi=num(r['ci_high']), pil=num(r['pi_low']),
                        pih=num(r['pi_high']), tau2=num(r['tau2'], 4), i2=num(r['I2'], 1), status=r['status'], reports=r['reports'],
                        parent=r['parent_model_id'], basis=r['basis'], note=r['note']))
    for m, lab, fam, meas, unit in (('pain24_unclassified_TEAS_usual', 'Pain at 24 h, rest or movement not stated, TEAS vs usual care', 'pain', 'MD', 'points (0-10)'),
                                    ('nausea24_TEAS_usual', 'Nausea 0-24 h, TEAS vs usual care', 'nausea', 'RR', 'risk ratio'),
                                    ('pain24_WANG_1997_SHAM_SINGLE', 'Wang 1997 pain at 24 h vs sham (paired with its broader dose result)', 'pain', 'MD', 'points (0-10)')):
        x = W97_MOD[m]
        oth.append(dict(model=m, label=lab, role='Sensitivity' if 'pain' in m else 'Additional', family=fam, measure=meas, unit=unit, k=x['k'],
                        n=x['N'], eff=num(x['effect']), lo=num(x['ci_low']), hi=num(x['ci_high']), pil='', pih='', tau2='', i2='',
                        status='Single trial, normal interval', reports=x['reports'], parent='', basis='Wang 1997 (included 2 Nov 2026)',
                        note='Added with Wang 1997 (decision D1)'))"""),
("""    miss = recs(R / 'missing_outcome_assumptions.csv')""",
 """    miss = recs(R / 'missing_outcome_assumptions.csv')
    for sc in ('NONE', 'ALL', 'UNFAVOURABLE_TO_TEAS', 'FAVOURABLE_TO_TEAS'):   # Wang 1997: all randomised analysed, nothing to assign
        miss.append(dict(scenario=sc, report='Wang 1997', observed_n_i='50', observed_n_c='25', randomized_n_i='50', randomized_n_c='25',
                         missing_i='0', missing_c='0', imputed_events_i='0', imputed_events_c='0',
                         assumption='No missing outcomes; observed values used in every scenario (added 2 Nov 2026)'))"""),
("""                  'Missing-outcome scenarios are hypothetical: missing outcomes were not measured, and the scenarios do not recover them.'])""",
 """                  'Missing-outcome scenarios are hypothetical: missing outcomes were not measured, and the scenarios do not recover them.',
                  'Wang 1997 was included on 2 Nov 2026 (decision D1). Every analysis it enters was refitted (Note column); without it, '
                  'the broader first-day TEAS-versus-sham estimate is the earlier one (E2_TEAS_sham_LOO_Wang_1997).'])"""),
# ---- AF9: Wang records, refit script and archived refit
("""    'figures': [HERE / 'figures/manuscript_figures_REVISED_2026-11-02.do'],""",
 """    'figures': [HERE / 'figures/manuscript_figures_REVISED_2026-11-02.do', HERE / 'figures/Fig2_source_contribution_map.csv'],
    'wang1997': [W97 / f for f in ('wang1997_results.csv', 'wang1997_characteristics.csv', 'wang1997_analysis_inputs.csv',
                                   'wang1997_rob2_DRAFT.csv', 'wang1997_grade_DRAFT.csv', 'rob_domain_summary_2026-10-23.csv',
                                   'rob_key_analyses_2026-10-23.csv', 'prisma_counts_with_wang1997.json', 'stata_figures_with_wang1997.log',
                                   'apply_wang_text.py', 'patch_af_wang.py')],"""),
("""                     HERE / 'reproduce/reproduced_final_estimates.csv',""",
 """                     HERE / 'reproduce/reproduced_final_estimates.csv', W97 / 'models_with_wang.csv',"""),
("""        z.write(HERE / 'reproduce/reproduce_final.R', 'Additional_file_9/reproduce_final.R')""",
 """        z.write(HERE / 'reproduce/reproduce_final.R', 'Additional_file_9/reproduce_final.R')
        z.write(W97 / 'refit_with_wang.R', 'Additional_file_9/refit_with_wang.R')"""),
("""              'Expected output ends: "Reproduction passed." A passing run shows that the estimates follow from these inputs; it '""",
 """              'It then runs `refit_with_wang.R`, which adds Wang 1997 (included 2 November 2026) to every analysis it enters, '
              'and compares the result with `data/results/models_with_wang.csv`. '
              'Expected output ends: "Reproduction passed." A passing run shows that the estimates follow from these inputs; it '"""),
]

R = [
("""cat(sprintf("Broader first-day TEAS vs sham without Lee 2011: k = %d""",
 """cat(sprintf("Broader first-day TEAS vs sham without Lee 2011 (archived, before Wang 1997): k = %d"""),
("""# Lee 2011 is held from all pooled analyses (23 Oct 2026): broader first-day models are refitted without it and
# compared with data/results/lee_hold_rerun_2026-10-23.csv.""",
 """# Lee 2011 is held from all pooled analyses (23 Oct 2026): broader first-day models are refitted without it and
# compared with data/results/lee_hold_rerun_2026-10-23.csv. Wang 1997 was included on 2 Nov 2026: refit_with_wang.R
# refits every analysis it enters, and the result is compared with data/results/models_with_wang.csv."""),
("""res <- do.call(rbind, out)
write.csv(res, file.path(here, "reproduced_final_estimates.csv"), row.names = FALSE)""",
 """res <- do.call(rbind, out)
write.csv(res, file.path(here, "reproduced_final_estimates.csv"), row.names = FALSE)
# 4. Analyses with Wang 1997 (decision D1, 2 Nov 2026): rerun refit_with_wang.R and compare with the archived refit
if (file.exists(file.path(here, "refit_with_wang.R")) && file.exists(file.path(here, "data", "results", "models_with_wang.csv"))) {
  wenv <- new.env(); invisible(capture.output(sys.source(file.path(here, "refit_with_wang.R"), envir = wenv)))
  wa <- rd("data/results/models_with_wang.csv"); wn <- wenv$o
  stopifnot(identical(wa$model_id, wn$model_id))
  wd <- max(abs(c(num(wa$effect) - wn$effect, num(wa$ci_low) - wn$ci_low, num(wa$ci_high) - wn$ci_high)))
  cat(sprintf("Refitted %d analyses with Wang 1997; maximum absolute difference from the archived refit %.2e\\n", nrow(wn), wd))
  w1 <- wn[wn$model_id == "E2_opioid24_TEAS_sham", ]
  cat(sprintf("Broader first-day TEAS vs sham with Wang 1997: k = %d, MD %.2f (%.2f to %.2f)\\n", w1$k, w1$effect, w1$ci_low, w1$ci_high))
  if (wd > 1e-9) stop("Wang 1997 refit differs from the archived refit")
}"""),
]

(REV / 'build_additional_files.py').write_text(patch((SNAP / 'build_additional_files.py').read_text(), B))
(REV / 'reproduce/reproduce_final.R').write_text(patch((SNAP / 'reproduce_final.R').read_text(), R))
print(len(B), 'builder edits;', len(R), 'reproduction-script edits')
